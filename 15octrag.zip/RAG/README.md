﻿# RAG → Oracle SQL (End-to-End)

Natural-language → validated Oracle `SELECT`, with retrieval, LLM generation, safety checks, and execution — plus a Streamlit UI.

---

## ✨ Highlights

* **Zero-guess** metadata: actual Oracle schema (tables, columns, comments) + **2 example rows per table**.
* **Three-tier embeddings**: table / column / example rows → FAISS.
* **Retriever** returns **allowlisted** ATS tables + true date columns.
* **LLM generation (Mistral 7B via Ollama)** with a **strict JSON contract**.
* **Guardrails**: no DML/DDL/PL/JSON-agg, owner/table/column allowlist, date binds, Oracleisms enforced.
* **Executor**: Oracle-aware binds, `NLS_DATE_FORMAT`, timeouts, preview rows, clean shutdown.
* **Streamlit app**: run E2E, watch context, SQL, repairs, logs, and results; download CSV/XLSX.

---

## 🗂️ Project Structure

```
src/
  crawler.py                     # crawl Oracle schema + examples
  preprocess_tables.py           # filter down to a focused subset
  vectorize.py                   # enrich + embed to FAISS
  retriever.py                   # ANN retrieval → TableContext[]
  sql_generator.py               # prompt → LLM → robust JSON → validate → repair
  executor.py                    # safe SELECT execution with bind normalization
  app.py                         # Streamlit dashboard

  db_conn.py                     # db_session context manager

  utils/
    llm_client.py                # langchain_ollama client wrapper
    prompting.py                 # prompt builder + robust parse_llm_json()
    validators.py                # SQL guardrails (owner/table/columns, JSON agg ban, etc.)
    sql_exec_utils.py            # execution helpers (binds, rewrites, errors)
```

Artifacts:

```
data/
  oracle_schema/
    ats_schema_metadata.json
    ats_schema_metadata.filtered.json
    ats_schema_metadata.filtered.enriched.json
  faiss_oracle/
    index.faiss
    index.pkl

Stats/
  selection_stats/               # filtering metrics
```

---

## 🧰 Requirements

* Python 3.10+
* Oracle client: `python -m pip install oracledb`
* Vector & LLM:

  * `faiss-cpu`
  * `sentence-transformers`
  * `langchain>=0.3`
  * `langchain-ollama`
* UI: `streamlit`, `pandas`, `openpyxl` (for XLSX export)
* Ollama (local): `mistral:7b-instruct`

Recommended install:

```bash
python -m venv doc-rag
# Windows
doc-rag\Scripts\activate
# macOS/Linux
source doc-rag/bin/activate

pip install -U oracledb faiss-cpu sentence-transformers langchain langchain-ollama streamlit pandas openpyxl
```

Ollama:

```bash
# Install Ollama from https://ollama.ai
ollama pull mistral:7b-instruct
ollama serve   # keep running in another terminal
```

---

## 🔑 Configuration

You can pass Oracle credentials via CLI or environment:

```bash
set ORACLE_USER=ATS
set ORACLE_PASSWORD=ABC
set ORACLE_DSN=192.168.36.227:1521/DEVDB
```

(Use `export` on macOS/Linux.)

---

## 🚦 End-to-End Flow

1. **Crawl schema (with 2 example rows per table)**

```bash
python crawler.py --owner ATS --out data/oracle_schema/ats_schema_metadata.json --examples
```

2. **Preprocess (filter set + stats)**

```bash
python preprocess_tables.py \
  --in  data/oracle_schema/ats_schema_metadata.json \
  --out data/oracle_schema/ats_schema_metadata.filtered.json \
  --stats_dir Stats/selection_stats
```

3. **Vectorize (auto-enrich + embed to FAISS)**

```bash
python vectorize.py \
  --metadata data/oracle_schema/ats_schema_metadata.json \
  --owner ATS \
  --auto-enrich \
  --oracle-user ATS --oracle-password ABC --oracle-dsn 192.168.36.227:1521/DEVDB \
  --persist_dir ./data/faiss_oracle --reset --samples
```

4. **Retriever smoke test**

```bash
python retriever.py
# Prints top tables per test query with date columns & top chunk types/scores
```

5. **Generate SQL only**

```bash
python sql_generator.py \
  --query "daily trades by instrument between dates" \
  --persist_dir ./data/faiss_oracle \
  --metadata ./data/oracle_schema/ats_schema_metadata.json \
  --owner ATS --model mistral:7b-instruct
```

6. **End-to-end: generate → validate → execute**

```bash
python executor.py \
  --query "daily trades by instrument between dates" \
  --bind from_date=2025-07-01 \
  --bind to_date="2025-12-31 23:59:59" \
  --bind limit=50 \
  --owner ATS \
  --persist_dir ./data/faiss_oracle \
  --metadata ./data/oracle_schema/ats_schema_metadata.json \
  --model mistral:7b-instruct \
  --oracle_user ATS --oracle_password ABC --oracle_dsn 192.168.36.227:1521/DEVDB \
  --preview 20
```

7. **Streamlit app**

```bash
streamlit run app.py
```

UI note (Streamlit ≥ 1.40): replace `use_container_width=True/False` with `width='stretch'/'content'`.

---

## 🧱 Components (What they do)

### `crawler.py`

* Reads Oracle data dictionary for `--owner`.
* Collects: table/column metadata (+ comments).
* Adds `examples`: two random rows per table, excluding heavy types, ISO string dates.
* Output: `ats_schema_metadata.json`.

### `preprocess_tables.py`

* Filters full schema to relevant tables (keep/candidate/omitted stats).
* Output: `ats_schema_metadata.filtered.json` + stats.

### `vectorize.py`

* Auto-enriches (PK/FK/index/date-like/minmax/last_analyzed) using live DB.
* Embeds **table / column / example** chunks → FAISS.
* `--reset` to rebuild index cleanly.

### `retriever.py`

* ANN search over FAISS, aggregate by table.
* Hydrate exact columns from JSON; extract date columns.
* Returns `TableContext[]` and allowlist owners/tables for generator.

### `sql_generator.py` (+ `utils/prompting.py`, `utils/llm_client.py`, `utils/validators.py`)

* Build a strict prompt with **only** allowlisted tables/columns; daily/top-N hints; date binds.
* LLM → **strict JSON** (`sql`, `bind_params`, `rationale`).
* **Robust JSON parser** (fences, concatenation, illegal escapes, trailing commas) with one **formatting retry**.
* **Auto-fix** missing CTE column lists.
* **Validate** (SELECT only, owner/table/column allowlist, require date binds/columns, no JSON aggregation, no `LIMIT`).
* **Repair loop** (≤3 attempts) guided by explicit validator failures.
* Returns validated SQL + bind hints + tables used + rationale.

### `executor.py` (+ `utils/sql_exec_utils.py`)

* Strips comments (unless `--allow_hints`), enforces **owner + table allowlist**.
* Finds bind names in SQL; **normalizes** values (DATE, INT?, timestamp strings).
* Sets `NLS_DATE_FORMAT`; uses `callTimeout`, `arraysize/prefetchrows`.
* Executes and **materializes preview rows** while connection is open (fixes `DPY-1001`).
* Rewrites `FETCH FIRST :limit` to `ROWNUM` on older DBs if needed.
* Prints columns + preview rows + diagnostics.

---

## 🧪 Example Queries

* “daily trades by instrument between dates”
* “top 10 biggest trades by volume this month”
* “smallest trade by value per symbol”
* “orders with order date and trade date columns”

The generator:

* Uses `TRUNC(ENTRY_DATETIME)` if you say “daily”.
* Uses `ORDER BY … FETCH FIRST :limit ROWS ONLY` for top-N.
* Avoids `ROW_NUMBER() … WHERE rank <= :limit` unless needed.

---

## 🛡️ Guardrails Recap

* **No DML/DDL/PL/JSON-agg** (`INSERT/UPDATE/.../JSON_OBJECT/JSON_ARRAYAGG/...`).
* **Owner/table allowlist** from retriever (e.g., ATS only).
* **Column allowlist** via alias map from FROM/JOIN clauses.
* **Datey** queries require `:from_date` & `:to_date` **and** a real date column predicate.
* **Oracleisms**: no MySQL `LIMIT`; prefer 12c `FETCH FIRST`; fallback to `ROWNUM`.
* **CTE**: auto-inject column alias lists to satisfy Oracle’s stricter parser.

---

## 🧯 Troubleshooting

**Malformed JSON from LLM**
Fixed by robust parser + one formatting retry. If it persists, check Ollama logs and network/proxy.

**ORA-00904 (invalid identifier)**
The validator will print which `alias.column` is invalid and where. Usually a hallucinated column—retriever columns are the source of truth; repair loop uses the error to correct.

**ORA-00928 (missing SELECT)**
Model stopped after `WITH`. Repair loop instructs to append a final `SELECT`; autofixer adds CTE column lists.

**DPY-1001 (not connected)**
Executor now fetches preview rows **before** closing the connection.

**Always getting `SUM(...)`**
Prompt discourages aggregation unless asked. If user says “top/biggest/smallest”, the system steers toward `ORDER BY + FETCH FIRST` instead of SUM unless explicitly requested.

---

## ✅ Quick Sanity Checklist

* [ ] `crawler.py --examples` produced JSON with `columns` + `examples`.
* [ ] `preprocess_tables.py` wrote `.filtered.json` + stats.
* [ ] `vectorize.py --auto-enrich --samples` built FAISS and `.enriched.json`.
* [ ] `retriever.py` shows relevant tables & date columns.
* [ ] `sql_generator.py` outputs **validated** SQL and bind hints.
* [ ] `executor.py` prints columns + preview rows without errors.
* [ ] `app.py` drives the whole pipeline and exports CSV/XLSX.

---

## 🧭 Command Reference

**Crawl**

```bash
python crawler.py --owner ATS --out data/oracle_schema/ats_schema_metadata.json --examples
```

**Preprocess**

```bash
python preprocess_tables.py --in data/oracle_schema/ats_schema_metadata.json \
  --out data/oracle_schema/ats_schema_metadata.filtered.json --stats_dir Stats/selection_stats
```

**Vectorize**

```bash
python vectorize.py --metadata data/oracle_schema/ats_schema_metadata.json \
  --owner ATS --auto-enrich \
  --oracle-user ATS --oracle-password ABC --oracle-dsn 192.168.36.227:1521/DEVDB \
  --persist_dir ./data/faiss_oracle --reset --samples
```

**Generate SQL**

```bash
python sql_generator.py --query "top 10 biggest trades by volume" \
  --persist_dir ./data/faiss_oracle --metadata ./data/oracle_schema/ats_schema_metadata.json \
  --owner ATS --model mistral:7b-instruct
```

**Execute E2E**

```bash
python executor.py --query "daily trades by instrument between dates" \
  --bind from_date=2025-07-01 --bind to_date="2025-12-31 23:59:59" --bind limit=50 \
  --owner ATS --persist_dir ./data/faiss_oracle \
  --metadata ./data/oracle_schema/ats_schema_metadata.json \
  --model mistral:7b-instruct \
  --oracle_user ATS --oracle_password ABC --oracle_dsn 192.168.36.227:1521/DEVDB \
  --preview 20
```

**Run UI**

```bash
streamlit run app.py
```

---

## 🗺️ TODOs / Roadmap

**Core**

* [ ] Add **EXPLAIN PLAN** precheck with cost threshold gate before execution.
* [ ] Cache `(query → SQL)` pairs for repeated requests.
* [ ] Add **relative date** parsing (e.g., “last week”) → bind normalization.
* [ ] Optional: allow safe **read-only views** outside ATS (configurable).

**Retrieval**

* [ ] FK graph-based **join suggestion** bias for multi-table tasks.
* [ ] Dynamic `mmr` toggle via UI; compare recall vs. diversity per query.

**Generator**

* [ ] Few-shot exemplars for **common query templates** (daily rollups, top-N, per-symbol stats).
* [ ] Structured **join patterns** guide (prefer PK→FK; avoid cartesian).
* [ ] Add a classifier to route “aggregation” vs “row listing” prompts.

**Executor / Results**

* [ ] Streaming to disk (CSV) for large row sets with progress bar.
* [ ] Optional `LIMIT` emulation for pre-12c DBs without `FETCH FIRST`.

**UI**

* [ ] Side-by-side **diffs** between initial SQL and repaired SQL.
* [ ] Toggle to show **retrieved example rows** used in embeddings.
* [ ] Saved query history + one-click re-run.
* [ ] Multi-export (CSV/XLSX/Parquet) + schema-aware formatting.

**Ops**

* [ ] CI smoke tests with **golden queries** and expected SQL shapes.
* [ ] Telemetry: generation time, repair counts, validation failure taxonomy.

