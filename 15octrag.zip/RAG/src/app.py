# app.py
from __future__ import annotations
import os
import json
import logging
from typing import Dict, Any, List

import streamlit as st
import pandas as pd

# pipeline modules
from retriever import SchemaRetriever
from sql_generator import SQLGenerator
from executor import SQLExecutor, ExecRequest
from utils.ui_helper import StreamlitLogHandler, df_to_csv_bytes

st.set_page_config(page_title="RAG → SQL → Oracle", layout="wide")

# --------------------------
# Sidebar configuration
# --------------------------
with st.sidebar:
    st.header("⚙️ Configuration")

    persist_dir = st.text_input("FAISS persist dir", "./data/faiss_oracle")
    metadata_path = st.text_input("Metadata JSON", "./data/oracle_schema/ats_schema_metadata.filtered.enriched.json")

    owner = st.text_input("Schema owner", "ATS")
    model_name = st.text_input("LLM model (Ollama)", "mistral:7b-instruct")

    st.subheader("Retriever")
    st.caption("MMR disabled. search_k fixed at 64.")
    search_k = 64
    require_date_cols = st.checkbox("Require date columns", value=True)

    st.subheader("Execution")
    preview_n = st.number_input("Preview rows (display)", min_value=1, max_value=1000, value=50, step=5)
    st.caption(":limit affects Oracle SQL fetch; Preview rows controls what is shown in UI.")

    st.subheader("Oracle Connection")
    oracle_user = st.text_input("ORACLE_USER", os.getenv("ORACLE_USER") or "")
    oracle_password = st.text_input("ORACLE_PASSWORD", os.getenv("ORACLE_PASSWORD") or "", type="password")
    oracle_dsn = st.text_input("ORACLE_DSN", os.getenv("ORACLE_DSN") or "192.168.36.227:1521/DEVDB")

    st.markdown("---")
    st.caption("Tip: set ORACLE_* env vars to skip manual entry.")

# --------------------------
# Main layout
# --------------------------
st.title("🔎 RAG → 🧠 SQL → 🗄️ Oracle")

col_q, col_binds = st.columns([2, 1])

with col_q:
    user_query = st.text_area(
        "Natural-language query",
        height=100,
        placeholder="e.g., daily trades by instrument between July and August 2022"
    )

with col_binds:
    st.markdown("**Bind Parameters**")
    bd_from = st.text_input(":from_date", "2022-07-01")
    bd_to = st.text_input(":to_date", "2022-08-31")
    bd_limit = st.text_input(":limit (optional)", "10")
    run_btn = st.button("Run Pipeline 🚀", type="primary", use_container_width=True)

# --------------------------
# Logging setup
# --------------------------
if "log_lines" not in st.session_state:
    st.session_state.log_lines = []
log_lines: List[str] = st.session_state.log_lines
log_lines.clear()

root_logger = logging.getLogger()
root_logger.setLevel(logging.INFO)
for h in list(root_logger.handlers):
    root_logger.removeHandler(h)

stream_handler = logging.StreamHandler()
stream_handler.setLevel(logging.INFO)
root_logger.addHandler(stream_handler)

ui_handler = StreamlitLogHandler(log_lines, level=logging.INFO)
fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
ui_handler.setFormatter(fmt)
root_logger.addHandler(ui_handler)

# --------------------------
# Run pipeline
# --------------------------
if run_btn:
    if not user_query.strip():
        st.error("Please enter a query.")
        st.stop()

    # Build bind params
    binds: Dict[str, Any] = {}
    if bd_from.strip():
        binds["from_date"] = bd_from.strip()
    if bd_to.strip():
        binds["to_date"] = bd_to.strip()
    if bd_limit.strip():
        try:
            binds["limit"] = int(bd_limit.strip())
        except:
            binds["limit"] = bd_limit.strip()

    # Live step-by-step status
    with st.status("Running pipeline…", expanded=True) as status:
        # 1️⃣ Retrieval
        status.write("📚 Retrieving candidate tables…")
        retr = SchemaRetriever(
            persist_dir=persist_dir,
            metadata_path=metadata_path,
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            default_owner=owner,
        )
        contexts = retr.retrieve(
            query=user_query,
            k_tables=8,
            owners=[owner],
            require_date_cols=require_date_cols,
            search_k=search_k,
            mmr=False
        )
        if not contexts:
            status.update(label="No candidate tables found.", state="error")
            st.stop()
        status.write(f"✅ Retrieved {len(contexts)} candidate tables")

        # Display retrieved tables
        rcol1, rcol2 = st.columns([1, 1])
        with rcol1:
            rows = [{
                "table": f"{c.owner}.{c.table_name}",
                "n_columns": len(c.columns),
                "date_cols": ", ".join(c.date_cols[:5]),
                "top_scores": ", ".join([f"{t}:{s:.3f}" for t, s in c.top_chunk_scores])
            } for c in contexts]
            st.dataframe(pd.DataFrame(rows), width='stretch', height=220)
        with rcol2:
            st.write("**Columns (first candidate)**")
            first_cols = [{"column_name": col.column_name, "data_type": col.data_type, "nullable": col.nullable}
                          for col in contexts[0].columns]
            st.dataframe(pd.DataFrame(first_cols), width='stretch', height=220)

        # 2️⃣ SQL Generation
        status.write("🧠 Generating SQL…")
        gen = SQLGenerator(
            persist_dir=persist_dir,
            metadata_path=metadata_path,
            owner=owner,
            model=model_name,
        )
        gen_res = gen.generate(user_query)
        if not gen_res.ok:
            status.update(label="SQL generation failed.", state="error")
            st.error("SQL generation failed.")
            st.code(gen_res.error or "Unknown error", language="text")
            st.stop()

        st.write("**Generated SQL**")
        st.code(gen_res.sql or "", language="sql")
        st.write("**Bind Parameters (declared by LLM)**")
        st.json(gen_res.bind_params or {})
        if gen_res.tables_used:
            st.caption("Allowlist tables: " + ", ".join(gen_res.tables_used))
        status.write("✅ SQL generation complete")

        # 3️⃣ Execution
        status.write("🗄️ Executing SQL on Oracle…")

        # prepare connection info for executor
        connect_args = {
            "user": "ATS",
            "password": "ABC",
            "dsn": "192.168.36.227:1521/DEVDB"
        }

        # Initialize SQLExecutor safely
        exe = SQLExecutor(user=connect_args["user"],
                          password=connect_args["password"],dsn=connect_args["dsn"])

        tables_used = set()
        if gen_res.tables_used:
            tables_used = {t.split(".", 1)[1].upper() for t in gen_res.tables_used if "." in t}

        req = ExecRequest(
            sql=gen_res.sql,
            bind_params=gen_res.bind_params or {},
            binds=binds,
            # owner_allowlist=[owner],
            # allowed_table_names=tables_used,
            preview_rows=int(preview_n),
        )
        out = exe.execute(req)

        if not out.ok:
            status.update(label="Execution failed.", state="error")
            st.error("Execution failed.")
            if out.error_code:
                st.write(f"**{out.error_code}**")
            st.code(out.message or "Unknown error", language="text")
            if out.diagnostics:
                with st.expander("Diagnostics"):
                    st.json(out.diagnostics)
            with st.expander("Logs"):
                st.text("\n".join(log_lines[-400:]))
            st.stop()

        # ✅ Success
        status.write("✅ Execution OK")
        status.update(label="Pipeline completed successfully.", state="complete")

        cols = out.columns or []
        st.caption(f"Columns ({len(cols)}): " + ", ".join(cols))
        df = pd.DataFrame(out.rows or [], columns=cols)
        st.dataframe(df, width='stretch', height=420)

        csv_bytes = df_to_csv_bytes(df)
        st.download_button(
            "Download CSV",
            data=csv_bytes,
            file_name="query_result.csv",
            mime="text/csv",
            width='stretch'
        )

    # Show logs
    with st.expander("Logs (tail)"):
        st.text("\n".join(log_lines[-400:]))

else:
    st.info("Enter a query, set binds/config in the sidebar, then click **Run Pipeline 🚀**.")
