"""
db_conn.py
-----------
Centralized module for managing Oracle (real) and SQLite (mock) connections.

- Choose backend explicitly via db_session(mode="oracle"|"mock"|"auto")
- Pass Oracle creds directly OR via config.settings / env:
    ORACLE_DSN, ORACLE_USER, ORACLE_PASSWORD
- Mock uses SQLite (in-memory by default or file path)

Always yields exactly once so callers can fall back gracefully.
"""

from __future__ import annotations

import logging
import os
from contextlib import contextmanager
from typing import Generator, Optional, Tuple

# ---------------------------------------------------------------------------
# Optional settings loader (keeps your original behavior)
# ---------------------------------------------------------------------------
settings = None
try:
    # If running inside your package
    from RAG.src.config.settings import settings as _settings  # type: ignore
    settings = _settings
except Exception:
    try:
        from config.settings import settings as _settings  # type: ignore
        settings = _settings
    except Exception:
        settings = None

def _get_setting(name: str, default: Optional[str] = None) -> Optional[str]:
    """Read setting from config.settings if present, else from environment."""
    if settings is not None:
        val = getattr(settings, name, None)
        if val is not None:
            return val
    return os.getenv(name, default)

# ---------------------------------------------------------------------------
# Optional drivers
# ---------------------------------------------------------------------------
try:
    import oracledb  # official Oracle driver
except ImportError:
    oracledb = None
    logging.warning("⚠️ 'oracledb' package not installed. Oracle connectivity unavailable.")

import sqlite3  # always available for mock

# ---------------------------------------------------------------------------
# Config resolution helpers
# ---------------------------------------------------------------------------
def _resolve_oracle_creds(
    user: Optional[str], password: Optional[str], dsn: Optional[str]
) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Prefer explicit args; fall back to settings/env."""
    u = user or _get_setting("ORACLE_USER")
    p = password or _get_setting("ORACLE_PASSWORD")
    d = dsn or _get_setting("ORACLE_DSN")
    return u, p, d

# ---------------------------------------------------------------------------
# Connection factories
# ---------------------------------------------------------------------------
def get_oracle_connection(
    user: Optional[str] = None,
    password: Optional[str] = None,
    dsn: Optional[str] = None,
) -> Optional["oracledb.Connection"]:
    """
    Try to connect to Oracle using explicit args first, then settings/env.
    Returns a live connection or None.
    """
    if oracledb is None:
        logging.info("Oracle driver not available. Skipping Oracle connection.")
        return None

    user, password, dsn = _resolve_oracle_creds(user, password, dsn)
    if not all([dsn, user, password]):
        logging.info("Oracle connection details are missing; need ORACLE_DSN / ORACLE_USER / ORACLE_PASSWORD.")
        return None

    try:
        logging.info(f"Connecting to Oracle (DSN={dsn}) …")
        conn = oracledb.connect(user=user, password=password, dsn=dsn)
        logging.info("✅ Oracle connection established.")
        return conn
    except Exception as e:
        logging.exception(f"❌ Oracle connection failed: {e}")
        return None

def get_mock_connection(sqlite_path: Optional[str] = None) -> sqlite3.Connection:
    """
    Returns a SQLite connection for mock mode.
    If sqlite_path is None, uses an in-memory DB (':memory:').
    """
    path = sqlite_path or ":memory:"
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    logging.info(f"🧪 Mock SQLite connected ({'memory' if path==':memory:' else path}).")
    return conn

# ---------------------------------------------------------------------------
# db_session(): choose backend explicitly or automatically
# ---------------------------------------------------------------------------
@contextmanager
def db_session(
    mode: str = "auto",  # "oracle" | "mock" | "auto"
    user: Optional[str] = None,
    password: Optional[str] = None,
    dsn: Optional[str] = None,
    sqlite_path: Optional[str] = None,
):
    """
    Context manager for DB work.

    - mode="oracle": try Oracle only (returns None on failure)
    - mode="mock": open SQLite (in-memory by default)
    - mode="auto": try Oracle; if unavailable and sqlite_path provided → mock; else None

    Always yields exactly once.
    """
    conn = None
    backend = None

    try:
        if mode == "oracle":
            conn = get_oracle_connection(user=user, password=password, dsn=dsn)
            backend = "oracle" if conn else None
        elif mode == "mock":
            conn = get_mock_connection(sqlite_path=sqlite_path)
            backend = "mock"
        elif mode == "auto":
            conn = get_oracle_connection(user=user, password=password, dsn=dsn)
            backend = "oracle" if conn else None
            if conn is None and sqlite_path:
                conn = get_mock_connection(sqlite_path=sqlite_path)
                backend = "mock"
        else:
            logging.warning(f"Unknown mode '{mode}', defaulting to 'auto'.")
            conn = get_oracle_connection(user=user, password=password, dsn=dsn)
            backend = "oracle" if conn else None
            if conn is None and sqlite_path:
                conn = get_mock_connection(sqlite_path=sqlite_path)
                backend = "mock"

        if backend:
            logging.info(f"DB session opened (mode={mode}, backend={backend}).")
        else:
            logging.error(f"No DB backend available (mode={mode}).")
        yield conn
    finally:
        if conn is not None:
            try:
                conn.close()
                logging.info("🔒 DB connection closed.")
            except Exception as e:
                logging.warning(f"Error closing DB connection: {e}")

# ---------------------------------------------------------------------------
# Connectivity probes
# ---------------------------------------------------------------------------
def test_connection(
    mode: str = "oracle",
    user: Optional[str] = None,
    password: Optional[str] = None,
    dsn: Optional[str] = None,
    sqlite_path: Optional[str] = None,
) -> bool:
    """
    Quick probe:
      - oracle: SELECT 1 FROM dual
      - mock:   SELECT 1
    """
    with db_session(mode=mode, user=user, password=password, dsn=dsn, sqlite_path=sqlite_path) as conn:
        if not conn:
            return False
        try:
            cur = conn.cursor()
            if mode == "oracle" and oracledb and isinstance(conn, oracledb.Connection):
                cur.execute("SELECT 1 FROM dual")
            else:
                cur.execute("SELECT 1")
            cur.fetchone()
            return True
        except Exception as e:
            logging.exception(f"DB test query failed: {e}")
            return False
