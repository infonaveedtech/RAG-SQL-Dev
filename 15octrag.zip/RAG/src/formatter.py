﻿"""
formatter.py
-------------
Handles final report generation and output formatting for the RAG pipeline.

Responsibilities:
- Take query results (list of dicts) and metadata.
- Produce formatted table output (Markdown/HTML/CSV).
- Create a consistent report structure usable in UI, API, or PDF.

Future extensibility:
- Add Jinja2 templates for branded PDF/HTML reports.
- Add summary metrics or visual charts.
"""

from __future__ import annotations
from typing import List, Dict, Any, Optional
import datetime
import pandas as pd
from tabulate import tabulate
import os

# Ensure pandas + tabulate installed
# pip install pandas tabulate


class ReportFormatter:
    """
    Responsible for formatting query results into tabular report templates.
    """

    def __init__(self, output_dir: str = "./reports"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

    # --------------------------------------------------------------
    # Core formatter
    # --------------------------------------------------------------
    def format_table(
        self,
        rows: List[Dict[str, Any]],
        query: str,
        sql: str,
        start_time: datetime.datetime,
        end_time: datetime.datetime,
        export: Optional[str] = None,
    ) -> str:
        """
        Create a structured report from query results.

        Args:
            rows: list of dicts (query results)
            query: user’s natural language query
            sql: executed SQL query text
            start_time: datetime when execution started
            end_time: datetime when execution ended
            export: optional format to export ('csv' or 'html')

        Returns:
            Markdown-style string for console rendering.
        """
        exec_duration = round((end_time - start_time).total_seconds(), 2)
        row_count = len(rows)
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Convert to DataFrame for convenience
        df = pd.DataFrame(rows) if rows else pd.DataFrame(columns=["No data"])

        # Create header info
        header = [
            f"# 📊 RAG Oracle Report",
            f"**Generated:** {timestamp}",
            f"**Natural Query:** {query}",
            f"**SQL Executed:** `{sql.strip()}`",
            f"**Rows Returned:** {row_count}",
            f"**Execution Time:** {exec_duration} sec",
            "",
        ]

        # Create main table in Markdown
        table_md = tabulate(df.head(50), headers="keys", tablefmt="github", showindex=False)

        report_md = "\n".join(header) + "\n" + table_md

        # ----------------------------------------------------------
        # Optional export
        # ----------------------------------------------------------
        if export:
            filename_base = f"report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
            if export == "csv":
                path = os.path.join(self.output_dir, f"{filename_base}.csv")
                df.to_csv(path, index=False)
            elif export == "html":
                path = os.path.join(self.output_dir, f"{filename_base}.html")
                df.to_html(path, index=False, border=0)
            else:
                path = None
            if path:
                print(f"✅ Report exported to {path}")

        return report_md

    # --------------------------------------------------------------
    # Utility: preview on console
    # --------------------------------------------------------------
    def display(self, markdown_report: str):
        """Pretty-print report to console."""
        print("\n" + "=" * 80)
        print(markdown_report)
        print("=" * 80 + "\n")


# --------------------------------------------------------------
# Example usage / quick test
# --------------------------------------------------------------
if __name__ == "__main__":
    from time import sleep

    formatter = ReportFormatter()

    # Simulate query metadata
    query = "Show total trade volume per instrument between Jan and Feb"
    sql = "SELECT instrument_id, SUM(trade_volume) AS total_volume FROM trade_data GROUP BY instrument_id"
    start_time = datetime.datetime.now()
    sleep(1.2)
    end_time = datetime.datetime.now()

    # Mock results
    rows = [
        {"INSTRUMENT_ID": "ABC", "TOTAL_VOLUME": 1500},
        {"INSTRUMENT_ID": "XYZ", "TOTAL_VOLUME": 2300},
        {"INSTRUMENT_ID": "LMN", "TOTAL_VOLUME": 1200},
    ]

    report = formatter.format_table(rows, query, sql, start_time, end_time, export="html")
    formatter.display(report)
