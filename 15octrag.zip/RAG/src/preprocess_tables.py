# preprocess_tables.py
"""
CLI to preprocess raw crawler JSON into a filtered JSON for vectorization,
plus auditable stats for must_keep / candidate / omit_now.

Example:
    python preprocess_tables.py \
      --in data/oracle_schema/ats_schema_metadata.json \
      --out data/oracle_schema/ats_schema_metadata.filtered.json \
      --yaml config/ats_table_selection.yaml \
      --stats_dir data/selection_stats
"""

import os
import json
import argparse
from utils.table_selection import load_rules, select_tables, write_stats


def main():
    ap = argparse.ArgumentParser(description="Preprocess schema tables (schema-agnostic).")
    ap.add_argument("--in", dest="in_path", required=True, help="Path to crawler JSON (raw full schema).")
    ap.add_argument("--out", dest="out_path", required=True, help="Path to write filtered JSON (must_keep + candidate).")
    ap.add_argument("--yaml", dest="yaml_path", required=False, default=None, help="Optional selection rules YAML.")
    ap.add_argument("--stats_dir", dest="stats_dir", required=False, default="data/selection_stats",
                    help="Directory to write CSV/JSON stats.")
    args = ap.parse_args()

    assert os.path.exists(args.in_path), f"Input not found: {args.in_path}"
    with open(args.in_path, "r", encoding="utf-8") as f:
        tables = json.load(f)

    rules = load_rules(args.yaml_path)
    parts = select_tables(tables, rules)

    # write stats
    write_stats(args.stats_dir, parts)

    # filtered = MUST + CANDIDATE
    filtered = parts["must_keep"] + parts["candidate"]
    os.makedirs(os.path.dirname(args.out_path), exist_ok=True)
    with open(args.out_path, "w", encoding="utf-8") as f:
        json.dump(filtered, f, indent=2)

    print(f"✅ Wrote filtered tables: {len(filtered)} → {args.out_path}")
    print(f"📊 Stats in: {args.stats_dir} ("
          f"must_keep={len(parts['must_keep'])}, candidate={len(parts['candidate'])}, omit_now={len(parts['omit_now'])})")


if __name__ == "__main__":
    main()
