﻿from __future__ import annotations
import re, json, logging, argparse
from dataclasses import dataclass
from typing import Optional, List, Dict

from retriever import SchemaRetriever
from utils.llm_client import LLMClient
from utils.prompting import build_prompt_v1, extract_sql_from_fence, build_schema_context
from utils.validators import basic_validate ,validate_sql_columns
OWNER_DEFAULT = "ATS"

# --- tiny helpers in this module (kept local until we need them elsewhere) ---

_FROM_JOIN = re.compile(r"\b(?:FROM|JOIN)\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\b", re.I)

def _extract_owner_tables(sql: str, owner_hint: str | None = None) -> List[str]:
    """
    Extract tables only from FROM/JOIN clauses. Optionally filter by owner_hint (e.g., 'ATS').
    """
    seen, out = set(), []
    for o, t in _FROM_JOIN.findall(sql.upper()):
        if owner_hint and o != owner_hint.upper():
            continue
        key = f"{o}.{t}"
        if key not in seen:
            seen.add(key); out.append(key)
    return out

def _rewrite_symbol_join_to_id(sql: str, colmap: Dict[str, set]) -> str:
    """
    If the query joins trades to symbols on SYMBOL=SYMBOL, and both tables expose SYMBOL_ID,
    rewrite the join to use SYMBOL_ID. We only do this when it's obviously safe.
    """
    text = sql
    # find FROM/JOIN table pairs we know
    tables = re.findall(r"\b(?:FROM|JOIN)\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\s+(?:AS\s+)?([A-Z0-9_]+)", text, flags=re.I)
    alias_to_fqn = {}  # e.g., {'T':'ATS.NEGOTIATED_TRADES', 'S':'ATS.SYMBOLS'}
    for owner, tbl, alias in tables:
        alias_to_fqn[alias.upper()] = f"{owner.upper()}.{tbl.upper()}"

    # Look for ON <alias1>.SYMBOL = <alias2>.SYMBOL
    def repl(m):
        a1 = m.group(1).upper()
        a2 = m.group(2).upper()
        f1 = alias_to_fqn.get(a1, "")
        f2 = alias_to_fqn.get(a2, "")
        if not f1 or not f2:
            return m.group(0)  # leave as-is
        cols1 = colmap.get(f1, set())
        cols2 = colmap.get(f2, set())
        if "SYMBOL_ID" in cols1 and "SYMBOL_ID" in cols2:
            return f"{a1}.SYMBOL_ID = {a2}.SYMBOL_ID"
        return m.group(0)

    text = re.sub(r"\b([A-Z0-9_]+)\.SYMBOL\s*=\s*([A-Z0-9_]+)\.SYMBOL\b", repl, text, flags=re.I)
    return text

import re
from typing import Tuple

_JOIN_BLOCK_RE = re.compile(
    r"""
    (
      \bFROM\b\s+.+?                                # FROM ... (greedy minimal)
      (?=\bJOIN\b)                                  # up to first JOIN
    )
    (
      (?:\bJOIN\b\s+.+?\bON\b\s+.+?)+               # one or more JOIN ... ON ...
    )
    (\bWHERE\b|\bGROUP\b|\bORDER\b|FETCH|\Z)        # until next clause or end
    """,
    re.IGNORECASE | re.DOTALL | re.VERBOSE,
)

_JOIN_ITEM_RE = re.compile(
    r"""\bJOIN\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\s+(?:AS\s+)?([A-Z0-9_]+)\s+\bON\b\s+(.*?)(?=\bJOIN\b|\bWHERE\b|\bGROUP\b|\bORDER\b|FETCH|\Z)""",
    re.IGNORECASE | re.DOTALL,
)

def _fix_forward_join_aliases(sql: str) -> str:
    """
    Heuristic fix: if a JOIN's ON clause references an alias that is only introduced by a LATER JOIN,
    swap the order so that alias is introduced earlier. Minimal & safe: only swaps adjacent JOINs when needed.
    """
    m = _JOIN_BLOCK_RE.search(sql)
    if not m:
        return sql

    head, joins_blob, tail = m.group(1), m.group(2), m.group(3)
    items = list(_JOIN_ITEM_RE.finditer(joins_blob))
    if not items:
        return sql

    # Build a list of dicts for each JOIN
    joins = []
    for it in items:
        owner, table, alias, on_expr = it.group(1).upper(), it.group(2).upper(), it.group(3).upper(), it.group(4)
        joins.append({"owner": owner, "table": table, "alias": alias, "on": on_expr})

    # Running set of aliases introduced so far (start with aliases from FROM)
    # Try to capture the FROM alias if present
    from_aliases = set()
    from_alias_match = re.search(r"\bFROM\b\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\s+(?:AS\s+)?([A-Z0-9_]+)", head, re.I)
    if from_alias_match:
        from_aliases.add(from_alias_match.group(3).upper())

    # Walk joins; if a join's ON references an alias not yet introduced,
    # but the NEXT join introduces that alias, swap them.
    changed = False
    i = 0
    while i < len(joins):
        on_refs = set(a for a in re.findall(r"\b([A-Z][A-Z0-9_]*)\.", joins[i]["on"]))
        missing = [a for a in on_refs if a not in from_aliases and a != joins[i]["alias"]]
        if missing and i + 1 < len(joins):
            next_alias = joins[i + 1]["alias"]
            if next_alias in missing:
                joins[i], joins[i + 1] = joins[i + 1], joins[i]
                changed = True
                # do not advance i, re-check this position after swap
                continue

        # this join's alias becomes available for subsequent joins
        from_aliases.add(joins[i]["alias"])
        i += 1

    if not changed:
        return sql

    # Rebuild the JOIN blob
    new_blob = ""
    for j in joins:
        new_blob += f" JOIN {j['owner']}.{j['table']} {j['alias']} ON {j['on']}"
    # stitch back
    return sql[:m.start()] + head + new_blob + tail + sql[m.end():]


import difflib
import textwrap

def _llm_repair_sql(
    llm: LLMClient,
    user_query: str,
    bad_sql: str,
    bad_cols: List[str],
    schema_contexts: List,
    owner: str
) -> str:
    """
    Ask the LLM to repair the SQL using schema context and list of invalid columns.
    """
    repair_instruction = textwrap.dedent(f"""
    The previous SQL you generated contains invalid columns or schema mismatches:
    {', '.join(bad_cols)}.

    Please rewrite the SQL so that it is valid given the following schema definitions.
    Do not invent new columns that do not exist in the schema. If a column like 'VOLUME'
    doesn't exist, use another column representing similar meaning (e.g. TRADED_VOLUME, TURNOVER, TOTAL_VOLUME).

    Return only the corrected SQL query inside a ```sql fenced block.
    """)

    prompt = build_prompt_v1(
        user_query,
        owner,
        schema_contexts,
        repair_hint=repair_instruction
    )
    raw = llm.generate(prompt, as_json=False)
    return extract_sql_from_fence(raw)


def _auto_repair_columns(sql: str, bad_cols: List[str], metadata: Dict[str, Dict[str, List[str]]]) -> str:
    """
    Try to repair unknown columns by replacing them with closest valid column names.
    """
    fixed_sql = sql
    for bad in bad_cols:
        try:
            owner_tbl, col = bad.rsplit(".", 1)
            valid_cols = metadata.get(owner_tbl, {}).get("columns", [])
            if not valid_cols:
                continue
            # find closest column name
            match = difflib.get_close_matches(col, valid_cols, n=1, cutoff=0.6)
            if match:
                print(f"🩹 Auto-replaced {bad} → {owner_tbl}.{match[0]}")
                fixed_sql = re.sub(rf"\b{col}\b", match[0], fixed_sql, flags=re.I)
        except Exception:
            continue
    return fixed_sql


def _enforce_groupby_measures(sql: str) -> str:
    """
    If GROUP BY is present and we see plain measure columns like t.VOLUME / t.DISCLOSED_VOLUME / t.VALUE
    in the SELECT list (not already aggregated), wrap them in SUM(...).
    Rebuild the SELECT list ensuring spaces: 'SELECT <list> FROM'.
    """
    if not re.search(r"\bGROUP\s+BY\b", sql, re.I):
        return sql

    def transform_select_list(sel: str) -> str:
        # split select list on commas at top-level
        depth = 0
        buf, items = [], []
        for ch in sel:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth = max(0, depth - 1)
            if ch == ',' and depth == 0:
                items.append(''.join(buf).strip()); buf = []
            else:
                buf.append(ch)
        if buf:
            items.append(''.join(buf).strip())

        def agg_wrap(expr: str) -> str:
            # already aggregated?
            if re.search(r"\b(SUM|AVG|MIN|MAX|COUNT)\s*\(", expr, re.I):
                return expr
            # if it looks like a measure, wrap
            if re.search(r"\b(DISCLOSED_?VOLUME|VOLUME|VALUE|QUANTITY)\b", expr, re.I):
                m2 = re.search(r"\bAS\s+([A-Z0-9_\"$#]+)\b", expr, re.I)
                alias = m2.group(1) if m2 else None
                base = re.sub(r"\bAS\s+[A-Z0-9_\"$#]+\b", "", expr, flags=re.I).strip()
                out = f"SUM({base})"
                out += f" AS {alias}" if alias else " AS VOLUME"
                return out
            return expr

        items2 = [agg_wrap(it) for it in items]
        return ", ".join(items2)

    # rebuild using a regex with a callback to guarantee spaces around SELECT/FROM
    def repl(m):
        sel = m.group(1)
        new_sel = transform_select_list(sel)
        return f"SELECT {new_sel} FROM"

    return re.sub(r"(?is)\bSELECT\b(.*?)\bFROM\b", repl, sql, count=1)


def _find_bind_names(sql: str) -> List[str]:
    # re.findall already returns the name WITHOUT the leading colon
    return sorted(set(re.findall(r":([a-zA-Z_][a-zA-Z0-9_]*)", sql or "")))

def _normalize_generated_sql(sql: str) -> str:
    """Light normalization: remove comments; replace TO_DATE(...) BETWEEN with bind-based BETWEEN; ensure FETCH FIRST :limit if missing."""
    # strip single-line comments
    sql = re.sub(r"--.*?$", "", sql, flags=re.MULTILINE)

    # replace hard-coded BETWEEN TO_DATE(...) AND TO_DATE(...) with binds
    # tolerant regex to catch different spacing and masks
    sql = re.sub(
        r"BETWEEN\s+TO_DATE\(\s*:[a-zA-Z_][a-zA-Z0-9_]*\s*,\s*'[^']*'\)\s+AND\s+TO_DATE\(\s*:[a-zA-Z_][a-zA-Z0-9_]*\s*,\s*'[^']*'\)",
        "BETWEEN :from_date AND :to_date",
        sql,
        flags=re.IGNORECASE | re.DOTALL,
    )

    # ensure FETCH FIRST :limit ROWS ONLY (append if missing)
    if not re.search(r"FETCH\s+FIRST\s+:\s*limit\s+ROWS\s+ONLY", sql, re.I):
        # ensure we have an ORDER BY; if not, add a generic one on the first selected expression
        if not re.search(r"\bORDER\s+BY\b", sql, re.I):
            # very small nudge: order by first column in select list if we can find it
            m = re.search(r"SELECT\s+(.*?)\bFROM\b", sql, re.I | re.S)
            if m:
                first_expr = m.group(1).split(",")[0].strip()
                sql += f"\nORDER BY {first_expr} DESC"
        sql += "\nFETCH FIRST :limit ROWS ONLY"
    return sql.strip()


def _infer_bind_types(names: List[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for n in names:
        nl = n.lower()
        if nl in ("from_date","to_date"):
            out[n] = "DATE"
        elif nl in ("limit","top","topn","top_n"):
            out[n] = "INT?"
        else:
            out[n] = "TEXT?"
    return out

# --- result model ---

@dataclass
class SQLGenResult:
    ok: bool
    sql: Optional[str] = None
    tables_used: Optional[List[str]] = None
    bind_params: Optional[Dict[str, str]] = None
    rationale: Optional[str] = None
    error: Optional[str] = None

# --- main generator ---

class SQLGenerator:
    def __init__(
        self,
        persist_dir: str = "./data/faiss_oracle",
        metadata_path: str = "./data/oracle_schema/ats_schema_metadata.filtered.enriched.json",
        owner: str = OWNER_DEFAULT,
        model: str = "mistral:7b-instruct",
    ):
        self.owner = owner
        self.metadata_path = metadata_path
        self.retriever = SchemaRetriever(
            persist_dir=persist_dir,
            metadata_path=metadata_path,
            default_owner=owner,
        )
        self.llm = LLMClient(model=model)

    def generate(self, user_query: str, k_tables: int = 5, require_date_cols: bool = True) -> SQLGenResult:
        # 1) retrieve
        tctxs = self.retriever.retrieve(
            query=user_query,
            k_tables=k_tables,
            require_date_cols=require_date_cols,
            search_k=64,
            mmr=False,
        )
        if not tctxs:
            return SQLGenResult(ok=False, error="No relevant tables found.")
        logging.info("Allowlist tables: %s", ", ".join(f"{t.owner}.{t.table_name}" for t in tctxs))

        colmap: Dict[str, List[str]] = {}
        for t in tctxs:
            fq= f"{t.owner}.{t.table_name}"
            colmap[fq] = [c.column_name.upper() for c in t.columns]
        
        # 2) prompt once → expect fenced SQL only
        prompt = build_prompt_v1(user_query, self.owner, tctxs)
        raw = self.llm.generate(prompt, as_json=False)

        try:
            sql = extract_sql_from_fence(raw)
            sql = _normalize_generated_sql(sql)
            # post-fixes that depend on schema knowledge and on GROUP BY presence
            sql = _rewrite_symbol_join_to_id(sql, colmap)
            sql = _enforce_groupby_measures(sql)
            sql = _fix_forward_join_aliases(sql) 
            # Build a minimal metadata dict from retrieved contexts (allowlist only)
            meta_for_validation: Dict[str, Dict[str, List[str]]] = {}
            for t in tctxs:
                fq = f"{t.owner}.{t.table_name}".upper()
                meta_for_validation[fq] = {
                    "columns": [c.column_name.upper() for c in t.columns if c.column_name]
                }

            # now validate with the dict (NOT the path)
            ok_cols, bad_cols = validate_sql_columns(sql, meta_for_validation)
            if not ok_cols:
                logging.error("Unknown columns detected: %s", bad_cols)
                bad_cols = [bc.upper() for bc in bad_cols]
                sql = _auto_repair_columns(sql, bad_cols, meta_for_validation)
                # revalidate
                ok_cols2, bad_cols2 = validate_sql_columns(sql, meta_for_validation)

                    
                if not ok_cols2:
                    logging.warning("Auto repair failed; attempting LLM repair round...")
                    try:
                        repaired_sql = _llm_repair_sql(
                            self.llm,
                            user_query,
                            sql,
                            bad_cols2,
                            tctxs,
                            self.owner
                        )
                        repaired_sql = _normalize_generated_sql(repaired_sql)
                        ok_cols3, bad_cols3 = validate_sql_columns(repaired_sql, meta_for_validation)
                        if not ok_cols3:
                            return SQLGenResult(ok=False, error="LLM repair still invalid: " + ", ".join(bad_cols3))
                        else:
                            sql = repaired_sql
                            logging.info("✅ LLM-based repair successful.")
                    except Exception as e:
                        return SQLGenResult(ok=False, error=f"LLM repair attempt failed: {e}")
                else:
                    logging.info("Column issues auto-repaired.")

                
        except Exception as e:
            logging.error("LLM raw (truncated):\n%s", raw[:600])
            return SQLGenResult(ok=False, error=f"Could not extract SQL from LLM output: {e}")

        # 3) minimal validation
        ok, err = basic_validate(sql)
        if not ok:
            return SQLGenResult(ok=False, error=f"{err}\n--- SQL (first 400 chars) ---\n{sql[:800]}")

        # 4) derive helpful metadata
        tables = _extract_owner_tables(sql,owner_hint=self.owner)
        binds = _infer_bind_types(_find_bind_names(sql))

        return SQLGenResult(ok=True, sql=sql, tables_used=tables, bind_params=binds)

# -------------- CLI --------------
def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--query", default="daily trades by instrument between :from_date and :to_date")
    ap.add_argument("--owner", default=OWNER_DEFAULT)
    ap.add_argument("--persist_dir", default="./data/faiss_oracle")
    ap.add_argument("--metadata", default="./data/oracle_schema/ats_schema_metadata.json")
    ap.add_argument("--model", default="mistral:7b-instruct")
    args = ap.parse_args()

    gen = SQLGenerator(
        persist_dir=args.persist_dir,
        metadata_path=args.metadata,
        owner=args.owner,
        model=args.model,
    )
    res = gen.generate(args.query)
    if not res.ok:
        print("ERROR:", res.error); return
    print("\n=== SQL ===\n", res.sql)
    print("\n=== tables_used ===\n", json.dumps(res.tables_used, indent=2))
    print("\n=== bind_params ===\n", json.dumps(res.bind_params, indent=2))

if __name__ == "__main__":
    main()
