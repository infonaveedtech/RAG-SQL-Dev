# run_query.py — one-shot "ask → SQL → execute → rows"
from __future__ import annotations
import os, sys, json, argparse, datetime as dt
from typing import List, Dict, Any

from sql_generator import SQLGenerator
from executor import SQLExecutor

# --- light helpers -----------------------------------------------------------
def _parse_date(s: str) -> dt.datetime:
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y", "%d-%b-%Y", "%Y%m%d"):
        try:
            return dt.datetime.strptime(s, fmt)
        except Exception:
            pass
    # last resort (ISO)
    try:
        return dt.datetime.fromisoformat(s)
    except Exception:
        raise ValueError(f"Could not parse date: {s}")

def _load_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

# --- main entry --------------------------------------------------------------
def run_once(
    query: str,
    *,
    enriched_path: str = "./data/oracle_schema/ats_schema_metadata.filtered.enriched.json",
    faiss_dir: str = "./data/faiss_oracle",
    owner: str = "ATS",
    model: str = "mistral:7b-instruct",
    ollama_url: str | None = None,
    # DB
    user: str | None = None,
    password: str | None = None,
    dsn: str | None = None,
    # date binds
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 1000,
) -> List[Dict[str, Any]]:
    # 1) Generate SQL
    gen = SQLGenerator(
        use_llm=True,
        backend="ollama",
        model=model,
        temperature=0.0,
        max_new_tokens=512,
        dialect="Oracle",
        enable_repair=True,
        base_url=ollama_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
    )

    # load minimal context for generator CLI path
    enriched = _load_json(enriched_path)
    # lean on the generator's CLI logic by calling via a tiny inlined routine:
    # We'll reuse its FAISS retrieval by letting the generator's CLI code run in-process.
    # For simplicity, we just feed the same params the CLI would (subset is handled inside).
    context = {
        "query": query,
        "enriched_tables": enriched if isinstance(enriched, list) else list(enriched.values()),
        "relevant_tables": [],         # let generator pick via FAISS or fallback
        "context_snippets": [],
        "limit_hint": limit,
        "owner": owner,
    }

    sql = gen.generate_sql(context)
    print("\n---- SQL ----")
    print(sql)
    print("---- Generator mode ----")
    print(getattr(gen, "last_mode", "unknown"))

    # 2) Prepare bind params (names without colons)
    if not from_date and not to_date:
        # sensible default: this calendar year
        today = dt.date.today()
        y = today.year
        from_dt = dt.datetime(y, 1, 1)
        to_dt = dt.datetime(y, 12, 31, 23, 59, 59)
    else:
        from_dt = _parse_date(from_date) if from_date else dt.datetime(1970, 1, 1)
        to_dt = _parse_date(to_date) if to_date else dt.datetime.now()

    params = {"from_date": from_dt, "to_date": to_dt}

    # 3) Execute
    execu = SQLExecutor(use_mock=False)
    rows = execu.run_query(
        sql,
        params=params,
        max_rows=limit,
        timeout_seconds=60,
        mode="oracle",
        user=user or os.getenv("ORACLE_USER"),
        password=password or os.getenv("ORACLE_PASSWORD"),
        dsn=dsn or os.getenv("ORACLE_DSN"),
    )

    # 4) Print small preview
    print(f"---- Rows ({len(rows)}) ----")
    for r in rows[: min(10, len(rows))]:
        print(r)

    return rows

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="One-shot: NL query → SQL → Oracle execution")
    ap.add_argument("--query", required=True)
    ap.add_argument("--enriched", default="./data/oracle_schema/ats_schema_metadata.filtered.enriched.json")
    ap.add_argument("--faiss_dir", default="./data/faiss_oracle")  # not used directly here, but generator uses it
    ap.add_argument("--owner", default="ATS")
    ap.add_argument("--model", default="mistral:7b-instruct")
    ap.add_argument("--ollama_url", default=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"))
    ap.add_argument("--limit", type=int, default=1000)

    ap.add_argument("--from", dest="from_date", default=None, help="e.g. 2024-03-01")
    ap.add_argument("--to", dest="to_date", default=None, help="e.g. 2024-09-30")

    ap.add_argument("--user", default=os.getenv("ORACLE_USER"))
    ap.add_argument("--password", default=os.getenv("ORACLE_PASSWORD"))
    ap.add_argument("--dsn", default=os.getenv("ORACLE_DSN"))
    args = ap.parse_args()

    run_once(
        args.query,
        enriched_path=args.enriched,
        faiss_dir=args.faiss_dir,
        owner=args.owner,
        model=args.model,
        ollama_url=args.ollama_url,
        user=args.user,
        password=args.password,
        dsn=args.dsn,
        from_date=args.from_date,
        to_date=args.to_date,
        limit=args.limit,
    )
