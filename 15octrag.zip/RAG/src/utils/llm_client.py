from __future__ import annotations
from langchain_ollama import OllamaLLM

class LLMClient:
    def __init__(self, model: str = "mistral:7b-instruct", num_ctx: int = 8192):
        self.model = model
        self.llm_text = OllamaLLM(
            model=self.model,
            num_ctx=num_ctx,
            temperature=0,
            top_p=0,
        )
        self.llm_json = OllamaLLM(
            model=self.model,
            num_ctx=num_ctx,
            temperature=0,
            top_p=0,
            format="json",
        )

    def generate(self, prompt: str, *, as_json: bool = False) -> str:
        """Default to plain text (for fenced SQL). Use as_json=True only if you later need JSON."""
        if as_json:
            return self.llm_json.invoke(prompt)
        return self.llm_text.invoke(prompt)
