from __future__ import annotations
import re
from typing import List
from retriever import TableContext

_SQL_FENCE = re.compile(r"```sql\s*(.*?)\s*```", re.I | re.S)

def build_schema_context(tctxs: List[TableContext]) -> str:
    """Compact, deterministic context: owner.table and a few columns."""
    lines = []
    for t in tctxs:
        cols = ", ".join(c.column_name for c in t.columns[:8] if c.column_name)
        lines.append(f"- {t.owner}.{t.table_name}  (cols: {cols})")
    return "\n".join(lines)

def build_prompt_v1(
    user_query: str,
    owner: str,
    tctxs: List[TableContext],
    repair_hint: str | None = None
) -> str:
    """
    Build an LLM prompt for SQL generation or repair.
    If repair_hint is provided, include it to guide the model in fixing a previous invalid SQL.
    """
    schema_ctx = build_schema_context(tctxs)

    return f"""You are an expert Oracle SQL writer. You must generate **strictly valid Oracle SQL**.
Use **only** the tables and columns provided below. 
If a column is not listed, **you cannot use it**.
If you need data not present, gracefully choose the best available alternative column.

User request:
{user_query}

{"--- Repair Instruction ---\nThe previous SQL query had issues:\n" + repair_hint if repair_hint else ""}

Allowed schema (use only these objects, prefix tables with {owner}):
{schema_ctx}

Rules (follow exactly):
- Oracle SELECT only. One statement only. No Comments.
- Use explicit column names (no SELECT *).
- Must Use these bind variables exactly as shown: :from_date, :to_date, :limit
- If a date range is implied, use: TRUNC(<date_col>) BETWEEN :from_date AND :to_date
- End with ORDER BY a sensible column and FETCH FIRST :limit ROWS ONLY.
- Do NOT embed date literals; always use bind vars as above.
- Do NOT hard-code TO_DATE(...) dates; always use the bind variables above.
- Use numeric-safe aggregation only. Never apply arithmetic (+, -) directly between two SUM() calls.
- Each column alias must be unique.
- Only use numeric columns in SUM(), and ensure CASE expressions return numbers.
- In each JOIN ... ON clause, reference only tables that have already been introduced (left side + the current right table). Do not reference aliases that are introduced later.

Return ONLY a single fenced SQL block — no prose before/after:

Example only and ONLY for reference:
```
sql
SELECT
  TRUNC(t.ENTRY_DATETIME) AS TRADE_DATE,
  t.SYMBOL_ID,
  SUM(t.VOLUME) AS VOLUME
FROM {owner}.NEGOTIATED_TRADES t
WHERE TRUNC(t.ENTRY_DATETIME) BETWEEN :from_date AND :to_date
GROUP BY TRUNC(t.ENTRY_DATETIME), t.SYMBOL_ID
ORDER BY TRADE_DATE DESC
FETCH FIRST :limit ROWS ONLY
```
Now produce the SQL for the user request, following the same pattern and using only tables/columns from the allowed schema:

"""



def extract_sql_from_fence(text: str) -> str:
    """Pull the SQL from a sql fenced block; allow plain SELECT/WITH fallback.""" 
    m = _SQL_FENCE.search(text or "") 
    if m: 
        sql = m.group(1).strip() 
    else: 
        t = (text or "").strip() 
        if not re.match(r"^(SELECT|WITH)\b", t, re.I): 
            raise ValueError("No sql fenced block found and output does not start with SELECT/WITH.")
        sql = t
    # strip a single trailing semicolon if present
    return re.sub(r";\s*$", "", sql)
