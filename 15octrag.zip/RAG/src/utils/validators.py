from __future__ import annotations
import re
from typing import Tuple

_DDL_DML = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|GRANT|REVOKE|BEGIN|END|EXCEPTION|CALL|EXEC(?:UTE)?)\b",
    re.I,
)


def _single_statement(sql: str) -> bool:
    """Allow at most one trailing semicolon; otherwise no semicolons at top level."""
    s = sql.strip()
    s = re.sub(r";\s*$", "", s)
    # naive is fine to start; we’ll harden if needed
    return s.count(";") == 0

def basic_validate(sql: str) -> Tuple[bool, str | None]:
    """Minimal guardrails for v1. Return (ok, error_message_or_None)."""
    if not sql or "SELECT" not in sql.upper():
        return False, "No SELECT detected."

    # Prevent false matches: TRUNC( and CASE ... END)
    safe_sql = sql
    safe_sql = re.sub(r"\bTRUNC\s*\(", "SAFEFUNC(", safe_sql, flags=re.I)
    safe_sql = re.sub(r"\bCASE\b[\s\S]+?\bEND\b", "SAFECASE", safe_sql, flags=re.I)

    _DDL_DML = re.compile(
        r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|GRANT|REVOKE|BEGIN|EXCEPTION|CALL|EXEC(?:UTE)?)\b",
        re.I,
    )

    if _DDL_DML.search(safe_sql):
        return False, "Only plain SELECT statements are allowed."

    if not _single_statement(sql):
        return False, "Provide a single SQL statement (no extra semicolons)."

    return True, None


import re
from typing import Dict, List, Tuple

def validate_sql_columns(sql: str, metadata: Dict[str, Dict[str, List[str]]]) -> Tuple[bool, List[str]]:
    # build alias → owner.table map
    alias_map = {}
    for m in re.finditer(r'\bFROM\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\s+(?:AS\s+)?([A-Z0-9_]+)', sql, re.I):
        alias_map[m.group(3).upper()] = f"{m.group(1).upper()}.{m.group(2).upper()}"
    for m in re.finditer(r'\bJOIN\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\s+(?:AS\s+)?([A-Z0-9_]+)', sql, re.I):
        alias_map[m.group(3).upper()] = f"{m.group(1).upper()}.{m.group(2).upper()}"

    unknowns = []
    # find alias.column refs
    for alias, col in re.findall(r'\b([A-Z][A-Z0-9_]*)\.([A-Z][A-Z0-9_]*)\b', sql, re.I):
        a, c = alias.upper(), col.upper()
        fqn = alias_map.get(a)
        if not fqn:
            continue
        cols = [x.upper() for x in (metadata.get(fqn, {}).get("columns") or [])]
        if c not in cols:
            unknowns.append(f"{fqn}.{c}")
    return (len(unknowns) == 0, unknowns)
