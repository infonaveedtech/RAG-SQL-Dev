"""
generate_mock_metadata_auto.py
-------------------------------
Automatically generate a schema_metadata.json file
from the mock SQLite database (created by mock_data.py).
"""

import sqlite3
import json
import os
from mock_data import create_mock_db_connection


def generate_schema_from_mock():
    conn, _ = create_mock_db_connection()
    cursor = conn.cursor()

    tables = cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()

    metadata = {}
    for (table_name,) in tables:
        # Skip SQLite internal tables
        if table_name.startswith("sqlite_"):
            continue

        columns = cursor.execute(f"PRAGMA table_info({table_name});").fetchall()
        col_data = []
        for col in columns:
            col_data.append({
                "column_name": col[1],
                "data_type": col[2],
                "nullable": "Y" if col[3] == 0 else "N"
            })

        # Row count estimate
        row_count = cursor.execute(f"SELECT COUNT(*) FROM {table_name}").fetchone()[0]

        metadata[table_name] = {
            "table_name": table_name,
            "num_rows": row_count,
            "tablespace": "MOCK",
            "columns": col_data
        }

    os.makedirs("./data", exist_ok=True)
    with open("./data/schema_metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=4)

    print("✅ Auto-generated mock schema metadata at ./data/schema_metadata.json")
    conn.close()


if __name__ == "__main__":
    generate_schema_from_mock()
