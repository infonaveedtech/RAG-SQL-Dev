import torch, platform
print("Python:", platform.python_version())
print("Torch version:", torch.__version__)
print("CUDA in wheel:", torch.version.cuda)
print("CUDA available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))
    x = torch.randn(2048,2048, device="cuda")
    y = x @ x
    print("Matmul done on", y.device, "mean:", y.mean().item())
else:
    print("GPU not accessible — check PyTorch install.")
