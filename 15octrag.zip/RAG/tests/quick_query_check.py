# quick_query_check.py
from src.retriever import SchemaRetriever
from src.sql_generator import SQLGenerator
from src.executor import SQLExecutor

r = SchemaRetriever(persist_dir="./data/faiss")  # or your FAISS path if you’re using FAISS
ctx = r.retrieve_schema_context(
    "Show total trade volume for each instrument between Jan and Feb 2024", k=5
)

gen = SQLGenerator(use_llm=False)     # keep fallback on for now
sql = gen.generate_sql(ctx)
print("SQL:\n", sql)

# 👇 no db_path here — executor will use Oracle if available, else auto-fallback to mock SQLite
db = SQLExecutor()                    # or SQLExecutor(use_mock=True) to force mock
rows = db.run_query(sql, params={"from_date": "2024-01-01", "to_date": "2024-02-29"})
print("Rows:", rows)
