1) “daily trades by instrument between dates”

Top results: multiple ATS.TRADES_* tables with date-like columns:

ENTRY_DATETIME, INITIAL_DATE, TERMINATION_DATE.

✅ That’s exactly what we’d expect—trade tables with date/timestamp fields.
This means the retriever is homing in on the right part of the schema for time-windowed trade queries.

2) “fetch all symbols listed after 2020”

Top results: SYMBOL_* tables:

SYMBOL_INDICATORS, SYMBOL_MARKETS10MAY22, SYMBOL_DAILY_INDICATORS_220721, SYMBOL_SCHEDULES, etc.

Date fields like FIRST_TRADING_DAY, STATS_DATE, START_DATETIME.

✅ Also expected. For “listed after 2020”, FIRST_TRADING_DAY makes sense.
Later, the SQL generator can prefer base tables/views (e.g., SYMBOLS / SYMBOL_MARKETS) over dated snapshots.

3) “get orders with order date and trade date columns”

Top results: ORDERS + ORDERS_* + some TRADES_* and NEGOTIATED_TRADES_*.

Date-like fields listed include ENTRY_DATETIME, STATE_TIME, QUEUING_TIME.

You also see TIF present as a “date column” in your output.

⚠️ Note about TIF: In trading, Time-In-Force (TIF) is usually a code, not a date.
If it’s showing up under date_cols, it likely means the column’s Oracle type is DATE/TIMESTAMP in your schema. If that’s unintended, the crawler is still “correct” (it’s reporting types faithfully). We can:

Leave it (harmless; generator can choose a better date column), or

Add a denylist of column names for date-use in SQL generation (e.g., exclude TIF as a date only at generation time, not at retrieval).

Either way, retrieval is doing its job—type-based identification, not guessing.

General patterns you’re seeing (and why that’s fine)

Many tables with date suffixes (e.g., TRADES_20FEB25, SYMBOL_DAILY_INDICATORS_220721). That’s common in systems with history/snapshots/rollovers.

The retriever is surfacing those because they semantically match your query. That’s correct behavior for recall.

For precision later, we’ll add table preference rules in the SQL generator:

Prefer unsuffixed “base” tables/views (e.g., ORDERS, TRADES, SYMBOLS) when present.

Or, if you truly query snapshots, prefer the latest snapshot by parsing the suffix.

So—is it “right”?

Yes:

Trades queries → trade tables with timestamp fields ✔️

Symbols/listing-date query → symbol tables with listing-like dates ✔️

Orders dates query → orders tables with multiple timestamp fields ✔️

TIF surfaced as a date only because the schema says so (we’ll handle at SQL time) ✔️