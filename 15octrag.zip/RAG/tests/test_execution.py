# run_once.py — generate SQL then execute it against Oracle
from __future__ import annotations
from datetime import datetime
from retriever import SchemaRetriever
from sql_generator import SQLGenerator
from executor import SQLExecutor

FAISS_DIR = "./data/faiss_oracle"
METADATA_JSON = "./data/oracle_schema/ats_schema_metadata.json"
DEFAULT_OWNER = "ATS"

ORACLE_DSN = "192.168.36.227:1521/DEVDB"
ORACLE_USER = "ATS"
ORACLE_PASSWORD = "ABC"

def pick_tables(table_ctxs):
    main = table_ctxs[0]
    dim = next((tc for tc in table_ctxs if "SYMBOL" in tc.table_name.upper() or "INSTRUMENT" in tc.table_name.upper()), None)
    return [main] + ([dim] if dim else [])

def build_ctx(uq, tcs):
    relevant_tables = [f"{tc.owner}.{tc.table_name}" for tc in tcs]
    columns_by_table = {f"{tc.owner}.{tc.table_name}": [c.column_name for c in tc.columns] for tc in tcs}
    relevant_columns = [f"{tbl}.{c}" for tbl, cols in columns_by_table.items() for c in cols]
    return {
        "query": uq,
        "relevant_tables": relevant_tables,
        "relevant_columns": relevant_columns,
        "columns_by_table": columns_by_table,
        "main_table": relevant_tables[0] if relevant_tables else None,
        "context_snippets": [],
    }

def main():
    user_query = "daily trades by instrument between 2024-01-01 and 2024-02-15"

    retriever = SchemaRetriever(persist_dir=FAISS_DIR, metadata_path=METADATA_JSON, default_owner=DEFAULT_OWNER)
    tcs = retriever.retrieve(user_query, k_tables=5, require_date_cols=True, mmr=True, search_k=48)
    if not tcs:
        print("No candidate tables found.")
        return

    picked = pick_tables(tcs)
    ctx = build_ctx(user_query, picked)

    sql = SQLGenerator(dialect="Oracle", model="mistral:7b-instruct", use_llm=True).generate_sql(ctx)
    print("\nSQL to execute:\n", sql)

    # Bind params (datetimes are best for Oracle)
    params = {"from_date": datetime(2024, 1, 1), "to_date": datetime(2024, 2, 15)}

    rows = SQLExecutor().run_query(
        sql, params=params,
        mode="oracle", user=ORACLE_USER, password=ORACLE_PASSWORD, dsn=ORACLE_DSN,
        max_rows=2000, timeout_seconds=60
    )
    print(f"\nReturned {len(rows)} rows.")
    for r in rows[:5]:
        print(r)

if __name__ == "__main__":
    main()
