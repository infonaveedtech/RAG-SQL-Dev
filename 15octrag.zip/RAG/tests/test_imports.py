﻿def test_imports():
    # Simple smoke-test to ensure modules import (placeholders)
    import importlib
    modules = [
        "rag_oracle.config",
        "rag_oracle.crawler",
        "rag_oracle.vectorize",
        "rag_oracle.nl2sql",
    ]
    for m in modules:
        importlib.import_module(m)
