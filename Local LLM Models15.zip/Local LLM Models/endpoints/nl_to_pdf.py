
from fastapi import APIRouter
from endpoints.pipeline import run_pipeline_internal
# from reports.report_utils import generate_report_payload
from reports.pdf_utils import build_report_pdf
import base64

router = APIRouter()

@router.post("/v1/nl-to-pdf")
def nl_to_pdf(payload: dict):
    query = payload["additionalProp1"]
    row_limit = payload.get("row_limit", 200)
    title = payload.get("title", "Report")

    # 1️⃣ Run pipeline internally (NO API response leakage)
    pipeline_result = run_pipeline_internal(
        query=query,
        run_db=True,
        row_limit=row_limit,
        save_artifacts=False
    )

    final_sql = pipeline_result["final_sql"]
    columns = pipeline_result["db"]["columns"]
    rows = pipeline_result["db"]["rows"]

    # 2️⃣ Generate report payload (NO SQL)
    report_payload = {
        "title": title,
        "columns": columns,
        "rows": rows,
        "include_sql": False   # 🔴 important
    }

    # 3️⃣ Generate PDF
    pdf_base64 = build_report_pdf(report_payload)
    pdf_base64 = base64.b64encode(pdf_base64).decode("utf-8")

    return {
        "pdf_base64": pdf_base64,
        "columns": columns,
        "rows": rows
    }
 