﻿# RAG Oracle â€” project scaffold

This repository contains a scaffold for a Retrieval-Augmented-Generation (RAG) pipeline
that works with Oracle trading data. Files are placeholders to be filled once DB details are available.

Next steps:
1. Fill .env.example and src/rag_oracle/config.py with DB credentials/settings.
2. Implement crawler.py (schema & sample extraction).
3. Implement 
l2sql.py, sql_validator.py, and other modules one-by-one.
