# app.py — RAG → SQL Console with retrieval preview + resilient execution
from __future__ import annotations
import os, io, re, datetime as dt
from calendar import monthrange
from typing import Any, Dict, List

import streamlit as st
import pandas as pd

# pipeline modules
from retriever import SchemaRetriever
from sql_generator import SQLGenerator
from executor import SQLExecutor, execute_select  # <- stream-friendly
from utils.query_guard import resolve_instruments, enforce_or_fallback, interpret_ranking_intent
from html_report import render_html, save_html, export_html_to_pdf

# ---------------------------------------------------------------------
# Date helpers
# ---------------------------------------------------------------------
MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
    "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}

def _mk(y: int, m: int, d: int) -> str:
    return f"{y:04d}-{m:02d}-{d:02d}"

def derive_date_params(user_query: str) -> dict:
    if not user_query:
        return {}
    q = user_query.strip().lower().replace("–", "-").replace("—", "-")

    m = re.search(r"between\s+(\d{4}-\d{2}-\d{2})\s+(?:and|to|-|through)\s+(\d{4}-\d{2}-\d{2})", q)
    if m:
        a, b = m.group(1), m.group(2)
        if a > b: a, b = b, a
        return {"from_date": a, "to_date": b}

    m = re.search(r"from\s+(\d{4}-\d{2}-\d{2})\s+(?:to|-|through)\s+(\d{4}-\d{2}-\d{2})", q)
    if m:
        a, b = m.group(1), m.group(2)
        if a > b: a, b = b, a
        return {"from_date": a, "to_date": b}

    m = re.search(r"(?:for|in)\s+(\d{4})-(\d{2})\b", q)
    if m:
        y, mm = int(m.group(1)), int(m.group(2))
        _, last = monthrange(y, mm)
        return {"from_date": _mk(y, mm, 1), "to_date": _mk(y, mm, last)}

    m = re.search(r"between\s+([a-z]+)\s+(?:and|-|to)\s+([a-z]+)\s+(\d{4})", q)
    if m and m.group(1) in MONTHS and m.group(2) in MONTHS:
        y = int(m.group(3)); a, b = MONTHS[m.group(1)], MONTHS[m.group(2)]
        if a > b: a, b = b, a
        _, last = monthrange(y, b)
        return {"from_date": _mk(y, a, 1), "to_date": _mk(y, b, last)}

    m = re.search(r"(?:for|in)\s+([a-z]+)\s+(\d{4})", q)
    if m and m.group(1) in MONTHS:
        y, mm = int(m.group(2)), MONTHS[m.group(1)]
        _, last = monthrange(y, mm)
        return {"from_date": _mk(y, mm, 1), "to_date": _mk(y, mm, last)}

    months = [MONTHS[t] for t in MONTHS if re.search(rf"\b{t}\b", q)]
    years = re.findall(r"\b(20\d{2})\b", q)
    if years and months:
        y = int(years[0]); a, b = min(months), max(months)
        _, last = monthrange(y, b)
        return {"from_date": _mk(y, a, 1), "to_date": _mk(y, b, last)}
    return {}

# ---------------------------------------------------------------------
# UI setup
# ---------------------------------------------------------------------
st.set_page_config(page_title="RAG → SQL Explorer", layout="wide")

# singletons
if "executor" not in st.session_state:
    st.session_state.executor = SQLExecutor()

if "retriever" not in st.session_state:
    st.session_state.retriever = SchemaRetriever(
        persist_dir=os.getenv("VECTOR_DB_DIR", "./data/faiss_oracle"),
        model_name=os.getenv("EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2"),
    )

if "generator" not in st.session_state:
    st.session_state.generator = SQLGenerator(
        use_llm=True,
        backend="ollama",
        model=os.getenv("OLLAMA_MODEL", "mistral:7b-instruct"),
        dialect=os.getenv("SQL_DIALECT", "Oracle"),
    )

execu: SQLExecutor = st.session_state.executor
retr:  SchemaRetriever = st.session_state.retriever
gen:   SQLGenerator   = st.session_state.generator

# ---------------------------------------------------------------------
# Sidebar: connection + table browser
# ---------------------------------------------------------------------
with st.sidebar:
    st.header("🔌 Connection")
    db_mode = st.selectbox("DB Mode", ["oracle", "sqlite"], index=0)
    owner = st.text_input("Oracle Owner", value=os.getenv("ORACLE_OWNER", "ATS"))
    user = st.text_input("Oracle User", value=os.getenv("ORACLE_USER", ""), key="u")
    password = st.text_input("Oracle Password", value=os.getenv("ORACLE_PASSWORD", ""), type="password", key="p")
    dsn = st.text_input("Oracle DSN", value=os.getenv("ORACLE_DSN", "192.168.36.227:1521/DEVDB"), key="d")

    st.markdown("---")
    st.subheader("📚 Tables")
    tables: List[str] = []
    try:
        if db_mode == "sqlite":
            rows = execu.run_query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name", {})
            tables = [r.get("name") for r in rows]
        else:
            q = "SELECT table_name FROM all_tables WHERE owner = :owner ORDER BY table_name"
            rows = execu.run_query(q, {"owner": owner}, mode="oracle", user=user, password=password, dsn=dsn)
            tables = [r.get("TABLE_NAME") for r in rows]
    except Exception as e:
        st.warning(f"Table listing failed: {e}")
    st.caption(f"{len(tables)} tables")
    st.dataframe(pd.DataFrame({"table": tables}), use_container_width=True, height=240)

# ---------------------------------------------------------------------
# Main: query + retrieval preview + execution
# ---------------------------------------------------------------------
st.title("RAG → SQL Report Console")

col1, col2 = st.columns([3, 2], gap="large")
with col1:
    nl_query = st.text_area(
        "📝 Natural-language prompt",
        value="top 10 symbols by average traded price last month",
        height=110,
    )
    manual_dates = st.checkbox("Override dates", value=False)
    md1, md2 = st.columns(2)
    from_date_val, to_date_val = None, None
    if manual_dates:
        from_date_val = md1.date_input("From", value=dt.date(2024, 3, 1))
        to_date_val   = md2.date_input("To",   value=dt.date(2024, 9, 30))

    topk = st.slider("Retriever top-k", min_value=3, max_value=15, value=8, step=1)
    run_btn = st.button("▶️ Run")

with col2:
    st.markdown("#### Ranking intent (auto)")
    ob, lim = interpret_ranking_intent(nl_query)
    st.write(f"**ORDER BY**: `{ob or 'DESC on main metric'}`")
    st.write(f"**LIMIT**: `{lim if lim is not None else 'None'}`")

st.markdown("---")

if run_btn:
    with st.spinner("Retrieving schema context…"):
        # 1) VectorDB retrieval (show hits)
        ctx = retr.retrieve_schema_context(nl_query, k=topk)
        rel_tables = ctx.get("relevant_tables", [])
        rel_cols   = ctx.get("relevant_columns", [])
        snippets   = ctx.get("context_snippets", [])
        hits_df = pd.DataFrame({
            "rank": list(range(1, len(rel_tables)+1)),
            "table": rel_tables,
            "snippet": [s[:200] + ("…" if s and len(s) > 200 else "") for s in snippets]
        })
    st.subheader("📎 Retrieval preview (VectorDB hits)")
    st.dataframe(hits_df, use_container_width=True, height=220)

    # 2) Resolve date params
    params: Dict[str, Any] = {}
    if manual_dates and from_date_val and to_date_val:
        params = {"from_date": from_date_val.strftime("%Y-%m-%d"),
                  "to_date":   to_date_val.strftime("%Y-%m-%d")}
    else:
        params = derive_date_params(nl_query) or {"from_date": "2024-01-01", "to_date": "2024-12-31"}

    # 3) Resolve instruments
    resolved = resolve_instruments(nl_query, execu)
    resolved_names = [r.get("instrument_name") for r in resolved]

    # 4) Generate SQL from LLM with the retrieved context
    gen_ctx = {
        "query": nl_query,
        "relevant_tables": rel_tables,
        "relevant_columns": rel_cols,
        "context_snippets": snippets,
        "resolved_instruments": resolved,
        "faiss_dir": os.getenv("VECTOR_DB_DIR", "./data/faiss_oracle"),
    }
    sql_candidate = gen.generate_sql(gen_ctx)

    # 5) Policy enforcement / fallback pass
    final_sql, final_params, diag = enforce_or_fallback(sql_candidate, params, resolved_names, user_text=nl_query)

    st.subheader("🧠 SQL (candidate)")
    st.code(sql_candidate or "", language="sql")
    st.subheader("🛡️ SQL (executed)")
    st.code(final_sql or "", language="sql")
    st.subheader("🧭 Params")
    st.json(final_params or {})
    st.subheader("ℹ️ Diagnostics")
    st.write(diag)

    # 6) Execute (stream) — show partial rows even on error
    st.subheader("📈 Results")
    rows: List[Dict[str, Any]] = []
    error_msg = None
    start_ts = dt.datetime.now()

    try:
        # Stream rows so we can show partials if something breaks mid-way
        gen_rows = execute_select(
            final_sql,
            final_params,
            fetch_size=500,
            max_rows=10_000,
            timeout_seconds=60,
            mode=db_mode,
            user=user if db_mode == "oracle" else None,
            password=password if db_mode == "oracle" else None,
            dsn=dsn if db_mode == "oracle" else None,
        )
        for r in gen_rows:
            rows.append(r)
    except Exception as e:
        error_msg = str(e)

    if rows:
        st.dataframe(pd.DataFrame(rows), use_container_width=True)
    else:
        st.info("No rows returned.")

    if error_msg:
        st.error(f"DB error (showing any partial rows above if fetched):\n\n{error_msg}")

    # 7) Optional HTML/PDF report (same as your previous block; guarded)
    try:
        os.makedirs("./reports", exist_ok=True)
        mapped_rows = []
        for r in rows:
            if isinstance(r, dict):
                inst = r.get("instrument") or r.get("instrument_name") or r.get("INSTRUMENT") or r.get("SYMBOL_ID")
                total_volume = r.get("total_volume") or r.get("TOTAL_VOLUME") or 0
                total_value  = r.get("total_value")  or r.get("TOTAL_VALUE")  or 0.0
            else:
                inst, total_volume, total_value = r[0], r[1], r[2]
            mapped_rows.append({
                "instrument": inst,
                "total_volume": int(total_volume or 0),
                "total_value": float(total_value or 0.0),
            })

        totals = {
            "total_volume": sum(x["total_volume"] for x in mapped_rows),
            "total_value": sum(x["total_value"] for x in mapped_rows),
        }

        context = {
            "report_title": "Market Summary",
            "as_of_display": (final_params or {}).get("to_date") or (final_params or {}).get("from_date") or dt.date.today().isoformat(),
            "generated_by": "RAG SQL Assistant",
            "rows": mapped_rows,
            "totals": totals,
            "sql": final_sql,
            "row_count": len(mapped_rows),
            "exec_ms": (dt.datetime.now() - start_ts).total_seconds() * 1000.0,
        }

        ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        html = render_html("./templates", "market_summary.html", context)
        html_path = save_html(html, "./reports", f"market_summary_{ts}.html")
        pdf_path = os.path.join("./reports", f"market_summary_{ts}.pdf")
        export_html_to_pdf(html_path, pdf_path)

        st.subheader("🧾 Report preview (HTML)")
        with open(html_path, "r", encoding="utf-8") as f:
            st.components.v1.html(f.read(), height=600, scrolling=True)

        st.download_button("⬇️ Download HTML", data=open(html_path, "rb"), file_name=os.path.basename(html_path), mime="text/html")
        st.download_button("⬇️ Download PDF",  data=open(pdf_path,  "rb"), file_name=os.path.basename(pdf_path),  mime="application/pdf")
        st.caption(f"Saved: {html_path} and {pdf_path}")
    except Exception as e:
        st.warning(f"Report export skipped: {e}")

