﻿# """
# crawler.py — Oracle schema crawler (real ATS schema, full fidelity)

# Purpose:
# --------
# Extracts the real Oracle schema metadata (for one owner, e.g., ATS) —
# no assumptions, no column filtering.

# Collects:
# - Table metadata (name, num_rows, tablespace, comments)
# - Column metadata (name, datatype, length, nullable, comments)
# - Optionally PK info (future)
# and stores them in structured JSON format for later vectorization.

# Usage:
# ------
# python crawler.py
# """

# from __future__ import annotations
# import os
# import json
# import logging
# from typing import Any, Dict, List, DefaultDict
# from collections import defaultdict

# from db_conn import db_session


# # ---------------------------------------------------------------------------
# # Configuration
# # ---------------------------------------------------------------------------
# DEFAULT_OWNER = "ATS"
# SAVE_PATH = "data/oracle_schema/ats_schema_metadata.json"


# # ---------------------------------------------------------------------------
# # Core function: crawl_schema()
# # ---------------------------------------------------------------------------
# def crawl_schema(owner: str = DEFAULT_OWNER,
#                  save_path: str = SAVE_PATH) -> List[Dict[str, Any]]:
#     """
#     Crawl Oracle data dictionary for a specific schema owner and extract
#     all tables, columns, and comments (no assumptions, no guessing).

#     Args:
#         owner (str): Oracle schema owner to crawl (default: ATS)
#         save_path (str): JSON output path

#     Returns:
#         List of dicts, one per table, containing:
#         {
#             "owner": "ATS",
#             "table_name": "TRADES",
#             "num_rows": 12345,
#             "tablespace": "USERS",
#             "table_comment": "Trade transactions table",
#             "columns": [
#                 {
#                     "column_name": "TRADE_ID",
#                     "data_type": "NUMBER",
#                     "data_length": 22,
#                     "nullable": "N",
#                     "column_comment": "Trade identifier"
#                 },
#                 ...
#             ]
#         }
#     """
#     logging.info(f"Starting Oracle schema crawl for owner '{owner}'...")
#     os.makedirs(os.path.dirname(save_path), exist_ok=True)

#     with db_session(mode="oracle", user="ATS", password="ABC", dsn="192.168.36.227:1521/DEVDB") as conn:
#         if not conn:
#             logging.error("No Oracle DB connection available.")
#             return []

#         cur = conn.cursor()
#         # Optimize fetch performance
#         cur.arraysize = 1000

#         # -------------------------------------------------------------------
#         # Step 1: Fetch table-level metadata
#         # -------------------------------------------------------------------
#         table_query = """
#             SELECT owner, table_name, num_rows, tablespace_name
#             FROM all_tables
#             WHERE owner = :owner
#             ORDER BY table_name
#         """
#         cur.execute(table_query, {"owner": owner})
#         tables = [
#             {
#                 "owner": row[0],
#                 "table_name": row[1],
#                 "num_rows": row[2],
#                 "tablespace": row[3],
#             }
#             for row in cur.fetchall()
#         ]
#         logging.info(f"Fetched {len(tables)} tables for owner {owner}.")

#         # -------------------------------------------------------------------
#         # Step 2: Fetch table comments
#         # -------------------------------------------------------------------
#         cur.execute("""
#             SELECT owner, table_name, comments
#             FROM all_tab_comments
#             WHERE owner = :owner
#         """, {"owner": owner})
#         table_comments = {
#             (r[0], r[1]): r[2] for r in cur.fetchall() if r[2]
#         }

#         # -------------------------------------------------------------------
#         # Step 3: Fetch column-level metadata (ALL columns in one go)
#         # -------------------------------------------------------------------
#         col_query = """
#             SELECT owner, table_name, column_name, data_type, data_length, nullable
#             FROM all_tab_columns
#             WHERE owner = :owner
#             ORDER BY table_name, column_id
#         """
#         cur.execute(col_query, {"owner": owner})
#         all_columns: DefaultDict[str, List[Dict[str, Any]]] = defaultdict(list)
#         for row in cur.fetchall():
#             all_columns[row[1]].append({
#                 "column_name": row[2],
#                 "data_type": row[3],
#                 "data_length": row[4],
#                 "nullable": row[5],
#             })
#         logging.info(f"Fetched column metadata for {len(all_columns)} tables.")

#         # -------------------------------------------------------------------
#         # Step 4: Fetch column comments
#         # -------------------------------------------------------------------
#         cur.execute("""
#             SELECT owner, table_name, column_name, comments
#             FROM all_col_comments
#             WHERE owner = :owner
#         """, {"owner": owner})
#         col_comments = {
#             (r[0], r[1], r[2]): r[3] for r in cur.fetchall() if r[3]
#         }

#         # -------------------------------------------------------------------
#         # Step 5: Merge everything into final structure
#         # -------------------------------------------------------------------
#         final_data: List[Dict[str, Any]] = []
#         for t in tables:
#             tname = t["table_name"]
#             tkey = (t["owner"], tname)
#             cols = all_columns.get(tname, [])

#             # attach column comments
#             for c in cols:
#                 ckey = (t["owner"], tname, c["column_name"])
#                 if ckey in col_comments:
#                     c["column_comment"] = col_comments[ckey]

#             record = {
#                 **t,
#                 "table_comment": table_comments.get(tkey),
#                 "columns": cols
#             }
#             final_data.append(record)

#         # -------------------------------------------------------------------
#         # Step 6: Save to disk
#         # -------------------------------------------------------------------
#         with open(save_path, "w", encoding="utf-8") as f:
#             json.dump(final_data, f, indent=2, ensure_ascii=False)

#         logging.info(f"Schema crawl completed. Saved {len(final_data)} tables → {save_path}")

#         return final_data


# # ---------------------------------------------------------------------------
# # Script entry point
# # ---------------------------------------------------------------------------
# if __name__ == "__main__":
#     logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
#     data = crawl_schema()
#     print(f"Extracted metadata for {len(data)} tables.")


"""
crawler.py — Oracle schema crawler (real ATS schema, full fidelity)

Purpose:
--------
Extracts the real Oracle schema metadata (for one owner, e.g., ATS) —
no assumptions, no column filtering.

Collects:
- Table metadata (name, num_rows, tablespace, comments)
- Column metadata (name, datatype, length, nullable, comments)
- (Optional) Small sample rows per table (JSON-serializable, safe types)

Usage:
------
# default crawl (no samples)
python crawler.py

# enable sampling (3 rows per table)
python crawler.py --sample-rows --sample-n 3
"""

from __future__ import annotations
import os
import json
import logging
import argparse
from typing import Any, Dict, List, DefaultDict
from collections import defaultdict
from datetime import datetime, date
from decimal import Decimal

from db_conn import db_session

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
DEFAULT_OWNER = "ATS"
SAVE_PATH = "data/oracle_schema/ats_schema_metadata.json"

# conservative defaults to avoid heavy scans
DEFAULT_SAMPLE_ENABLE = False
DEFAULT_SAMPLE_ROWS = 3
DEFAULT_SAMPLE_MAX_COLS = 1000           # guard against extremely wide tables
DEFAULT_SAMPLE_SKIP_TYPES = {
    "BLOB", "CLOB", "NCLOB", "LONG", "LONG RAW", "RAW", "XMLTYPE", "SDO_GEOMETRY"
}

# ---------------------------------------------------------------------------
# Safe serialization helpers
# ---------------------------------------------------------------------------
def _safe_cell(v: Any) -> Any:
    """Convert DB cell to JSON-serializable value without blowing up."""
    if v is None:
        return None
    if isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, (datetime, date)):
        # ISO 8601 is deterministic, friendly to embeddings
        return v.isoformat(sep=" ")
    if isinstance(v, Decimal):
        # preserve exact text (avoid float rounding)
        return str(v)
    if isinstance(v, (bytes, bytearray, memoryview)):
        return f"<{type(v).__name__} {len(v)} bytes>"
    # fallback: string representation with type tag
    t = type(v).__name__
    s = str(v)
    if len(s) > 500:
        s = s[:500] + "…"
    return f"<{t}:{s}>"

def _row_to_dict(columns: List[str], row: tuple) -> Dict[str, Any]:
    return {columns[i]: _safe_cell(row[i]) for i in range(len(columns))}

# ---------------------------------------------------------------------------
# Sample fetcher
# ---------------------------------------------------------------------------
def _fetch_sample_rows(conn, owner: str, table: str, limit: int = 3, skip_types: set[str] = DEFAULT_SAMPLE_SKIP_TYPES) -> List[Dict[str, Any]]:
    """
    Fetch up to `limit` sample rows from owner.table.
    - Uses ROWNUM to cap rows (works on all Oracle versions).
    - Skips selecting columns with heavy/unsupported types to avoid large payloads.
    - Best effort: if anything fails, returns [].
    """
    try:
        cur = conn.cursor()
        # discover columns & types to filter heavy ones
        cur.execute("""
            SELECT column_name, data_type
            FROM all_tab_columns
            WHERE owner = :owner AND table_name = :table
            ORDER BY column_id
        """, {"owner": owner, "table": table})
        cols_meta = cur.fetchall()
        if not cols_meta:
            return []

        cols = [r[0] for r in cols_meta if str(r[1]).upper() not in skip_types]
        if not cols:
            return []

        # guard against absurdly wide selects
        if len(cols) > DEFAULT_SAMPLE_MAX_COLS:
            cols = cols[:DEFAULT_SAMPLE_MAX_COLS]

        # Quote owner/table/columns safely; Oracle treats quoted identifiers case-sensitive
        q_owner = f'"{owner}"'
        q_table = f'"{table}"'
        q_cols = ", ".join(f'"{c}"' for c in cols)

        # ROWNUM predicate to limit rows
        sql = f"SELECT {q_cols} FROM {q_owner}.{q_table} WHERE ROWNUM <= :lim"

        cur2 = conn.cursor()
        cur2.arraysize = max(50, limit)
        cur2.execute(sql, {"lim": int(limit)})

        # Column names from the select (preserve the chosen/ordered columns)
        colnames = [d[0] for d in cur2.description] if cur2.description else cols

        rows = []
        for r in cur2.fetchmany(limit):
            rows.append(_row_to_dict(colnames, r))
        return rows
    except Exception as e:
        logging.debug(f"Sample fetch failed for {owner}.{table}: {e}")
        return []

# ---------------------------------------------------------------------------
# Core function: crawl_schema()
# ---------------------------------------------------------------------------
def crawl_schema(
    owner: str = DEFAULT_OWNER,
    save_path: str = SAVE_PATH,
    sample_rows: bool = DEFAULT_SAMPLE_ENABLE,
    sample_n: int = DEFAULT_SAMPLE_ROWS
) -> List[Dict[str, Any]]:
    """
    Crawl Oracle data dictionary for a specific schema owner and extract
    all tables, columns, and comments; optionally attach small sample rows.

    Returns: list of table dicts, e.g.:
        {
            "owner": "ATS",
            "table_name": "TRADES",
            "num_rows": 12345,
            "tablespace": "USERS",
            "table_comment": "Trade transactions table",
            "columns": [
                {
                    "column_name": "TRADE_ID",
                    "data_type": "NUMBER",
                    "data_length": 22,
                    "nullable": "N",
                    "column_comment": "Trade identifier"
                },
                ...
            ],
            "sample_rows": [ {"TRADE_ID": 1, "ENTRY_DATE": "2025-10-11 09:30:00", ...}, ... ]   # if enabled
        }
    """
    logging.info(f"Starting Oracle schema crawl for owner '{owner}'...")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    # ⚠️ pass your working creds here or via db_conn defaults
    with db_session(mode="oracle", user="ATS", password="ABC", dsn="192.168.36.227:1521/DEVDB") as conn:
        if not conn:
            logging.error("No Oracle DB connection available.")
            return []

        cur = conn.cursor()
        cur.arraysize = 1000

        # 1) table-level
        table_query = """
            SELECT owner, table_name, num_rows, tablespace_name
            FROM all_tables
            WHERE owner = :owner
            ORDER BY table_name
        """
        cur.execute(table_query, {"owner": owner})
        tables = [
            {
                "owner": row[0],
                "table_name": row[1],
                "num_rows": row[2],
                "tablespace": row[3],
            }
            for row in cur.fetchall()
        ]
        logging.info(f"Fetched {len(tables)} tables for owner {owner}.")

        # 2) table comments
        cur.execute("""
            SELECT owner, table_name, comments
            FROM all_tab_comments
            WHERE owner = :owner
        """, {"owner": owner})
        table_comments = { (r[0], r[1]): r[2] for r in cur.fetchall() if r[2] }

        # 3) columns
        col_query = """
            SELECT owner, table_name, column_name, data_type, data_length, nullable
            FROM all_tab_columns
            WHERE owner = :owner
            ORDER BY table_name, column_id
        """
        cur.execute(col_query, {"owner": owner})
        all_columns: DefaultDict[str, List[Dict[str, Any]]] = defaultdict(list)
        for row in cur.fetchall():
            all_columns[row[1]].append({
                "column_name": row[2],
                "data_type": row[3],
                "data_length": row[4],
                "nullable": row[5],
            })
        logging.info(f"Fetched column metadata for {len(all_columns)} tables.")

        # 4) column comments
        cur.execute("""
            SELECT owner, table_name, column_name, comments
            FROM all_col_comments
            WHERE owner = :owner
        """, {"owner": owner})
        col_comments = { (r[0], r[1], r[2]): r[3] for r in cur.fetchall() if r[3] }

        # 5) merge & optional sample rows
        final_data: List[Dict[str, Any]] = []
        for t in tables:
            tname = t["table_name"]
            tkey = (t["owner"], tname)
            cols = all_columns.get(tname, [])

            # attach column comments
            for c in cols:
                ckey = (t["owner"], tname, c["column_name"])
                if ckey in col_comments:
                    c["column_comment"] = col_comments[ckey]

            record = {
                **t,
                "table_comment": table_comments.get(tkey),
                "columns": cols
            }

            if sample_rows and sample_n > 0:
                samples = _fetch_sample_rows(conn, owner=t["owner"], table=tname, limit=sample_n)
                if samples:
                    record["sample_rows"] = samples

            final_data.append(record)

        # 6) save
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(final_data, f, indent=2, ensure_ascii=False)

        logging.info(f"Schema crawl completed. Saved {len(final_data)} tables → {save_path}")
        return final_data

# ---------------------------------------------------------------------------
# Script entry
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    ap = argparse.ArgumentParser()
    ap.add_argument("--owner", default=DEFAULT_OWNER)
    ap.add_argument("--out", default=SAVE_PATH)
    ap.add_argument("--sample-rows", action="store_true", help="Attach up to N sample rows per table")
    ap.add_argument("--sample-n", type=int, default=DEFAULT_SAMPLE_ROWS, help="Number of rows per table when sampling")
    args = ap.parse_args()

    data = crawl_schema(
        owner=args.owner,
        save_path=args.out,
        sample_rows=args.sample_rows,
        sample_n=args.sample_n,
    )
    print(f"Extracted metadata for {len(data)} tables. Sample rows: {'ON' if args.sample_rows else 'OFF'}")
