﻿# executor.py — hardened streaming executor for Oracle / mock
from __future__ import annotations
import logging
import re
import time
from typing import Any, Dict, Generator, Iterable, List, Optional, Tuple

from db_conn import db_session
try:
    # optional mock support (your existing helper)
    from tests.mock_data import create_mock_db_connection
except Exception:  # pragma: no cover
    create_mock_db_connection = None  # type: ignore

# ---------------------------------------------------------------------
# Safety checks
# ---------------------------------------------------------------------

import datetime as _dt

def _normalize_bind_name(name: str) -> str:
    """Strip leading colon and normalize case (Oracle bind names are case-sensitive in Python dicts)."""
    if not name:
        return name
    return name.lstrip(":")  # keep original case used in SQL; we won’t lower()

def _normalize_params_for_oracle(sql: str, params: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """
    - Accept keys with or without ':' and normalize to names WITHOUT ':'.
    - Coerce common date strings to datetime so we don't depend on NLS_DATE_FORMAT.
    """
    params = params or {}
    norm: Dict[str, Any] = {}

    # Map SQL bind names appearing in the text (without colon)
    bind_names = re.findall(r":([A-Za-z_][A-Za-z0-9_]*)", sql)
    bind_set = set(bind_names)

    def _maybe_parse_date(v: Any) -> Any:
        if isinstance(v, (_dt.date, _dt.datetime)):
            return v
        if isinstance(v, str):
            s = v.strip()
            # super simple ISO-ish handling first
            for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%b-%Y", "%d-%m-%Y", "%Y%m%d"):
                try:
                    d = _dt.datetime.strptime(s, fmt)
                    return d
                except Exception:
                    pass
            # last resort: try fromisoformat (handles 'YYYY-MM-DDTHH:MM:SS' etc.)
            try:
                d = _dt.datetime.fromisoformat(s)
                return d
            except Exception:
                return v  # leave as-is
        return v

    # Normalize names and coerce values
    for k, v in params.items():
        nk = _normalize_bind_name(k)
        if nk in bind_set:
            norm[nk] = _maybe_parse_date(v)

    return norm


_SELECT_ONLY = re.compile(r"^\s*select\b", re.IGNORECASE | re.DOTALL)

FORBIDDEN = {
    "insert","update","delete","merge","drop","truncate","alter","create",
    "grant","revoke","exec","execute","call"
}

def _sanitize_for_execute(sql: str) -> str:
    """Keep first statement; strip comments and trailing semicolon for driver."""
    s = sql.strip()
    # keep first statement only
    parts = [p.strip() for p in s.split(";") if p.strip()]
    s = parts[0] if parts else ""
    # strip -- and /* ... */
    s = re.sub(r"--.*?$", "", s, flags=re.MULTILINE).strip()
    s = re.sub(r"/\*.*?\*/", "", s, flags=re.DOTALL).strip()
    # collapse whitespace
    s = re.sub(r"\s+", " ", s).strip()
    # ensure it doesn't end with ;
    if s.endswith(";"):
        s = s[:-1].strip()
    return s

def _is_safe_select(sql: str) -> Tuple[bool, Optional[str]]:
    """Must be a single SELECT and contain no forbidden tokens or extra semicolons."""
    s = (sql or "").strip()
    if not s or not _SELECT_ONLY.match(s):
        return False, "Only a single SELECT statement is allowed."
    low = s.lower()
    for tok in FORBIDDEN:
        if re.search(rf"\b{re.escape(tok)}\b", low):
            return False, f"Forbidden token in SQL: {tok}"
    # absolutely no second statement
    if ";" in s[:-1]:
        return False, "Multiple statements are not allowed."
    return True, None



def _extract_binds(sql: str) -> List[str]:
    # Oracle bind names: :name (not :: or :1 numeric)
    names = re.findall(r":([A-Za-z_][A-Za-z0-9_]*)", sql)
    # de-dup preserving order
    seen = set()
    out = []
    for n in names:
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out

def execute_select(
    sql_text: str,
    params: Optional[Dict[str, Any]] = None,
    *,
    fetch_size: int = 500,
    max_rows: int = 10000,
    timeout_seconds: Optional[int] = None,
    # connection options
    mode: str = "oracle",
    user: Optional[str] = None,
    password: Optional[str] = None,
    dsn: Optional[str] = None,
) -> Generator[Dict[str, Any], None, None]:
    ok, msg = _is_safe_select(sql_text)
    if not ok:
        raise ValueError(f"Unsafe SQL: {msg}")
    
    sanitized = _sanitize_for_execute(sql_text)

    # 1) extract bind names present in SQL
    bind_names = re.findall(r":([A-Za-z_][A-Za-z0-9_]*)", sanitized)

    # 2) normalize and coerce params
    params_in = params or {}
    params = _normalize_params_for_oracle(sanitized, params_in)

    # 3) warn about unused or missing binds
    expected = set(bind_names)
    provided = set(params.keys())

    missing = expected - provided
    extra = set(_normalize_bind_name(k) for k in params_in.keys()) - expected

    if extra:
        logging.warning(f"Dropping unused bind params not in SQL: {sorted(extra)}")
    if missing:
        raise ValueError(f"Missing required bind params: {sorted(missing)}")

    start = time.time()
    rows_out = 0

    with db_session(mode=mode, user=user, password=password, dsn=dsn) as conn:
        if conn is None:
            if not create_mock_db_connection:
                raise ConnectionError("No DB connection and mock is unavailable.")
            logging.warning("⚠️ No Oracle connection. Falling back to Mock (SQLite) DB.")
            conn, _ = create_mock_db_connection()

        if timeout_seconds and hasattr(conn, "call_timeout"):
            try:
                conn.call_timeout = int(timeout_seconds * 1000)
            except Exception:
                pass

        cur = conn.cursor()
        try:
            try:
                cur.arraysize = int(fetch_size)
            except Exception:
                pass

            logging.info(f"Executing SQL: {sanitized} | binds={bind_names} | params={params}")
            cur.execute(sanitized, params)

            columns = [d[0] for d in (cur.description or [])]
            while True:
                if timeout_seconds and (time.time() - start) > timeout_seconds:
                    logging.warning("⏱️ Query timed out (client-side). Stopping fetch loop.")
                    break

                batch = cur.fetchmany(fetch_size)
                if not batch:
                    break

                for row in batch:
                    yield {columns[i]: row[i] for i in range(len(columns))}
                    rows_out += 1
                    if rows_out >= max_rows:
                        logging.info(f"Reached max_rows={max_rows}; stopping.")
                        return
        except Exception as e:
            # Surface concise DB error with SQL snippet
            msg = getattr(e, "args", [str(e)])[0]
            logging.error(f"DB execute failed: {msg}")
            raise
        
        finally:
            try:
                cur.close()
            except Exception:
                pass


def fetch_all(
    sql_text: str,
    params: Optional[Dict[str, Any]] = None,
    *,
    max_rows: int = 10000,
    timeout_seconds: Optional[int] = None,
    mode: str = "oracle",
    user: Optional[str] = None,
    password: Optional[str] = None,
    dsn: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Collect up to max_rows into a list (for small/medium results)."""
    return list(
        execute_select(
            sql_text,
            params,
            fetch_size=1000,
            max_rows=max_rows,
            timeout_seconds=timeout_seconds,
            mode=mode,
            user=user,
            password=password,
            dsn=dsn,
        )
    )

class SQLExecutor:
    """Thin OO wrapper your pipeline can use uniformly."""

    def __init__(self, use_mock: bool = False):
        self.use_mock = use_mock

    def run_query(
        self,
        sql_text: str,
        params: Optional[Dict[str, Any]] = None,
        *,
        max_rows: int = 10000,
        timeout_seconds: Optional[int] = None,
        mode: str = "oracle",
        user: Optional[str] = None,
        password: Optional[str] = None,
        dsn: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        if self.use_mock:
            # Force mock regardless of db_session outcome
            if not create_mock_db_connection:
                raise ConnectionError("Mock requested but unavailable.")
            conn, _ = create_mock_db_connection()
            cur = conn.cursor()
            try:
                cur.execute(_sanitize_for_execute(sql_text), params or {})
                cols = [d[0] for d in cur.description or []]
                rows = cur.fetchall()
                return [{cols[i]: r[i] for i in range(len(cols))} for r in rows][:max_rows]
            finally:
                try:
                    cur.close()
                except Exception:
                    pass
        else:
            return fetch_all(
                sql_text,
                params=params,
                max_rows=max_rows,
                timeout_seconds=timeout_seconds,
                mode=mode,
                user=user,
                password=password,
                dsn=dsn,
            )
