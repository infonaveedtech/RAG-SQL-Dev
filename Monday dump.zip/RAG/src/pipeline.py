# """
# pipeline.py — RAG → LLM SQL → Execute → HTML → PDF
# """

# from __future__ import annotations
# import os
# import re
# import time
# import datetime
# from datetime import date
# from calendar import monthrange

# from retriever import SchemaRetriever
# from sql_generator import SQLGenerator
# from executor import SQLExecutor
# from formatter import ReportFormatter

# from html_report import render_html, save_html, export_html_to_pdf  # NEW
# from utils.query_guard import resolve_instruments, enforce_or_fallback


# # --------- Utilities Functions--------------------
# # ---------- date parsing ----------
# MONTHS = {
#     "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
#     "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7,
#     "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9,
#     "oct": 10, "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
# }

# def derive_date_params(user_query: str) -> dict:
#     """
#     Returns {"from_date":"YYYY-MM-DD", "to_date":"YYYY-MM-DD"} when it can,
#     else {}. Handles:
#       - between 2024-01-01 and 2024-03-31
#       - from 2024-01-01 to 2024-03-31
#       - in 2024-02
#       - between Mar and Apr 2024 / Mar–Apr 2024
#       - for/in <Month> <Year>
#       - mentions of multiple month names + a year (unordered)
#     """
#     if not user_query:
#         return {}
#     q = user_query.strip().lower()

#     def _mk(y: int, m: int, d: int) -> str:
#         return f"{y:04d}-{m:02d}-{d:02d}"

#     # 0) canonicalize separators like en dash/em dash
#     q = q.replace("–", "-").replace("—", "-")

#     # A) between YYYY-MM-DD and YYYY-MM-DD
#     m = re.search(r"between\s+(\d{4}-\d{2}-\d{2})\s+(?:and|to|-|through)\s+(\d{4}-\d{2}-\d{2})", q)
#     if m:
#         a, b = m.group(1), m.group(2)
#         if a > b: a, b = b, a
#         return {"from_date": a, "to_date": b}

#     # B) from YYYY-MM-DD to YYYY-MM-DD
#     m = re.search(r"from\s+(\d{4}-\d{2}-\d{2})\s+(?:to|-|through)\s+(\d{4}-\d{2}-\d{2})", q)
#     if m:
#         a, b = m.group(1), m.group(2)
#         if a > b: a, b = b, a
#         return {"from_date": a, "to_date": b}

#     # C) in YYYY-MM  (whole month)
#     m = re.search(r"(?:for|in)\s+(\d{4})-(\d{2})\b", q)
#     if m:
#         y, mm = int(m.group(1)), int(m.group(2))
#         _, last = monthrange(y, mm)
#         return {"from_date": _mk(y, mm, 1), "to_date": _mk(y, mm, last)}

#     # D) between Mar and Apr 2024   (month words + year)
#     m = re.search(r"between\s+([a-z]+)\s+(?:and|-|to)\s+([a-z]+)\s+(\d{4})", q)
#     if m and m.group(1) in MONTHS and m.group(2) in MONTHS:
#         y = int(m.group(3))
#         a, b = MONTHS[m.group(1)], MONTHS[m.group(2)]
#         if a > b: a, b = b, a
#         _, last = monthrange(y, b)
#         return {"from_date": _mk(y, a, 1), "to_date": _mk(y, b, last)}

#     # E) for/in <Month> <Year>
#     m = re.search(r"(?:for|in)\s+([a-z]+)\s+(\d{4})", q)
#     if m and m.group(1) in MONTHS:
#         y, mm = int(m.group(2)), MONTHS[m.group(1)]
#         _, last = monthrange(y, mm)
#         return {"from_date": _mk(y, mm, 1), "to_date": _mk(y, mm, last)}

#     # F) mention multiple month names + year (unordered)
#     months = [MONTHS[t] for t in MONTHS if re.search(rf"\b{t}\b", q)]
#     years = re.findall(r"\b(20\d{2})\b", q)
#     if years and months:
#         y = int(years[0])
#         a, b = min(months), max(months)
#         _, last = monthrange(y, b)
#         return {"from_date": _mk(y, a, 1), "to_date": _mk(y, b, last)}

#     return {}


# # ---------- pipeline ----------
# class RAGPipeline:
#     def __init__(
#         self,
#         retriever: SchemaRetriever,
#         sql_generator: SQLGenerator,
#         executor: SQLExecutor,
#         formatter: ReportFormatter,
#         templates_dir: str = "./templates",
#         reports_dir: str = "./reports",
#         html_template_name: str = "market_summary.html",
#         report_title: str = "Market Summary",
#         generated_by: str = "RAG SQL Assistant"
#     ):
#         self.retriever = retriever
#         self.sql_generator = sql_generator
#         self.executor = executor
#         self.formatter = formatter
#         self.templates_dir = templates_dir
#         self.reports_dir = reports_dir
#         self.html_template_name = html_template_name
#         self.report_title = report_title
#         self.generated_by = generated_by

#     def run(self, natural_query: str, from_date: str | None = None, to_date: str | None = None, export: str = "html") -> str:
#         print("\n🚀 Starting RAG Pipeline Execution...")
#         start_ts = time.perf_counter()
#         start_dt = datetime.datetime.now()

#         # 1) Retrieve context
#         print("🔍 Retrieving relevant schema context...")
#         ctx = self.retriever.retrieve_schema_context(natural_query)
#         print(f"✅ Retrieved {len(ctx)} context entries")
        
#         # 1.5) Resolve instrument names deterministically (works with Oracle or mock)
#         resolved = resolve_instruments(natural_query, self.executor)
#         if resolved:
#             print(f"🔎 Resolved instruments: {[r.get('instrument_name') for r in resolved]}")

#         # 2) Generate candidate SQL (LLM)
#         print("🧠 Generating SQL query from natural language...")
#         gen_ctx = {
#             "query": natural_query,
#             "relevant_tables": ctx.get("relevant_tables", []),
#             "relevant_columns": ctx.get("relevant_columns", []),
#             "context_snippets": ctx.get("context_snippets", []),
#             # pass resolved to help the prompt (your SQLGenerator can ignore it if not used)
#             "resolved_instruments": resolved,
#         }
#         sql_candidate = self.sql_generator.generate_sql(gen_ctx)
#         print(f"✅ Generated SQL (candidate):\n{sql_candidate}\n")

#         # 3) Params + Guard + Execute
#         base_params = {"from_date": from_date, "to_date": to_date} if (from_date and to_date) else derive_date_params(natural_query)

#         # If no date params were found, skip the guard (your current behavior) and run as-is
#         if not base_params:
#             print("⚠️ No date params resolved — executing candidate SQL without guard.")
#             print("🗄️  Executing SQL query on Oracle DB...")
#             rows = self.executor.run_query(sql_candidate, params=None)
#             end_dt = datetime.datetime.now()
#             exec_ms = int((time.perf_counter() - start_ts) * 1000)

#         else:
#             # Enforce correctness or fall back to deterministic safe SQL
#             resolved_names = [r.get("instrument_name") for r in resolved]
#             final_sql, final_params, diag = enforce_or_fallback(sql_candidate, base_params, resolved_names, user_text=natural_query)
#             # final_sql, final_params, diag = enforce_or_fallback(sql_candidate, base_params, resolved_names)
#             print(f"🛡️ SQL guard mode: {diag.get('mode')}" + (f" | reason: {diag.get('reason')}" if diag.get('reason') else ""))
#             print(f"🧭 Using params: {final_params}")
#             print("🗄️  Executing SQL query on Oracle DB...")
#             rows = self.executor.run_query(final_sql, params=final_params)
#             end_dt = datetime.datetime.now()
#             exec_ms = int((time.perf_counter() - start_ts) * 1000)

#         # carry the final SQL we executed for downstream reporting (HTML/PDF)
#         sql = final_sql if base_params else sql_candidate


#         # 4) Quick console HTML view you already have
#         print("📄 Formatting final report (HTML quick view)...")
#         quick = self.formatter.format_table(
#             rows=rows,
#             query=natural_query,
#             sql=sql,
#             start_time=start_dt,        # you already set this earlier
#             end_time=end_dt,            # <-- use end_dt
#             export=export,
#         )

#         self.formatter.display(quick)

#         # 5) HTML → PDF with our template
#         try:
#             # Make rows schema for the HTML table {instrument, total_volume, total_value}
#             # If your SQL already returns those aliases, great. Otherwise map them:
#             mapped_rows = []
#             for r in rows:
#                 # handle both dict and tuple-ish rows; your executor returns dicts already
#                 inst = r.get("instrument") or r.get("instrument_id") or r.get("instrument_name")
#                 total_volume = r.get("total_volume") or r.get("SUM(trade_volume)") or r.get("sum_trade_volume")
#                 total_value  = r.get("total_value") or r.get("SUM(trade_volume * trade_price)") or r.get("sum_value")
#                 mapped_rows.append({
#                     "instrument": inst,
#                     "total_volume": int(total_volume or 0),
#                     "total_value": float(total_value or 0.0),
#                 })

#             totals = {
#                 "total_volume": sum(x["total_volume"] for x in mapped_rows),
#                 "total_value": sum(x["total_value"] for x in mapped_rows),
#             }

#             as_of_display = (to_date or from_date) or datetime.datetime.now().strftime("%Y-%m-%d")
#             context = {
#                 "report_title": self.report_title,
#                 "as_of_display": as_of_display,
#                 "generated_by": self.generated_by,
#                 "rows": mapped_rows,
#                 "totals": totals,
#                 "sql": sql,
#                 "row_count": len(mapped_rows),
#                 "exec_ms": exec_ms,
#             }

#             html = render_html(self.templates_dir, self.html_template_name, context)
#             ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
#             html_path = save_html(html, self.reports_dir, f"market_summary_{ts}.html")
#             pdf_path = os.path.join(self.reports_dir, f"market_summary_{ts}.pdf")
#             export_html_to_pdf(html_path, pdf_path)
#             print(f"✅ HTML saved: {html_path}")
#             print(f"✅ PDF  saved: {pdf_path}")
#         except Exception as e:
#             print(f"⚠️ HTML/PDF generation skipped: {e}")

#         print("🎯 Pipeline complete.")
#         return quick


# # -------------- CLI --------------
# if __name__ == "__main__":
#     retriever = SchemaRetriever(
#         persist_dir=os.getenv("VECTOR_DB_DIR", "./data/faiss"),
#         model_name=os.getenv("EMBED_MODEL", "sentence-transformers/all-MiniLM-L6-v2"),
#     )

#     # local LLM via Ollama (use 'sqlcoder' after it’s pulled)
#     from os import getenv
#     sql_generator = SQLGenerator(
#         use_llm=True,
#         backend="ollama",
#         model=getenv("OLLAMA_MODEL", "mistral:7b-instruct"),
#         dialect=getenv("SQL_DIALECT", "SQLite"),
#     )

#     executor = SQLExecutor()  # auto-falls back to mock SQLite if Oracle not configured
#     formatter = ReportFormatter()

#     pipeline = RAGPipeline(
#         retriever=retriever,
#         sql_generator=sql_generator,
#         executor=executor,
#         formatter=formatter,
#         templates_dir="./templates",
#         reports_dir="./reports",
#         html_template_name="market_summary.html",
#         report_title="Market Summary",
#         generated_by="RAG SQL Assistant",
#     )

#     pipeline.run(
#         # natural_query="Top instrument by total volume in 2024-02."
#         natural_query= "Bottom 3 instruments by total value between 2024-01-01 and 2024-03-31",
#         # natural_query="Compare Alpha Bond Corp and Lumen Metals Inc from 2024-01-01 to 2024-02-29",
#         # natural_query="Compare All company volumns and value and pick the top 4 from 2024-01-01 to 2024-10-29",
#         # natural_query="Show total trade volume and value for Alpha Bond Corp and Lumen Metals between Jan and Feb 2024",
#         # natural_query="Show total trade volume and value for each instrument between Jan and Feb 2024",
#         # from_date="2024-01-01", to_date="2024-02-29",
#         # export="html",
#     )
