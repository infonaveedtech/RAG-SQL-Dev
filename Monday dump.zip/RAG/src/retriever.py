﻿# """
# retriever.py
# -------------
# This module retrieves the most relevant database schema/context from
# the vector store given a natural language query.

# It will later feed into the SQL generation step.
# """

# import os
# from typing import Dict, List, Any
# from langchain_huggingface import HuggingFaceEmbeddings
# from langchain_community.vectorstores import FAISS

# class SchemaRetriever:
#     def __init__(self, persist_dir: str = "./data/faiss", model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
#         self.persist_dir = persist_dir
#         self.embedder = HuggingFaceEmbeddings(model_name=model_name)
#         if not os.path.exists(persist_dir):
#             raise FileNotFoundError(f"❌ Vector store not found at {persist_dir}. Run vectorize.py first.")
#         # allow_dangerous_deserialization=True is needed for local FAISS
#         self.vectorstore = FAISS.load_local(persist_dir, self.embedder, allow_dangerous_deserialization=True)

#     def retrieve_schema_context(self, query: str, k: int = 5):
#         print(f"🔍 Searching for schema info relevant to query: '{query}'")
#         results = self.vectorstore.similarity_search(query, k=k)

#         tables, columns, context_snippets = set(), set(), []
#         for res in results:
#             md = res.metadata or {}
#             if md.get("table_name"): tables.add(md["table_name"])

#             # ✅ robust column extraction: supports "column_name" and/or "columns"
#             col_meta = md.get("column_name") or md.get("columns")
#             if isinstance(col_meta, str):
#                 for c in [x.strip() for x in col_meta.split(",") if x.strip()]:
#                     columns.add(c)
#             elif isinstance(col_meta, list):
#                 for c in col_meta:
#                     if c: columns.add(str(c).strip())

#             context_snippets.append(res.page_content.strip())

#         structured_context = {
#             "query": query,
#             "relevant_tables": sorted(tables),
#             "relevant_columns": sorted(columns),
#             "context_snippets": context_snippets,
#         }

#         print("\n🎯 Retrieved Context Summary:")
#         print(f"   Tables: {sorted(tables)}")
#         print(f"   Columns: {sorted(columns)}")
#         print(f"   Snippets: {len(context_snippets)} found\n")
#         return structured_context

"""
retriever.py
-------------
Production-grade schema retriever over FAISS + Oracle metadata.

Design:
- Load FAISS (built by vectorize.py) for fast ANN.
- Load crawler metadata JSON to hydrate full, exact columns.
- Retrieve top-K chunks, aggregate to tables, filter by owner/date-cols.
- Return structured TableContext objects (no assumptions, no guessing names).
"""

from __future__ import annotations
import os, json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS


# -----------------------------
# Data models
# -----------------------------
@dataclass
class ColumnInfo:
    column_name: str
    data_type: Optional[str] = None
    data_length: Optional[int] = None
    nullable: Optional[str] = None
    column_comment: Optional[str] = None

@dataclass
class TableContext:
    owner: str
    table_name: str
    columns: List[ColumnInfo]               # full, exact set
    date_cols: List[str]                    # type-based (DATE/TIMESTAMP)
    top_chunk_scores: List[Tuple[str,float]]  # [(chunk_type, score)], for transparency


# -----------------------------
# Utilities
# -----------------------------
def _load_metadata(metadata_path: str) -> Dict[Tuple[str,str], Dict[str, Any]]:
    """Load crawler JSON; return map keyed by (owner, table_name)."""
    if not os.path.exists(metadata_path):
        raise FileNotFoundError(f"Metadata JSON not found: {metadata_path}")
    with open(metadata_path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    out: Dict[Tuple[str,str], Dict[str, Any]] = {}
    if isinstance(raw, list):
        for t in raw:
            owner = (t.get("owner") or "").upper()
            tbl = (t.get("table_name") or "").upper()
            if owner and tbl:
                out[(owner, tbl)] = t
    elif isinstance(raw, dict):
        # legacy shape {table_name: {...}}
        for tbl, t in raw.items():
            owner = (t.get("owner") or "ATS").upper()
            out[(owner, (t.get("table_name") or tbl).upper())] = t
    else:
        raise ValueError("Unsupported metadata JSON shape (expected list or dict).")
    return out

def _type_is_date_like(oracle_type: Optional[str]) -> bool:
    if not oracle_type:
        return False
    t = oracle_type.upper()
    return ("DATE" in t) or ("TIMESTAMP" in t)

def _columns_from_meta(table_meta: Dict[str, Any]) -> List[ColumnInfo]:
    cols = []
    for c in (table_meta.get("columns") or []):
        cols.append(
            ColumnInfo(
                column_name=c.get("column_name"),
                data_type=c.get("data_type"),
                data_length=c.get("data_length"),
                nullable=c.get("nullable"),
                column_comment=c.get("column_comment"),
            )
        )
    return cols

def _date_cols_from_meta(table_meta: Dict[str, Any]) -> List[str]:
    cols = []
    for c in (table_meta.get("columns") or []):
        if _type_is_date_like(c.get("data_type")) and c.get("column_name"):
            cols.append(c["column_name"])
    return cols


# -----------------------------
# Retriever
# -----------------------------
class SchemaRetriever:
    def __init__(
        self,
        persist_dir: str = "./data/faiss_oracle",
        metadata_path: str = "./data/oracle_schema/ats_schema_metadata.json",
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        default_owner: Optional[str] = "ATS",
    ):
        if not os.path.exists(persist_dir):
            raise FileNotFoundError(f"❌ Vector store not found at {persist_dir}. Run vectorize.py first.")
        self.persist_dir = persist_dir
        self.embedder = HuggingFaceEmbeddings(model_name=model_name)
        # allow_dangerous_deserialization=True is required for local FAISS
        self.vectorstore = FAISS.load_local(
            persist_dir, self.embedder, allow_dangerous_deserialization=True
        )
        self.meta_index = _load_metadata(metadata_path)
        self.default_owner = (default_owner or "").upper() if default_owner else None

    # ---- public API
    def retrieve(
        self,
        query: str,
        k_tables: int = 8,
        owners: Optional[List[str]] = None,
        require_date_cols: bool = True,
        search_k: int = 32,
        mmr: bool = True,
        score_threshold: Optional[float] = None,
    ) -> List[TableContext]:
        """
        Retrieve top-K tables relevant to query.

        Args:
          query: natural language
          k_tables: number of tables to return
          owners: restrict to owners; defaults to [default_owner] if set
          require_date_cols: keep only tables with DATE/TIMESTAMP columns
          search_k: initial chunk candidates to pull from FAISS
          mmr: use Maximal Marginal Relevance for diversified chunks
          score_threshold: optional min similarity score (0..1 cosine-ish)

        Returns:
          List[TableContext] sorted by best chunk score (desc).
        """
        owners_norm = [o.upper() for o in (owners or ([self.default_owner] if self.default_owner else []))]

        # 1) Pull chunk candidates
        if mmr and hasattr(self.vectorstore, "max_marginal_relevance_search_with_score"):
            results = self.vectorstore.max_marginal_relevance_search_with_score(
                query, k=search_k, fetch_k=max(search_k*2, 50)
            )
        else:
            # similarity with score
            if hasattr(self.vectorstore, "similarity_search_with_score"):
                results = self.vectorstore.similarity_search_with_score(query, k=search_k)
            else:
                # fallback (no scores)
                docs = self.vectorstore.similarity_search(query, k=search_k)
                results = [(d, 0.0) for d in docs]

        # 2) Aggregate chunks → tables (owner, table_name)
        by_table: Dict[Tuple[str,str], Dict[str, Any]] = {}
        for doc, score in results:
            md = doc.metadata or {}
            owner = (md.get("owner") or self.default_owner or "").upper()
            table = (md.get("table_name") or "").upper()
            if not owner or not table:
                continue
            if owners_norm and owner not in owners_norm:
                continue
            key = (owner, table)
            entry = by_table.setdefault(key, {"scores": [], "chunk_types": []})
            entry["scores"].append(float(score))
            entry["chunk_types"].append(md.get("chunk_type") or "unknown")

        # 3) Hydrate with full metadata + filter
        contexts: List[TableContext] = []
        for key, agg in by_table.items():
            meta = self.meta_index.get(key)
            if not meta:
                continue  # vector store might have stale entries; ignore
            cols = _columns_from_meta(meta)
            date_cols = _date_cols_from_meta(meta)
            if require_date_cols and not date_cols:
                continue
            # Track a few top chunk types & their best scores for transparency
            top_scores = sorted(agg["scores"], reverse=True)[:3]
            top_types = agg["chunk_types"][:3]
            contexts.append(
                TableContext(
                    owner=key[0],
                    table_name=key[1],
                    columns=cols,
                    date_cols=date_cols,
                    top_chunk_scores=list(zip(top_types, top_scores)),
                )
            )

        # 4) Rank tables by best score
        contexts.sort(key=lambda c: (c.top_chunk_scores[0][1] if c.top_chunk_scores else 0.0), reverse=True)

        # 5) Optional threshold
        if score_threshold is not None:
            contexts = [c for c in contexts if (c.top_chunk_scores and c.top_chunk_scores[0][1] >= score_threshold)]

        # 6) Truncate to k_tables
        return contexts[:k_tables]

    # Convenience wrapper matching your old name (so callers don't break)
    def retrieve_schema_context(self, query: str, k: int = 5):
        """
        Legacy-style context summary (tables/columns/snippets), using the
        new structured retrieve() internally. This keeps older code working.
        """
        contexts = self.retrieve(query=query, k_tables=k)
        tables = [f"{c.owner}.{c.table_name}" for c in contexts]
        all_cols = sorted({col.column_name for c in contexts for col in c.columns if col.column_name})
        # We no longer rely on raw snippets; we prefer structured context. Provide light placeholders.
        context_snippets = [f"{c.owner}.{c.table_name}: {len(c.columns)} columns; date_cols={c.date_cols[:3]}" for c in contexts]
        return {
            "query": query,
            "relevant_tables": tables,
            "relevant_columns": all_cols,
            "context_snippets": context_snippets,
        }
        
        
# ---------------------------------------------------------------------------
# Quick smoke test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import pprint
    import logging
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    print("\n🚀 Testing SchemaRetriever with FAISS index and Oracle metadata...\n")

    retriever = SchemaRetriever(
        persist_dir="./data/faiss_oracle",
        metadata_path="./data/oracle_schema/ats_schema_metadata.json",
        default_owner="ATS",
    )

    # 🔍 Try a few realistic natural-language queries
    test_queries = [
        "daily trades by instrument between dates",
        "fetch all symbols listed after 2020",
        "get orders with order date and trade date columns",
    ]

    for q in test_queries:
        print(f"\n🧠 Query: {q}")
        contexts = retriever.retrieve(query=q, k_tables=5, require_date_cols=True)
        print(f"→ Retrieved {len(contexts)} candidate tables\n")
        for ctx in contexts:
            print(f"   📄 {ctx.owner}.{ctx.table_name}")
            print(f"      Columns: {len(ctx.columns)} total")
            print(f"      Date columns: {ctx.date_cols[:5]}")
            print(f"      Top chunk scores: {ctx.top_chunk_scores[:3]}")
        print("-" * 70)

    print("\n✅ Retrieval test complete.")
