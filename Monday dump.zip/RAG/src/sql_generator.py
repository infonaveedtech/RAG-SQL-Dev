﻿# sql_generator.py — enrichment-aware, Oracle-focused generator
from __future__ import annotations
from typing import Dict, Any, Optional, List, Tuple
import os, re, textwrap, json

from langchain.prompts import PromptTemplate
from langchain.schema.output_parser import StrOutputParser
from langchain_ollama import ChatOllama
from utils.query_guard import interpret_ranking_intent

from utils.sql_utils import (
    sanitize_sql, strip_spurious_date_literals, looks_like_select, ensure_order_limit,
    wants_dates, parse_sql_from_json_or_text, only_allowed_identifiers,
    assemble_schema_summary, infer_main_table, pick_best_date_col,
    build_fk_graph, build_from_join_sql, as_upper_name,
    ensure_date_params,replace_unknown_aliases, assemble_single_select, contains_forbidden, remove_date_literals
)

# --- FAISS retrieval helpers -------------------------------------------------
def _unique_keep_order(seq):
    seen = set(); out = []
    for x in seq:
        if x not in seen:
            out.append(x); seen.add(x)
    return out

def _retrieve_tables_via_faiss(query: str, faiss_dir: str, k: int = 6) -> list[str]:
    """
    Return up to k table names (UPPERCASE) from FAISS hits, preserving order.
    We read `metadata.table_name` from the hits.
    """
    try:
        from langchain_huggingface import HuggingFaceEmbeddings
        from langchain_community.vectorstores import FAISS
        idx_path = os.path.join(faiss_dir, "index.faiss")
        if not os.path.exists(idx_path):
            return []
        embed = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        store = FAISS.load_local(faiss_dir, embed, allow_dangerous_deserialization=True)
        hits = store.similarity_search(query, k=max(8, k * 2))
        tables = []
        for h in hits:
            md = getattr(h, "metadata", {}) or {}
            t = (md.get("table_name") or "").upper()
            if t:
                tables.append(t)
        return _unique_keep_order([t for t in tables if t])[:k]
    except Exception:
        return []

def _score_table_for_query(tmeta: dict, q: str) -> int:
    name = (tmeta.get("table_name") or "").upper()
    fk_in = int(tmeta.get("fk_in_count", 0) or 0)
    score = fk_in
    ql = q.lower()
    if any(k in ql for k in ["trade", "price", "volume", "vwap", "avg", "top", "rank"]):
        if any(s in name for s in ["TRADE", "NEGOTIATED", "ORDER"]):
            score += 50
    if any(s in name for s in ["SYMBOL","INSTRUMENT","SECUR","ASSET"]):
        score += 10
    return score

def _choose_relevant_tables(enriched: list[dict], q: str, k: int = 6) -> list[str]:
    scored = [(_score_table_for_query(t, q), (t.get("table_name") or "").upper()) for t in enriched]
    scored.sort(reverse=True)
    out = []
    seen = set()
    for _, name in scored:
        if name and name not in seen:
            out.append(name); seen.add(name)
        if len(out) >= k:
            break
    return out


# -----------------------------
# Prompt (Oracle-focused; expressive)
# -----------------------------
# SQL_PROMPT = PromptTemplate(
#     template=textwrap.dedent("""
#     You are a senior Oracle SQL writer. Return **JSON only**, exactly one line:
#     {{"sql":"<single SELECT>"}}

#     HARD CONSTRAINTS:
#     - Dialect: Oracle (12c+). Use `FETCH FIRST n ROWS ONLY` for pagination.
#     - Use ONLY the tables and columns listed below; NEVER invent names.
#     - Build FROM/JOIN based on the provided join skeleton and aliases. Keep aliases stable.

#     SAFETY:
#     - One read-only SELECT (no CTEs, no DDL/DML, no comments).
#     - Do NOT inline date/time/string literals for filters; use binds like :from_date, :to_date, :instrument_1, etc.
#     - If a date range is present or implied, filter with: {date_between_template}

#     ADVANCED TOOLS YOU MAY USE WHEN NEEDED:
#     - Window functions (ROW_NUMBER, RANK, DENSE_RANK), PARTITION BY, analytic SUM/AVG.
#     - Conditional aggregates with CASE WHEN.
#     - Weighted averages: SUM(x*y)/NULLIF(SUM(y),0).
#     - Percentiles: PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY col).
#     - Bucketing by day: TRUNC(ts). By month: TRUNC(ts,'MM'). By week: TRUNC(ts,'IW').

#     USER QUERY:
#     {user_query}

#     TABLE CANDIDATES (aliases):
#     {table_aliases}

#     FROM/JOIN SKELETON:
#     {from_join_sql}

#     SCHEMA SNAPSHOT (must adhere strictly):
#     {schema_summary}

#     HELPFUL CONTEXT SNIPPETS:
#     {snippets}

#     Return only:
#     {{"sql":"<query>"}}
#     """).strip(),
#     input_variables=[
#         "user_query",
#         "schema_summary",
#         "snippets",
#         "table_aliases",
#         "from_join_sql",
#         "date_between_template",
#     ],
# )

_AGG_FUN = re.compile(r"(?i)\b(SUM|AVG|COUNT|MIN|MAX|PERCENTILE_CONT|STDDEV|VARIANCE)\s*\(")

def _auto_group_by_if_needed(select_expr: str, group_by_expr: str) -> str:
    if not select_expr: return group_by_expr
    has_agg = bool(_AGG_FUN.search(select_expr))
    if not has_agg or group_by_expr.strip(): 
        return group_by_expr
    # Collect simple column refs that are not inside functions: a.b or "A"."B"
    cols = re.findall(r'\b([a-z]\w*)\."([A-Z0-9_]+)"\b', select_expr, flags=re.I)
    # De-dup while keeping order
    seen, out = set(), []
    for a, c in cols:
        key = f'{a.upper()}."{c}"'
        if key not in seen:
            seen.add(key); out.append(key)
    return ", ".join(out)

STRUCTURED_SQL_PROMPT = PromptTemplate(
    template=textwrap.dedent("""
    You are an expert Oracle SQL writer. Output **JSON only**, one line:
    {{"select":"<projection>","where_extra":"<conditions without dates or literals>","group_by":"<cols>","having":"<expr>","order_by":"<expr>","limit":"<int or empty>"}}

    RULES:
    - Dialect: Oracle 12c+. NO CTEs, NO UNION, NO DDL/DML, NO comments.
    - Use only listed tables/columns. DO NOT invent names.
    - From/Join is PROVIDED and FIXED. You MUST use the aliases as-is in your expressions.
    - NEVER include any date/time/string literals (no TO_DATE, DATE '…', SYSDATE). Filter dates only via binds baked into the system (we will inject them).
    - **SUPER IMPORTANT** - If ranking/top-N is implied, set order_by and limit accordingly.
    - Prefer analytic/window functions when appropriate (ROW_NUMBER, PERCENTILE_CONT, etc.), but keep everything in a SINGLE SELECT (no CTEs).

    USER QUERY:
    {user_query}

    ALIASES:
    {table_aliases}

    FROM/JOIN (fixed, do not modify):
    {from_join_sql}

    SCHEMA (tables & columns you may reference):
    {schema_summary}

    HELPFUL CONTEXT:
    {snippets}

    Return only JSON:
    {{"select":"...","where_extra":"...","group_by":"...","having":"...","order_by":"...","limit":"..."}}
    """).strip(),
    input_variables=["user_query","table_aliases","from_join_sql","schema_summary","snippets"],
)
SQL_PROMPT = STRUCTURED_SQL_PROMPT


# -----------------------------
# Generator
# -----------------------------
class SQLGenerator:
    def __init__(
        self,
        use_llm: bool = True,
        backend: str = "ollama",
        model: str = "mistral:7b-instruct",
        temperature: float = 0.0,
        max_new_tokens: int = 512,
        dialect: str = "Oracle",
        enable_repair: bool = True,
        base_url: Optional[str] = None,
        debug: bool = False,
        last_mode: str = "unknown",
    ):
        self.use_llm = use_llm
        self.dialect = dialect
        self.enable_repair = enable_repair
        self.backend = backend
        self.model = model
        self.debug = debug
        self.last_mode = 'unknown'

        if self.use_llm and self.backend == "ollama":
            self.llm = ChatOllama(
                model=self.model,
                temperature=temperature,
                num_predict=max_new_tokens,
                base_url=base_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
            )
            self.chain = SQL_PROMPT | self.llm | StrOutputParser()
        else:
            self.llm = None
        # self.chain = STRUCTURED_SQL_PROMPT | self.llm | StrOutputParser()


    def generate_sql(self, context: Dict[str, Any]) -> str:
        """
        Expected context keys:
          - query: str
          - enriched_tables: List[table_dict]  # from enriched.json subset you retrieved
          - relevant_tables: List[str]         # owner.table or table
          - columns_by_table: Dict[str,List[str]]  # optional; if absent we'll build it from enriched_tables
          - context_snippets: List[str]        # optional snippets from retriever
          - main_table: str (optional hint)
          - order_by_hint: str (optional)
          - limit_hint: int (optional)
        """
        user_query: str = context.get("query", "")
        selected_tables: List[str] = context.get("relevant_tables", [])
        enriched_tables: List[Dict[str, Any]] = context.get("enriched_tables", [])
        snippets = "\n".join(context.get("context_snippets", [])[:6])
        # ---- ensure we always have a small, high-signal selected_tables ----
        faiss_dir = context.get("faiss_dir") or "./data/faiss_oracle"
        if not selected_tables:
            # 1) try FAISS retrieval
            selected_tables = _retrieve_tables_via_faiss(user_query, faiss_dir, k=6)

        # 2) fallback chooser if FAISS empty
        if not selected_tables and enriched_tables:
            selected_tables = _choose_relevant_tables(enriched_tables, user_query, k=6)

        # 3) hard cap to keep the join skeleton small & sane
        if len(selected_tables) > 8:
            selected_tables = selected_tables[:8]


        if not selected_tables and enriched_tables:
            selected_tables = [t.get("table_name") for t in enriched_tables]

        # schema summary + per-table info
        schema_summary, columns_by_table, date_like_by_table = assemble_schema_summary(
            enriched_tables, selected_tables
        )

        # main table inference
        main_table = (context.get("main_table") or
                      infer_main_table(user_query, selected_tables, enriched_tables))
        main_table = as_upper_name(main_table or (selected_tables[0] if selected_tables else ""))

        # FK graph and deterministic FROM/JOIN skeleton
        fk_graph = build_fk_graph(enriched_tables)
        # owner for quoting (assume all same owner in subset)
        owner = enriched_tables[0].get("owner") if enriched_tables else "ATS"
        from_join_sql, alias_map = build_from_join_sql(owner, main_table, selected_tables, fk_graph)
        table_aliases = ", ".join([f"{t} AS {a}" for t, a in alias_map.items()])

        # date col + template
        date_col = pick_best_date_col(main_table, columns_by_table, date_like_by_table)
        date_between_template = f"{date_col} BETWEEN :from_date AND :to_date"

        # ranking
        # order_by_hint = context.get("order_by_hint")
        # limit_hint = context.get("limit_hint")
        
            # ranking from NL intent (top N / most / least …)
        ord_hint_ctx = context.get("order_by_hint")
        limit_hint_ctx = context.get("limit_hint")
        ord_from_nl, lim_from_nl = interpret_ranking_intent(user_query)  # returns (order_by, limit_int or None)

        # prefer explicit context > NL hint
        order_by_hint = ord_hint_ctx or ord_from_nl
        # limit_hint = limit_hint_ctx if limit_hint_ctx is not None else lim_from_nl
        limit_hint = lim_from_nl if lim_from_nl is not None else limit_hint_ctx


        decisions = {
            "path": None,               # "llm_ok", "llm_repaired", "fallback"
            "order_by_hint": None,
            "limit_final": None,
            "raw_structured": None,     # JSON returned by the model
        }
        # --- sanity cleanups ---
        if self.use_llm and self.chain:
            # === LLM structured generation ===
            raw = self.chain.invoke({
                "user_query": user_query,
                "schema_summary": schema_summary,
                "snippets": snippets,
                "table_aliases": table_aliases,
                "from_join_sql": from_join_sql,
            })
            decisions["raw_structured"] = raw
            # parse the JSON fields
            # --- parse the JSON fields safely ---
        try:
            obj = json.loads(raw.strip())
        except Exception:
            m = re.search(r"\{.*\}", raw, flags=re.S)
            obj = json.loads(m.group(0)) if m else {
                "select": "t.*", "where_extra": "", "group_by": "", "having": "",
                "order_by": "", "limit": str(limit_hint or "")
            }

        select_expr    = (obj.get("select")     or "t.*").strip()
        where_extra    = (obj.get("where_extra") or "").strip()
        group_by_expr  = (obj.get("group_by")    or "").strip()
        having_expr    = (obj.get("having")      or "").strip()
        order_by_expr  = (obj.get("order_by")    or (context.get("order_by_hint") or "")).strip()
        limit_expr     = (obj.get("limit")       or "").strip()
        group_by_expr = _auto_group_by_if_needed(select_expr, group_by_expr)

        # scrub any sneaky date/time literals from free-text fields
        where_extra = remove_date_literals(where_extra)
        having_expr = remove_date_literals(having_expr)

        # replace unknown aliases with main alias 't' (last-resort guard)
        known_aliases = set(alias_map.values())  # e.g., {'t','i','j',...}
        def _alias_safe(expr: str) -> str:
            if not expr:
                return expr
            toks = re.findall(r'\b([A-Za-z]\w*)\.', expr)
            bad = {a for a in toks if a not in known_aliases}
            for a in bad:
                expr = re.sub(rf'\b{a}\.', 't.', expr)
            return expr

        select_expr   = _alias_safe(select_expr)
        where_extra   = _alias_safe(where_extra)
        group_by_expr = _alias_safe(group_by_expr)
        having_expr   = _alias_safe(having_expr)
        order_by_expr = _alias_safe(order_by_expr)
        # NEW: if where_extra/having_expr reduced to empty or connector → drop it
        def _empty_or_connector(x: str) -> bool:
            return not x or re.fullmatch(r"(?is)\s*(?:AND|OR)?\s*", x or "") is not None
        if _empty_or_connector(where_extra): where_extra = ""
        if _empty_or_connector(having_expr): having_expr = ""

        # normalize limit
        # normalize limit with precedence: JSON -> NL hint -> default 1000
        try:
            lim_final = int(limit_expr) if limit_expr else (limit_hint if limit_hint is not None else 1000)
        except Exception:
            lim_final = limit_hint if limit_hint is not None else 1000


        # assemble date clause (if implied by NL query)
        date_clause = f"{date_col} BETWEEN :from_date AND :to_date" if wants_dates(user_query) else None

        # assemble single SELECT safely (no CTE/UNION; binds only)
        sql = assemble_single_select(
            select=select_expr,
            from_join_sql=from_join_sql,
            where_extra=where_extra,
            date_clause=date_clause,
            group_by=group_by_expr,
            having=having_expr,
            order_by=order_by_expr or None,
            limit_n=lim_final,
            dialect=self.dialect,
        )
        # final alias safety across the whole statement
        sql = replace_unknown_aliases(sql, set(alias_map.values()))


        # validation & one-shot repair
        forbidden = contains_forbidden(sql)
        if forbidden:
            select_expr = re.sub(r"\bWITH\b.*", "", select_expr, flags=re.I | re.S)
            where_extra = re.sub(r"(?is)(TO_DATE|DATE\s*'|TIMESTAMP\s*'|SYSDATE|TRUNC\s*\(\s*SYSDATE)[^)]*\)?", "", where_extra).strip()
            sql = assemble_single_select(
                select=select_expr or "t.*",
                from_join_sql=from_join_sql,
                where_extra=where_extra,
                date_clause=date_clause,
                group_by=group_by_expr,
                having=having_expr,
                order_by=order_by_expr or None,
                limit_n=lim_final,
                dialect=self.dialect,
            )

        # final allowlist check; if it fails, use fallback
        if not only_allowed_identifiers(sql, selected_tables, columns_by_table):
            return self.fallback_rule_based({
                "query": user_query,
                "tables": selected_tables,
                "enriched_tables": enriched_tables,
                "main_table": main_table,
                "owner": owner,
                "date_col": date_col,
                "order_by_hint": order_by_expr or None,
                "limit_hint": lim_final or 1000,
            })

        # ✅ normal successful path — return the LLM SQL
        
        self.last_mode = 'llm_ok'
        return sql
        # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

    # ------------------- Generalized fallback (no hardcoding) -------------------
    def fallback_rule_based(self, ctx: Dict[str, Any]) -> str:
        tables: List[str] = ctx.get("tables") or []
        enriched_tables: List[Dict[str, Any]] = ctx.get("enriched_tables") or []
        main_table = as_upper_name(ctx.get("main_table") or (tables[0] if tables else ""))
        owner = ctx.get("owner") or "ATS"
        date_col = ctx.get("date_col") or "t.trade_date"
        order_by_hint = ctx.get("order_by_hint")
        limit_hint = ctx.get("limit_hint")

        # Build graph + FROM/JOIN skeleton
        fk_graph = build_fk_graph(enriched_tables)
        from_join_sql, alias_map = build_from_join_sql(owner, main_table, tables, fk_graph)

        # Try to pick a reasonable measure fields generically
        def has_col(tn: str, needle: str) -> Optional[str]:
            t = next((x for x in enriched_tables if as_upper_name(x.get("table_name")) == as_upper_name(tn)), None)
            for c in (t.get("columns") or []):
                name = (c.get("column_name") if isinstance(c, dict) else str(c))
                if needle.lower() in name.lower():
                    return name
            return None

        # sensible generic guesses (no table name constants)
        vol = has_col(main_table, "VOLUME") or has_col(main_table, "QTY") or has_col(main_table, "QUANTITY")
        price = has_col(main_table, "PRICE") or has_col(main_table, "RATE")
        idcol = has_col(main_table, "ID") or has_col(main_table, "NO")
        inst_id = has_col(main_table, "INSTRUMENT_ID") or has_col(main_table, "SYMBOL_ID") or has_col(main_table, "ISIN")

        # pick a likely instrument lookup if available
        other_tables = [t for t in tables if as_upper_name(t) != as_upper_name(main_table)]
        inst_table = ""
        for t in other_tables:
            if re.search(r"(SYMBOL|INSTRUMENT|SECURIT|ASSET)", t, flags=re.I):
                inst_table = t; break

        a_main = "t"
        a_inst = alias_map.get(as_upper_name(inst_table)) if inst_table else None

        select_lines = []
        group_by = []

        if inst_table and a_inst:
            # name column on instrument-like table
            inst_name_col = None
            inst_meta = next((x for x in enriched_tables if as_upper_name(x.get("table_name")) == as_upper_name(inst_table)), None)
            if inst_meta:
                for c in (inst_meta.get("columns") or []):
                    nm = (c.get("column_name") if isinstance(c, dict) else str(c))
                    if re.search(r"(NAME|TITLE|SYMBOL|TICKER|ISIN)", nm, flags=re.I):
                        inst_name_col = nm; break
            if inst_name_col:
                select_lines.append(f'{a_inst}."{inst_name_col}" AS instrument')
                group_by.append(f'{a_inst}."{inst_name_col}"')

        if inst_id:
            select_lines.append(f'{a_main}."{inst_id}" AS instrument_id')
            group_by.append(f'{a_main}."{inst_id}"')

        if vol:
            select_lines.append(f'SUM({a_main}."{vol}") AS total_volume')
        if price and vol:
            select_lines.append(f'SUM({a_main}."{vol}" * {a_main}."{price}") AS total_value')

        # If nothing meaningful found, just project a few columns
        if not select_lines:
            # pick first 3 columns to avoid *
            main_meta = next((x for x in enriched_tables if as_upper_name(x.get("table_name")) == as_upper_name(main_table)), None)
            first_cols = []
            if main_meta:
                for c in (main_meta.get("columns") or [])[:3]:
                    nm = (c.get("column_name") if isinstance(c, dict) else str(c))
                    first_cols.append(f'{a_main}."{nm}"')
            select_lines = first_cols or [f"{a_main}.*"]

        where_clause = f"WHERE {date_col} BETWEEN :from_date AND :to_date"

        sql = f"""
        SELECT
            {", ".join(select_lines)}
        {from_join_sql}
        {where_clause}
        """.strip()

        # GROUP BY iff any non-aggregated expressions present
        if group_by and any("SUM(" in s or "AVG(" in s or "COUNT(" in s for s in select_lines):
            sql += "\nGROUP BY " + ", ".join(group_by)

        sql = sanitize_sql(sql)
        sql = ensure_order_limit(sql, order_by_hint or None, limit_hint or 1000, self.dialect)
        self.last_mode = 'fallback'
        return sql


# -----------------------------
# CLI runner for quick testing
# -----------------------------
if __name__ == "__main__":
    import argparse, json, os, sys
    from langchain_huggingface import HuggingFaceEmbeddings
    from langchain_community.vectorstores import FAISS

    def _load_json(path: str):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _as_dict_by_table(enriched):
        out = {}
        if isinstance(enriched, list):
            for t in enriched:
                name = (t.get("table_name") or "").upper()
                if name:
                    out[name] = t
        elif isinstance(enriched, dict):
            for k, v in enriched.items():
                name = (v.get("table_name") or k or "").upper()
                v["table_name"] = name
                out[name] = v
        return out

    def _unique_keep_order(seq):
        seen = set()
        out = []
        for x in seq:
            if x not in seen:
                out.append(x); seen.add(x)
        return out

    ap = argparse.ArgumentParser(description="SQL generator smoke test (Oracle)")
    ap.add_argument("--query", required=True, help="Natural language request")
    ap.add_argument("--enriched", default="./data/oracle_schema/ats_schema_metadata.filtered.enriched.json",
                    help="Path to enriched metadata JSON")
    ap.add_argument("--faiss_dir", default="./data/faiss_oracle", help="Path to FAISS index (optional)")
    ap.add_argument("--k", type=int, default=8, help="Top-k chunks to collect tables from")
    ap.add_argument("--model", default="mistral:7b-instruct", help="Ollama model")
    ap.add_argument("--ollama_url", default=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"))
    ap.add_argument("--owner", default="ATS")
    ap.add_argument("--limit", type=int, default=1000)
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args()

    # 1) Load enriched metadata
    if not os.path.exists(args.enriched):
        print(f"ERROR: enriched metadata not found: {args.enriched}", file=sys.stderr)
        sys.exit(1)
    enriched_all = _load_json(args.enriched)
    enriched_by_name = _as_dict_by_table(enriched_all)

    # 2) Retrieve relevant tables via FAISS (if available)
    relevant_tables: list[str] = []
    context_snippets: list[str] = []

    try:
        idx_path = os.path.join(args.faiss_dir, "index.faiss")
        if os.path.exists(idx_path):
            embed = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
            store = FAISS.load_local(args.faiss_dir, embed, allow_dangerous_deserialization=True)
            hits = store.similarity_search(args.query, k=max(2, args.k))
            for h in hits:
                md = getattr(h, "metadata", {}) or {}
                tbl = (md.get("table_name") or "").upper()
                if tbl:
                    relevant_tables.append(tbl)
                # keep a little context text for the prompt
                if h.page_content:
                    context_snippets.append(h.page_content[:300])
        else:
            if args.debug:
                print(f"(no FAISS index at {args.faiss_dir}; using fallback tables)", file=sys.stderr)
    except Exception as e:
        if args.debug:
            print(f"(FAISS load/search failed: {e}; falling back)", file=sys.stderr)

    # Fallback: if retrieval empty, take a small set of “central” tables from enrichment
    if not relevant_tables:
        # choose by inbound FK count desc, then name
        scored = []
        for tname, tmeta in enriched_by_name.items():
            scored.append((int(tmeta.get("fk_in_count", 0) or 0), tname))
        scored.sort(reverse=True)
        relevant_tables = [t for _, t in scored[:5]]

    relevant_tables = _unique_keep_order(relevant_tables)
    
    # --- After relevant_tables are collected (before building enriched_subset) ---

    # Light heuristic: prefer trade-like tables if the query smells like trading
    q = args.query.lower()
    if any(w in q for w in ["trade", "price", "volume", "vwap", "成交", "交易"]):
        # stable priority list (adjust to your schema names)
        prefer = ["TRADES", "NEGOTIATED_TRADES", "CANCELLED_TRADES", "REMAINING_ORDERS"]
        # keep any preferred tables that exist in enriched_by_name
        boosted = [t for t in prefer if t in enriched_by_name]
        # merge, keeping order/uniqueness
        merged = []
        seen_boost = set()
        for t in boosted + relevant_tables:
            if t not in seen_boost:
                merged.append(t); seen_boost.add(t)
        relevant_tables = merged[:6]  # keep it small for better SQL


    # 3) Build enriched subset for those tables
    enriched_subset = [enriched_by_name[t] for t in relevant_tables if t in enriched_by_name]
    if args.debug:
        print(f"Chosen tables: {', '.join(relevant_tables)}")

    # 4) Create the generator and context
    gen = SQLGenerator(
        use_llm=True,
        backend="ollama",
        model=args.model,
        temperature=0.0,
        max_new_tokens=512,
        dialect="Oracle",
        enable_repair=True,
        base_url=args.ollama_url,
        debug=args.debug
    )
    
    # Prefer NL "top N" over --limit default
    _, lim_from_nl = interpret_ranking_intent(args.query)
    limit_for_context = lim_from_nl if lim_from_nl is not None else args.limit


    context = {
        "query": args.query,
        "enriched_tables": enriched_subset,
        "relevant_tables": relevant_tables,
        "context_snippets": context_snippets[:6],
        # optional: you can hint these from a higher layer if your UI detected intent:
        "order_by_hint": None,             # e.g., "total_value DESC"
        "limit_hint": limit_for_context,
        "faiss_dir": args.faiss_dir # default page size
        # "main_table": "TRADES",          # optional strong hint
    }

    # 5) Generate SQL
    sql = gen.generate_sql(context)

    # 6) Print nicely + a param template
    print("\n---- SQL ----")
    print(sql)
    print("---- Generator mode ----")
    print(gen.last_mode)
    print("---- Bind Params (typical) ----")
    print("{':from_date': '2024-01-01', ':to_date': '2024-12-31'}")
