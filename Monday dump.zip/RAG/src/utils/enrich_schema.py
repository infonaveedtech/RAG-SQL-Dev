# utils/enrich_schema.py
"""
Enrich filtered schema metadata with *factual* Oracle dictionary info:
- Primary keys
- Foreign keys (outbound) and inbound-FK counts
- Index leaders
- Date-like columns (derived only from types/names)
- Last analyzed timestamp (if available)
- Optional: column stats (NDV / histogram) and min/max for date-like columns (guarded)

No assumptions or heuristic relationships are created. Only what exists in ALL_* views.

Usage (programmatic)
--------------------
from utils.enrich_schema import ensure_enriched_metadata

meta_path = ensure_enriched_metadata(
    metadata_path="data/oracle_schema/ats_schema_metadata.filtered.json",
    owner="ATS",
    with_stats=False,
    with_minmax=False,
    max_probe_tables=20,
    max_date_cols_per_table=2,
    per_query_timeout_s=3,
)

Returns the path to the enriched JSON. If enrichment fails, returns the original path unchanged.

Requirements
------------
- A working Oracle connection via your existing db_conn.db_session(mode="oracle").
- SELECT privilege on ALL_CONSTRAINTS, ALL_CONS_COLUMNS, ALL_INDEXES, ALL_IND_COLUMNS,
  ALL_TABLES and optionally ALL_TAB_COL_STATS / ALL_TAB_COLS (if `with_stats=True`).
"""

from __future__ import annotations
import json, os, logging, time
from typing import Dict, Any, List, Tuple, Optional, Iterable, Set
from contextlib import contextmanager

# uses your project's db session
from db_conn import db_session


def _upper(s: Optional[str]) -> str:
    return (s or "").upper()


def _build_date_like_list(columns: List[Dict[str, Any]]) -> List[str]:
    out: List[str] = []
    for c in columns or []:
        cn = _upper(c.get("column_name"))
        dt = _upper(c.get("data_type"))
        if dt in {
            "DATE",
            "TIMESTAMP",
            "TIMESTAMP(6)",
            "TIMESTAMP WITH TIME ZONE",
            "TIMESTAMP WITH LOCAL TIME ZONE",
        }:
            out.append(cn)
        else:
            # name hint only (no semantics assumed; just discoverability)
            if cn.endswith("DATE") or cn.endswith("_DT") or cn.endswith("_TIME") or cn.endswith("TIMESTAMP"):
                out.append(cn)
    # preserve stable order
    seen: Set[str] = set()
    uniq: List[str] = []
    for x in out:
        if x not in seen:
            uniq.append(x)
            seen.add(x)
    return uniq


def _fetch_pk_map(conn, owner: str) -> Dict[str, List[str]]:
    """
    Returns {table_name -> [pk_col1, ...]} (column order preserved).
    """
    sql = """
        SELECT ac.table_name, acc.column_name, acc.position
        FROM ALL_CONSTRAINTS ac
        JOIN ALL_CONS_COLUMNS acc
          ON ac.owner = acc.owner
         AND ac.constraint_name = acc.constraint_name
        WHERE ac.owner = :owner
          AND ac.constraint_type = 'P'
        ORDER BY ac.table_name, acc.position
    """
    cur = conn.cursor()
    cur.execute(sql, {"owner": owner})
    pk_map: Dict[str, List[Tuple[int, str]]] = {}
    for tname, col, pos in cur:
        t = _upper(tname)
        pk_map.setdefault(t, []).append((int(pos or 0), _upper(col)))
    return {t: [c for _, c in sorted(cols)] for t, cols in pk_map.items()}


def _fetch_fk_maps(conn, owner: str) -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, int]]:
    """
    Outbound FKs: {table_name -> [{"cols":[...],"ref_owner":..,"ref_table":..,"ref_cols":[...]}, ...]}
    Inbound counts: {ref_table_name -> count_of_inbound_fks} (only for same owner)
    """
    sql = """
        SELECT a.owner, a.table_name, a.constraint_name,
               a_r.owner AS r_owner, a_r.table_name AS r_table_name, a_r.constraint_name AS r_constraint_name
        FROM ALL_CONSTRAINTS a
        JOIN ALL_CONSTRAINTS a_r
          ON a.r_owner = a_r.owner
         AND a.r_constraint_name = a_r.constraint_name
        WHERE a.owner = :owner
          AND a.constraint_type = 'R'
    """
    cur = conn.cursor()
    cur.execute(sql, {"owner": owner})
    rows = cur.fetchall()

    # Collect column pairs per FK constraint
    # For each FK constraint, join ALL_CONS_COLUMNS (child) to ALL_CONS_COLUMNS (parent) by position
    fk_cols_sql = """
        SELECT acc_child.table_name AS child_table,
               acc_child.constraint_name AS child_cname,
               acc_child.position AS pos,
               acc_child.column_name AS child_col,
               acc_parent.column_name AS parent_col
        FROM ALL_CONS_COLUMNS acc_child
        JOIN ALL_CONS_COLUMNS acc_parent
          ON acc_child.position = acc_parent.position
         AND acc_child.owner = :owner
        WHERE acc_child.owner = :owner
          AND acc_child.constraint_name = :child_cname
          AND acc_parent.owner = :parent_owner
          AND acc_parent.constraint_name = :parent_cname
        ORDER BY pos
    """

    outbound: Dict[str, List[Dict[str, Any]]] = {}
    inbound_count: Dict[str, int] = {}

    for owner_c, child_table, child_cname, parent_owner, parent_table, parent_cname in rows:
        # gather matching columns for this FK
        c2 = conn.cursor()
        c2.execute(
            fk_cols_sql,
            {
                "owner": owner,
                "child_cname": child_cname,
                "parent_owner": parent_owner,
                "parent_cname": parent_cname,
            },
        )
        child_cols: List[str] = []
        parent_cols: List[str] = []
        for _t, _cname, _pos, child_col, parent_col in c2:
            child_cols.append(_upper(child_col))
            parent_cols.append(_upper(parent_col))
        c2.close()

        # record outbound for child
        child_table_u = _upper(child_table)
        outbound.setdefault(child_table_u, []).append(
            {
                "cols": child_cols,
                "ref_owner": _upper(parent_owner),
                "ref_table": _upper(parent_table),
                "ref_cols": parent_cols,
            }
        )

        # count inbound for parent (only within same owner scope)
        if _upper(parent_owner) == _upper(owner):
            ptab = _upper(parent_table)
            inbound_count[ptab] = inbound_count.get(ptab, 0) + 1

    return outbound, inbound_count


def _fetch_indexes(conn, owner: str) -> Dict[str, List[Dict[str, Any]]]:
    """
    Returns {table_name -> [ {"name":..., "unique": bool, "leading_cols":[...]} ] }
    """
    sql_idx = """
        SELECT ai.table_name, ai.index_name, ai.uniqueness
        FROM ALL_INDEXES ai
        WHERE ai.owner = :owner
    """
    sql_cols = """
        SELECT column_name, column_position
        FROM ALL_IND_COLUMNS
        WHERE index_owner = :owner
          AND index_name  = :index_name
        ORDER BY column_position
    """
    cur = conn.cursor()
    cur.execute(sql_idx, {"owner": owner})
    out: Dict[str, List[Dict[str, Any]]] = {}
    for table_name, index_name, uniq in cur:
        c2 = conn.cursor()
        c2.execute(sql_cols, {"owner": owner, "index_name": index_name})
        leading = [ _upper(r[0]) for r in c2 ]
        c2.close()
        out.setdefault(_upper(table_name), []).append(
            {
                "name": _upper(index_name),
                "unique": str(uniq or "").upper() == "UNIQUE",
                "leading_cols": leading,
            }
        )
    return out


def _fetch_last_analyzed(conn, owner: str) -> Dict[str, str]:
    """
    Returns {table_name -> ISO8601 string} if available.
    """
    sql = """
        SELECT table_name, last_analyzed
        FROM ALL_TABLES
        WHERE owner = :owner
    """
    cur = conn.cursor()
    cur.execute(sql, {"owner": owner})
    out: Dict[str, str] = {}
    for tname, last_analyzed in cur:
        if last_analyzed:
            try:
                out[_upper(tname)] = last_analyzed.strftime("%Y-%m-%dT%H:%M:%S")
            except Exception:
                out[_upper(tname)] = str(last_analyzed)
    return out


def _fetch_column_stats(conn, owner: str) -> Dict[Tuple[str, str], Dict[str, Any]]:
    """
    Optional: NDV / histogram stats if available.
    Returns {(table, column) -> {"ndv": int|None, "histogram": str|None}}
    Notes:
    - LOW_VALUE/HIGH_VALUE conversions are driver/version specific; kept out for safety.
    """
    sql = """
        SELECT table_name, column_name, num_distinct, histogram
        FROM ALL_TAB_COL_STATISTICS
        WHERE owner = :owner
    """
    cur = conn.cursor()
    cur.execute(sql, {"owner": owner})
    out: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for t, c, ndv, h in cur:
        out[( _upper(t), _upper(c) )] = {
            "ndv": None if ndv is None else int(ndv),
            "histogram": None if h is None else str(h),
        }
    return out


def _probe_minmax_date(conn, owner: str, table: str, column: str, timeout_s: int = 3) -> Tuple[Optional[str], Optional[str]]:
    """
    Safe min/max probe for DATE/TIMESTAMP-like columns.
    Returns ISO strings (yyyy-mm-dd hh24:mi:ss) as text or (None, None) on timeout/error.
    """
    # Some drivers support statement timeouts via call timeout attribute
    try:
        # Thin mode attribute (if supported); ignore if not
        conn.call_timeout = int(timeout_s * 1000)
    except Exception:
        pass

    sql = f"""
        SELECT
          TO_CHAR(MIN({column}), 'YYYY-MM-DD HH24:MI:SS'),
          TO_CHAR(MAX({column}), 'YYYY-MM-DD HH24:MI:SS')
        FROM "{owner}"."{table}"
    """
    try:
        cur = conn.cursor()
        cur.execute(sql)
        row = cur.fetchone()
        return (row[0], row[1]) if row else (None, None)
    except Exception:
        return (None, None)


def enrich_tables_in_memory(
    tables: List[Dict[str, Any]],
    owner: str,
    with_stats: bool = False,
    with_minmax: bool = False,
    max_probe_tables: int = 20,
    max_date_cols_per_table: int = 2,
    per_query_timeout_s: int = 3,
    oracle_user: str | None = None,
    oracle_password: str | None = None,
    oracle_dsn: str | None = None,
) -> List[Dict[str, Any]]:
    """
    Enriches in-memory list of table dicts with PK/FK/indexes/last_analyzed/date-like cols
    and augments column dicts with is_pk/is_fk/fk_target/indexed and optional stats/minmax.
    """
    owner_u = _upper(owner)

    # with db_session(mode="oracle") as conn:
    with db_session(mode="oracle", user=oracle_user, password=oracle_password, dsn=oracle_dsn) as conn:

        if conn is None:
            logging.warning("enrich_schema: No Oracle connection; returning original tables.")
            return tables

        pk_map = _fetch_pk_map(conn, owner_u)
        fk_out_map, fk_in_count_map = _fetch_fk_maps(conn, owner_u)
        idx_map = _fetch_indexes(conn, owner_u)
        last_ana = _fetch_last_analyzed(conn, owner_u)
        stats_map: Dict[Tuple[str, str], Dict[str, Any]] = {}
        if with_stats:
            try:
                stats_map = _fetch_column_stats(conn, owner_u)
            except Exception as e:
                logging.warning(f"enrich_schema: column stats unavailable ({e}); continuing without stats.")

        # Build a quick reverse index: which columns are leading in any index
        leading_cols_map: Dict[Tuple[str, str], bool] = {}
        for tname, idx_list in idx_map.items():
            for idx in idx_list:
                for lead_col in idx.get("leading_cols") or []:
                    leading_cols_map[(tname, lead_col)] = True

        # For min/max probing, pre-select which tables/cols to probe (date-like only)
        probe_plan: List[Tuple[str, List[str]]] = []
        if with_minmax and max_probe_tables > 0:
            for t in tables[:max_probe_tables]:
                tname = _upper(t.get("table_name"))
                dcols = _build_date_like_list(t.get("columns") or [])
                if dcols:
                    probe_plan.append((tname, dcols[:max_date_cols_per_table]))

        minmax: Dict[Tuple[str, str], Tuple[Optional[str], Optional[str]]] = {}
        if probe_plan:
            for tname, cols in probe_plan:
                for col in cols:
                    mn, mx = _probe_minmax_date(conn, owner_u, tname, col, timeout_s=per_query_timeout_s)
                    minmax[(tname, col)] = (mn, mx)

    # Mutate copies with enrichments
    enriched: List[Dict[str, Any]] = []
    for t in tables:
        tname = _upper(t.get("table_name"))
        cols = t.get("columns") or []

        date_like_cols = _build_date_like_list(cols)

        # augment columns with flags
        pk_cols = set(pk_map.get(tname, []))
        fk_out = fk_out_map.get(tname, [])
        fk_child_cols = set(c for fk in fk_out for c in fk.get("cols") or [])
        idx_leading_cols = set(c for (tt, c), _ in leading_cols_map.items() if tt == tname)

        fk_target_by_col: Dict[str, Dict[str, Any]] = {}
        for fk in fk_out:
            for c in fk.get("cols") or []:
                fk_target_by_col[c] = {
                    "ref_owner": fk.get("ref_owner"),
                    "ref_table": fk.get("ref_table"),
                    "ref_cols": fk.get("ref_cols"),
                }

        new_cols: List[Dict[str, Any]] = []
        for c in cols:
            cn = _upper(c.get("column_name"))
            item = dict(c)  # shallow copy
            item["is_pk"] = cn in pk_cols
            item["is_fk"] = cn in fk_child_cols
            item["indexed"] = cn in idx_leading_cols
            if item["is_fk"]:
                item["fk_target"] = fk_target_by_col.get(cn)
            # stats (optional)
            if with_stats:
                st = stats_map.get((tname, cn))
                if st:
                    item["stats"] = st
            # min/max (optional)
            if with_minmax and (tname, cn) in minmax:
                mn, mx = minmax[(tname, cn)]
                if mn or mx:
                    item["min_date"] = mn
                    item["max_date"] = mx
            new_cols.append(item)

        new_t = dict(t)
        new_t["columns"] = new_cols
        new_t["pk"] = pk_map.get(tname, [])
        new_t["fks_out"] = fk_out
        new_t["fk_in_count"] = int(fk_in_count_map.get(tname, 0))
        new_t["indexes"] = idx_map.get(tname, [])
        new_t["date_like_cols"] = date_like_cols
        if tname in last_ana:
            new_t["last_analyzed"] = last_ana[tname]

        enriched.append(new_t)

    return enriched


def ensure_enriched_metadata(
    metadata_path: str,
    owner: str,
    with_stats: bool = False,
    with_minmax: bool = False,
    max_probe_tables: int = 20,
    max_date_cols_per_table: int = 2,
    per_query_timeout_s: int = 3,
    oracle_user: str | None = None,
    oracle_password: str | None = None,
    oracle_dsn: str | None = None,
) -> str:
    """
    If <metadata>.enriched.json exists, return it.
    Otherwise enrich and write it next to the input file. On failure, return original path.
    """
    root, ext = os.path.splitext(metadata_path)
    out_path = root + ".enriched.json"
    if os.path.exists(out_path):
        return out_path

    try:
        with open(metadata_path, "r", encoding="utf-8") as f:
            tables = json.load(f)
    except Exception as e:
        logging.error(f"enrich_schema: failed to read {metadata_path}: {e}")
        return metadata_path

    try:
        enriched = enrich_tables_in_memory(
            tables=tables,
            owner=owner,
            with_stats=with_stats,
            with_minmax=with_minmax,
            max_probe_tables=max_probe_tables,
            max_date_cols_per_table=max_date_cols_per_table,
            per_query_timeout_s=per_query_timeout_s,
            oracle_user=oracle_user,
            oracle_password=oracle_password,
            oracle_dsn=oracle_dsn,
        )
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(enriched, f, indent=2)
        logging.info(f"enrich_schema: wrote {out_path} (tables={len(enriched)})")
        return out_path
    except Exception as e:
        logging.warning(f"enrich_schema: enrichment failed ({e}); using original metadata.")
        return metadata_path
