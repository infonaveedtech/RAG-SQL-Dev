# normalizer.py
from __future__ import annotations
from typing import List, Dict, Any, Tuple
import math

# canonical fields we want in the report table
TARGET_FIELDS = [
    "exchange","symbol","market","volume","value","price","high","low","open","close",
    "average","trades","open_yield","close_yield"
]

# simple alias map (lowercase keys)
ALIASES = {
    "exchange": ["exchange","exch","venue","market_name"],
    "symbol": ["symbol","ticker","instrument","instrument_id","ric"],
    "market": ["market","board","segment","category"],
    "volume": ["volume","qty","quantity","shares","units","trade_volume"],
    "value": ["value","turnover","notional","vwap_value","trade_value","amount"],
    "price": ["price","last","last_price","close_price"],  # fallback when close is missing
    "high": ["high","day_high","high_price"],
    "low": ["low","day_low","low_price"],
    "open": ["open","open_price","opening_price"],
    "close": ["close","close_price","last_close","last"],
    "average": ["average","avg_price","vwap","avg","mean_price"],
    "trades": ["trades","count","num_trades","trade_count"],
    "open_yield": ["open_yield","yield_open","yield_o"],
    "close_yield": ["close_yield","yield_close","yield_c"],
}

def _find_key(row: Dict[str, Any], names: List[str]) -> Tuple[str, Any] | (None, None):
    lower = {k.lower(): k for k in row.keys()}
    for alias in names:
        if alias in lower:
            orig = lower[alias]
            return orig, row[orig]
    return None, None

def _to_float(x):
    try:
        if x is None or (isinstance(x, str) and x.strip()== ""): return None
        return float(x)
    except: return None

def normalize_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for r in rows:
        nr: Dict[str, Any] = {f: None for f in TARGET_FIELDS}
        # map fields
        for field, aliases in ALIASES.items():
            k, v = _find_key(r, aliases)
            if k is not None:
                nr[field] = v

        # derive missing values
        # average ~ value/volume if both numeric and average missing
        vol = _to_float(nr.get("volume"))
        val = _to_float(nr.get("value"))
        if nr.get("average") is None and vol and vol != 0 and val is not None:
            nr["average"] = val / vol

        # price: if not provided, prefer 'close', else 'average'
        if nr.get("price") is None:
            nr["price"] = nr.get("close", nr.get("average"))

        # yields: (close-open)/open
        op = _to_float(nr.get("open"))
        cl = _to_float(nr.get("close"))
        if nr.get("open_yield") is None and op and op != 0 and cl is not None:
            nr["open_yield"] = (cl - op) / op
        if nr.get("close_yield") is None and op and op != 0 and cl is not None:
            nr["close_yield"] = (cl - op) / op  # same unless you provide another definition

        out.append(nr)
    return out

def compute_totals(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    tvol = sum(_to_float(r.get("volume")) or 0 for r in rows)
    tval = sum(_to_float(r.get("value")) or 0 for r in rows)
    ttrd = sum(int(_to_float(r.get("trades")) or 0) for r in rows)
    return {"volume": int(tvol), "value": tval, "trades": ttrd}
