# utils/query_guard.py
import re
from typing import List, Dict, Any, Tuple, Optional
import os


from executor import SQLExecutor

# ---------- 1) Name extraction ----------
_COMPANY_TAILS = (" inc", " ltd", " llc", " plc", " corp", " co.", " real estate", " metals", " energy", " bank", " pharma", " telecom")

def _current_dialect() -> str:
    # falls back to SQLite (your mock)
    return (os.getenv("SQL_DIALECT") or "SQLite").strip().lower()

def _limit_clause(n: Optional[int]) -> str:
    if n is None:
        return ""
    n = int(n)
    d = _current_dialect()
    if "oracle" in d:
        return f"FETCH FIRST {n} ROWS ONLY"
    # default / sqlite / postgres / duckdb:
    return f"LIMIT {n}"


def _has_aliases(sql: str, aliases: List[str]) -> bool:
    """Return True only if every alias token appears somewhere in the SQL."""
    return all(re.search(rf"\b{re.escape(a)}\b", sql or "", re.IGNORECASE) for a in aliases)

def _extract_order_by_and_limit(sql: str) -> Tuple[Optional[str], Optional[int]]:
    """Pull ORDER BY expression (raw text) and LIMIT N (int) if present."""
    order_by = None
    limit_n = None
    if sql:
        m = re.search(r"(?is)\border\s+by\s+([^\n;]+)", sql)
        if m:
            order_by = m.group(1).strip()
        m2 = re.search(r"(?i)\blimit\s+(\d+)\b", sql)
        if m2:
            limit_n = int(m2.group(1))
    return order_by, limit_n

def interpret_ranking_intent(text: str) -> Tuple[Optional[str], Optional[int]]:
    if not text:
        return None, None
    t = text.lower()

    # default direction/metric
    direction = "DESC"
    metric = "total_value"
    n = None

    # explicit top/bottom N
    m = re.search(r"\btop\s+(\d+)\b", t)
    if m:
        n = int(m.group(1)); direction = "DESC"
    m = re.search(r"\bbottom\s+(\d+)\b", t)
    if m:
        n = int(m.group(1)); direction = "ASC"

    # implicit "top instrument" / "top company" without a number => 1
    if n is None and re.search(r"\btop\b\s+(instrument|company|instrument\s+by|company\s+by)", t):
        n = 1; direction = "DESC"

    # metric
    if "volume" in t:
        metric = "total_volume"
    elif "value" in t:
        metric = "total_value"

    return f"{metric} {direction}", n




def _extract_candidate_names(text: str) -> List[str]:
    if not text:
        return []
    t = text.strip()

    # 1) grab quoted names first
    quoted = re.findall(r'["“](.+?)["”]', t)
    candidates = [q.strip() for q in quoted if len(q.split()) >= 2]

    # 2) split on commas and " and " to catch lists: "A and B", "A, B and C"
    #    keep only segments that look like multi-word capitalized names
    segs = re.split(r"\s+(?:and|&)\s+|,", t)
    for seg in segs:
        seg = seg.strip(" .")
        # pick capitalized spans inside the segment
        spans = re.findall(r'([A-Z][A-Za-z]+(?: [A-Z][A-Za-z]+){1,5})', seg)
        for s in spans:
            s = re.sub(r"\s+", " ", s).strip()
            if len(s.split()) >= 2:
                candidates.append(s)

    # 3) suffix hints (Inc, Ltd, Corp, PLC, …)
    low = t.lower()
    for tail in _COMPANY_TAILS:
        if tail in low:
            # get a window ending with tail
            tokens = t.split()
            for i, tok in enumerate(tokens):
                if tok.lower().rstrip(".,").endswith(tail.strip()):
                    start = max(0, i-4)
                    s = " ".join(tokens[start:i+1]).strip(" ,.")
                    if len(s.split()) >= 2:
                        candidates.append(s)

    # normalize + de-dup
    out, seen = [], set()
    for c in candidates:
        c = re.sub(r"\s+", " ", c).strip()
        k = c.casefold()
        if len(c) >= 3 and k not in seen:
            seen.add(k)
            out.append(c)
    return out
def resolve_instruments(user_text: str, exec_: SQLExecutor) -> List[Dict[str, Any]]:
    """
    Robust resolver: scan the user text for any known instrument_name.
    - Pulls all instruments once (fast for the small mock; you can cap for prod).
    - Matches case-insensitively using substring checks after light normalization.
    - Falls back to per-candidate SQL resolution only if scanning finds nothing.
    """
    if not user_text:
        return []

    text_raw = user_text
    text = re.sub(r"[\.,;:!?\(\)\[\]\"“”']", " ", text_raw).lower()
    text = re.sub(r"\s+", " ", text).strip()

    # 1) Pull all instruments once (cache this later if you like)
    try:
        all_rows = exec_.run_query("SELECT instrument_id, instrument_name FROM INSTRUMENTS", {})
    except Exception:
        all_rows = []

    resolved: list[Dict[str, Any]] = []
    seen: set[str] = set()

    if all_rows:
        for row in all_rows:
            name = (row.get("instrument_name") or "").strip()
            if not name:
                continue
            name_norm = re.sub(r"\s+", " ", name).strip().lower()
            # Simple substring presence — very robust for natural queries
            if name_norm and name_norm in text:
                key = (row.get("instrument_id") or name).casefold()
                if key not in seen:
                    seen.add(key)
                    resolved.append({"instrument_id": row.get("instrument_id"), "instrument_name": name})

    # 2) If scanning found nothing, fall back to candidate extraction + SQL lookup
    if not resolved:
        candidates = _extract_candidate_names(text_raw)
        for cand in candidates:
            hit = _resolve_one(cand, exec_)
            if hit:
                key = (hit.get("instrument_id") or hit.get("instrument_name", "")).casefold()
                if key not in seen:
                    seen.add(key)
                    resolved.append(hit)

    return resolved


def _resolve_one(name: str, exec_: SQLExecutor) -> Optional[Dict[str, Any]]:
    sql = """
        SELECT instrument_id, instrument_name, 1 AS rank
        FROM INSTRUMENTS
        WHERE LOWER(instrument_name) = LOWER(:q_exact)

        UNION ALL
        SELECT instrument_id, instrument_name, 2 AS rank
        FROM INSTRUMENTS
        WHERE instrument_name LIKE :q_like

        UNION ALL
        SELECT instrument_id, instrument_name, 3 AS rank
        FROM INSTRUMENTS
        WHERE instrument_name LIKE :q_prefix

        ORDER BY rank, instrument_name
        LIMIT 1
    """
    params = {"q_exact": name, "q_like": f"%{name}%", "q_prefix": f"{name}%"}
    rows = exec_.run_query(sql, params)
    return rows[0] if rows else None




# ---------- 3) Fallback builder ----------
# utils/query_guard.py

# make sure at the top you have:
# from typing import List, Dict, Tuple, Optional
# import re

def build_totals_sql(
    resolved_names: List[str],
    date_col: str = "t.trade_date",
    order_by: Optional[str] = "total_value DESC",
    limit_n: Optional[int] = None,
) -> Tuple[str, Dict[str, str]]:
    """
    Deterministic, safe SQL with bind params only. Simple shape:
    SELECT ... FROM ... WHERE ... GROUP BY ... ORDER BY ... LIMIT/FETCH
    """
    lines = [
        "SELECT i.instrument_name AS instrument,",
        "       SUM(t.trade_volume) AS total_volume,",
        "       SUM(t.trade_volume * t.trade_price) AS total_value",
        "FROM TRADE_DATA t",
        "JOIN INSTRUMENTS i ON i.instrument_id = t.instrument_id",
        f"WHERE {date_col} BETWEEN :from_date AND :to_date",
    ]
    params: Dict[str, str] = {}

    if resolved_names:
        placeholders = []
        for idx, name in enumerate(resolved_names, 1):
            k = f"instrument_name_{idx}"
            params[k] = name
            placeholders.append(f":{k}")
        lines.append(f"  AND i.instrument_name IN ({', '.join(placeholders)})")

    lines.append("GROUP BY i.instrument_name")

    # sanitize order_by
    safe_order = None
    if order_by:
        safe_order = re.sub(r"[^A-Za-z0-9_ .,\(\)]", "", order_by).strip()
    if safe_order:
        lines.append(f"ORDER BY {safe_order}")

    # dialect-aware limit/fetch
    if limit_n is not None:
        n = int(limit_n)
        d = (os.getenv("SQL_DIALECT") or "SQLite").strip().lower()
        if "oracle" in d:
            lines.append(f"FETCH FIRST {n} ROWS ONLY")
        else:
            lines.append(f"LIMIT {n}")

    sql = "\n".join(lines).strip()
    return sql, params



# ---------- 4) SQL validation & enforcement ----------
_FORBIDDEN = (
    r"\bINSERT\b", r"\bUPDATE\b", r"\bDELETE\b", r"\bMERGE\b", r"\bDROP\b",
    r"\bALTER\b", r"\bTRUNCATE\b", r"--", r"/\*", r"\*/"
)

def _is_select_only(sql: str) -> bool:
    s = sql.strip()
    if not s or not re.match(r"(?is)^\s*SELECT\b", s): return False
    if s.count(";") > 1: return False
    for pat in _FORBIDDEN:
        if re.search(pat, s): return False
    return True

def _no_string_literals_in_filters(sql: str) -> bool:
    # Only check WHERE/HAVING parts
    where = re.findall(r"(?is)\bWHERE\b(.*?)(?:\bGROUP\b|\bORDER\b|\bHAVING\b|$)", sql)
    having = re.findall(r"(?is)\bHAVING\b(.*?)(?:\bGROUP\b|\bORDER\b|$)", sql)
    for part in where + having:
        if re.search(r"'[^']*'", part):  # any 'literal'
            return False
    return True

def _requires_join_if_name(sql: str, filtering_by_name: bool) -> bool:
    if not filtering_by_name:
        return True
    return bool(re.search(r"(?is)\bJOIN\s+INSTRUMENTS\b", sql)) and bool(re.search(r"\bi\.", sql))

def _has_bind_params(sql: str, params: List[str]) -> bool:
    return all(re.search(fr":{re.escape(p)}\b", sql) for p in params)

def validate_sql(sql: str, filtering_by_name: bool, required_params: List[str]) -> Tuple[bool, str]:
    if not _is_select_only(sql): return False, "Not a single read-only SELECT."
    if not _no_string_literals_in_filters(sql): return False, "String literals found in WHERE/HAVING; must use bind params."
    if not _requires_join_if_name(sql, filtering_by_name): return False, "Must JOIN INSTRUMENTS and filter by i.instrument_name when using names."
    if not _has_bind_params(sql, required_params): return False, f"Missing bind params: {required_params}"
    return True, "ok"

def _instrument_placeholder_count(sql: str) -> int:
    return len(re.findall(r":instrument_name_(\d+)\b", sql or ""))

# def enforce_or_fallback(sql_from_llm: Optional[str],
#                         base_params: Dict[str, Any],
#                         resolved_names: List[str],
#                         user_text: Optional[str] = None) -> Tuple[str, Dict[str, Any], Dict[str, Any]]:


#     def _attach_name_params(p: Dict[str, Any]) -> Dict[str, Any]:
#         for idx, nm in enumerate(resolved_names, 1):
#             p[f"instrument_name_{idx}"] = nm
#         return p

#     # If no candidate, synthesize
#     if not sql_from_llm:
#         sql, extra = build_totals_sql(resolved_names)
#         p = _attach_name_params({**base_params, **extra})
#         return sql, p, {"mode": "fallback:empty"}

#     # Validate base rules
#     ok, reason = validate_sql(sql_from_llm, filtering, required)
#     if not ok:
#         sql, extra = build_totals_sql(resolved_names)
#         p = _attach_name_params({**base_params, **extra})
#         return sql, p, {"mode": "fallback:invalid", "reason": reason}

#     # NEW: ensure placeholder count matches resolved names
#     ph_count = _instrument_placeholder_count(sql_from_llm)
#     if ph_count != len(resolved_names):
#         # If the model used placeholders but we have fewer names, or vice versa,
#         # rebuild deterministically to avoid bind mismatches.
#         sql, extra = build_totals_sql(resolved_names)
#         p = _attach_name_params({**base_params, **extra})
#         return sql, p, {"mode": "fallback:ph_mismatch", "expected": len(resolved_names), "found": ph_count}

#     # All good — attach params matching placeholders
#     p = _attach_name_params(dict(base_params))
#     return sql_from_llm, p, {"mode": "llm_ok"}
def enforce_or_fallback(sql_from_llm: Optional[str],
                        base_params: Dict[str, Any],
                        resolved_names: List[str],
                        user_text: Optional[str] = None) -> Tuple[str, Dict[str, Any], Dict[str, Any]]:
    required = ["from_date", "to_date"]
    filtering = bool(resolved_names)

    def _attach_name_params(p: Dict[str, Any]) -> Dict[str, Any]:
        for idx, nm in enumerate(resolved_names, 1):
            p[f"instrument_name_{idx}"] = nm
        return p

    # Pull intent from text
    intent_ob, intent_lim = interpret_ranking_intent(user_text or "")

    # If no candidate → synthesize with intent
    if not sql_from_llm:
        sql, extra = build_totals_sql(resolved_names, order_by=intent_ob, limit_n=intent_lim)
        p = _attach_name_params({**base_params, **extra})
        return sql, p, {"mode": "fallback:empty"}

    # Validate LLM SQL
    ok, reason = validate_sql(sql_from_llm, filtering, required)

    # Extract explicit ORDER BY / LIMIT if present in candidate
    ob_from_sql, lim_from_sql = _extract_order_by_and_limit(sql_from_llm)

    # Decide final ORDER BY / LIMIT to preserve
    final_ob = ob_from_sql or intent_ob   # prefer what the model wrote, else NL intent
    final_lim = lim_from_sql if lim_from_sql is not None else intent_lim

    # Reject invalid → rebuild with chosen ORDER BY / LIMIT
    if not ok:
        sql, extra = build_totals_sql(resolved_names, order_by=final_ob, limit_n=final_lim)
        p = _attach_name_params({**base_params, **extra})
        return sql, p, {"mode": "fallback:invalid", "reason": reason}

    # Ensure both metrics exist; if missing → rebuild with ORDER BY/LIMIT
    need_aliases = ["total_volume", "total_value"]
    if not _has_aliases(sql_from_llm, need_aliases):
        sql, extra = build_totals_sql(resolved_names, order_by=final_ob, limit_n=final_lim)
        p = _attach_name_params({**base_params, **extra})
        return sql, p, {"mode": "fallback:missing_metrics"}

    # Placeholder count must match resolved names
    ph_count = len(re.findall(r":instrument_name_(\d+)\b", sql_from_llm or ""))
    if ph_count != len(resolved_names):
        sql, extra = build_totals_sql(resolved_names, order_by=final_ob, limit_n=final_lim)
        p = _attach_name_params({**base_params, **extra})
        return sql, p, {"mode": "fallback:ph_mismatch", "expected": len(resolved_names), "found": ph_count}

    # All good: attach params and return original LLM SQL
    p = _attach_name_params(dict(base_params))
    return sql_from_llm, p, {"mode": "llm_ok"}


