# utils/sql_utils.py
from __future__ import annotations
from typing import Dict, Any, List, Tuple, Optional, Iterable, Set
import re, json, hashlib
from datetime import datetime


# -----------------------------
# Basic SQL text hygiene
# -----------------------------

# --- add near the other helpers ---

# --- at top with imports ---
import re, json, hashlib
# ...

# --- replace previous patterns with case-insensitive versions ---
FORBIDDEN_TOKENS = re.compile(r"(?is)\bWITH\b|\bUNION\b|;.+\bSELECT\b")

DATE_LITERAL_PATTERNS = [
    r"(?i)TO_DATE\s*\(\s*'[^']+'\s*,\s*'[^']*'\s*\)",
    r"(?i)DATE\s*'[^']+'",
    r"(?i)TIMESTAMP\s*'[^']+'",
    r"(?i)\bSYSDATE\b(?:\s*[-+]\s*\d+)?",
    r"(?i)TRUNC\s*\(\s*SYSDATE\s*(?:[-+]\s*\d+)?\s*(?:,\s*'[^']+')?\s*\)",
]

def contains_forbidden(sql: str) -> Optional[str]:
    s = (sql or "")
    if FORBIDDEN_TOKENS.search(s):
        return "forbidden CTE/UNION/multi-select"
    return None

def remove_date_literals(sql: str) -> str:
    """
    Remove any predicates that rely on explicit date/time literals (TO_DATE(...), DATE '...', TIMESTAMP '...',
    TRUNC(SYSDATE...), SYSDATE±k, etc.). We drop the *entire predicate*, including the adjacent boolean connector,
    to avoid leaving 't.col > AND' fragments.
    """
    s = (sql or "").strip().rstrip(";")

    # 1) BETWEEN with date literals: col BETWEEN <lit> AND <lit>
    date_lit = r"(?:TO_DATE\s*\([^)]*\)|DATE\s*'[^']+'|TIMESTAMP\s*'[^']+'|TRUNC\s*\(\s*SYSDATE[^)]*\)|SYSDATE\s*(?:[-+]\s*\d+)?)"
    between_pat = re.compile(
        rf"(?is)(?:^|\s)(?:AND|OR)?\s*([\w\.\"']+\s+BETWEEN\s+{date_lit}\s+AND\s+{date_lit})\s*(?=$|\s(?:AND|OR)\s)"
    )
    while True:
        m = between_pat.search(s)
        if not m:
            break
        span = m.span(1)
        # remove optional connector before/after too
        pre = s[:span[0]]
        post = s[span[1]:]
        pre = re.sub(r"(?is)(?:\s(?:AND|OR)\s*)?$", " ", pre)  # trim trailing connector
        post = re.sub(r"^(?:\s*(?:AND|OR)\s*)?", " ", post)   # trim leading connector
        s = (pre + post).strip()

    # 2) Simple comparisons with date literal: col <op> <lit>
    cmp_pat = re.compile(
        rf"(?is)(?:^|\s)(?:AND|OR)?\s*([\w\.\"']+\s*(?:=|<>|<=|>=|<|>)\s*{date_lit})\s*(?=$|\s(?:AND|OR)\s)"
    )
    while True:
        m = cmp_pat.search(s)
        if not m:
            break
        span = m.span(1)
        pre = s[:span[0]]
        post = s[span[1]:]
        pre = re.sub(r"(?is)(?:\s(?:AND|OR)\s*)?$", " ", pre)
        post = re.sub(r"^(?:\s*(?:AND|OR)\s*)?", " ", post)
        s = (pre + post).strip()

    # 3) Clean any doubled/leading/trailing connectors left behind
    s = re.sub(r"(?is)\s+(AND|OR)\s+(AND|OR)\s+", r" \1 ", s)
    s = re.sub(r"(?is)^\s*(AND|OR)\s+", " ", s)
    s = re.sub(r"(?is)\s+(AND|OR)\s*$", " ", s)
    s = re.sub(r"\s{2,}", " ", s).strip()
    return s + ";" if s else ""


def assemble_single_select(
    select: str,
    from_join_sql: str,
    where_extra: Optional[str],
    date_clause: Optional[str],
    group_by: Optional[str],
    having: Optional[str],
    order_by: Optional[str],
    limit_n: Optional[int],
    dialect: str = "Oracle",
) -> str:
    parts = ["SELECT " + select.strip(), from_join_sql.strip()]
    where_clauses = []
    if date_clause:
        where_clauses.append(date_clause.strip())
    if where_extra and where_extra.strip().lower() not in {"", "none", "n/a"}:
        where_clauses.append(where_extra.strip())
    if where_clauses:
        parts.append("WHERE " + " AND ".join(where_clauses))
    if group_by and group_by.strip():
        parts.append("GROUP BY " + group_by.strip())
    if having and having.strip():
        parts.append("HAVING " + having.strip())

    sql = "\n".join(parts).strip()
    sql = ensure_order_limit(sql, order_by, limit_n, dialect)
    sql = sanitize_sql(sql)
    # hard scrub after assembly
    sql = remove_date_literals(sql)
    # sql = strip_spurious_date_literals(sql)

    # guarantee bind range if caller asked for dates
    if date_clause and (":from_date" not in sql.lower() or ":to_date" not in sql.lower()):
        base = sql.rstrip(";")
        if " where " in base.lower():
            sql = base + " AND " + date_clause + ";"
        else:
            sql = base + " WHERE " + date_clause + ";"
    return sql


SQL_KEYWORDS = {
    "SELECT","FROM","WHERE","JOIN","LEFT","RIGHT","FULL","OUTER","ON","GROUP","BY","ORDER","HAVING",
    "AND","OR","SUM","COUNT","AVG","MIN","MAX","OVER","PARTITION","ROWS","RANGE","BETWEEN","AS","DESC","ASC",
    "FETCH","FIRST","ONLY","LIMIT","OFFSET","CASE","WHEN","THEN","END","DISTINCT","TOP","UNION","ALL"
}

def strip_code_fences(s: str) -> str:
    if not s: return s
    s = s.strip()
    s = re.sub(r"^```(?:sql)?", "", s, flags=re.I).strip()
    s = re.sub(r"```$", "", s).strip()
    return s

def sanitize_sql(sql: str) -> str:
    if not sql: return sql
    sql = strip_code_fences(sql)
    parts = [p.strip() for p in sql.split(";") if p.strip()]
    sql = parts[0] if parts else ""
    sql = re.sub(r"--.*?$", "", sql, flags=re.M).strip()
    sql = re.sub(r"/\*.*?\*/", "", sql, flags=re.S).strip()
    sql = re.sub(r"\s+", " ", sql).strip()
    if sql and not sql.endswith(";"):
        sql += ";"
    return sql

def looks_like_select(sql: str) -> bool:
    return bool(re.match(r"^\s*select\b", sql or "", flags=re.I))

def ensure_order_limit(sql: str, order_by: Optional[str], limit_n: Optional[int], dialect: str) -> str:
    s = (sql or "").strip().rstrip(";")
    if order_by:
        if re.search(r"(?is)\border\s+by\b", s):
            s = re.sub(r"(?is)\border\s+by\s+[^;]+$", f"ORDER BY {order_by}", s)
        else:
            s += f" ORDER BY {order_by}"
    if limit_n is not None:
        if "oracle" in dialect.lower():
            if re.search(r"(?is)\bfetch\s+first\b", s):
                s = re.sub(r"(?is)\bfetch\s+first\s+\d+\s+rows\s+only\b", f"FETCH FIRST {int(limit_n)} ROWS ONLY", s)
            else:
                s += f" FETCH FIRST {int(limit_n)} ROWS ONLY"
        else:
            if re.search(r"(?is)\blimit\b\s+\d+\b", s):
                s = re.sub(r"(?is)\blimit\b\s+\d+\b", f"LIMIT {int(limit_n)}", s)
            else:
                s += f" LIMIT {int(limit_n)}"
    return s + ";"

def strip_spurious_date_literals(sql: str) -> str:
    s = (sql or "").strip().rstrip(";")
    s = re.sub(r"(?is)\s+(and|or)\s+[a-z0-9_\.]*date[ a-z0-9_\.]*[<>=]{1,2}\s*'[^']+'\s*", " ", s)
    s = re.sub(r"(?is)\s+(and|or)\s+[a-z0-9_\.]*date[ a-z0-9_\.]*\s+between\s*'[^']+'\s*and\s*'[^']+'\s*", " ", s)
    s = re.sub(r"\s{2,}", " ", s).strip()
    return s + ";"

def wants_dates(user_query: str) -> bool:
    q = (user_query or "").lower()
    return any(k in q for k in [
        "between","from","to","since","until","yesterday","today","last","this","prev",
        "jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec","20"
    ])

def parse_sql_from_json_or_text(text: str) -> str:
    s = (text or "").strip()
    try:
        obj = json.loads(s)
        sql = (obj.get("sql") or "").strip()
        if sql:
            return sql
    except Exception:
        pass
    s = strip_code_fences(s)
    m = re.search(r"(?is)\bselect\b.+", s)
    return m.group(0).strip() if m else s

# -----------------------------
# Date column picking (metadata-aware)
# -----------------------------
LIKELY_DATE_NAMES = [
    "entry_datetime","entry_date","trade_date","txn_date","transaction_date","order_date",
    "initial_date","termination_date","business_date","created_at","timestamp","date","dt"
]

def _ensure_date_params(sql: str, date_col: str) -> str:
    s = sql.strip().rstrip(";")
    lower = s.lower()
    if (":from_date" in lower) and (":to_date" in lower):
        return s + ";"
    clause = f"{date_col} BETWEEN :from_date AND :to_date"
    if re.search(r"(?i)\bwhere\b", s):
        s = re.sub(r"(?is)\bwhere\b", f"WHERE {clause} AND ", s, count=1)
    else:
        m = re.search(r"(?is)\b(group\s+by|order\s+by|limit|fetch)\b", s)
        if m:
            s = s[:m.start()] + " WHERE " + clause + " " + s[m.start():]
        else:
            s = s + " WHERE " + clause
    return s.strip() + ";"

def pick_best_date_col(main_table: str, columns_by_table: Dict[str, List[str]], date_like_by_table: Dict[str, List[str]]|None=None) -> str:
    main = (main_table or "").upper()
    # strongest signal: enriched date_like list for main table
    if date_like_by_table and main in date_like_by_table and date_like_by_table[main]:
        return f"t.{date_like_by_table[main][0]}"
    # else heuristic by name on main table
    for c in (columns_by_table.get(main, []) or []):
        lc = c.lower()
        if any(w in lc for w in LIKELY_DATE_NAMES):
            return f"t.{c}"
    # fallback: first column named DATE/DT/TIME on any table
    for t, cols in (columns_by_table or {}).items():
        for c in cols:
            lc = c.lower()
            if any(w in lc for w in ["date","_dt","time","timestamp"]):
                return f"t.{c}" if t.upper()==main else f"t.{c}"
    return "t.trade_date"

def ensure_date_params(sql: str, date_col: str) -> str:
    s = (sql or "").strip().rstrip(";")
    lower = s.lower()
    if (":from_date" in lower) and (":to_date" in lower):
        return s + ";"
    clause = f"{date_col} BETWEEN :from_date AND :to_date"
    if re.search(r"(?i)\bwhere\b", s):
        s = re.sub(r"(?is)\bwhere\b", f"WHERE {clause} AND ", s, count=1)
    else:
        m = re.search(r"(?is)\b(group\s+by|order\s+by|limit|fetch)\b", s)
        if m:
            s = s[:m.start()] + " WHERE " + clause + " " + s[m.start():]
        else:
            s = s + " WHERE " + clause
    return s.strip() + ";"

# -----------------------------
# Schema → graph helpers (from enriched metadata)
# -----------------------------
def as_upper_name(x: str) -> str:
    return (x or "").upper()

def build_columns_by_table(enriched_tables: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for t in enriched_tables:
        tname = as_upper_name(t.get("table_name"))
        cols = t.get("columns") or []
        out[tname] = [(c.get("column_name") if isinstance(c, dict) else str(c)) for c in cols]
    return out

def build_date_like_by_table(enriched_tables: List[Dict[str, Any]]) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for t in enriched_tables:
        tname = as_upper_name(t.get("table_name"))
        out[tname] = [str(c) for c in (t.get("date_like_cols") or [])]
    return out

def build_fk_graph(enriched_tables: List[Dict[str, Any]]) -> Dict[Tuple[str,str], List[Tuple[List[str], str, List[str]]]]:
    """
    Graph keyed by (child_table, parent_table) → list of FK edges
    Each edge: (child_cols, parent_owner.parent_table, parent_cols)
    Self-edges (table -> same table) are skipped.
    """
    g: Dict[Tuple[str,str], List[Tuple[List[str], str, List[str]]]] = {}
    for t in enriched_tables:
        child = as_upper_name(t.get("table_name"))
        for fk in (t.get("fks_out") or []):
            parent = as_upper_name(fk.get("ref_table"))
            if not parent or parent == child:
                continue  # skip self edge
            child_cols = [as_upper_name(c) for c in (fk.get("cols") or [])]
            parent_cols = [as_upper_name(c) for c in (fk.get("ref_cols") or [])]
            g.setdefault((child, parent), []).append(
                (child_cols, f"{as_upper_name(fk.get('ref_owner'))}.{parent}", parent_cols)
            )
    return g

def _adjacency_from_fks(
    fk_graph: Dict[Tuple[str,str], List[Tuple[List[str], str, List[str]]]]
) -> Dict[str, List[Tuple[str, Tuple[List[str], str, List[str]], bool]]]:
    """
    Undirected adjacency from FK edges.
    node -> list of (neighbor, edge_payload, direction_is_child_to_parent)
    Keep only one representative edge per unordered pair.
    """
    adj: Dict[str, List[Tuple[str, Tuple[List[str], str, List[str]], bool]]] = {}
    seen_pair = set()
    for (child, parent), edges in fk_graph.items():
        if not edges:
            continue
        key = tuple(sorted([child, parent]))
        if key in seen_pair:
            continue
        seen_pair.add(key)
        payload = edges[0]  # (child_cols, ref_qualified, parent_cols)
        adj.setdefault(child, []).append((parent, payload, True))   # child -> parent
        adj.setdefault(parent, []).append((child, payload, False))  # parent -> child
    return adj

def _bfs_connected_within_selection(
    main: str,
    wanted: Set[str],
    adj: Dict[str, List[Tuple[str, Tuple[List[str], str, List[str]], bool]]],
) -> Tuple[Set[str], List[Tuple[str,str,Tuple[List[str],str,List[str]]]]]:
    """
    BFS from main but ONLY across nodes that are in `wanted`.
    Returns:
      - connected set (subset of wanted that is reachable from main),
      - list of directed edges (child, parent, payload) connecting those nodes.
    """
    main = as_upper_name(main)
    if main not in wanted:
        wanted = set(wanted)
        wanted.add(main)

    visited: Set[str] = set()
    parent_edge: Dict[str, Tuple[str, Tuple[List[str],str,List[str]]]] = {}

    queue: List[str] = []
    if main in wanted:
        queue.append(main)
        visited.add(main)

    while queue:
        u = queue.pop(0)
        for v, payload, dir_c2p in adj.get(u, []):
            v = as_upper_name(v)
            if v in visited:
                continue
            # only traverse inside the selected set
            if v not in wanted:
                continue
            visited.add(v)
            queue.append(v)

            # Orient edge for JOIN: payload describes child_cols vs parent_cols.
            # We want a directed tuple (child, parent, payload).
            child, parent = (u, v) if dir_c2p and u != v else (v, u)
            parent_edge[v] = (u, (payload[0], payload[1], payload[2]))

    # Build edges connecting visited nodes (excluding the root)
    edges: List[Tuple[str,str,Tuple[List[str],str,List[str]]]] = []
    for node in visited:
        if node == main:
            continue
        if node in parent_edge:
            _p, payload = parent_edge[node]
            child_cols, refq, parent_cols = payload
            # Deduce (child,parent) names from payload orientation relative to 'node' and its parent
            # Here we keep (child,parent) as (node, parent_of_node) if the payload originally was child→parent
            # Otherwise invert. parent name is _p.
            if (node, _p) and child_cols and parent_cols:
                # We can't perfectly infer orientation for all cases; the important bit is we have column pairs.
                edges.append((node, _p, (child_cols, refq, parent_cols)))
            else:
                edges.append((node, _p, (child_cols, refq, parent_cols)))
    return visited, edges

def replace_unknown_aliases(sql: str, known_aliases: set[str]) -> str:
    """
    Replace any alias like X.col (unknown X) with t.col in the entire SQL string.
    """
    if not sql:
        return sql
    # Build a negative-lookahead for known aliases
    if not known_aliases:
        known_aliases = {"t"}
    pattern = rf'\b(?!({"|".join(map(re.escape, known_aliases))})\.)([A-Za-z]\w*)\.'
    return re.sub(pattern, 't.', sql)


def build_from_join_sql(owner: str, main_table: str, tables: List[str], fk_graph) -> Tuple[str, Dict[str,str]]:
    """
    Build FROM/JOIN using only FK-connected tables within the selected `tables`.
    - Drops unconnected tables (no cartesian joins).
    - Skips self-joins and edges without real ON columns.
    - Deduplicates joins per (child,parent) unordered pair.
    """
    wanted_u = []
    seen = set()
    for x in [main_table] + [t for t in tables if as_upper_name(t) != as_upper_name(main_table)]:
        u = as_upper_name(x)
        if u and u not in seen:
            wanted_u.append(u)
            seen.add(u)

    if not wanted_u:
        mt = as_upper_name(main_table)
        return f'FROM "{owner}"."{mt}" t', {mt: "t"}

    # adjacency (undirected) from FK graph
    def _adj(fk_graph):
        adj = {}
        seen_pair = set()
        for (c, p), edges in fk_graph.items():
            if not edges: continue
            if c == p:    continue
            key = tuple(sorted((c, p)))
            if key in seen_pair: 
                continue
            seen_pair.add(key)
            payload = edges[0]  # (child_cols, ref_qualified, parent_cols)
            adj.setdefault(c, []).append((p, payload, True))   # child->parent
            adj.setdefault(p, []).append((c, payload, False))  # parent->child
        return adj

    adj = _adj(fk_graph)

    # BFS within selection
    main_u = wanted_u[0]
    wanted_set = set(wanted_u)
    visited = {main_u}
    parent_edge = {}
    queue = [main_u]

    while queue:
        u = queue.pop(0)
        for v, payload, dir_c2p in adj.get(u, []):
            v = as_upper_name(v)
            if v in visited or v not in wanted_set:
                continue
            visited.add(v); queue.append(v)
            # orient edge for join
            child_cols, refq, parent_cols = payload
            # we keep (child, parent) consistent with the payload meaning (child->parent)
            child, parent = (u, v) if dir_c2p else (v, u)
            parent_edge[v] = (child, (child_cols, refq, parent_cols))

    # order used nodes
    used_nodes = [x for x in wanted_u if x in visited]
    alias_map = {used_nodes[0]: "t"}
    letters = "ijklmnopqrstuvwxyzabcdefgh"
    for i, tn in enumerate(used_nodes[1:], 0):
        alias_map[tn] = letters[i]

    # build FROM/JOIN
    def q(name: str) -> str:
        return f'"{owner}"."{name}"'

    from_sql = f'FROM {q(used_nodes[0])} {alias_map[used_nodes[0]]}'

    added_pairs = set()
    for node in used_nodes[1:]:
        if node not in parent_edge:
            continue
        parent, (child_cols, _refq, parent_cols) = parent_edge[node]
        cU, pU = as_upper_name(node), as_upper_name(parent)
        if cU == pU:
            continue  # no self-joins
        if not child_cols or not parent_cols:
            continue  # skip ambiguous edge
        pair = tuple(sorted((cU, pU)))
        if pair in added_pairs:
            continue
        added_pairs.add(pair)

        ca = alias_map.get(cU)
        pa = alias_map.get(pU)
        if not ca or not pa:
            continue
        eqs = [f'{ca}."{cc}" = {pa}."{pc}"' for cc, pc in zip(child_cols, parent_cols)]
        from_sql += f' JOIN {q(pU)} {pa} ON ' + " AND ".join(eqs)

    return from_sql, alias_map

# -----------------------------
# Prompt-friendly summaries
# -----------------------------
def summarize_table_for_prompt(t: Dict[str, Any], max_cols: int = 16, max_indexes: int = 4, max_fks: int = 4) -> str:
    owner = t.get("owner") or ""
    name  = t.get("table_name") or ""
    cols_list = []
    for c in (t.get("columns") or []):
        if isinstance(c, dict):
            cols_list.append(c.get("column_name") or "")
        else:
            cols_list.append(str(c))
    head = ", ".join(cols_list[:max_cols]) + ("..." if len(cols_list) > max_cols else "")
    bits = [f"{(owner+'.' if owner else '')}{name}({head})"]
    pk = t.get("pk") or []
    if pk: bits.append(f"PK=({', '.join(pk)})")
    date_like = t.get("date_like_cols") or []
    if date_like: bits.append(f"DATE_COLS=({', '.join(date_like[:6])}{'...' if len(date_like)>6 else ''})")
    idxs = t.get("indexes") or []
    if idxs:
        idx_lines = []
        for idx in idxs[:max_indexes]:
            tag = "[U]" if idx.get("unique") else ""
            idx_lines.append(f"{idx.get('name')} {tag}({', '.join(idx.get('leading_cols', []) )})".strip())
        bits.append("IDX={" + "; ".join(idx_lines) + "}")
    fks = t.get("fks_out") or []
    if fks:
        lines = []
        for fk in fks[:max_fks]:
            lines.append(f"{','.join(fk.get('cols', []))}→{fk.get('ref_table')}({','.join(fk.get('ref_cols', []))})")
        bits.append("FK→{" + "; ".join(lines) + "}")
    return " | ".join(bits)

def assemble_schema_summary(enriched_tables: List[Dict[str,Any]], chosen_tables: List[str]) -> Tuple[str, Dict[str,List[str]], Dict[str,List[str]]]:
    """
    Returns (summary_text, columns_by_table, date_like_by_table) for only the chosen tables.
    """
    chosen_set = {as_upper_name(x) for x in chosen_tables}
    subset = [t for t in enriched_tables if as_upper_name(t.get("table_name")) in chosen_set]
    lines = [f"- {summarize_table_for_prompt(t)}" for t in subset]
    cbt = build_columns_by_table(subset)
    dlt = build_date_like_by_table(subset)
    return ("\n".join(lines) if lines else "N/A"), cbt, dlt

# -----------------------------
# Main table inference (generic)
# -----------------------------
def infer_main_table(user_query: str, candidates: List[str], enriched_tables: List[Dict[str,Any]]) -> str:
    """
    Heuristics (no hardcoding to ATS):
    - If a single candidate → pick it.
    - Prefer table with more inbound FKs (often 'fact' tables).
    - Prefer table whose name appears in the query text.
    - Else pick the first candidate.
    """
    if not candidates:
        return ""
    if len(candidates) == 1:
        return candidates[0]
    q = (user_query or "").lower()
    cand_upper = [as_upper_name(t) for t in candidates]

    inbound_map = { as_upper_name(t.get("table_name")): int(t.get("fk_in_count", 0) or 0) for t in enriched_tables }
    best = None
    best_score = -1
    for t in cand_upper:
        score = 0
        if t.lower() in q: score += 2
        score += inbound_map.get(t, 0)
        if score > best_score:
            best = t; best_score = score
    return best or candidates[0]

# -----------------------------
# Soft validation
# -----------------------------
def only_allowed_identifiers(sql: str, allowed_tables: List[str], columns_by_table: Dict[str, List[str]]) -> bool:
    s = (sql or "").strip().rstrip(";")
    allowed_tables_u = {t.split(".")[-1].upper() for t in allowed_tables}
    for t in re.findall(r"\b([A-Z_][A-Z0-9_\$#\.]+)\b", s, flags=re.I):
        if t.upper() in SQL_KEYWORDS: continue
        if len(t) <= 2: continue
        bare = t.split(".")[-1].upper()
        if bare in allowed_tables_u: continue
    return True
