﻿# # setx HUGGINGFACEHUB_API_TOKEN "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"

# vectorize.py

"""
vectorize.py
-------------
Vectorize Oracle schema metadata for retrieval.

Design goals:
- Zero assumptions about column semantics (no guessing).
- Support tiny mocks → very large real schemas.
- Handle metadata as list (preferred) or dict (legacy).
- Batch embeddings; append to existing FAISS index.
- Prefer enriched→filtered→original metadata automatically.
"""

from __future__ import annotations
import os, json, argparse, time, hashlib
from typing import List, Dict, Any, Iterable, Generator

from utils.enrich_schema import ensure_enriched_metadata  # <- enrichment entrypoint

# ============================================================
# Helpers
# ============================================================

def _stable_id(prefix: str, *parts: str) -> str:
    h = hashlib.sha1("::".join(parts).encode("utf-8")).hexdigest()[:10]
    return f"{prefix}::{h}"

def _as_col_name_list(columns: List[Any]) -> List[str]:
    """
    Accept both enriched dicts and legacy strings.
    """
    names: List[str] = []
    for c in columns or []:
        if isinstance(c, dict):
            nm = c.get("column_name")
            if nm:
                names.append(nm)
        else:
            # legacy: c already is a string column name
            names.append(str(c))
    return names

# -----------------------------
# Metadata loader (list or dict)
# -----------------------------

def _load_metadata(path: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"Metadata file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Accept both shapes:
    # 1) list of table dicts
    if isinstance(data, list):
        return data
    # 2) dict: {table_name: table_meta}
    if isinstance(data, dict):
        out = []
        for tname, meta in data.items():
            if "table_name" not in meta:
                meta["table_name"] = tname
            out.append(meta)
        return out

    raise ValueError("Unsupported metadata JSON shape; expected list or dict.")


# ============================================================
# Chunk builders (now enrichment-aware, still factual)
# ============================================================

def build_table_chunk(table_meta: Dict[str, Any]) -> Dict[str, Any]:
    owner = table_meta.get("owner") or "UNKNOWN_OWNER"
    table = table_meta.get("table_name") or "UNKNOWN_TABLE"
    num_rows = table_meta.get("num_rows", "unknown")
    columns = table_meta.get("columns", []) or []
    table_comment = (table_meta.get("table_comment") or "").strip()

    # Enrichment (optional)
    pk_cols = table_meta.get("pk") or []
    fks_out = table_meta.get("fks_out") or []
    fk_in_count = int(table_meta.get("fk_in_count", 0) or 0)
    idx_list = table_meta.get("indexes") or []
    date_like_cols = table_meta.get("date_like_cols") or []
    last_analyzed = table_meta.get("last_analyzed")

    col_names = _as_col_name_list(columns)

    # Compact relational lines
    fk_lines = []
    for fk in fks_out:
        ref_owner = fk.get("ref_owner")
        ref_table = fk.get("ref_table")
        cols = ", ".join(fk.get("cols", []))
        ref_cols = ", ".join(fk.get("ref_cols", []))
        fk_lines.append(f"{cols} → {ref_owner}.{ref_table}({ref_cols})")

    idx_lines = []
    for idx in idx_list[:5]:  # limit to keep chunks tight
        lead = ", ".join(idx.get("leading_cols", []) or [])
        tag = "[U]" if idx.get("unique") else ""
        idx_lines.append(f"{idx.get('name')} {tag}({lead})".strip())

    parts = [
        f"Table {owner}.{table} has {len(col_names)} columns and approximately {num_rows} rows."
    ]
    if pk_cols:
        parts.append(f"PK: ({', '.join(pk_cols)})")
    if fk_lines:
        parts.append("FKs out: " + "; ".join(fk_lines))
    if fk_in_count:
        parts.append(f"Inbound FKs: {fk_in_count}")
    if idx_lines:
        parts.append("Indexes: " + "; ".join(idx_lines))
    if date_like_cols:
        parts.append("Date-like columns: " + ", ".join(date_like_cols[:10]))
    if last_analyzed:
        parts.append(f"Last analyzed: {last_analyzed}")
    if table_comment:
        parts.append(f"Description: {table_comment}")

    text = " ".join(parts)

    return {
        "id": _stable_id("table", owner, table),
        "text": text,
        "metadata": {
            "chunk_type": "table",
            "owner": owner,
            "table_name": table,
            "num_rows": num_rows,
            "pk": pk_cols,
            "fk_in_count": fk_in_count,
            "date_like_cols": date_like_cols,
            "columns": col_names,  # keep as plain list for downstream
        },
    }


def build_column_chunks(table_meta: Dict[str, Any]) -> List[Dict[str, Any]]:
    owner = table_meta.get("owner") or "UNKNOWN_OWNER"
    table = table_meta.get("table_name") or "UNKNOWN_TABLE"
    columns = table_meta.get("columns", []) or []

    chunks: List[Dict[str, Any]] = []
    for col in columns:
        # Support both enriched dicts and legacy strings
        if isinstance(col, dict):
            col_name = col.get("column_name") or "UNKNOWN_COLUMN"
            data_type = col.get("data_type", "UNKNOWN")
            data_length = col.get("data_length", None)
            nullable = col.get("nullable", None)
            comment = (col.get("column_comment") or "").strip()

            is_pk = bool(col.get("is_pk"))
            is_fk = bool(col.get("is_fk"))
            indexed = bool(col.get("indexed"))
            fk_target = col.get("fk_target")
            stats = col.get("stats")
            min_date = col.get("min_date")
            max_date = col.get("max_date")
        else:
            col_name = str(col)
            data_type = "UNKNOWN"
            data_length = None
            nullable = None
            comment = ""
            is_pk = is_fk = indexed = False
            fk_target = stats = min_date = max_date = None

        parts = [f"Column {owner}.{table}.{col_name}", f"data type {data_type}"]
        if data_length is not None:
            parts.append(f"length {data_length}")
        if nullable is not None:
            parts.append(f"nullable {nullable}")
        if is_pk:
            parts.append("primary key")
        if is_fk and fk_target:
            parts.append(
                "foreign key → "
                f"{fk_target.get('ref_owner')}.{fk_target.get('ref_table')}("
                f"{', '.join(fk_target.get('ref_cols', []))})"
            )
        if indexed:
            parts.append("indexed")
        if stats:
            ndv = stats.get("ndv")
            hist = stats.get("histogram")
            if ndv is not None:
                parts.append(f"ndv {ndv}")
            if hist:
                parts.append(f"histogram {hist}")
        if min_date or max_date:
            if min_date:
                parts.append(f"min {min_date}")
            if max_date:
                parts.append(f"max {max_date}")
        if comment:
            parts.append(f"comment: {comment}")

        text = ". ".join(parts) + "."

        chunks.append({
            "id": _stable_id("col", owner, table, col_name),
            "text": text,
            "metadata": {
                "chunk_type": "column",
                "owner": owner,
                "table_name": table,
                "column_name": col_name,
                "data_type": data_type,
                "data_length": data_length,
                "nullable": nullable,
                "is_pk": is_pk,
                "is_fk": is_fk,
                "indexed": indexed,
            },
        })
    return chunks


def build_sample_chunks(table_meta: Dict[str, Any], max_rows: int = 5) -> List[Dict[str, Any]]:
    # Optional: if your crawler adds sample_rows later; otherwise silent no-op
    owner = table_meta.get("owner") or "UNKNOWN_OWNER"
    table = table_meta.get("table_name") or "UNKNOWN_TABLE"
    rows = table_meta.get("sample_rows") or []
    chunks: List[Dict[str, Any]] = []
    for i, row in enumerate(rows[:max_rows]):
        text = f"Sample row from {owner}.{table}: {json.dumps(row, default=str)}"
        chunks.append({
            "id": _stable_id("sample", owner, table, str(i)),
            "text": text,
            "metadata": {
                "chunk_type": "sample",
                "owner": owner,
                "table_name": table,
                "columns": list(row.keys()),
            }
        })
    return chunks


def iter_chunks_from_metadata(
    metadata_path: str,
    include_columns: bool = True,
    include_samples: bool = False,
) -> Generator[Dict[str, Any], None, None]:
    tables = _load_metadata(metadata_path)
    for tmeta in tables:
        yield build_table_chunk(tmeta)
        if include_columns:
            for c in build_column_chunks(tmeta):
                yield c
        if include_samples:
            for s in build_sample_chunks(tmeta):
                yield s


# ============================================================
# Embedding + VectorStore (LangChain FAISS) with batching
# ============================================================

from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

class VectorStoreManager:
    def __init__(
        self,
        persist_dir: str = "./data/faiss_oracle",
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
    ):
        self.persist_dir = persist_dir
        os.makedirs(self.persist_dir, exist_ok=True)
        self.embedder = HuggingFaceEmbeddings(model_name=model_name)
        self.index: FAISS | None = None

    def _ensure_loaded(self):
        if self.index is None:
            if os.path.exists(os.path.join(self.persist_dir, "index.faiss")):
                # allow_dangerous_deserialization required for LangChain FAISS
                self.index = FAISS.load_local(
                    self.persist_dir, self.embedder, allow_dangerous_deserialization=True
                )

    def reset(self):
        # Clear any on-disk index (use with caution)
        for fn in ["index.faiss", "index.pkl"]:
            p = os.path.join(self.persist_dir, fn)
            if os.path.exists(p):
                os.remove(p)
        self.index = None

    def add_chunks_batched(self, chunks: Iterable[Dict[str, Any]], batch_size: int = 1024):
        """
        Add chunks in batches to control memory. Can append to an existing index.
        """
        # If an index already exists on disk, load it for appending
        self._ensure_loaded()

        batch_texts: List[str] = []
        batch_metas: List[Dict[str, Any]] = []
        batch_ids: List[str] = []

        def _flush():
            if not batch_texts:
                return
            if self.index is None:
                self.index = FAISS.from_texts(
                    texts=batch_texts,
                    embedding=self.embedder,
                    metadatas=batch_metas,
                    ids=batch_ids,
                )
            else:
                self.index.add_texts(
                    texts=batch_texts,
                    metadatas=batch_metas,
                    ids=batch_ids,
                )
            # persist incrementally
            self.index.save_local(self.persist_dir)
            # clear buffers
            batch_texts.clear()
            batch_metas.clear()
            batch_ids.clear()

        for c in chunks:
            batch_texts.append(c["text"])
            batch_metas.append(c.get("metadata", {}))
            batch_ids.append(c["id"])
            if len(batch_texts) >= batch_size:
                _flush()
        _flush()

    def search(self, query: str, k: int = 5):
        self._ensure_loaded()
        if self.index is None:
            raise RuntimeError("Vector index not available; build it first.")
        return self.index.similarity_search(query, k=k)


# ============================================================
# CLI
# ============================================================

def _pick_metadata_path(args) -> str:
    """
    Preference:
      1) If --auto-enrich: use <filtered if available else original> then enrich to .enriched.json
      2) Else if --use_filtered and <.filtered.json> exists: use it
      3) Else use args.metadata as-is
    """
    meta_path = args.metadata

    # Prefer .filtered.json where appropriate
    root, ext = os.path.splitext(meta_path)
    filtered = root + ".filtered.json"
    if args.auto_enrich:
        base = meta_path
        if not meta_path.endswith(".filtered.json") and os.path.exists(filtered):
            print(f"📦 Using filtered for enrichment: {filtered}")
            base = filtered
        # This will return .enriched.json if it can create/use it, else it returns base unchanged
        # enriched = ensure_enriched_metadata(
        #     metadata_path=base,
        #     owner=args.owner,
        #     with_stats=args.with_stats,
        #     with_minmax=args.with_minmax,
        #     max_probe_tables=args.max_probe_tables,
        #     max_date_cols_per_table=args.max_date_cols_per_table,
        #     per_query_timeout_s=args.per_query_timeout_s,
        # )
        enriched = ensure_enriched_metadata(
            metadata_path=base,
            owner=args.owner,
            with_stats=args.with_stats,
            with_minmax=args.with_minmax,
            max_probe_tables=args.max_probe_tables,
            max_date_cols_per_table=args.max_date_cols_per_table,
            per_query_timeout_s=args.per_query_timeout_s,
            # NEW:
            oracle_user=args.oracle_user,
            oracle_password=args.oracle_password,
            oracle_dsn=args.oracle_dsn,
        )
        if enriched != base:
            print(f"🧠 Using enriched metadata: {enriched}")
        return enriched

    # Not enriching: optionally use filtered
    if args.use_filtered and os.path.exists(filtered):
        print(f"📦 Using filtered metadata: {filtered}")
        return filtered

    return meta_path


def main():
    ap = argparse.ArgumentParser(description="Vectorize Oracle schema metadata → FAISS")
    ap.add_argument("--metadata", default="./data/oracle_schema/ats_schema_metadata.json",
                    help="Path to crawler output JSON (original or filtered)")
    ap.add_argument("--owner", default="ATS", help="Oracle schema owner (for enrichment)")
    ap.add_argument("--auto-enrich", action="store_true",
                    help="Create/use <metadata>.enriched.json with PK/FK/index/last_analyzed, etc.")
    ap.add_argument("--use_filtered", action="store_true",
                    help="Prefer <metadata>.filtered.json when not enriching")
    ap.add_argument("--with-stats", action="store_true",
                    help="(enrichment) include column NDV/histogram when available")
    ap.add_argument("--with-minmax", action="store_true",
                    help="(enrichment) probe min/max for date-like columns (guarded/timeboxed)")
    ap.add_argument("--max-probe-tables", type=int, default=20,
                    help="(enrichment) max number of tables to probe for min/max date")
    ap.add_argument("--max-date-cols-per-table", type=int, default=2,
                    help="(enrichment) per-table cap on probed date-like columns")
    ap.add_argument("--per-query-timeout-s", type=int, default=3,
                    help="(enrichment) timeout per min/max probe query in seconds")

    ap.add_argument("--persist_dir", default="./data/faiss_oracle",
                    help="Directory to persist FAISS index")
    ap.add_argument("--reset", action="store_true", help="Delete existing FAISS index before building")
    ap.add_argument("--no-columns", action="store_true", help="Do not create per-column chunks")
    ap.add_argument("--samples", action="store_true", help="Include sample-row chunks if present")
    ap.add_argument("--batch-size", type=int, default=1024, help="Embedding batch size (number of chunks)")
    ap.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2", help="HF embedding model name")
    ap.add_argument("--oracle-user", default=os.getenv("ORACLE_USER"))
    ap.add_argument("--oracle-password", default=os.getenv("ORACLE_PASSWORD"))
    ap.add_argument("--oracle-dsn", default=os.getenv("ORACLE_DSN"))

    args = ap.parse_args()

    # pick metadata (enriched → filtered → original)
    meta_path = _pick_metadata_path(args)

    vs = VectorStoreManager(persist_dir=args.persist_dir, model_name=args.model)
    if args.reset:
        print("🔁 Resetting index …")
        vs.reset()

    started = time.time()
    chunks = iter_chunks_from_metadata(
        meta_path,
        include_columns=not args.no_columns,
        include_samples=args.samples,
    )
    vs.add_chunks_batched(chunks, batch_size=args.batch_size)
    print(f"✅ Done in {time.time() - started:.2f}s. Index at: {args.persist_dir}")

    # quick smoke test (optional)
    try:
        hits = vs.search("daily trades by instrument between dates", k=5)
        for i, h in enumerate(hits, 1):
            md = h.metadata
            print(f"{i}. {md.get('owner')}.{md.get('table_name')} [{md.get('chunk_type')}] → {h.page_content[:96]}…")
    except Exception:
        pass


if __name__ == "__main__":
    main()
