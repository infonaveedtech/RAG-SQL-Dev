"""
mock_data.py
-------------
Creates a local SQLite-based mock Oracle database for testing the RAG pipeline.

This allows us to test:
- Schema extraction
- Query execution
- Report generation
without needing a live Oracle connection.
"""

import sqlite3
import random
import datetime
from typing import Tuple
random.seed(42)


# ---------------------------------------------------------------------
# Helper to create mock trading-related tables and seed sample data
# ---------------------------------------------------------------------
def create_mock_db_connection() -> Tuple[sqlite3.Connection, sqlite3.Cursor]:
    """
    Creates a mock SQLite DB in memory with sample trading data.
    Returns both connection and cursor.
    """
    conn = sqlite3.connect(":memory:")
    cur = conn.cursor()

    # ----------------------------------------------------------
    # 1️⃣ Create tables similar to what Oracle might have
    # ----------------------------------------------------------
    cur.executescript("""
    CREATE TABLE INSTRUMENTS (
        instrument_id TEXT PRIMARY KEY,
        instrument_name TEXT,
        category TEXT
    );

    CREATE TABLE TRADE_DATA (
        trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
        instrument_id TEXT,
        trade_date DATE,
        trade_volume INTEGER,
        trade_price REAL,
        FOREIGN KEY (instrument_id) REFERENCES INSTRUMENTS (instrument_id)
    );
    """)

    # ----------------------------------------------------------
    # 2️⃣ Seed instruments
    # ----------------------------------------------------------
    instruments = [
        ("ABC", "Alpha Bond Corp", "Bonds"),
        ("XYZ", "Xylon Energy Ltd", "Equities"),
        ("LMN", "Lumen Metals Inc", "Commodities"),
        ("PQR", "Prime Real Estate", "REITs"),
        ("I005", "Orion Tech PLC", "Bonds"),          # new
        ("I006", "GreenFields Agro Ltd", "Bonds")
    ]
    cur.executemany("INSERT INTO INSTRUMENTS VALUES (?, ?, ?)", instruments)

    # ----------------------------------------------------------
    # 3️⃣ Seed trade data
    # ----------------------------------------------------------
    start_date = datetime.date(2024, 1, 1)
    for i in range(180):  # ~6 months of sample data
        trade_date = start_date + datetime.timedelta(days=i)
        for inst in instruments:
            instrument_id = inst[0]
            trade_volume = random.randint(50, 1000)
            trade_price = round(random.uniform(80, 150), 2)
            cur.execute(
                "INSERT INTO TRADE_DATA (instrument_id, trade_date, trade_volume, trade_price) VALUES (?, ?, ?, ?)",
                (instrument_id, trade_date, trade_volume, trade_price),
            )

    conn.commit()
    print("✅ Mock Oracle (SQLite) DB initialized with sample trading data.")
    return conn, cur


# Quick standalone test
if __name__ == "__main__":
    conn, cur = create_mock_db_connection()
    res = cur.execute("SELECT instrument_id, SUM(trade_volume) FROM TRADE_DATA GROUP BY instrument_id").fetchall()
    print(res)
