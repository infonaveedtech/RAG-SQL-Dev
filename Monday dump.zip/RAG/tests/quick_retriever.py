# quick_retrieval_check.py
from src.retriever import SchemaRetriever
r = SchemaRetriever(persist_dir="./data/faiss")
ctx = r.retrieve_schema_context("Show total trade volume for each instrument between Jan and Feb 2024", k=5)
print(ctx)
