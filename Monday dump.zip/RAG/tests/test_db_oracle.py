import oracledb, os, socket, sys
dsn = os.getenv("ORACLE_DSN") or "192.168.36.227:1521/DEVDB"   # adjust here
user = os.getenv("ORACLE_USER") or "ATS"
pwd  = os.getenv("ORACLE_PASSWORD") or "ABC"

print("DNS/Host reachability:")
host = dsn.split(':')[0]
try:
    print(host, "->", socket.gethostbyname(host))
except Exception as e:
    print("DNS lookup failed:", e)

try:
    conn = oracledb.connect(user=user, password=pwd, dsn=dsn, config_dir=None, retry_count=2, retry_delay=2)
    cur = conn.cursor()
    cur.execute("select 1 from dual")
    print("OK:", cur.fetchone())
except Exception as e:
    print("FAIL:", type(e).__name__, e)
    raise
