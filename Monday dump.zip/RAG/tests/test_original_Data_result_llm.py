# pipeline_smoke.py
from __future__ import annotations

import os
from typing import Dict, List

from db_conn import db_session, test_connection # just to verify connectivity
from retriever import SchemaRetriever, TableContext
from sql_generator import SQLGenerator

# --- Config you already use elsewhere ---
FAISS_DIR = "./data/faiss_oracle"
METADATA_JSON = "./data/oracle_schema/ats_schema_metadata.json"
DEFAULT_OWNER = "ATS"

# Provide Oracle creds via env or your config.settings
os.environ["ORACLE_DSN"] = "192.168.36.227:1521/DEVDB"
os.environ["ORACLE_USER"] = "ATS"
os.environ["ORACLE_PASSWORD"] = "ABC"

def _build_generator_context(
    user_query: str,
    table_ctxs: List[TableContext],
) -> Dict:
    """
    Convert retriever TableContext objects into the flat fields your current
    SQLGenerator expects (relevant_tables, relevant_columns, context_snippets).
    """
    # Ranked candidate tables (keep order from retriever)
    relevant_tables = [f"{tc.owner}.{tc.table_name}" for tc in table_ctxs]

    # Flat list of fully-qualified columns (schema.table.column) for all candidates
    relevant_columns: List[str] = []
    for tc in table_ctxs:
        for col in tc.columns:
            # e.g., ATS.TRADES_20FEB25.ENTRY_DATETIME
            relevant_columns.append(f"{tc.owner}.{tc.table_name}.{col.column_name}")

    ctx = {
        "query": user_query,
        "relevant_tables": relevant_tables,
        "relevant_columns": relevant_columns,
        "context_snippets": [],  # optional (we use metadata-driven cols instead)
        # If you later adopt the upgraded generator, you can also pass:
        # "columns_by_table": {f"{tc.owner}.{tc.table_name}": [c.column_name for c in tc.columns] for tc in table_ctxs},
        # "main_table": relevant_tables[0] if relevant_tables else None,
    }
    return ctx

def main():
    # 0) DB connectivity check (no query execution yet)
    ok = test_connection(mode="oracle")
    if ok:
        print("🔌 Oracle connectivity looks good.")
    else:
        print("⚠️ Could not confirm Oracle connectivity (missing driver/creds?). Proceeding with generation-only test.")

    # 1) Init retriever on your existing FAISS + metadata
    retriever = SchemaRetriever(
        persist_dir=FAISS_DIR,
        metadata_path=METADATA_JSON,
        default_owner=DEFAULT_OWNER,
    )

    # 2) Natural-language test queries
    test_queries = [
        "daily trades by instrument between 2024-01-01 and 2024-02-15",
        "top 10 symbols by traded value last month",
        "get orders with both order date and trade date columns between 2024-07-01 and 2024-07-31",
    ]

    # 3) SQL generator (Oracle dialect)
    sqlgen = SQLGenerator(dialect="Oracle", model="mistral:7b-instruct", use_llm=True)

    for uq in test_queries:
        print("\n" + "=" * 80)
        print(f"🧠 Query: {uq}")

        # 3a) Retrieve top candidate tables (date cols required is usually helpful)
        table_ctxs = retriever.retrieve(
            query=uq,
            k_tables=5,
            require_date_cols=True,
            mmr=True,
            search_k=48,
        )

        if not table_ctxs:
            print("❌ No candidate tables found. Did you run crawler.py + vectorize.py?")
            continue

        print(f"→ Retrieved {len(table_ctxs)} candidate tables:")
        for tc in table_ctxs[:3]:
            print(f"   • {tc.owner}.{tc.table_name}  (date cols: {tc.date_cols[:3]})")

        # 3b) Build generation context and produce SQL
        gen_ctx = _build_generator_context(uq, table_ctxs)
        sql = sqlgen.generate_sql(gen_ctx)

        print("\n✅ Generated SQL:")
        print(sql)

    print("\n🎉 Smoke test done. Next step: wire this into executor for actual DB runs.")

if __name__ == "__main__":
    main()
