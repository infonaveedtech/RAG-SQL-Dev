﻿"""
crawler.py — Oracle schema crawler (real ATS schema, full fidelity)

Purpose:
--------
Extracts the real Oracle schema metadata (for one owner, e.g., ATS) —
no assumptions, no column filtering.

Collects:
- Table metadata (name, num_rows, tablespace, comments)
- Column metadata (name, datatype, length, nullable, comments)
- (Optional) Small sample rows per table (JSON-serializable, safe types)

Usage:
------
# default crawl (no samples)
python crawler.py

# enable sampling (3 rows per table)
python crawler.py --sample-rows --sample-n 3
"""

from __future__ import annotations
import os
import json
import logging
import argparse
from typing import Any, Dict, List, DefaultDict
from collections import defaultdict
from datetime import datetime, date
from decimal import Decimal

from db_conn import db_session

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------
DEFAULT_OWNER = "ATS"
SAVE_PATH = "data/oracle_schema/ats_schema_metadata.json"

# conservative defaults to avoid heavy scans
DEFAULT_SAMPLE_ENABLE = False
DEFAULT_SAMPLE_ROWS = 3
DEFAULT_SAMPLE_MAX_COLS = 1000           # guard against extremely wide tables
DEFAULT_SAMPLE_SKIP_TYPES = {
    "BLOB", "CLOB", "NCLOB", "LONG", "LONG RAW", "RAW", "XMLTYPE", "SDO_GEOMETRY"
}

# ---------------------------------------------------------------------------
# Safe serialization helpers
# ---------------------------------------------------------------------------
def _safe_cell(v: Any) -> Any:
    """Convert DB cell to JSON-serializable value without blowing up."""
    if v is None:
        return None
    if isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, (datetime, date)):
        # ISO 8601 is deterministic, friendly to embeddings
        return v.isoformat(sep=" ")
    if isinstance(v, Decimal):
        # preserve exact text (avoid float rounding)
        return str(v)
    if isinstance(v, (bytes, bytearray, memoryview)):
        return f"<{type(v).__name__} {len(v)} bytes>"
    # fallback: string representation with type tag
    t = type(v).__name__
    s = str(v)
    if len(s) > 500:
        s = s[:500] + "…"
    return f"<{t}:{s}>"

def _row_to_dict(columns: List[str], row: tuple) -> Dict[str, Any]:
    return {columns[i]: _safe_cell(row[i]) for i in range(len(columns))}


# --- add near your sampler utilities in crawler.py ---

EXCLUDED_TYPES = ('BLOB', 'CLOB', 'NCLOB', 'BFILE', 'RAW', 'LONG', 'LONG RAW', 'XMLTYPE', 'SDO_GEOMETRY', 'ANYDATA', 'ANYTYPE', 'ANYDATASET','OBJECT','VARRAY','REF','ROWID','UROWID')

def _build_select_for_examples(owner, table, columns):
    sel_cols = []
    for c in columns:
        dt = c.get("data_type", "").upper()
        name = f"\"{c['column_name']}\""
        if any(t in dt for t in EXCLUDED_TYPES):
            continue
        if dt.startswith("DATE"):
            sel_cols.append(f"TO_CHAR({name}, 'YYYY-MM-DD') AS {name}")
        elif dt.startswith("TIMESTAMP"):
            sel_cols.append(f"TO_CHAR({name}, 'YYYY-MM-DD\"T\"HH24:MI:SS.FF') AS {name}")
        else:
            sel_cols.append(name)
    if not sel_cols:
        return None
    quoted = f"\"{owner}\".\"{table}\""
    return f"SELECT {', '.join(sel_cols)} FROM {quoted} ORDER BY DBMS_RANDOM.VALUE FETCH FIRST 2 ROWS ONLY"

def fetch_example_rows(conn, owner, table, columns):
    sql = _build_select_for_examples(owner, table, columns)
    if not sql:
        return []
    try:
        cur = conn.cursor()
        cur.execute(sql)
        colnames = [d[0] for d in cur.description]
        rows = []
        for r in cur.fetchall():
            obj = {}
            for k, v in zip(colnames, r):
                sv = _safe_cell(v)
                if isinstance(sv, str) and len(sv) > 200:
                    sv = sv[:200]
                obj[k] = sv
            rows.append(obj)
        return rows
    except Exception as e:
        logging.debug("Example fetch failed for %s.%s: %s", owner, table, e)
        return []

# ---------------------------------------------------------------------------
# Core function: crawl_schema()
# ---------------------------------------------------------------------------
def crawl_schema(
    owner: str = DEFAULT_OWNER,
    save_path: str = SAVE_PATH,
    attach_examples: bool = False
) -> List[Dict[str, Any]]:
    """
    Crawl Oracle data dictionary for a specific schema owner and extract
    all tables, columns, and comments; optionally attach small sample rows.

    Returns: list of table dicts, e.g.:
        {
            "owner": "ATS",
            "table_name": "TRADES",
            "num_rows": 12345,
            "tablespace": "USERS",
            "table_comment": "Trade transactions table",
            "columns": [
                {
                    "column_name": "TRADE_ID",
                    "data_type": "NUMBER",
                    "data_length": 22,
                    "nullable": "N",
                    "column_comment": "Trade identifier"
                },
                ...
            ],
            "sample_rows": [ {"TRADE_ID": 1, "ENTRY_DATE": "2025-10-11 09:30:00", ...}, ... ]   # if enabled
        }
    """
    logging.info(f"Starting Oracle schema crawl for owner '{owner}'...")
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    # ⚠️ pass your working creds here or via db_conn defaults
    with db_session(mode="oracle", user="ATS", password="ABC", dsn="192.168.36.227:1521/DEVDB") as conn:
        if not conn:
            logging.error("No Oracle DB connection available.")
            return []

        cur = conn.cursor()
        cur.arraysize = 1000

        # 1) table-level
        table_query = """
            SELECT owner, table_name, num_rows, tablespace_name
            FROM all_tables
            WHERE owner = :owner
            ORDER BY table_name
        """
        cur.execute(table_query, {"owner": owner})
        tables = [
            {
                "owner": row[0],
                "table_name": row[1],
                "num_rows": row[2],
                "tablespace": row[3],
            }
            for row in cur.fetchall()
        ]
        logging.info(f"Fetched {len(tables)} tables for owner {owner}.")

        # 2) table comments
        cur.execute("""
            SELECT owner, table_name, comments
            FROM all_tab_comments
            WHERE owner = :owner
        """, {"owner": owner})
        table_comments = { (r[0], r[1]): r[2] for r in cur.fetchall() if r[2] }

        # 3) columns
        col_query = """
            SELECT owner, table_name, column_name, data_type, data_length, nullable
            FROM all_tab_columns
            WHERE owner = :owner
            ORDER BY table_name, column_id
        """
        cur.execute(col_query, {"owner": owner})
        all_columns: DefaultDict[str, List[Dict[str, Any]]] = defaultdict(list)
        for row in cur.fetchall():
            all_columns[row[1]].append({
                "column_name": row[2],
                "data_type": row[3],
                "data_length": row[4],
                "nullable": row[5],
            })
        logging.info(f"Fetched column metadata for {len(all_columns)} tables.")

        # 4) column comments
        cur.execute("""
            SELECT owner, table_name, column_name, comments
            FROM all_col_comments
            WHERE owner = :owner
        """, {"owner": owner})
        col_comments = { (r[0], r[1], r[2]): r[3] for r in cur.fetchall() if r[3] }

        # 5) merge & optional sample rows
        final_data: List[Dict[str, Any]] = []
        for t in tables:
            tname = t["table_name"]
            tkey = (t["owner"], tname)
            cols = all_columns.get(tname, [])

            # attach column comments
            for c in cols:
                ckey = (t["owner"], tname, c["column_name"])
                if ckey in col_comments:
                    c["column_comment"] = col_comments[ckey]

            record = {
                **t,
                "table_comment": table_comments.get(tkey),
                "columns": cols
            }
            
            # (new) examples path (2 random rows)
            if attach_examples:
                examples = fetch_example_rows(conn, owner=t["owner"], table=tname, columns=cols)
                if examples:
                    record["examples"] = examples
            final_data.append(record)

        # 6) save
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(final_data, f, indent=2, ensure_ascii=False)

        logging.info(f"Schema crawl completed. Saved {len(final_data)} tables → {save_path}")
        return final_data

# ---------------------------------------------------------------------------
# Script entry
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    ap = argparse.ArgumentParser()
    ap.add_argument("--owner", default=DEFAULT_OWNER)
    ap.add_argument("--out", default=SAVE_PATH)
    ap.add_argument("--examples", action="store_true", help="Attach ~2 random example rows per table")    
    args = ap.parse_args()

    data = crawl_schema(
        owner=args.owner,
        save_path=args.out,
        attach_examples=args.examples
    )
    
    print(f"Extracted metadata for {len(data)} tables. Examples: {'ON' if args.examples else 'OFF'}")
