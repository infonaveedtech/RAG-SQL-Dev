﻿# executor.py
from __future__ import annotations
import argparse
import logging
import json
import time
from dataclasses import dataclass
from typing import Optional, Dict, List, Any

import oracledb

# --- our modules ---
from sql_generator import SQLGenerator, SQLGenResult
from utils.sql_exec_utils import normalize_binds_for_oracle


# ===============================================
# Data Models
# ===============================================
@dataclass
class ExecRequest:
    sql: str
    binds: Dict[str, Any]
    bind_params: Dict[str, str]
    preview_rows: int = 20
    timeout_ms: int = 30000


@dataclass
class ExecResult:
    ok: bool
    columns: Optional[List[str]] = None
    rows: Optional[List[tuple]] = None
    message: Optional[str] = None
    error_code: Optional[str] = None
    diagnostics: Optional[Dict[str, Any]] = None


# ===============================================
# Core SQL Executor (Oracle)
# ===============================================
class SQLExecutor:
    def __init__(self, user: str, password: str, dsn: str):
        self.user = user
        self.password = password
        self.dsn = dsn

    def execute(self, req: ExecRequest) -> ExecResult:
        start = time.time()
        sql = req.sql.strip()

        try:
            conn = oracledb.connect(user=self.user, password=self.password, dsn=self.dsn)
        except Exception as e:
            return ExecResult(ok=False, message=f"Failed to connect to Oracle: {e}")

        try:
            with conn.cursor() as cur:
                try:
                    cur.callTimeout = req.timeout_ms
                except Exception:
                    pass

                logging.info("Executing SQL:\n%s", sql)
                logging.info("Bind Values (raw): %s", json.dumps(req.binds, indent=2))

                # ✅ Normalize & coerce binds using our utility (handles DATE/TIMESTAMP/INT properly)
                binds_fixed, bind_warnings = normalize_binds_for_oracle(
                    sql=sql,
                    user_binds=req.binds or {},
                    bind_hints=req.bind_params or {}
                )
                if bind_warnings:
                    logging.info("Bind warnings: %s", "; ".join(bind_warnings))

                # (Optional) log types to prove they are datetime/ints at execution time
                try:
                    type_log = {k: f"{v} ({type(v).__name__})" for k, v in (binds_fixed or {}).items()}
                    logging.info("Bind Values (normalized): %s", json.dumps(type_log, indent=2, default=str))
                except Exception:
                    pass

                cur.execute(sql, binds_fixed)
                if cur.description:
                    cols = [d[0] for d in cur.description]
                    rows = cur.fetchmany(req.preview_rows)
                    elapsed = round((time.time() - start) * 1000, 2)
                    return ExecResult(
                        ok=True,
                        columns=cols,
                        rows=rows,
                        diagnostics={
                            "elapsed_ms": elapsed,
                            "rows_returned": len(rows),
                            "binds_used": list(req.binds.keys()),
                        },
                    )
                else:
                    conn.commit()
                    elapsed = round((time.time() - start) * 1000, 2)
                    return ExecResult(
                        ok=True,
                        message=f"Statement executed successfully. Rows affected: {cur.rowcount}",
                        diagnostics={"elapsed_ms": elapsed},
                    )

        except Exception as e:
            err = str(e)
            code = None
            if hasattr(e, "args") and len(e.args) > 0:
                code = getattr(e.args[0], "code", None)
            return ExecResult(ok=False, message=err, error_code=str(code))
        finally:
            conn.close()


# ===============================================
# Pipeline Runner (Generator → Executor)
# ===============================================
def run_pipeline_and_execute(
    user_query: str,
    from_date: str,
    to_date: str,
    limit: int,
    oracle_user: str,
    oracle_password: str,
    oracle_dsn: str,
    persist_dir: str = "./data/faiss_oracle",
    metadata_path: str = "./data/oracle_schema/ats_schema_metadata.json",
    owner: str = "ATS",
    model: str = "mistral:7b-instruct",
    preview_rows: int = 20,
):
    logging.info("==== Stage 1: Generating SQL from natural language ====")
    gen = SQLGenerator(persist_dir=persist_dir, metadata_path=metadata_path, owner=owner, model=model)
    res: SQLGenResult = gen.generate(user_query)

    if not res.ok:
        print("\n❌ SQL Generation Failed:")
        print(res.error or "Unknown error")
        return

    print("\n✅ SQL Generation Success")
    print("\n=== SQL ===\n", res.sql)
    print("\n=== Tables Used ===\n", json.dumps(res.tables_used, indent=2))
    print("\n=== Bind Params ===\n", json.dumps(res.bind_params, indent=2))

    # -------------------------------------------------
    # Stage 2: Execution
    # -------------------------------------------------
    logging.info("==== Stage 2: Executing SQL ====")
    binds = {
        "from_date": from_date,
        "to_date": to_date,
        "limit": limit,
    }

    exe = SQLExecutor(user=oracle_user, password=oracle_password, dsn=oracle_dsn)
    req = ExecRequest(sql=res.sql, binds=binds, bind_params=res.bind_params, preview_rows=preview_rows)
    out = exe.execute(req)

    if not out.ok:
        print("\n❌ Execution Failed")
        print(out.message)
        if out.error_code:
            print("Oracle Error Code:", out.error_code)
        return

    print("\n✅ Execution OK")
    if out.columns:
        print("Columns:", out.columns)
    if out.rows:
        print(f"\nPreview (first {preview_rows} rows):")
        for r in out.rows:
            print(r)
    if out.diagnostics:
        print("\nDiagnostics:", json.dumps(out.diagnostics, indent=2))


# ===============================================
# CLI Entry Point
# ===============================================
def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

    ap = argparse.ArgumentParser(description="End-to-end Oracle NL→SQL→Execution pipeline")

    ap.add_argument("--query", required=True, help="Natural language query to convert and run")
    ap.add_argument("--from_date", default="2022-07-01")
    ap.add_argument("--to_date", default="2022-08-31")
    ap.add_argument("--limit", type=int, default=10)
    ap.add_argument("--oracle_user", required=True)
    ap.add_argument("--oracle_password", required=True)
    ap.add_argument("--oracle_dsn", required=True)
    ap.add_argument("--preview", type=int, default=20)
    ap.add_argument("--model", default="mistral:7b-instruct")

    args = ap.parse_args()

    run_pipeline_and_execute(
        user_query=args.query,
        from_date=args.from_date,
        to_date=args.to_date,
        limit=args.limit,
        oracle_user=args.oracle_user,
        oracle_password=args.oracle_password,
        oracle_dsn=args.oracle_dsn,
        preview_rows=args.preview,
        model=args.model,
    )


if __name__ == "__main__":
    main()
