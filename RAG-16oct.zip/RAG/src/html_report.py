# html_report.py
from __future__ import annotations
import os
import sys
import subprocess
from pathlib import Path
import logging
import platform
import shutil
from typing import Dict, Any
from jinja2 import Environment, FileSystemLoader, select_autoescape

logger = logging.getLogger(__name__)

# -------------------- Templating --------------------
def render_html(template_dir: str, template_name: str, context: Dict[str, Any]) -> str:
    env = Environment(
        loader=FileSystemLoader(template_dir),
        autoescape=select_autoescape(["html", "xml"])
    )
    tpl = env.get_template(template_name)
    return tpl.render(**context)

def save_html(html: str, out_dir: str, basename: str) -> str:
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, basename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return path

# -------------------- Portable PDF backends --------------------
def _file_url(p: str) -> str:
    p = Path(p).resolve()
    if platform.system() == "Windows":
        return "file:///" + str(p).replace("\\", "/")
    return "file://" + str(p)

def _export_with_playwright(html_path: str, pdf_path: str) -> bool:
    """
    Preferred: Playwright (Chromium). Cross-platform, no hardcoded paths.
    Requires:
        pip install playwright
        playwright install chromium
    We auto-attempt install if browser missing.
    """
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except Exception:
        return False

    # ensure Chromium is installed
    try:
        # If not installed, this call will fail and we’ll run the installer below
        pass
    except Exception:
        pass
    try:
        # Attempt silent install if needed
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium", "--with-deps"],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
    except Exception:
        # ignore; the export may still work if already installed
        pass

    try:
        from playwright.sync_api import sync_playwright  # re-import after install
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, args=["--no-sandbox"])
            page = browser.new_page()
            page.goto(_file_url(html_path), wait_until="load")
            page.pdf(
                path=pdf_path,
                print_background=True,
                format="A4",
                margin={"top": "15mm", "bottom": "15mm", "left": "12mm", "right": "12mm"},
            )
            browser.close()
        logger.info(f"✅ PDF exported (Playwright/Chromium): {pdf_path}")
        return True
    except Exception as e:
        logger.debug(f"Playwright export failed: {e}")
        return False

def _export_with_wkhtmltopdf(html_path: str, pdf_path: str) -> bool:
    """
    Fallback 1: wkhtmltopdf, discovered via PATH (no hardcoding).
    Requires:
        wkhtmltopdf installed and available on PATH
        pip install pdfkit
    """
    exe = shutil.which("wkhtmltopdf")
    if not exe:
        return False
    try:
        import pdfkit  # type: ignore
    except Exception:
        return False
    try:
        config = pdfkit.configuration(wkhtmltopdf=exe)
        options = {
            "print-media-type": None,
            "enable-local-file-access": None,
            "quiet": "",
            "page-size": "A4",
            "dpi": 300,
        }
        pdfkit.from_file(html_path, pdf_path, configuration=config, options=options)
        logger.info(f"✅ PDF exported (wkhtmltopdf): {pdf_path}")
        return True
    except Exception as e:
        logger.debug(f"wkhtmltopdf export failed: {e}")
        return False

def _export_with_weasyprint(html_path: str, pdf_path: str) -> bool:
    """
    Fallback 2: WeasyPrint if system libs exist.
    Requires:
        pip install weasyprint
        plus OS deps (Cairo/Pango/…)
    """
    try:
        from weasyprint import HTML  # type: ignore
    except Exception:
        return False
    try:
        HTML(filename=html_path).write_pdf(pdf_path)
        logger.info(f"✅ PDF exported (WeasyPrint): {pdf_path}")
        return True
    except Exception as e:
        logger.debug(f"WeasyPrint export failed: {e}")
        return False

def export_html_to_pdf(html_path: str, pdf_path: str) -> bool:
    """
    Portable HTML→PDF with cascading backends:
      1) Playwright/Chromium
      2) wkhtmltopdf (from PATH)
      3) WeasyPrint
    Returns True on success, False otherwise (HTML remains saved).
    """
    for fn in (_export_with_playwright, _export_with_wkhtmltopdf, _export_with_weasyprint):
        if fn(html_path, pdf_path):
            return True

    # Nothing worked; keep HTML and log guidance
    logger.warning(
        "⚠️ PDF export skipped: none of the backends worked.\n"
        "Enable one of:\n"
        "  • pip install playwright  &&  playwright install chromium\n"
        "  • Install wkhtmltopdf and add it to PATH, then pip install pdfkit\n"
        "  • Install WeasyPrint with required system libraries"
    )
    return False
