from __future__ import annotations
from langchain_ollama import OllamaLLM

# class LLMClient:
#     def __init__(self, model: str = "llama3.1:8b", num_ctx: int = 8192):
#         self.model = model
#         self.llm_text = OllamaLLM(
#             model=self.model,
#             num_ctx=num_ctx,
#             temperature=0,
#             top_p=0,
#         )
#         self.llm_json = OllamaLLM(
#             model=self.model,
#             num_ctx=num_ctx,
#             temperature=0,
#             top_p=0,
#             format="json",
#         )

#     def generate(self, prompt: str, *, as_json: bool = False) -> str:
#         """Default to plain text (for fenced SQL). Use as_json=True only if you later need JSON."""
#         if as_json:
#             return self.llm_json.invoke(prompt)
#         return self.llm_text.invoke(prompt)


class LLMClient:
    def __init__(self, model: str = "llama3.1:8b", num_ctx: int = 8192):
        self.model = model
        print(f"🔹 Initializing LLMClient with model: {self.model}")
        self.llm_text = OllamaLLM(
            model=self.model,
            num_ctx=num_ctx,
            temperature=0,
            top_p=0,
        )
        self.llm_json = OllamaLLM(
            model=self.model,
            num_ctx=num_ctx,
            temperature=0,
            top_p=0,
            format="json",
        )
    def generate(self, prompt: str, *, as_json: bool = False) -> str:
        """Default to plain text (for fenced SQL). Use as_json=True only if you later need JSON."""
        if as_json:
            return self.llm_json.invoke(prompt)
        return self.llm_text.invoke(prompt)
