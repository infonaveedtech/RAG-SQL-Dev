from __future__ import annotations
import re
from typing import List
from retriever import TableContext

_SQL_FENCE = re.compile(r"```sql\s*(.*?)\s*```", re.I | re.S)

def build_schema_context(tctxs: List[TableContext]) -> str:
    """Compact, deterministic context: owner.table and a few columns."""
    lines = []
    for t in tctxs:
        cols = ", ".join(c.column_name for c in t.columns[:8] if c.column_name)
        lines.append(f"- {t.owner}.{t.table_name}  (cols: {cols})")
    return "\n".join(lines)

def build_prompt_v1(
    user_query: str,
    owner: str,
    tctxs: List[TableContext],
    repair_hint: str | None = None
) -> str:
    """
    Build an LLM prompt for SQL generation or repair.
    If repair_hint is provided, include it to guide the model in fixing a previous invalid SQL.
    """
    schema_ctx = build_schema_context(tctxs)

    return f"""
You are an expert **Oracle SQL** writer. Generate **only valid Oracle SQL**.
Follow these instructions with absolute precision.

### Input
User request:
{user_query}

{"--- Repair Instruction ---\n" + repair_hint if repair_hint else ""}

### Allowed schema
Use only the tables and columns listed below. Prefix each table with `{owner}`:
{schema_ctx}

### Rules
- Generate exactly **one SQL SELECT statement**, no explanations or comments.
- Use **explicit columns only** (no `SELECT *`).
- Use these bind variables exactly: `:from_date`, `:to_date`, `:limit`
- For date ranges, use: `TRUNC(<date_col>) BETWEEN :from_date AND :to_date`
- End with: `ORDER BY <relevant_column> FETCH FIRST :limit ROWS ONLY`
- Never use hard-coded TO_DATE() literals; always rely on bind parameters.
- Fully qualify all columns with their table aliases in SELECT, WHERE, JOIN, GROUP BY, and ORDER BY.
- Each alias must be unique across the query.
- Do not use `NATURAL JOIN` or `USING`. Always join with `ON`.
- When joining, reference only aliases already introduced in the FROM or previous JOINs.
- Do not mix implicit and explicit joins.
- Avoid implicit conversions.  
- If joining CHAR ↔ NUMBER, cast the NUMBER to VARCHAR2: `TRIM(char_col) = TO_CHAR(num_col)`.
- - Never join a DATE column directly to a VARCHAR2, NUMBER, or non-DATE column.
  Dates are for filtering (e.g., TRUNC(date_col) BETWEEN :from_date AND :to_date), not for joining.
  Join tables by logical keys such as SYMBOL_ID, LEVY_CODE, or other matching identifiers.
- Only apply arithmetic **inside** aggregations, never between two SUMs.
- Use numeric-safe aggregation only.
- Use `CASE` expressions inside aggregates if needed, and ensure they return numeric types.
- **Most important:**  
  If an ID column exists (e.g. `LEVY_TYPE_ID`, `EXCHANGE_ID`), prefer joining the related descriptive table (e.g. `LEVY_TYPES`, `EXCHANGES`)  
  and select its human-readable name (e.g. `LEVY_TYPE_NAME`, `EXCHANGE_NAME`) instead of the raw ID.
- When joining tables that both have date columns, do NOT join directly on equality (e.g. STATS_DATE = EFFECTIVE_FROM).
  Instead, join by logical relationships (e.g., symbol or ID) and filter the date columns separately with BETWEEN :from_date AND :to_date.

- Output must be a single fenced code block:

Example:
```sql
SELECT
  TRUNC(t.ENTRY_DATETIME) AS TRADE_DATE,
  t.SYMBOL_ID,
  SUM(t.VOLUME) AS VOLUME
FROM {owner}.NEGOTIATED_TRADES t
WHERE TRUNC(t.ENTRY_DATETIME) BETWEEN :from_date AND :to_date
GROUP BY TRUNC(t.ENTRY_DATETIME), t.SYMBOL_ID
ORDER BY TRADE_DATE DESC
FETCH FIRST :limit ROWS ONLY
```
Now produce the SQL for the user request using only tables and columns from the allowed schema.
"""



def extract_sql_from_fence(text: str) -> str:
    """Pull the SQL from a sql fenced block; allow plain SELECT/WITH fallback.""" 
    m = _SQL_FENCE.search(text or "") 
    if m: 
        sql = m.group(1).strip() 
    else: 
        t = (text or "").strip() 
        if not re.match(r"^(SELECT|WITH)\b", t, re.I): 
            raise ValueError("No sql fenced block found and output does not start with SELECT/WITH.")
        sql = t
    # strip a single trailing semicolon if present
    return re.sub(r";\s*$", "", sql)
