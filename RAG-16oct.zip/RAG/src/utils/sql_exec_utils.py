# utils/sql_exec_utils.py
from __future__ import annotations
import re
import datetime as dt
from dataclasses import dataclass
from typing import Dict, Iterable, Iterator, List, Optional, Tuple

# -----------------------------
# Safety regexes
# -----------------------------
TABLE_IN_FROM = re.compile(r"\bFROM\s+([A-Z][A-Z0-9_$#]*\.[A-Z][A-Z0-9_$#]*)", re.I)
TABLE_IN_JOIN = re.compile(r"\bJOIN\s+([A-Z][A-Z0-9_$#]*\.[A-Z][A-Z0-9_$#]*)", re.I)
FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|ALTER|DROP|TRUNCATE|GRANT|REVOKE|CREATE|BEGIN|END|EXCEPTION|EXEC|CALL)\b",
    re.I,
)
HAS_SELECT = re.compile(r"\bSELECT\b", re.I)
HAS_SEMICOLON = re.compile(r";")
HAS_COMMENT = re.compile(r"(--[^\n]*$)|(/\*.*?\*/)", re.S | re.M)
JSON_FUNCS = re.compile(r"\b(JSON_OBJECT|JSON_ARRAYAGG|JSON_ARRAY|JSON_OBJECTAGG|JSON_QUERY|JSON_TABLE)\b", re.I)

# trailing FETCH FIRST :limit ROWS ONLY (case/space tolerant)
FETCH_FIRST_BIND = re.compile(
    r"\s+FETCH\s+FIRST\s+:([A-Z0-9_]+)\s+ROWS\s+ONLY\s*$", re.I
)

# -----------------------------
# Data typings
# -----------------------------
@dataclass
class BindHint:
    name: str
    typ: str   # e.g., "DATE", "TIMESTAMP", "INT", "INT?", "DATE?"
    optional: bool = False

# -----------------------------
# Helpers
# -----------------------------
def strip_comments(sql: str) -> str:
    return HAS_COMMENT.sub("", sql)

def is_select_only(sql: str) -> Tuple[bool, List[str]]:
    errs: List[str] = []
    s = sql.strip()
    u = s.upper()
    if not HAS_SELECT.search(u):
        errs.append("SQL has no SELECT.")
    if FORBIDDEN.search(u):
        errs.append("Forbidden statement detected (DML/DDL/PLSQL).")
    # disallow multi-statement
    if HAS_SEMICOLON.search(s):
        errs.append("Multiple statements (semicolon) are not allowed.")
    return (len(errs) == 0, errs)

OWNER_TABLE = re.compile(r"\b([A-Z][A-Z0-9_$#]*)\.([A-Z][A-Z0-9_$#]*)\b", re.I)

def extract_owner_table_pairs(sql: str) -> List[tuple[str, str]]:
    """Return (OWNER, NAME) tokens seen as OWNER.NAME (case-preserved -> we return upper)."""
    u = sql.upper()
    return [(m.group(1).upper(), m.group(2).upper()) for m in OWNER_TABLE.finditer(u)]

def extract_tables_from_from_join(sql: str) -> List[tuple[str, str]]:
    """Return unique (OWNER, TABLE) pairs seen after FROM/JOIN only."""
    u = sql.upper()
    pairs: set[tuple[str,str]] = set()
    for rx in (TABLE_IN_FROM, TABLE_IN_JOIN):
        for m in rx.finditer(u):
            owner, table = m.group(1).split(".", 1)
            pairs.add((owner, table))
    return sorted(pairs)

def enforce_owner_table_allowlist_from_fromjoin(
    sql: str,
    owner: Optional[str],
    allowed_tables: Optional[set[str]],
) -> tuple[bool, list[str]]:
    """
    Check only real FROM/JOIN tables:
      - If owner is provided, enforce OWNER == owner
      - If allowed_tables provided, enforce TABLE ∈ allowed_tables
    """
    errs: list[str] = []
    pairs = extract_tables_from_from_join(sql)
    owner_up = owner.upper() if owner else None

    for o, t in pairs:
        if owner_up and o != owner_up:
            errs.append(f"Owner {o} not allowed; must be {owner_up}.")
        if allowed_tables is not None and t not in allowed_tables:
            errs.append(f"Table {o}.{t} not in allowlist.")
    return (len(errs) == 0, errs)


def find_bind_names_in_sql(sql: str) -> List[str]:
    # Find :bind occurrences; exclude PostgreSQL-style casts (::) by keeping word-char names only
    names = set()
    for m in re.finditer(r":([A-Za-z_][A-Za-z0-9_]*)", sql):
        names.add(m.group(1))
    return sorted(names)

def _parse_date_like(value: str) -> dt.datetime:
    # Accept common ISO-ish inputs
    v = value.strip()
    fmts = [
        "%Y-%m-%d",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y/%m/%d",
        "%Y/%m/%d %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M:%S.%f",
    ]
    for f in fmts:
        try:
            return dt.datetime.strptime(v, f)
        except ValueError:
            pass
    # As a last resort, try fromisoformat for strict ISO
    try:
        return dt.datetime.fromisoformat(v)
    except Exception:
        raise ValueError(f"Unrecognized date/time format: {value}")

def normalize_bind_key(k: str) -> str:
    return k[1:] if k.startswith(":") else k

def normalize_binds_for_oracle(
    sql: str,
    user_binds: Dict[str, object],
    bind_hints: Optional[Dict[str, str]] = None
) -> Tuple[Dict[str, object], List[str]]:
    """
    - Strip leading ':' from keys
    - Enforce types per hints (DATE, TIMESTAMP, INT; '?' suffix means optional)
    - Drop unused keys
    - Return (normalized_binds, warnings)
    """
    warnings: List[str] = []
    hints = {normalize_bind_key(k): v for k, v in (bind_hints or {}).items()}
    # sql-needed binds
    needed = set(find_bind_names_in_sql(sql))
    # normalize keys
    norm_in = {normalize_bind_key(k): v for k, v in (user_binds or {}).items()}
    # drop unused
    unused = set(norm_in.keys()) - needed
    if unused:
        warnings.append(f"Ignoring unused bind(s): {', '.join(sorted(unused))}")
    use = {k: v for k, v in norm_in.items() if k in needed}

    # coerce types if hints are provided
    for key in sorted(needed):
        hint = hints.get(key)
        opt = False
        if hint:
            t = hint.strip().upper()
            if t.endswith("?"):
                opt = True
                t = t[:-1]
        else:
            t = None

        if key not in use:
            if hint and not opt:
                raise ValueError(f"Missing required bind :{key}")
            else:
                continue  # optional okay

        val = use[key]
        try:
            if t in ("DATE", "TIMESTAMP"):
                if isinstance(val, (dt.datetime, dt.date)):
                    # convert date to datetime at midnight for DATE
                    if isinstance(val, dt.date) and not isinstance(val, dt.datetime):
                        val = dt.datetime.combine(val, dt.time.min)
                elif isinstance(val, str):
                    val = _parse_date_like(val)
                else:
                    raise ValueError(f"Bind :{key} must be a date/datetime or ISO-like string")
            elif t == "INT":
                if isinstance(val, bool):
                    raise ValueError(f"Bind :{key} must be INT, got boolean")
                if isinstance(val, (int,)) or (isinstance(val, float) and val.is_integer()):
                    val = int(val)
                else:
                    val = int(str(val).strip())
            # else: pass through
        except Exception as e:
            raise ValueError(f"Bind :{key} type coercion failed ({t or 'unknown'}): {e}")
        use[key] = val

    # Warn for required-but-missing binds
    for key, t in hints.items():
        req = t.strip().upper()
        is_required = not req.endswith("?")
        if is_required and key in needed and key not in use:
            raise ValueError(f"Missing required bind :{key}")

    return use, warnings

def rewrite_fetch_first_to_rownum(sql: str) -> Tuple[str, Optional[str]]:
    """
    If SQL ends with 'FETCH FIRST :limit ROWS ONLY', rewrite to SELECT * FROM (...) WHERE ROWNUM <= :limit
    Return (new_sql, limit_bind_name or None)
    """
    m = FETCH_FIRST_BIND.search(sql)
    if not m:
        return sql, None
    bind = m.group(1)
    inner = FETCH_FIRST_BIND.sub("", sql).strip()
    wrapped = f"SELECT * FROM (\n{inner}\n)\nWHERE ROWNUM <= :{bind}"
    return wrapped, bind

def ensure_plain_rowset(sql: str, allow_json=False) -> Tuple[bool, List[str]]:
    errs: List[str] = []
    if not allow_json and JSON_FUNCS.search(sql):
        errs.append("JSON aggregation/functions not allowed.")
    ok, errs2 = is_select_only(sql)
    errs.extend(errs2)
    return len(errs) == 0, errs

def stream_fetchmany(cursor, batch_size: int, max_rows_soft: Optional[int] = None) -> Iterator[tuple]:
    emitted = 0
    while True:
        rows = cursor.fetchmany(batch_size)
        if not rows:
            break
        for r in rows:
            yield r
            emitted += 1
            if max_rows_soft and emitted >= max_rows_soft:
                return

def map_ora_error(e: Exception) -> Tuple[str, str]:
    """Return (code, message) friendly mapping for common Oracle errors."""
    msg = str(e)
    code = ""
    m = re.search(r"ORA-(\d+)", msg)
    if m:
        code = f"ORA-{m.group(1)}"

    if "ORA-01013" in msg:
        return code or "ORA-01013", "Query cancelled or timed out."
    if "ORA-00942" in msg:
        return code or "ORA-00942", "Table or view does not exist (check owner/privileges)."
    if "ORA-00904" in msg:
        return code or "ORA-00904", "Invalid identifier (unknown column or alias)."
    if "ORA-01722" in msg:
        return code or "ORA-01722", "Invalid number (type mismatch)."
    if "ORA-018" in msg:
        return code or "ORA-018xx", "Date/time format error (supply ISO-like dates)."
    if "ORA-00933" in msg or "ORA-00934" in msg:
        return code or "ORA-00933", "SQL not properly ended / aggregation mismatch."
    return code or "ORA-00000", msg
