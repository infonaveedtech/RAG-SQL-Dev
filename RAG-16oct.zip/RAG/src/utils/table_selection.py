# utils/table_selection.py
"""
Schema-agnostic table selection utilities.

What it does
------------
- Detects and omits "datey/derived" table names like:
  ORDERS03APR24, TRADES_29NOV, REPO_CONTRACTS_9_2_23, REPO_LOG13OCT23,
  *_20241012, *_241012, BK/BS/BKUP variants, etc.
- Omits general noise: TMP/TEST/TST/MOCK/DEV, COPY/DUP,
  Oracle AQ queue tables (AQ$_*), *_QTAB*, *_QCDSTAB*.
- Owner scoping (optional).
- Produces 3 buckets: must_keep, candidate, omit_now, based on rows/date-cols/width/comments.
- Writes auditable stats (CSV + JSON).

Usage
-----
from utils.table_selection import load_rules, select_tables, write_stats
rules = load_rules("config/ats_table_selection.yaml")  # or None for defaults
parts = select_tables(all_tables_json, rules)
write_stats("data/selection_stats", parts)
filtered = parts["must_keep"] + parts["candidate"]
"""

from typing import List, Dict, Any, Iterable
from datetime import datetime
import os
import re
import json
import csv

# Month tokens
MONTHS_SHORT = r"JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC"
MONTHS_FULL  = r"JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER"


def _rx(p: str) -> re.Pattern:
    return re.compile(p, re.IGNORECASE)


# Strong detection of date-stamped / derived table names
DATEY_PATTERNS = [
    rf"\d{{1,2}}({MONTHS_SHORT})\d{{2,4}}$",   # 2OCT25, 03APR24
    rf"({MONTHS_SHORT})\d{{2,4}}$",            # OCT24, OCT2024
    rf"\d{{1,2}}({MONTHS_SHORT})$",            # 29NOV
    rf"_\d{{1,2}}({MONTHS_SHORT})\d{{2,4}}$",  # _18MAR24
    rf"\d{{1,2}}({MONTHS_FULL})\d{{2,4}}$",    # 18MARCH24
    rf"({MONTHS_FULL})\d{{2,4}}$",             # MARCH24
    rf"\d{{1,2}}({MONTHS_FULL})$",             # 29NOVEMBER (rare but safe)
    r"_?\d{8}$",                               # 20241012 or _20241012
    r"_?\d{6}$",                               # 241012  or _241012
    r"(^|_)\d{1,2}_\d{1,2}_\d{2,4}($|_)",      # 9_2_23 / 06_07_23 / 9_2_2023
    r"\d{1,2}[_-]\d{1,2}[_-]\d{2,4}$",   # <- NEW: TRADES06_07_23 / TRADES06-07-23
    r"(^|_)BK\d+($|_)",                        # BK codes
    r"(^|_)BS\d+($|_)",                        # BS codes
    r"(^|_)BKUP($|_)|(^|_)BKP($|_)",           # backups
]

# General name-noise patterns
NOISE_NAME_PATTERNS = [
    r"(^|_)TMP|TEMP|TEMPORARY(_|$)",
    r"(^|_)(TEST|TST)(_|$)",
    r"(^|_)MOCK(_|$)",
    r"(^|_)(STG|STAGE|STAGING)(_|\b|$)",           # optional: staging tables
    r"(^|_)DEV(_|$)",
    r"(^|_)(ARCH|ARCHIVE)(_|\b|$)",                # optional: archives
    r"(^|_)COPY(_|$)|(^|_)DUP(_|$)",
    r"^AQ\$_",                    # Oracle AQ
    r"_QTAB(_|$)|_QCDSTAB(_|$)",  # queue table variants
]

DATEY_RE = [_rx(p) for p in DATEY_PATTERNS]
NOISE_RE = [_rx(p) for p in NOISE_NAME_PATTERNS]


class SelectionRules:
    def __init__(self) -> None:
        self.owners: List[str] = []               # optional owner allowlist (uppercased)
        self.exclude_name_patterns: List[str] = []# extra user regex patterns (case-insensitive)
        self.explicit_omit: List[str] = []        # exact table names to omit (uppercased)
        self.min_rows_must_keep: int = 1
        self.min_rows_candidate: int = 1
        self.min_date_cols_must_keep: int = 1
        self.min_date_cols_candidate: int = 2
        self.min_columns_candidate: int = 5


def _matches_any(name: str, patterns: Iterable[re.Pattern]) -> bool:
    u = (name or "").upper()
    return any(p.search(u) for p in patterns)


def _safe_int(x) -> int:
    try:
        return int(x)
    except Exception:
        return 0


def is_datey_name(table_name: str) -> bool:
    return _matches_any(table_name, DATEY_RE)


def is_noisy_name(table_name: str) -> bool:
    return _matches_any(table_name, NOISE_RE)


def summarise_table(t: Dict[str, Any]) -> Dict[str, Any]:
    """Compute small summary used by the rules."""
    cols = t.get("columns") or []
    date_like = 0
    for c in cols:
        cn = str(c.get("column_name") or "").upper()
        dt = str(c.get("data_type") or "").upper()
        if dt in {
            "DATE",
            "TIMESTAMP",
            "TIMESTAMP(6)",
            "TIMESTAMP WITH TIME ZONE",
            "TIMESTAMP WITH LOCAL TIME ZONE",
        }:
            date_like += 1
        elif re.search(r"(DATE|_DT|_TIME|TIMESTAMP)$", cn):
            date_like += 1
    return {
        "owner": t.get("owner"),
        "table_name": t.get("table_name"),
        "num_rows": t.get("num_rows"),
        "n_columns": len(cols),
        "n_date_like_cols": date_like,
        "table_comment": t.get("table_comment"),
    }


def load_rules(yaml_path: str | None) -> SelectionRules:
    """Load rules from YAML (optional). Falls back to defaults if file missing."""
    rules = SelectionRules()
    if not yaml_path or not os.path.exists(yaml_path):
        return rules
    try:
        import yaml  # lazy import to avoid hard dependency
    except Exception as e:
        raise RuntimeError(
            f"PyYAML required to read rules from {yaml_path}. Install with: pip install pyyaml"
        ) from e

    with open(yaml_path, "r", encoding="utf-8") as f:
        y = yaml.safe_load(f) or {}

    rules.owners = [o.upper() for o in y.get("owners", [])]
    R = y.get("rules", {})
    rules.exclude_name_patterns = R.get("exclude_name_patterns", [])
    rules.explicit_omit = R.get("explicit_omit", [])
    rules.min_rows_must_keep = int(R.get("min_rows_must_keep", 1))
    rules.min_rows_candidate = int(R.get("min_rows_candidate", 1))
    rules.min_date_cols_must_keep = int(R.get("min_date_cols_must_keep", 1))
    rules.min_date_cols_candidate = int(R.get("min_date_cols_candidate", 2))
    rules.min_columns_candidate = int(R.get("min_columns_candidate", 5))
    return rules


def select_tables(tables: List[Dict[str, Any]], rules: SelectionRules) -> Dict[str, List[Dict[str, Any]]]:
    """Partition tables into must_keep / candidate / omit_now."""
    extra_omit_re = [re.compile(p, re.I) for p in rules.exclude_name_patterns] if rules.exclude_name_patterns else []
    explicit_omit_set = {s.upper() for s in rules.explicit_omit}

    must_keep: List[Dict[str, Any]] = []
    candidate: List[Dict[str, Any]] = []
    omit_now:  List[Dict[str, Any]] = []

    for t in tables:
        owner = (t.get("owner") or "").upper()
        if rules.owners and owner not in rules.owners:
            omit_now.append(t); continue

        name = (t.get("table_name") or "").upper()
        s = summarise_table(t)
        n_rows = _safe_int(s["num_rows"])
        n_cols = s["n_columns"]
        n_date = s["n_date_like_cols"]
        has_comment = bool((t.get("table_comment") or "").strip())

        # Master omits: noisy name or "datey/derived" name or explicit pattern/name
        if (
            is_noisy_name(name)
            or is_datey_name(name)
            or name in explicit_omit_set
            or (extra_omit_re and any(r.search(name) for r in extra_omit_re))
        ):
            omit_now.append(t); continue

        # MUST KEEP: rows > 0 AND at least one date-like column
        if n_rows >= rules.min_rows_must_keep and n_date >= rules.min_date_cols_must_keep:
            must_keep.append(t); continue

        # CANDIDATE: rows > 0 AND (>=2 date cols OR wide OR has comment)
        if (n_rows >= rules.min_rows_candidate) and (
            n_date >= rules.min_date_cols_candidate
            or n_cols >= rules.min_columns_candidate
            or has_comment
        ):
            candidate.append(t); continue

        # Otherwise omit for now
        omit_now.append(t)

    return {"must_keep": must_keep, "candidate": candidate, "omit_now": omit_now}


def write_stats(out_dir: str, parts: Dict[str, List[Dict[str, Any]]]) -> None:
    """Write CSVs for each bucket and a small JSON summary."""
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    def to_rows(lst: List[Dict[str, Any]]):
        for t in lst:
            s = summarise_table(t)
            yield {
                "table_name": s["table_name"],
                "owner": s["owner"],
                "num_rows": s["num_rows"],
                "n_columns": s["n_columns"],
                "n_date_like_cols": s["n_date_like_cols"],
                "table_comment": s["table_comment"],
            }

    for key in ("must_keep", "candidate", "omit_now"):
        rows = list(to_rows(parts[key]))
        if not rows:
            continue
        path = os.path.join(out_dir, f"{key}_{stamp}.csv")
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys())
            w.writeheader()
            w.writerows(rows)

    summary_json = {
        "generated_at": stamp,
        "counts": {k: len(parts[k]) for k in parts},
        "samples": {k: [t.get("table_name") for t in parts[k][:10]] for k in parts},
    }
    with open(os.path.join(out_dir, f"selection_summary_{stamp}.json"), "w", encoding="utf-8") as f:
        json.dump(summary_json, f, indent=2)
