# ui_helpers.py
from __future__ import annotations
import io
import logging
import pandas as pd
from typing import List

class StreamlitLogHandler(logging.Handler):
    """Capture log records into a list (for Streamlit display)."""
    def __init__(self, sink: List[str], level=logging.INFO):
        super().__init__(level)
        self.sink = sink

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
        except Exception:
            msg = record.getMessage()
        self.sink.append(msg)

def df_to_csv_bytes(df: pd.DataFrame) -> bytes:
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")
