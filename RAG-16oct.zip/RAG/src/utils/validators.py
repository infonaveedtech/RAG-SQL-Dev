from __future__ import annotations
import re
from typing import Tuple
import re, difflib

_DDL_DML = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|GRANT|REVOKE|BEGIN|END|EXCEPTION|CALL|EXEC(?:UTE)?)\b",
    re.I,
)
# validators.py or sql_exec_utils.py


# utils/validators.py
import re

IDENT = r"[A-Za-z_][A-Za-z0-9_$#]*"
BARE_COL = re.compile(rf"\b({IDENT})\b(?!\s*\()")  # skip functions

def qualify_unqualified_columns(sql: str, ctx) -> str:
    # 1) collect alias -> set(columns)
    alias_cols = {}  # {"L": {"LEVY_NAME", ...}, "S": {...}, ...}
    primary_alias = None
    for i, t in enumerate(ctx.tables):  # preserve FROM order
        a = (t.alias or t.table_name).upper()
        if i == 0:
            primary_alias = a
        alias_cols[a] = {c.name.upper() for c in t.columns}

    # 2) inverse map: col -> {aliases}
    col_aliases = {}
    for a, cols in alias_cols.items():
        for c in cols:
            col_aliases.setdefault(c, set()).add(a)

    def repl(m):
        col = m.group(1).upper()
        # already qualified elsewhere; ignore keywords/params/numbers
        if col in {"SELECT","FROM","JOIN","WHERE","GROUP","BY","HAVING","ORDER","AND","OR",
                   "ON","IN","AS","BETWEEN","LIKE","DESC","ASC","FETCH","FIRST","ROWS",
                   "DATE","TIMESTAMP"}:
            return m.group(0)
        if col.startswith(":"):  # bind
            return m.group(0)
        aliases = col_aliases.get(col)
        if not aliases:
            return m.group(0)
        if len(aliases) == 1:
            a = list(aliases)[0]
            return f"{a}.{col}"
        # ambiguous → prefer primary alias (soft heal) if it has the column
        if primary_alias in aliases:
            return f"{primary_alias}.{col}"
        return m.group(0)

    # 3) only run inside clause regions (avoid table names)
    return BARE_COL.sub(repl, sql)


# utils/validators.py
import re

TYPE_FAMILY = {
    'CHAR': 'char', 'VARCHAR2': 'char', 'NCHAR': 'char', 'NVARCHAR2': 'char',
    'NUMBER': 'number', 'FLOAT': 'number', 'BINARY_FLOAT': 'number', 'BINARY_DOUBLE': 'number',
    'DATE': 'date', 'TIMESTAMP': 'timestamp'
}

def _family(col_meta):
    return TYPE_FAMILY.get(col_meta.oracle_type_base, 'other')

def coerce_mismatched_types(sql: str, table_ctx) -> str:
    """
    Rewrite simple equality joins/filters to avoid implicit conversions using table_ctx metadata.
    Supports patterns like: A.COL = B.COL  or  A.COL = :param
    """
    # Map "ALIAS.COL" -> family
    fam = {}
    for t in table_ctx.tables:  # your TableContext already lists columns per alias/table
        alias = t.alias or t.table_name  # normalize
        for c in t.columns:
            fam[f"{alias}.{c.name}".upper()] = _family(c)

    def _coerce(m):
        left, op, right = m.group(1), m.group(2), m.group(3)
        L = left.upper().strip()
        R = right.upper().strip()

        lf = fam.get(L)
        rf = fam.get(R)

        # alias.col = :param ? -> use column family on the alias.col only
        is_param_left = left.strip().startswith(':')
        is_param_right = right.strip().startswith(':')

        if lf and rf:
            # column = column
            if {lf, rf} == {'char', 'number'}:
                # make it TRIM(char) = TO_CHAR(number)
                if lf == 'char' and rf == 'number':
                    return f"TRIM({left}) {op} TO_CHAR({right})"
                if lf == 'number' and rf == 'char':
                    return f"TO_CHAR({left}) {op} TRIM({right})"
        elif lf and is_param_right:
            # column = :param
            if lf == 'char':
                return f"TRIM({left}) {op} {right}"
            if lf in ('number',):
                # keep as-is; bind is numeric upstream
                return f"{left} {op} {right}"
            if lf in ('date', 'timestamp'):
                return f"{left} {op} {right}"  # you bind datetimes already
        elif rf and is_param_left:
            if rf == 'char':
                return f"{left} {op} TRIM({right})"
            if rf in ('number', 'date', 'timestamp'):
                return f"{left} {op} {right}"

        return m.group(0)  # unchanged

    # Match simple equality/IN predicates inside ON/WHERE
    pattern = re.compile(r'(\b\w+\.\w+\b)\s*(=)\s*(\b\w+\.\w+\b|:\w+)', re.IGNORECASE)
    return pattern.sub(_coerce, sql)

def _align_groupby_with_select(sql: str) -> str:
    """
    If SELECT uses TRUNC(s.STATS_DATE) AS TRADE_DATE but GROUP BY uses
    TRUNC(t.ENTRY_DATETIME) or a mismatched expression, align them.
    """
    sel_match = re.search(r"SELECT\s+.*?TRUNC\((\w+\.\w+)\)\s+AS\s+TRADE_DATE", sql, re.I | re.S)
    grp_match = re.search(r"GROUP\s+BY\s+.*?TRUNC\((\w+\.\w+)\)", sql, re.I | re.S)
    if sel_match and grp_match:
        sel_expr = sel_match.group(1)
        grp_expr = grp_match.group(1)
        if sel_expr != grp_expr:
            sql = re.sub(rf"TRUNC\({grp_expr}\)", f"TRUNC({sel_expr})", sql, flags=re.I)
    return sql


def repair_alias_inconsistencies(sql: str) -> tuple[str, list[str]]:
    """
    Detect and repair alias mismatches in SQL by snapping unknown aliases
    to the closest declared alias (FROM/JOIN). Returns (fixed_sql, fixes).
    """
    alias_decl_re = re.compile(
        r'\b(?:FROM|JOIN)\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\s+(?:AS\s+)?([A-Z0-9_]+)',
        re.I
    )
    # owner, table, alias  ⟵ THREE values per match
    alias_pairs = alias_decl_re.findall(sql)

    declared_aliases = {a.upper(): f"{o.upper()}.{t.upper()}"
                        for o, t, a in alias_pairs}

    # All alias tokens used in alias.column form
    used_aliases = set(
        a.upper() for a, _ in re.findall(r'\b([A-Z][A-Z0-9_]*)\.([A-Z][A-Z0-9_]*)\b', sql, re.I)
    )

    undefined = sorted(used_aliases - set(declared_aliases.keys()))

    fixes = []
    for bad in undefined:
        match = difflib.get_close_matches(bad, declared_aliases.keys(), n=1, cutoff=0.6)
        if match:
            sql = re.sub(rf'\b{bad}\.', f'{match[0]}.', sql, flags=re.I)
            fixes.append(f"{bad}→{match[0]}")
    return sql, fixes



def _single_statement(sql: str) -> bool:
    """Allow at most one trailing semicolon; otherwise no semicolons at top level."""
    s = sql.strip()
    s = re.sub(r";\s*$", "", s)
    # naive is fine to start; we’ll harden if needed
    return s.count(";") == 0

def basic_validate(sql: str) -> Tuple[bool, str | None]:
    """Minimal guardrails for v1. Return (ok, error_message_or_None)."""
    if not sql or "SELECT" not in sql.upper():
        return False, "No SELECT detected."

    # Prevent false matches: TRUNC( and CASE ... END)
    safe_sql = sql
    safe_sql = re.sub(r"\bTRUNC\s*\(", "SAFEFUNC(", safe_sql, flags=re.I)
    safe_sql = re.sub(r"\bCASE\b[\s\S]+?\bEND\b", "SAFECASE", safe_sql, flags=re.I)

    _DDL_DML = re.compile(
        r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|GRANT|REVOKE|BEGIN|EXCEPTION|CALL|EXEC(?:UTE)?)\b",
        re.I,
    )

    if _DDL_DML.search(safe_sql):
        return False, "Only plain SELECT statements are allowed."

    if not _single_statement(sql):
        return False, "Provide a single SQL statement (no extra semicolons)."

    return True, None


import re
from typing import Dict, List, Tuple

def validate_sql_columns(sql: str, metadata: Dict[str, Dict[str, List[str]]]) -> Tuple[bool, List[str]]:
    # build alias → owner.table map
    alias_map = {}
    for m in re.finditer(r'\bFROM\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\s+(?:AS\s+)?([A-Z0-9_]+)', sql, re.I):
        alias_map[m.group(3).upper()] = f"{m.group(1).upper()}.{m.group(2).upper()}"
    for m in re.finditer(r'\bJOIN\s+([A-Z0-9_]+)\.([A-Z0-9_]+)\s+(?:AS\s+)?([A-Z0-9_]+)', sql, re.I):
        alias_map[m.group(3).upper()] = f"{m.group(1).upper()}.{m.group(2).upper()}"

    unknowns = []
    # find alias.column refs
    for alias, col in re.findall(r'\b([A-Z][A-Z0-9_]*)\.([A-Z][A-Z0-9_]*)\b', sql, re.I):
        a, c = alias.upper(), col.upper()
        fqn = alias_map.get(a)
        if not fqn:
            continue
        cols = [x.upper() for x in (metadata.get(fqn, {}).get("columns") or [])]
        if c not in cols:
            unknowns.append(f"{fqn}.{c}")
    return (len(unknowns) == 0, unknowns)
