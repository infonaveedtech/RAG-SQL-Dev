
# 🧭 SQLBot API Documentation

> **Version:** 1.0
> **Base URL:** `http://localhost:8080/api/v1`
> **Purpose:** Natural Language → SQL → Validation → Safe Execution → Export
> **Tech Stack:** FastAPI, Oracle DB, Gemini 2.5 Flash (LLM), Python 3.11+

---

## 🧠 Overview

This project provides a **unified backend API** that can take a natural language question (e.g.

> “Top 50 symbols by traded notional in the last 14 days”)

and automatically generate, validate, and safely execute an **Oracle SQL query**, returning both the SQL and a preview of results.

---

## ⚙️ System Flow (Big Picture)

1. **User input (Natural Language)** →
   Sent to `POST /query`

2. **LLM Generation (Gemini)** →
   LLM converts the input into Oracle SQL

3. **Guardrails**

   * Safety (read-only `SELECT` only)
   * Schema validation
   * Table allowlist
   * Label join enforcement (no raw IDs)
   * Row limit enforcement

4. **Execution (Oracle)** →
   Query is executed with preview row limits

5. **Response →** Preview returned, and user can export to CSV/PDF/HTML.

---

## 📁 Endpoint List

| Endpoint        | Method | Purpose                                   |
| --------------- | ------ | ----------------------------------------- |
| `/health`       | `GET`  | Check API and DB connection               |
| `/schema`       | `GET`  | Returns schema info and table allowlist   |
| `/query`        | `POST` | NL → SQL → Guard → Execute (LLM + Oracle) |
| `/sql/validate` | `POST` | Validate a raw SQL string (no LLM, no DB) |
| `/sql/execute`  | `POST` | Execute safe, validated SQL (no LLM)      |
| `/exports`      | `POST` | Export query result (CSV/HTML/PDF)        |

---

## 🔍 1. `/health`

### **Purpose**

Verify that the service and Oracle connection are live and functional.

### **How It Works**

* Reads `DB_DSN` and `DB_USER` from `.env`
* Attempts a lightweight DB query (`SELECT 1 FROM DUAL`)
* Returns API version, owner schema, and DB health status.

### **Request**

```bash
GET /api/v1/health
```

### **Response**

```json
{
  "status": "ok",
  "db": "connected",
  "owner": "ATS",
  "version": "1.0.0"
}
```

### **Usage**

Quick health check before running any query or connecting frontend.

---

## 🧱 2. `/schema`

### **Purpose**

Returns schema metadata and list of **allowed tables** from `.env`.

### **How It Works**

* Reads `OWNER` and `ALLOWLIST_TABLES`
* Returns aliases, allowed tables, and system name.

### **Request**

```bash
GET /api/v1/schema
```

### **Response**

```json
{
  "owner": "ATS",
  "aliases": ["ATS"],
  "allowlist": [
    "TRADES", "SYMBOLS", "ORDERS", "MARKETS"
  ],
  "tables": {
    "TRADES": ["TRADE_ID", "SYMBOL_ID", "PRICE", "VOLUME", "ENTRY_DATETIME"],
    "SYMBOLS": ["SYMBOL_ID", "SYMBOL", "EXCHANGE_ID"]
  }
}
```

### **Usage**

Useful for frontends (autocomplete, validation) and LLM context building.

---

## 🤖 3. `/query`

### **Purpose**

Main **LLM-powered endpoint** — converts a natural-language question into SQL, validates it, executes safely, and returns results.

### **Flow**

1. **Gemini Model Call**
   Converts text → SQL based on prompt pack (`system`, `schema`, `fewshots`, `glossary`).
2. **Guardrail Checks**

   * Read-only
   * Allowlist
   * Schema validation
   * Label joins
   * Enforced row limit
3. **Preview Execution**
   Executes in Oracle, fetches top N rows.

### **Request**

```bash
POST /api/v1/query
```

**Body**

```json
{
  "question": "Top 50 symbols by traded value in the last 14 days with symbol names",
  "strategy": "gemini",
  "preview_row_limit": 10
}
```

### **Response**

```json
{
  "sql": "SELECT s.SYMBOL AS symbol, SUM(t.PRICE * t.VOLUME) AS traded_notional FROM ATS.TRADES t JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = t.SYMBOL_ID WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE) - 14 GROUP BY s.SYMBOL ORDER BY traded_notional DESC FETCH FIRST 50 ROWS ONLY;",
  "guards": {
    "safety": "passed",
    "schema_check": "passed",
    "labels": "passed"
  },
  "preview": {
    "columns": ["SYMBOL", "TRADED_NOTIONAL"],
    "rows": [
      ["OG15L28A", 438353114],
      ["OF15G26B", 165483575]
    ]
  }
}
```

### **Usage**

Used by Streamlit UI or frontends to translate NL → SQL and preview results.

---

## 🧮 4. `/sql/validate`

### **Purpose**

Checks if a **manual SQL query** is safe, allowed, and schema-valid — **without executing it**.

### **Request**

```bash
POST /api/v1/sql/validate
```

**Body**

```json
{
  "sql": "SELECT TRADE_ID FROM ATS.TRADES WHERE ENTRY_DATETIME >= TRUNC(SYSDATE)-7"
}
```

### **Response**

```json
{
  "ok": false,
  "sql_normalized": "SELECT TRADE_ID FROM ATS.TRADES WHERE ENTRY_DATETIME >= TRUNC(SYSDATE)-7",
  "issues": [
    {
      "type": "LABELS",
      "message": "Raw IDs are restricted; join to label tables..."
    }
  ]
}
```

### **Usage**

For tools or UI validations before execution or saving a query.

---

## ⚙️ 5. `/sql/execute`

### **Purpose**

Execute a **safe** SQL query directly (bypasses LLM).
Used when SQL already exists (e.g., user-corrected query).

### **Flow**

* Same guards as `/query`
* Enforces row limit
* Executes in Oracle DB
* Returns rows and guard results

### **Request**

```bash
POST /api/v1/sql/execute
```

**Body**

```json
{
  "sql": "SELECT s.SYMBOL, SUM(t.PRICE * t.VOLUME) AS traded_notional FROM ATS.TRADES t JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = t.SYMBOL_ID WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE) - 14 GROUP BY s.SYMBOL ORDER BY traded_notional DESC FETCH FIRST 10 ROWS ONLY;",
  "row_limit": 500
}
```

### **Response**

```json
{
  "columns": ["SYMBOL", "TRADED_NOTIONAL"],
  "rows": [
    ["OG15L28A", 438353114],
    ["OF15G26B", 165483575]
  ],
  "row_limit_applied": 500,
  "guards": {
    "safety": "passed",
    "schema_check": "skipped",
    "labels": "passed"
  }
}
```

### **Usage**

For executing validated SQL (from `/query` or `/sql/validate`).

---

## 📦 6. `/exports`

### **Purpose**

Export query results in **CSV, HTML, or PDF** format.

### **Flow**

1. Accepts SQL and export type.
2. Executes safely under row limits.
3. Converts to the requested format.
4. Streams the generated file to user.

### **Request**

```bash
POST /api/v1/exports
```

**Body**

```json
{
  "sql": "SELECT s.SYMBOL, SUM(t.PRICE * t.VOLUME) AS traded_notional FROM ATS.TRADES t JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = t.SYMBOL_ID WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE) - 14 GROUP BY s.SYMBOL ORDER BY traded_notional DESC FETCH FIRST 50 ROWS ONLY;",
  "format": "pdf",
  "title": "Top-50-by-notional",
  "row_limit": 1000
}
```

### **Response**

* Returns a **file** stream of the requested export.

**Example CLI Test**

```powershell
Invoke-WebRequest http://localhost:8080/api/v1/exports -Method POST `
  -ContentType "application/json" `
  -Body $body -OutFile ./top50.pdf
```

---

## 🧩 How Everything Connects

| Step | Endpoint        | Responsible For                   |
| ---- | --------------- | --------------------------------- |
| 1    | `/query`        | LLM generation + first preview    |
| 2    | `/sql/validate` | Manual validation (optional)      |
| 3    | `/sql/execute`  | Re-execution with edits           |
| 4    | `/exports`      | Exporting final results           |
| 5    | `/schema`       | Provides metadata for LLM context |
| 6    | `/health`       | Service heartbeat                 |

---

## 🧱 Deployment Notes

**Dependencies**

* Python ≥ 3.10
* FastAPI, Uvicorn
* Oracle client (cx_Oracle)
* wkhtmltopdf (for PDF export)
* Gemini API key (set in `.env`)

**Run Locally**

```bash
uvicorn app.api.main:app --reload --port 8080
```

---

## 🔐 Adding Authentication (JWT / API Key)

If you want to **restrict access**, here’s how it would fit into this system:

### 🔑 JWT Integration (FastAPI)

1. Create a `auth.py` in `app/api/routers/`
2. Add `/login` to issue tokens (after verifying username/password)
3. Use a dependency in each route:

   ```python
   from fastapi import Depends
   from app.auth import get_current_user

   @router.post("/query")
   def post_query(payload: QueryRequest, user=Depends(get_current_user)):
       ...
   ```
4. Secure all routes with token verification.

**Libraries:**

* `python-jose`
* `passlib`
* `fastapi.security.JWTBearer`

**Environment Additions:**

```
JWT_SECRET=supersecret
JWT_ALGORITHM=HS256
TOKEN_EXPIRE_MINUTES=60
```

### 🔐 Alternative: API Key

Simpler for internal tools.

* Add a `X-API-Key` header
* Verify against `.env`-defined `API_KEY`
* Return `403` if mismatch.

Example:

```python
from fastapi import Header, HTTPException

async def verify_api_key(x_api_key: str = Header(...)):
    if x_api_key != os.getenv("API_KEY"):
        raise HTTPException(status_code=403, detail="Invalid API key")
```

Then:

```python
@router.post("/query", dependencies=[Depends(verify_api_key)])
```

---

## 📈 Next Expansion Ideas

| Goal                  | Description                                                            |
| --------------------- | ---------------------------------------------------------------------- |
| 🧮 Streamlit Frontend | Interactive UI where users type NL queries, see SQL + preview + export |
| 🧠 Model Switching    | Allow strategy = `gemini` / `gpt` / `claude`                           |
| 📋 Query History      | Store NL + SQL + timestamp + user ID                                   |
| 🧾 Error Reporting    | Log validation/execution failures to DB                                |
| 🔍 Search & Insights  | Add RAG layer for semantic search over schema docs                     |
| 🔄 Async Execution    | For large queries via Celery / BackgroundTasks                         |

---

## ✅ Final Takeaway

This backend is **modular, safe, and future-proof**:

* LLM → SQL pipeline ✅
* Oracle-safe guardrails ✅
* Validation + execution separation ✅
* Exporting pipeline ✅
* Ready for auth, logs, and UI integration 🔜

---

Would you like me to now generate this as a **ready-to-save Markdown file (`API_DOCS.md`)** so you can drop it straight into your repo?
