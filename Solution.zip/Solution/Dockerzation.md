# Docker & Compose Guide

This project ships as **two containers**:

* **`api`** – FastAPI + the NL→SQL pipeline (guards, Oracle, exports, LLM routing)
* **`ui`** – Streamlit v2 client that calls the API over HTTP

Both are stateless; all configuration is via environment variables.

---

## 1) Repo layout (relevant to Docker)

```
.
├─ app/
│  ├─ api/              # FastAPI app (routers, DTOs)
│  ├─ pipeline/         # NL→SQL pipeline + guards + execution
│  └─ ui/               # Streamlit v2 client
├─ Dockerfile.api       # Backend image
├─ Dockerfile.ui        # Frontend image (UI only)
├─ docker-compose.yml   # Brings up both containers + network
├─ requirements.api.txt # Minimal deps for API image
├─ requirements.ui.txt  # Minimal deps for UI image
├─ .dockerignore
├─ .env                 # Dev/DB defaults (NOT committed)
└─ .env.docker          # Container-only overrides (NOT committed)
```

---

## 2) Requirements

* Docker Desktop (WSL2 on Windows)
* Outbound internet for dependency install / LLM calls
* Oracle reachable from the machine running Docker

---

## 3) Environment files

> Do **not** quote values in env files (no `"value"`).
> Keep secrets out of git; commit only `.env.example`.

**`.env`** (host dev + shared DB config)

```
# Oracle
ORACLE_DSN=HOST:PORT/SERVICE
ORACLE_USER=ATS
ORACLE_PASSWORD=*****
ORACLE_OWNER=ATS

# Limits / guards
ROW_LIMIT_DEFAULT=100
MAX_ESTIMATED_ROWS=200000
EXPLAIN_GATE_ENABLED=1
```

**`.env.docker`** (container-specific)

```
# LLM (Gemini recommended for lean images)
MODEL_STRATEGY=gemini
GEMINI_MODEL=gemini-2.5-flash
GEMINI_API_KEY=AIza...

# PDF exports (in Linux container)
WKHTMLTOPDF_PATH=/usr/bin/wkhtmltopdf
```

You can layer env files at runtime; later values override earlier ones.

---

## 4) Images

### 4.1 `Dockerfile.api` (backend)

* Base: `python:3.11-slim-bookworm`
* Non-root user
* Installs `wkhtmltopdf` for PDF exports
* Installs **minimal** Python deps from `requirements.api.txt`
* Healthcheck hits `/api/v1/health`
* CMD: `uvicorn app.api.main:app --host 0.0.0.0 --port 8080`

**Ports:** 8080 in container → mapped by compose to host 8080.

### 4.2 `Dockerfile.ui` (frontend)

* Base: `python:3.11-slim-bookworm`
* Non-root user
* Installs `streamlit` + `requests`
* ENV `API_BASE_URL` default: `http://api:8080/api/v1`
* CMD: `streamlit run app/ui/chatbot_v2.py --server.address 0.0.0.0 --server.port 8501`

**Ports:** 8501 in container → mapped by compose to host 8502 (configurable).

---

## 5) Build & Run

### Build both

```bash
docker compose build
```

### Run both

```bash
docker compose up -d
docker compose ps
```

Expected:

* `sqlbot-api` → `0.0.0.0:8080->8080/tcp` (healthy)
* `sqlbot-ui`  → `0.0.0.0:8502->8501/tcp`

**Open UI:** [http://localhost:8502](http://localhost:8502)
**API health:** [http://localhost:8080/api/v1/health](http://localhost:8080/api/v1/health)

> If you change the host port, remember mapping is `host:container`.
> Example: `ports: ["8502:8501"]` maps host 8502 → container 8501.

---

## 6) Smoke tests (copy/paste)

### API up (no DB probe)

```bash
curl -s http://localhost:8080/api/v1/health
```

### DB connectivity

```bash
curl -s "http://localhost:8080/api/v1/health?db=1"
```

### Guarded execution

```bash
curl -s -X POST http://localhost:8080/api/v1/sql/execute \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT 1 AS X FROM DUAL FETCH FIRST 1 ROWS ONLY"}'
```

### Natural language → SQL (Gemini)

```bash
curl -s -X POST http://localhost:8080/api/v1/query \
  -H "Content-Type: application/json" \
  -d '{"question":"show 3 recent rows from TRADES with ENTRY_DATETIME and PRICE"}'
```

### Exports

```bash
# CSV
curl -D csv.hdr -s -X POST http://localhost:8080/api/v1/exports \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT 1 AS X FROM DUAL FETCH FIRST 1 ROWS ONLY","title":"smoke","format":"csv"}' -o preview.csv

# HTML
curl -D html.hdr -s -X POST http://localhost:8080/api/v1/exports \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT 1 AS X FROM DUAL FETCH FIRST 1 ROWS ONLY","title":"smoke","format":"html"}' -o preview.html

# PDF (requires WKHTMLTOPDF_PATH in env)
curl -D pdf.hdr -s -X POST http://localhost:8080/api/v1/exports \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT 1 AS X FROM DUAL FETCH FIRST 1 ROWS ONLY","title":"smoke","format":"pdf"}' -o preview.pdf
```

---

## 7) Logs, rebuilds, cleanup

```bash
# Tail logs
docker compose logs -f api
docker compose logs -f ui

# Rebuild and restart one service
docker compose build api && docker compose up -d api

# Stop all
docker compose down
```

---

## 8) Troubleshooting

* **UI not reachable on host**
  Check port mapping (`ports: ["8502:8501"]`) and `docker compose ps`.

* **UI can’t reach API**
  Ensure `API_BASE_URL` in the UI container is `http://api:8080/api/v1` (compose DNS uses the service name `api`).

* **PDF export returns 422 or corrupt file**
  Make sure you POST with `"format"` in JSON body and set `WKHTMLTOPDF_PATH=/usr/bin/wkhtmltopdf` (in image or `.env.docker`).

* **Gemini “API key not valid”**
  Confirm there are **no quotes** around keys in env files. You can verify inside the container:

  ```bash
  docker run --rm --env-file .env --env-file .env.docker \
    --entrypoint /bin/sh sqlbot-api:dev -lc 'env | grep -E "GEMINI|GOOGLE|MODEL"'
  ```

* **Docker CLI can’t connect to engine (Windows)**
  Open Docker Desktop → ensure “Engine running”. If needed:

  ```
  wsl --shutdown
  # restart Docker Desktop
  ```

---

## 9) Production notes (quick)

* Keep the same two images; deploy behind your reverse proxy/LB.
* Supply env via orchestrator secrets/ConfigMaps or Compose env files (never bake secrets into images).
* Monitoring/health: image healthcheck pings `/api/v1/health` (no DB). Use `/health?db=1` for deeper probes sparingly.
* Set resource limits in your orchestrator if desired (CPU/memory).
* Optional hardening:

  * Add OCI labels in both Dockerfiles (title/description/repo).
  * Add a simple API key middleware on the API (`X-API-Key`)—UI already supports sending it.

---

## 10) One-liner “it works” checklist

* `docker compose up -d`
* [http://localhost:8502](http://localhost:8502) loads the UI
* Health buttons OK in sidebar
* Ask: “show 3 recent rows from TRADES with ENTRY_DATETIME and PRICE”
* See SQL, preview rows, and successful CSV/HTML/PDF exports

---

### Appendix: `.dockerignore` suggestions

```
.git
__pycache__/
*.py[cod]
*.log
.env
.env.*
node_modules/
dist/
build/
.streamlit/
.pytest_cache/
*.coverage
evaluation/
```

| Image            | Purpose            | Built from       | Runs on                     | Exposes                             |
| ---------------- | ------------------ | ---------------- | --------------------------- | ----------------------------------- |
| `sqlbot-api:dev` | FastAPI backend    | `Dockerfile.api` | `python:3.11-slim-bookworm` | Port `8080`                         |
| `sqlbot-ui:dev`  | Streamlit frontend | `Dockerfile.ui`  | `python:3.11-slim-bookworm` | Port `8501` (mapped to host `8502`) |

##  Add “ship images as .tar” to your Docker doc

You already have a great Docker guide. Append the section below to your **Dockerzation.md** (right after the Build & Run section fits nicely). I’ve tailored the wording to match your doc’s style. 

### Distribute prebuilt images (no build on target machines)

If teammates should **run without building**, you can export your local images to `.tar` files, send them, and they can load & run immediately.

**On the source machine (where images already exist):**

```bash
# Save images to tar files
docker save -o sqlbot-api.tar sqlbot-api:dev
docker save -o sqlbot-ui.tar  sqlbot-ui:dev
```

Send `sqlbot-api.tar`, `sqlbot-ui.tar`, plus your repo folder (or at least `docker-compose.yml` and env files).

**On the target machine:**

```bash
# Load images
docker load -i sqlbot-api.tar
docker load -i sqlbot-ui.tar

# Ensure .env and .env.docker sit next to docker-compose.yml, then:
docker compose up -d
docker compose ps
```

Expected:

* `sqlbot-api` → `0.0.0.0:8080->8080/tcp`
* `sqlbot-ui`  → `0.0.0.0:8502->8501/tcp`

Open:

* UI → [http://localhost:8502](http://localhost:8502)
* API health → [http://localhost:8080/api/v1/health](http://localhost:8080/api/v1/health)

---

## Bonus: quick refresher — what to run after you change code

* **Backend (API/pipeline) changed:**

  ```bash
  docker compose build api && docker compose up -d api
  ```

* **Frontend (UI) changed:**

  ```bash
  docker compose build ui && docker compose up -d ui
  ```

* **Env or compose changed:**

  ```bash
  docker compose down
  docker compose up -d --build
  ```

