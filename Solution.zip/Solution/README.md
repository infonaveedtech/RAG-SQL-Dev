<!-- # 🧠 ATS SQL Assistant — Oracle Natural Language → SQL Pipeline

End-to-end intelligent SQL generation system for **ATS / DNS (BODIVA)** datasets.
It converts natural-language questions into **validated Oracle SQL**, executes them safely, and returns tabular and downloadable report outputs.

---

## 🚀 Overview

The system unifies **LLM-driven SQL generation**, **schema awareness**, **runtime safety**, and **role-based access control**.
It supports multiple model back-ends (Gemini, Llama, GPT-OSS) and automatically routes requests for best reliability.

### Supported data domains

* **Markets** — `SYMBOL_DAILY_INDICATORS`, `SYMBOL_INDICATORS`, `BEST_MKT`, `INDICES`
* **Orders / Rejections** — `ORDERS`, `REJECTED_ORDERS`, `REJECTIONS`
* **Trades** — `TRADES`, `CANCELLED_TRADES`, `NEGOTIATED_TRADES`
* **Levies / Fees** — `ATS_LEVY_DATA_LOG`, `LEVIES`, `LEVY_TYPES`, etc.
* **Shared Lookups** — `SYMBOLS`, `EXCHANGES`, `CLIENTS`, `USERS`
* **Repo / Funding** — repo and cashflow tables (v2.1+)

---

## 🧩 System Flow (recap)

```
User (NL)
  ↓
UI / API chatbot
  ↓
Prompting → Model routing (Gemini / Llama / GPT-OSS)
  ↓
SQL guardrails
  ↓
Row-level filter injection (Trader/Broker/Admin)
  ↓
Execution (Oracle or DNS via DB links)
  ↓
Result table + CSV / HTML / PDF exports
```

Key modules remain unchanged: `prompting.py`, `router.py`, `guards/*`, and `execution.py`.

---

## ⚙️ Environment Setup

```bash
conda create -n ats-assistant python=3.10
conda activate ats-assistant
pip install -r requirements.txt
```

**`.env` example**

```ini
# --- Oracle connections ---
ORACLE_DSN=192.168.36.160:1521/gsedb
ORACLE_USER=ATS
ORACLE_PASSWORD=ABC
ORACLE_OWNER=DNS
ORACLE_OWNER_ALIASES=ATS,DNS

# --- Allowed tables ---
SAFETY_ALLOWED_TABLES=ORDERS TRADES CANCELLED_TRADES INDICES EXCHANGES SYMBOLS ...
ALLOWED_TABLES=ORDERS,TRADES,CANCELLED_TRADES,INDICES,EXCHANGES,SYMBOLS,...

# --- Safety / validation ---
ROW_LIMIT_DEFAULT=200
EXPLAIN_GATE_ENABLED=0
MAX_ESTIMATED_ROWS=5000000

# --- Model strategy ---
MODEL_STRATEGY=AUTO
GEMINI_MODEL=gemini-1.5-pro
OLLAMA_MODEL=llama3
```

Run UI:

```bash
streamlit run app/ui/chatbot.py
```

---

## 🔐 Row-Level Security (Trader/Broker/Admin)

Each authenticated request carries role claims:

| Role               | Scope enforced                                                |
| ------------------ | ------------------------------------------------------------- |
| **Trader**         | Only rows where `TRADER_ID` or `USER_ID` = trader’s ID        |
| **Broker**         | Rows where `BROKER_ID` (or buyer/seller broker) = broker’s ID |
| **Exchange Admin** | Full dataset (no filter)                                      |

### How it works

1. **JWT claims** — API receives `{role, trader_id, broker_id}`.
2. **Policy map** — `app/config/row_level_policy.json` defines which column(s) identify trader/broker per table.
3. **Injector** — `guards/row_level.py` parses generated SQL and `AND`s the appropriate predicates before validation and execution.
4. **Guards** — Safety, schema, and label validators still run normally after scoping.
5. **DB-level option** — For stronger enforcement, Oracle VPD (FGAC) can be used to apply the same predicates server-side.

Example:

```sql
-- original (model output)
SELECT * FROM ORDERS WHERE CREATED_AT >= TRUNC(SYSDATE)-7;

-- after RLS injection (trader_id='T007')
SELECT * FROM ORDERS
WHERE (TRADER_ID='T007' OR USER_ID='T007')
  AND CREATED_AT >= TRUNC(SYSDATE)-7;
```

---


## 🧩 Adding New Tables

Follow this proven checklist:

| Step                     | Description                                                                        |
| ------------------------ | ---------------------------------------------------------------------------------- |
| **Inspect**              | Create `_smoke/inspect_<table>.py` to examine structure and joins.                 |
| **Allowlist**            | Add table name to `.env` → `SAFETY_ALLOWED_TABLES` / `ALLOWED_TABLES`.             |
| **Schema cards**         | Update `prompts/schema_card.txt` + `schema_card.json` via `build_schema_card*.py`. |
| **Glossary & few-shots** | Add domain terms and 2–3 exemplar SQLs to guide LLM.                               |
| **Test**                 | Validate generation and execution through the Streamlit UI or API.                 |

---

## ☁️ Deployment & Integration

### Architecture options

1. **Streamlit App (internal users)** — current default.
2. **FastAPI Backend + Web Widget**

   * API: `/api/query` accepts `{question}` + JWT → returns `{sql, rows, exports}`.
   * Frontend: small JS widget / popup (“Ask Data”) that calls the API.
3. **Hybrid** — Streamlit for analysts, API for embedding into trading portals.

---

## ✅ TODOs / Next Steps

| Area                   | Task                                                                | Status      |
| ---------------------- | ------------------------------------------------------------------- | ----------- |
| **1. API Layer**       | Implement FastAPI `/api/query` reusing chatbot pipeline.            | ⏳ Planned   |
| **2. RLS Policy Map**  | Finalize `row_level_policy.json` (trader/broker columns per table). | ⏳ Planned   |
| **3. Injector Module** | Add `guards/row_level.py` to apply predicates before validation.    | ⏳ Planned   |
| **4. JWT Auth**        | Integrate SSO → JWT parsing for role claims.                        | ⏳ Planned   |
| **5. DNS Integration** | Create DB link + synonym for `INDICES`; update schema cards.        | ✅ Ongoing   |
| **6. Dockerization**   | Build Dockerfile + CI workflow.                                     | ⏳ Planned   |
| **7. Monitoring**      | Add query/audit logging (`original_sql`, `scoped_sql`, `role`).     | ⏳ Planned   |
| **8. Optional**        | Add Oracle VPD policies for DB-level enforcement.                   | 🔒 Optional |
| **9. Documentation**   | Update developer guide and API docs.                                | ⏳ Planned   |

---

## 🔒 Guardrails Summary

| Guard               | Purpose                                         | File                        |
| ------------------- | ----------------------------------------------- | --------------------------- |
| **Safety**          | Block non-read SQL, enforce allowlist + limits. | `guards/safety.py`          |
| **Schema Validate** | Confirm columns exist for their tables.         | `guards/schema_validate.py` |
| **Labels**          | Detect / repair missing label joins.            | `guards/labels.py`          |
| **Row-Level**       | Inject trader/broker/admin predicates.          | `guards/row_level.py`       |
| **Execution**       | Enforce row limits, optional plan gate.         | `services/execution.py`     |

---

## 🏗 Deployment Q&A

**Q:** How do we restrict data visibility per role?
**A:** Use row-level security injector or Oracle VPD; both automatically filter results.

**Q:** How do we expose this in the trading app?
**A:** Deploy as FastAPI microservice, connect via secure widget.

**Q:** Can we support both ATS & DNS tables?
**A:** Yes — by using DB links or multiple connections; schema cards stay unified.

**Q:** What happens when schemas grow?
**A:** Continue adding to allowlist and schema cards; retrieval or modular loading can be added later if context becomes too large.

---

## 🧾 License & Notes

* Internal use only under Infotech Group license.
* Requires Oracle connectivity and read privileges.
* Tested with `python-oracledb` 2.x (thin mode).
* Supports both Windows and Linux.

---

**Author:** *Infotech / ATS SQL Assistant Team*
**Version:** v3.0 — Multi-DB integration + Role-based Row-Level Security (Trader/Broker/Admin) + API deployment plan (October 2025) -->

# 🧠 ATS SQL Assistant — Oracle Natural Language → SQL Pipeline

End-to-end intelligent SQL generation and execution system for **ATS / DNS (BODIVA)** datasets.  
It converts natural-language questions into **validated Oracle SQL**, applies multi-layer guardrails, executes securely, and returns tabular previews and downloadable reports.

---

## 🚀 Overview

ATS SQL Assistant unifies:
- **LLM-driven SQL generation** (Gemini / Llama / GPT-OSS)
- **Schema awareness** and table allowlisting  
- **Runtime safety validation** (read-only enforcement, row limits)
- **Extensible API** for embedding into any internal portal or app
- **Dockerized deployment** for backend + UI
- **Planned authentication & role-based access (RLS)** for production rollout

### Supported Data Domains

| Domain | Example Tables |
|---------|----------------|
| **Markets** | `SYMBOL_DAILY_INDICATORS`, `BEST_MKT`, `INDICES` |
| **Orders / Rejections** | `ORDERS`, `REJECTED_ORDERS`, `REJECTIONS` |
| **Trades** | `TRADES`, `CANCELLED_TRADES`, `NEGOTIATED_TRADES` |
| **Levies / Fees** | `ATS_LEVY_DATA_LOG`, `LEVIES`, `LEVY_TYPES` |
| **Shared Lookups** | `SYMBOLS`, `EXCHANGES`, `CLIENTS`, `USERS` |
| **Repo / Funding** | Repo & cashflow tables *(v2.1+)* |

---

## 🧩 Current System Flow

```

User (Natural Language)
↓
UI (Streamlit / host app) or API Client
↓
FastAPI Backend (Gemini-powered pipeline)
↓
Guardrails → Schema validation → Execution
↓
Oracle / DNS (read-only)
↓
Preview + CSV / HTML / PDF exports

````

> The entire backend can run standalone as an API microservice or with the included Streamlit UI.

---

## ⚙️ Environment Setup

```bash
python -m venv .venv
source .venv/bin/activate       # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
````

**`.env` Example**

```ini
# --- Oracle connections ---
ORACLE_DSN=192.168.36.160:1521/gsedb
ORACLE_USER=ATS
ORACLE_PASSWORD=ABC
ORACLE_OWNER=DNS
ORACLE_OWNER_ALIASES=ATS,DNS

# --- Allowed tables ---
SAFETY_ALLOWED_TABLES=ORDERS TRADES CANCELLED_TRADES INDICES EXCHANGES SYMBOLS ...
ALLOWED_TABLES=ORDERS,TRADES,CANCELLED_TRADES,INDICES,EXCHANGES,SYMBOLS,...

# --- Model configuration ---
MODEL_STRATEGY=AUTO
GEMINI_MODEL=gemini-1.5-pro
OLLAMA_MODEL=llama3
GEMINI_API_KEY=<your_internal_key>

# --- Safety / validation ---
ROW_LIMIT_DEFAULT=200
EXPLAIN_GATE_ENABLED=0
MAX_ESTIMATED_ROWS=5000000
```

---

## 🧠 Running Locally

1. Ensure Oracle network access (and `python-oracledb` installed).
2. Activate your environment and start the API:

   ```bash
   uvicorn api:app --host 0.0.0.0 --port 8080
   ```
3. Access the docs at: [http://localhost:8080/docs](http://localhost:8080/docs)
4. Or launch the Streamlit interface:

   ```bash
   streamlit run app/ui/chatbot.py
   ```

---

## 📡 API Layer

Base URL: `http://localhost:8080/api/v1`

| Method   | Endpoint        | Purpose                                   |
| -------- | --------------- | ----------------------------------------- |
| **GET**  | `/health`       | Health & DB connectivity check            |
| **GET**  | `/schema`       | Schema metadata for UI and LLM context    |
| **POST** | `/query`        | NL question → validated SQL + preview     |
| **POST** | `/sql/validate` | Validate user-supplied SQL (no execution) |
| **POST** | `/sql/execute`  | Execute safe SQL and return JSON rows     |
| **POST** | `/exports`      | Execute & stream CSV / HTML / PDF         |

**Auth:**
For the current internal phase, API calls are unrestricted.
Planned next step is header-based authentication (`X-Api-Key` or JWT Bearer token).

**Example Call**

```bash
curl -X POST http://localhost:8080/api/v1/query \
  -H "Content-Type: application/json" \
  -d '{"question": "show top 5 trades with price and volume"}'
```

**Example Response**

```json
{
  "sql": "SELECT PRICE, VOLUME FROM TRADES FETCH FIRST 5 ROWS ONLY",
  "guards": { "read_only": true, "allowlist_ok": true },
  "preview": [
    {"PRICE": 12.5, "VOLUME": 1000},
    {"PRICE": 13.2, "VOLUME": 850}
  ]
}
```

---

## 🐳 Dockerization

Two independent containers are provided for deployment:

| Service          | Purpose             | Port          |
| ---------------- | ------------------- | ------------- |
| **`sqlbot-api`** | FastAPI backend     | `8080`        |
| **`sqlbot-ui`**  | Streamlit interface | `8501 → 8502` |

### Quick Start

```bash
docker compose build
docker compose up -d
```

Access:

* UI → [http://localhost:8502](http://localhost:8502)
* API → [http://localhost:8080/api/v1/health](http://localhost:8080/api/v1/health)

### Environment Variables

Defined in `.env` and `.env.docker`:

```
MODEL_STRATEGY=gemini
API_PORT=8080
WKHTMLTOPDF_PATH=/usr/bin/wkhtmltopdf
```

### Smoke Test

```bash
curl http://localhost:8080/api/v1/health
curl -X POST http://localhost:8080/api/v1/sql/execute \
  -H "Content-Type: application/json" \
  -d '{"sql":"SELECT 1 AS TEST FROM DUAL"}'
```

---

## 🔒 Guardrails Summary

| Guard Type          | Purpose                                        | Location                    |
| ------------------- | ---------------------------------------------- | --------------------------- |
| **Safety**          | Block non-read SQL, enforce allowlist & limits | `guards/safety.py`          |
| **Schema Validate** | Verify columns/tables exist                    | `guards/schema_validate.py` |
| **Labels**          | Auto-fix label join mismatches                 | `guards/labels.py`          |
| **Execution**       | Apply row limits and plan gate                 | `services/execution.py`     |

---

## 🧱 Deployment & Integration

### Typical Architecture

```
[Client Apps / Portals]  →  [FastAPI (ATS SQLBot API)]  →  [Oracle / DNS]
                                 ↑
                                 └── uses Gemini API internally
```

### Integration Options

1. **Direct API Calls** — existing apps (Tomcat, .NET, etc.) hit the `/api/v1` endpoints.
2. **Streamlit UI** — internal analysts use web interface.
3. **Hybrid** — both active (shared backend).

### Deployment Targets

* Internal VM / Linux host (Uvicorn or Docker)
* Cloud VM or Kubernetes with ingress and TLS
* Reverse-proxied domain: `https://sqlbot.mycompany.com/api/v1`

### Operations Checklist

* Set all env secrets (Oracle creds, Gemini key, API key)
* Expose health route for monitoring
* Rotate keys and monitor logs
* Enable HTTPS (proxy or LB)
* Optionally configure CORS for frontend origin

---

## 🔐 Next Steps (v4.1 Roadmap)

| Area                    | Task                                                 | Status         |
| ----------------------- | ---------------------------------------------------- | -------------- |
| **Authentication**      | Add API Key & JWT-based access control               | 🚧 In progress |
| **Authorization / RLS** | Add role-based row filters (Trader / Broker / Admin) | 🚧 Planned     |
| **Audit Logging**       | Log original SQL, scoped SQL, caller, latency        | ⏳ Planned      |
| **Monitoring**          | Expose Prometheus metrics and structured logs        | ⏳ Planned      |
| **CI/CD**               | Automated builds and versioned Docker pushes         | ⏳ Planned      |
| **Docs**                | Integration notice and OpenAPI alignment             | ✅ Done         |
| **Security Hardening**  | Rate limiting, CORS, secrets via vault               | ⏳ Planned      |

---

## 🧪 Testing & Validation


* **Few-shot verification scripts** available under `_smoke/`.
* **Postman collection** (`SQLBot.postman_collection.json`) provides ready-made endpoint tests.

---

## 🧾 License & Notes

* Internal use only under Infotech Group license.
* Requires Oracle connectivity (read-only).
* Tested on Python 3.10+, `python-oracledb` 2.x (thin mode).
* Compatible with Windows, Linux, and Docker environments.

---

**Author:** *Infotech / ATS SQL Assistant Team*
**Version:** v4.0 — API-Ready, Dockerized Backend with Integration Support *(Nov 2025)*
**Next:** Authentication + Role-based Authorization rollout (v4.1)