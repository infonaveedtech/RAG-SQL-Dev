# RUN.md — Setup & Run Guide

This guide helps you run the SQL Copilot locally on **any laptop** with Oracle access and Gemini API credentials.

---

## 0) Prerequisites

* **Python 3.10+**
* **Oracle access** (network reachability to `ORACLE_DSN`)
* **Gemini API key** (Google AI Studio)
* Optional: **Oracle Instant Client** (helps avoid DPI-1047 errors)
* Optional: **wkhtmltopdf** if you plan to export PDFs

> The app uses the `oracledb` driver (thin mode by default). If you hit client-library errors, install Instant Client (see below).

---

## 1) Get the code

```bash
# macOS / Linux
git clone <your-repo-url>
cd <your-repo>

# Windows (PowerShell)
git clone <your-repo-url>
cd <your-repo>
```

---

## 2) Create a virtual environment

```bash
# macOS / Linux
python3 -m venv .venv
source .venv/bin/activate

# Windows (PowerShell)
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

---

## 3) Install dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 4) Configure environment (.env)

Create a file named **`.env`** in the project root:

```ini
# --- Oracle DB ---
ORACLE_DSN=192.168.36.227:1521/DEVDB
ORACLE_USER=ATS
ORACLE_PASSWORD=ABC
ORACLE_OWNER=ATS

# --- LLM (Gemini primary) ---
GEMINI_API_KEY=YOUR_KEY_HERE
GEMINI_MODEL=gemini-2.5-flash

# Strategy: auto (Gemini→Llama), gemini, llama
MODEL_STRATEGY=auto

# --- App toggles / diagnostics ---
SAFETY_DEBUG=1
EXPLAIN_GATE_ENABLED=0

# Optional utilities
WKHTMLTOPDF_PATH=C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe

# --- Request timeouts / perf knobs ---
LLM_CONNECT_TIMEOUT=10
LLM_READ_TIMEOUT=300
GPTOSS_NUM_PREDICT=320
OLLAMA_KEEP_ALIVE=5m

# --- Table allowlists (UPDATED with Rejections & Levies) ---
ALLOWED_TABLES=SYMBOL_DAILY_INDICATORS,SYMBOL_INDICATORS,BEST_MKT,SYMBOLS,EXCHANGES,ORDERS,SYMBOL_MARKETS,FLAGS,ORDER_TYPES,ORDER_STATES,SUBSCRIBED_BROKERS,EDS_CLIENTS,USERS,TRADES,CANCELLED_TRADES,NEGOTIATED_TRADES,TRADE_STATES,SETTLEMENT_TYPES,REJECTED_ORDERS,REJECTIONS,ATS_LEVY_DATA_LOG,SETTLEMENT_LEVY_DATA,LEVIES,LEVY_TYPES,LEVY_RANGES,LEVY_CRITERIA,LEVY_INFO,LEVY_MEMBER_TYPES,LEVY_SECURITIES

SAFETY_ALLOWED_TABLES=SYMBOL_DAILY_INDICATORS SYMBOL_INDICATORS BEST_MKT SYMBOLS EXCHANGES ORDERS FLAGS ORDER_TYPES ORDER_STATES SUBSCRIBED_BROKERS EDS_CLIENTS USERS SYMBOL_MARKETS TRADES CANCELLED_TRADES NEGOTIATED_TRADES TRADE_STATES SETTLEMENT_TYPES REJECTED_ORDERS REJECTIONS ATS_LEVY_DATA_LOG SETTLEMENT_LEVY_DATA LEVIES LEVY_TYPES LEVY_RANGES LEVY_CRITERIA LEVY_INFO LEVY_MEMBER_TYPES LEVY_SECURITIES
```

> Keep secrets private. Never commit `.env`.

---

## 5) (If needed) Install Oracle Instant Client

**Windows**

1. Download “Basic Package” (64-bit) from Oracle.
2. Unzip to e.g. `C:\oracle\instantclient_21_13`
3. Add to PATH:

   * Start → “Edit the system environment variables” → **Environment Variables**
   * Edit **Path** → Add `C:\oracle\instantclient_21_13`

**macOS**

```bash
# Homebrew (cask) or manual unzip
brew install --cask oracle-instant-client  # or
# export DYLD_LIBRARY_PATH=/usr/local/instantclient:$DYLD_LIBRARY_PATH
```

**Linux**

```bash
sudo mkdir -p /opt/oracle
sudo tar -xzf instantclient-basic-linux.x64-21.x.x.x.zip -C /opt/oracle
export LD_LIBRARY_PATH=/opt/oracle/instantclient_21_13:$LD_LIBRARY_PATH
```

**Verify**

```bash
python -c "import oracledb; print(oracledb.__version__)"
```

---

## 6) Run the Streamlit app

```bash
# If the UI module lives at app/ui/chatbot.py
streamlit run app/ui/chatbot.py

# If your file layout is app/chatbot.py
# streamlit run app/chatbot.py
```

Open the URL printed by Streamlit (usually `http://localhost:8501`).

---

## 7) Run few-shot sanity tests (optional but recommended)

```bash
python -m app.tools.run_rejections_levies_fewshots
```

Expected: 4/4 succeed; CSVs saved under `evaluation/run_fewshots_results/`.

---

## 8) Typical prompts to try

* “Daily counts of rejected orders by reason (last 30 days).”
* “Totals by levy type (last 90 days).”
* “Top clients by levy amount this quarter.”
* “Daily levy by market and side (last 30 days).”

The UI should show **a single SQL block** and a one-line status, then results.

---

## 9) Adding new tables (mini-playbook)

1. **Smoke inspect** new table(s) using your existing `inspect_*.py` pattern.
2. **Allowlist** in `.env`:

   * Add to `SAFETY_ALLOWED_TABLES` (space-separated) and `ALLOWED_TABLES` (comma-separated).
3. **Schema Card** (`schema_card.txt`):

   * Add columns, date key, dimensions, measures, and *preferred joins*.
   * Make sure markdown code fences are **balanced** (`…`).
4. **Glossary** (`glossary.md`):

   * Add plain English descriptions and synonyms.
5. **Fewshots** (`fewshots.sql.md`):

   * Add 1–3 examples that cover common aggregations/joins.
6. **Re-run few-shots** & validate output CSVs.

> If the model ever echoes long text (schema, prompts), check your fences first; that’s usually the culprit.

---

## 10) Troubleshooting

**DPI-1047 or client library errors**

* Add/verify Instant Client path (PATH / LD_LIBRARY_PATH / DYLD_LIBRARY_PATH).
* Restart the terminal after changing PATH.

**ORA-12154 (TNS)/connectivity issues**

* Verify `ORACLE_DSN` syntax: `host:port/SERVICE_NAME`
* Confirm network reachability (VPN/firewall).
* Test with `sqlplus` or `tnsping` if available.

**Model errors / empty responses**

* Ensure `GEMINI_API_KEY` is set and valid.
* Set `MODEL_STRATEGY=gemini` to force Gemini only (for debugging).

**Overly long answers**

* Ensure `schema_card.txt` / `fewshots.sql.md` have **balanced** ``` fences.
* UI should print only a **one-liner + SQL**; don’t render raw model text.

---

## 11) Optional: Export PDFs (if enabled)

* Install **wkhtmltopdf** and set `WKHTMLTOPDF_PATH` in `.env`.
* If you don’t need PDF exports, you can omit the tool entirely.

---

## 12) Quick “works on my machine” checklist

* `pip install -r requirements.txt` completes without error
* `python -c "import oracledb"` succeeds
* `streamlit run app/ui/chatbot.py` opens UI
* Few-shots runner saves 4 CSVs under `evaluation/run_fewshots_results/`
* Example prompt returns a query + results, without extra prose

---

## 13) Roadmap / TODO

1. **Indices tables**: add schema → glossary → fewshots → allowlist.
2. **Deployment feasibility**: Docker + corporate proxy notes + light cloud options.

