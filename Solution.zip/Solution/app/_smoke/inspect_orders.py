# app/_smoke/inspect_tables.py
from __future__ import annotations

import os
import sys
from contextlib import contextmanager
from typing import Iterable, List, Tuple, Dict, Sequence
from dotenv import load_dotenv

load_dotenv()

import oracledb

OWNER = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
USER = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
PASSWORD = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")
DSN = os.getenv("ORACLE_DSN") or os.getenv("DB_DSN")           # e.g. "host:1521/service"
STATEMENT_TIMEOUT_MS = int(os.getenv("STATEMENT_TIMEOUT_MS", "60000"))

# Comma-separated list, or pass tables via CLI args
INSPECT_TABLES = [t.strip().upper() for t in os.getenv("INSPECT_TABLES", "").split(",") if t.strip()]
SAMPLE_ROWS = int(os.getenv("SAMPLE_ROWS", "2"))

# Extra columns to try distributions on (comma separated)
EXTRA_DIST_COLS = [c.strip().upper() for c in os.getenv("EXTRA_DIST_COLS", "").split(",") if c.strip()]

LABEL_LIKE_SUBSTRINGS = ("NAME", "CODE", "DESC")  # heuristic to find label columns


def die(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(1)


def _require_env():
    missing = [k for k, v in {
        "ORACLE_USER/DB_USER": USER,
        "ORACLE_PASSWORD/DB_PASSWORD": PASSWORD,
        "ORACLE_DSN/DB_DSN": DSN,
    }.items() if not v]
    if missing:
        die(f"Missing connection envs: {', '.join(missing)}")


@contextmanager
def connect_ro():
    """Create a thin connection, set call timeout & current_schema."""
    _require_env()
    conn = oracledb.connect(user=USER, password=PASSWORD, dsn=DSN)
    try:
        try:
            conn.callTimeout = STATEMENT_TIMEOUT_MS
        except Exception:
            pass
        with conn.cursor() as cur:
            cur.execute(f"alter session set current_schema = {OWNER}")
            try:
                cur.execute("alter session set optimizer_dynamic_sampling = 0")
            except Exception:
                pass
        yield conn
    finally:
        conn.close()


def fetchall(cur, sql: str, params: dict | tuple | None = None) -> Tuple[List[str], List[tuple]]:
    cur.execute(sql, params or {})
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    return cols, rows


def print_section(title: str):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def print_table(cols: Iterable[str], rows: Iterable[Iterable], max_rows: int | None = None):
    cols = list(cols)
    rows = list(rows if max_rows is None else rows[:max_rows])
    if rows is None or len(rows) == 0:
        print("(no rows)")
        return
    widths = [max(len(c), *(len(str(r[i])) for r in rows if r is not None and i < len(r))) for i, c in enumerate(cols)]
    line = " | ".join(c.ljust(widths[i]) for i, c in enumerate(cols))
    print(line)
    print("-" * len(line))
    for r in rows:
        print(" | ".join(str(r[i]).ljust(widths[i]) for i in range(len(cols))))


def column_exists(columns: List[Dict[str, str]], name: str) -> bool:
    name_u = name.upper()
    return any(c["COLUMN_NAME"] == name_u for c in columns)


def label_like_columns(columns: List[Dict[str, str]]) -> List[str]:
    out = []
    for c in columns:
        cn = c["COLUMN_NAME"]
        up = cn.upper()
        if any(sub in up for sub in LABEL_LIKE_SUBSTRINGS):
            out.append(cn)
    # include any extra the user wants
    out.extend([c for c in EXTRA_DIST_COLS if c not in out])
    return out


def load_columns(cur, table: str) -> List[Dict[str, str]]:
    sql_cols = """
        SELECT column_id,
               column_name,
               data_type,
               data_length,
               data_precision,
               data_scale,
               nullable
        FROM   all_tab_columns
        WHERE  owner = :owner AND table_name = :tab
        ORDER  BY column_id
    """
    _, rows = fetchall(cur, sql_cols, {"owner": OWNER, "tab": table})
    return [
        {
            "COLUMN_ID": r[0],
            "COLUMN_NAME": r[1],
            "DATA_TYPE": r[2],
            "DATA_LENGTH": r[3],
            "DATA_PRECISION": r[4],
            "DATA_SCALE": r[5],
            "NULLABLE": r[6],
        }
        for r in rows
    ]


def inspect_table(cur, table: str):
    print_section(f"TABLE PROFILE — {OWNER}.{table}")

    # Columns
    print_section("Columns / Types / Nullability")
    columns = load_columns(cur, table)
    if columns:
        print_table(
            ["COLUMN_ID", "COLUMN_NAME", "DATA_TYPE", "DATA_LENGTH", "DATA_PRECISION", "DATA_SCALE", "NULLABLE"],
            [[c[k] for k in ["COLUMN_ID","COLUMN_NAME","DATA_TYPE","DATA_LENGTH","DATA_PRECISION","DATA_SCALE","NULLABLE"]]
             for c in columns],
            None
        )
    else:
        print("(no column metadata — does the table exist?)")
        return

    # Sample rows
    print_section(f"Sample rows (ROWNUM <= {SAMPLE_ROWS})")
    sql_sample = f"SELECT * FROM {OWNER}.{table} WHERE ROWNUM <= :n"
    cols, rows = fetchall(cur, sql_sample, {"n": SAMPLE_ROWS})
    print_table(cols, rows, None)

    # PK / Unique constraints
    print_section("Primary / Unique Constraints")
    pk_sql = """
        SELECT ac.constraint_name, ac.constraint_type
        FROM   all_constraints ac
        WHERE  ac.owner = :owner
        AND    ac.table_name = :tab
        AND    ac.constraint_type IN ('P','U')
        ORDER  BY ac.constraint_type, ac.constraint_name
    """
    cols, rows = fetchall(cur, pk_sql, {"owner": OWNER, "tab": table})
    print_table(cols, rows)

    # PK columns
    print_section("Primary Key Columns")
    pk_cols_sql = """
        SELECT cols.column_name
        FROM   all_constraints cons
        JOIN   all_cons_columns cols
               ON cons.owner = cols.owner
              AND cons.constraint_name = cols.constraint_name
              AND cons.table_name = cols.table_name
        WHERE  cons.owner = :owner
        AND    cons.table_name = :tab
        AND    cons.constraint_type = 'P'
        ORDER  BY cols.position
    """
    cols, rows = fetchall(cur, pk_cols_sql, {"owner": OWNER, "tab": table})
    print_table(cols, rows)

    # Outgoing FKs
    print_section("Foreign Keys (outgoing)")
    fk_sql = """
        SELECT a.constraint_name,
               a.column_name,
               c_pk.owner      AS ref_owner,
               c_pk.table_name AS ref_table,
               b.column_name   AS ref_column
        FROM   all_cons_columns a
        JOIN   all_constraints c
               ON a.owner = c.owner
              AND a.constraint_name = c.constraint_name
        JOIN   all_constraints c_pk
               ON c.r_owner = c_pk.owner
              AND c.r_constraint_name = c_pk.constraint_name
        JOIN   all_cons_columns b
               ON c_pk.constraint_name = b.constraint_name
              AND b.position = a.position
        WHERE  c.owner = :owner
        AND    c.table_name = :tab
        AND    c.constraint_type = 'R'
        ORDER  BY a.constraint_name, a.position
    """
    cols, rows = fetchall(cur, fk_sql, {"owner": OWNER, "tab": table})
    print_table(cols, rows)

    # Indexes
    print_section("Indexes")
    idx_sql = """
        SELECT ai.index_name,
               ai.uniqueness,
               listagg(aic.column_name, ', ') within group (order by aic.column_position) AS columns
        FROM   all_indexes ai
        JOIN   all_ind_columns aic
               ON ai.index_name = aic.index_name
              AND ai.table_owner = aic.table_owner
              AND ai.table_name  = aic.table_name
        WHERE  ai.table_owner = :owner
        AND    ai.table_name  = :tab
        GROUP  BY ai.index_name, ai.uniqueness
        ORDER  BY ai.index_name
    """
    cols, rows = fetchall(cur, idx_sql, {"owner": OWNER, "tab": table})
    print_table(cols, rows)

    # Row count
    print_section("Row Count")
    total_sql = f"SELECT COUNT(*) AS total_rows FROM {OWNER}.{table}"
    cols, rows = fetchall(cur, total_sql, {})
    print_table(cols, rows)

    # Quick distributions for label-ish cols
    print_section("Quick value distributions (top 10)")
    label_cols = label_like_columns(columns)
    for col in label_cols:
        try:
            sql = f"""
                SELECT {col} AS value, COUNT(*) AS cnt
                FROM   {OWNER}.{table}
                GROUP  BY {col}
                ORDER  BY cnt DESC
                FETCH FIRST 10 ROWS ONLY
            """
            print(f"\n-- {col}")
            cols, rows = fetchall(cur, sql, {})
            print_table(cols, rows)
        except Exception as e:
            print(f"-- {col} (skipped, error: {e})")


def main():
    # Tables list from CLI or env
    tables: Sequence[str] = [t.upper() for t in (sys.argv[1:] if len(sys.argv) > 1 else INSPECT_TABLES)]
    if not tables:
        print("Usage:")
        print("  python -m app._smoke.inspect_tables FLAGS ORDER_TYPES ORDER_STATES SYMBOLS EXCHANGES SUBSCRIBED_BROKERS EDS_CLIENTS USERS SYMBOL_MARKETS")
        print("Or set env INSPECT_TABLES=FLAGS,ORDER_TYPES,...")
        sys.exit(0)

    print_section(f"INSPECT — OWNER={OWNER}")
    print(f"Tables: {', '.join(tables)}")

    with connect_ro() as conn, conn.cursor() as cur:
        for t in tables:
            try:
                inspect_table(cur, t)
            except Exception as e:
                print_section(f"ERROR while inspecting {OWNER}.{t}")
                print(repr(e))

    print_section("Done ✅")


if __name__ == "__main__":
    main()
