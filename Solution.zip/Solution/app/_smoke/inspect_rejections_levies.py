# app/_smoke/inspect_rejections_and_levies.py
from __future__ import annotations

"""
Smoke inspector for:
  1) Rejections domain: REJECTED_ORDERS, REJECTIONS (+ common lookups)
  2) Levy domain: ATS_LEVY_DATA_LOG, SETTLEMENT_LEVY_DATA, and levy lookups

Usage examples:
  # default selection (both families + lookups)
  python -m app._smoke.inspect_rejections_and_levies

  # custom tables via CLI
  python -m app._smoke.inspect_rejections_and_levies REJECTED_ORDERS REJECTIONS

  # via env
  INSPECT_TABLES="ATS_LEVY_DATA_LOG,LEVIES,LEVY_TYPES" python -m app._smoke.inspect_rejections_and_levies

  # save output to file (tee)
  python -m app._smoke.inspect_rejections_and_levies --out ./reports/inspect.txt
  OUT_FILE=./reports/inspect.txt python -m app._smoke.inspect_rejections_and_levies

Environment (same as other inspectors):
  ORACLE_OWNER / ORACLE_USER / ORACLE_PASSWORD / ORACLE_DSN
  STATEMENT_TIMEOUT_MS (default 60000)
  SAMPLE_ROWS (default 2)
  EXTRA_DIST_COLS (comma separated; added to label-like distributions)

Notes:
  - Sets CURRENT_SCHEMA and disables dynamic sampling for determinism.
  - Adds quick family-specific profiles so we get recency & business-health at a glance.
"""

import io
import os
import sys
from contextlib import contextmanager
from typing import Iterable, List, Tuple, Dict, Sequence

from dotenv import load_dotenv
load_dotenv()

import oracledb

# --- Connection / session env ---
OWNER = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
USER = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
PASSWORD = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")
DSN = os.getenv("ORACLE_DSN") or os.getenv("DB_DSN")           # e.g. "host:1521/service"
STATEMENT_TIMEOUT_MS = int(os.getenv("STATEMENT_TIMEOUT_MS", "60000"))

# --- Tables to inspect ---
REJECTIONS_DEFAULTS = [
    "REJECTED_ORDERS",
    "REJECTIONS",
    # helpful lookups for labels (optional)
    "ORDERS",
    "SYMBOLS",
    "EXCHANGES",
    "SUBSCRIBED_BROKERS",
    "EDS_CLIENTS",
    "USERS",
    "ORDER_TYPES",
    "ORDER_STATES",
    "FLAGS",
]

LEVY_DEFAULTS = [
    "ATS_LEVY_DATA_LOG",
    "SETTLEMENT_LEVY_DATA",
    "LEVIES",
    "LEVY_CRITERIA",
    "LEVI_INFO",
    "LEVY_MEMBER_TYPES",
    "LEVY_RANGES",
    "LEVY_RECURRENCE",
    "LEVY_SECURITIES",
    "LEVY_TYPES",
]

DEFAULT_TABLES = REJECTIONS_DEFAULTS + LEVY_DEFAULTS

INSPECT_TABLES = [
    t.strip().upper()
    for t in (os.getenv("INSPECT_TABLES") or "").split(",")
    if t.strip()
] or DEFAULT_TABLES

SAMPLE_ROWS = int(os.getenv("SAMPLE_ROWS", "2"))

# Extra columns to try distributions on (comma separated)
EXTRA_DIST_COLS = [c.strip().upper() for c in os.getenv("EXTRA_DIST_COLS", "").split(",") if c.strip()]

# Heuristic to find label-like columns
LABEL_LIKE_SUBSTRINGS = (
    "NAME", "CODE", "DESC",
    "SYMBOL", "VENUE",
    "REASON",
    "LEVY", "LEVI", "TYPE",
)

# ----------------------------
# Tee (save console output to file too)
# ----------------------------
class _Tee(io.TextIOBase):
    def __init__(self, stream_a, stream_b):
        self.a = stream_a
        self.b = stream_b
    def write(self, s):
        self.a.write(s)
        self.b.write(s)
        return len(s)
    def flush(self):
        self.a.flush()
        self.b.flush()

def _maybe_wrap_stdout_with_file(argv_like: List[str]) -> List[str]:
    # CLI flag: --out <path>
    out_path = None
    if "--out" in argv_like:
        try:
            idx = argv_like.index("--out")
            out_path = argv_like[idx + 1]
            # remove the flag + value from argv-like list
            del argv_like[idx:idx + 2]
        except Exception:
            pass
    # ENV fallback
    out_path = out_path or os.getenv("OUT_FILE")
    if out_path:
        try:
            import pathlib
            pathlib.Path(out_path).parent.mkdir(parents=True, exist_ok=True)
            f = open(out_path, "w", encoding="utf-8")
            sys.stdout = _Tee(sys.stdout, f)
            print(f"[tee] Saving a copy of this report to: {out_path}")
        except Exception as e:
            print(f"[tee] Could not open {out_path} for writing: {e}")
    return argv_like

# ----------------------------
# Helpers
# ----------------------------
def _die(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(1)

def _require_env():
    missing = [k for k, v in {
        "ORACLE_USER/DB_USER": USER,
        "ORACLE_PASSWORD/DB_PASSWORD": PASSWORD,
        "ORACLE_DSN/DB_DSN": DSN,
    }.items() if not v]
    if missing:
        _die(f"Missing connection envs: {', '.join(missing)}")

@contextmanager
def connect_ro():
    """
    Create a python-oracledb Thin connection, set call timeout & CURRENT_SCHEMA.
    """
    _require_env()
    conn = oracledb.connect(user=USER, password=PASSWORD, dsn=DSN)
    try:
        try:
            conn.callTimeout = STATEMENT_TIMEOUT_MS
        except Exception:
            pass
        with conn.cursor() as cur:
            cur.execute(f"alter session set current_schema = {OWNER}")
            try:
                cur.execute("alter session set optimizer_dynamic_sampling = 0")
            except Exception:
                pass
        yield conn
    finally:
        conn.close()

def _fetchall(cur, sql: str, params: dict | tuple | None = None) -> Tuple[List[str], List[tuple]]:
    cur.execute(sql, params or {})
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    return cols, rows

def _print_section(title: str):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)

def _print_table(cols: Iterable[str], rows: Iterable[Iterable], max_rows: int | None = None):
    cols = list(cols)
    rows = list(rows if max_rows is None else rows[:max_rows])
    if not rows:
        print("(no rows)")
        return
    widths = [max(len(c), *(len(str(r[i])) for r in rows if r is not None and i < len(r))) for i, c in enumerate(cols)]
    line = " | ".join(c.ljust(widths[i]) for i, c in enumerate(cols))
    print(line)
    print("-" * len(line))
    for r in rows:
        print(" | ".join(str(r[i]).ljust(widths[i]) for i in range(len(cols))))

def _label_like_columns(columns: List[Dict[str, str]]) -> List[str]:
    out = []
    for c in columns:
        cn = c["COLUMN_NAME"]
        up = cn.upper()
        if any(sub in up for sub in LABEL_LIKE_SUBSTRINGS):
            out.append(cn)
    # include any extra the user specified
    for c in EXTRA_DIST_COLS:
        if c not in out:
            out.append(c)
    return out

def _load_columns(cur, table: str) -> List[Dict[str, str]]:
    sql_cols = """
        SELECT column_id,
               column_name,
               data_type,
               data_length,
               data_precision,
               data_scale,
               nullable
        FROM   all_tab_columns
        WHERE  owner = :owner AND table_name = :tab
        ORDER  BY column_id
    """
    _, rows = _fetchall(cur, sql_cols, {"owner": OWNER, "tab": table})
    return [
        {
            "COLUMN_ID": r[0],
            "COLUMN_NAME": r[1],
            "DATA_TYPE": r[2],
            "DATA_LENGTH": r[3],
            "DATA_PRECISION": r[4],
            "DATA_SCALE": r[5],
            "NULLABLE": r[6],
        }
        for r in rows
    ]

# ----------------------------
# Deep per-table inspection
# ----------------------------
def inspect_table(cur, table: str):
    _print_section(f"TABLE PROFILE — {OWNER}.{table}")

    # Columns
    _print_section("Columns / Types / Nullability")
    columns = _load_columns(cur, table)
    if not columns:
        print("(no column metadata — does the table exist?)")
        return
    _print_table(
        ["COLUMN_ID", "COLUMN_NAME", "DATA_TYPE", "DATA_LENGTH", "DATA_PRECISION", "DATA_SCALE", "NULLABLE"],
        [[c[k] for k in ["COLUMN_ID", "COLUMN_NAME", "DATA_TYPE", "DATA_LENGTH", "DATA_PRECISION", "DATA_SCALE", "NULLABLE"]] for c in columns],
        None
    )

    # Sample rows
    _print_section(f"Sample rows (ROWNUM <= {SAMPLE_ROWS})")
    sql_sample = f"SELECT * FROM {OWNER}.{table} WHERE ROWNUM <= :n"
    cols, rows = _fetchall(cur, sql_sample, {"n": SAMPLE_ROWS})
    _print_table(cols, rows, None)

    # Primary / Unique constraints
    _print_section("Primary / Unique Constraints")
    pk_sql = """
        SELECT ac.constraint_name, ac.constraint_type
        FROM   all_constraints ac
        WHERE  ac.owner = :owner
        AND    ac.table_name = :tab
        AND    ac.constraint_type IN ('P','U')
        ORDER  BY ac.constraint_type, ac.constraint_name
    """
    cols, rows = _fetchall(cur, pk_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Primary Key columns
    _print_section("Primary Key Columns")
    pk_cols_sql = """
        SELECT cols.column_name
        FROM   all_constraints cons
        JOIN   all_cons_columns cols
               ON cons.owner = cols.owner
              AND cons.constraint_name = cols.constraint_name
              AND cons.table_name = cols.table_name
        WHERE  cons.owner = :owner
        AND    cons.table_name = :tab
        AND    cons.constraint_type = 'P'
        ORDER  BY cols.position
    """
    cols, rows = _fetchall(cur, pk_cols_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Foreign Keys (outgoing)
    _print_section("Foreign Keys (outgoing)")
    fk_out_sql = """
        SELECT a.constraint_name,
               a.column_name,
               c_pk.owner      AS ref_owner,
               c_pk.table_name AS ref_table,
               b.column_name   AS ref_column
        FROM   all_cons_columns a
        JOIN   all_constraints c
               ON a.owner = c.owner
              AND a.constraint_name = c.constraint_name
        JOIN   all_constraints c_pk
               ON c.r_owner = c_pk.owner
              AND c.r_constraint_name = c_pk.constraint_name
        JOIN   all_cons_columns b
               ON c_pk.constraint_name = b.constraint_name
              AND b.position = a.position
        WHERE  c.owner = :owner
        AND    c.table_name = :tab
        AND    c.constraint_type = 'R'
        ORDER  BY a.constraint_name, a.position
    """
    cols, rows = _fetchall(cur, fk_out_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Foreign Keys (incoming) — who references this table?
    _print_section("Foreign Keys (incoming)")
    fk_in_sql = """
        SELECT c.owner       AS ref_owner,
               c.table_name  AS ref_table,
               acc.column_name AS ref_column,
               c.constraint_name
        FROM   all_constraints c
        JOIN   all_cons_columns acc
               ON c.owner = acc.owner
              AND c.constraint_name = acc.constraint_name
        WHERE  c.constraint_type = 'R'
        AND    (c.r_owner, c.r_constraint_name) IN (
            SELECT owner, constraint_name
            FROM   all_constraints
            WHERE  owner = :owner AND table_name = :tab AND constraint_type IN ('P','U')
        )
        ORDER BY ref_owner, ref_table, c.constraint_name, acc.position
    """
    cols, rows = _fetchall(cur, fk_in_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Indexes
    _print_section("Indexes")
    idx_sql = """
        SELECT ai.index_name,
               ai.uniqueness,
               listagg(aic.column_name, ', ') within group (order by aic.column_position) AS columns
        FROM   all_indexes ai
        JOIN   all_ind_columns aic
               ON ai.index_name = aic.index_name
              AND ai.table_owner = aic.table_owner
              AND ai.table_name  = aic.table_name
        WHERE  ai.table_owner = :owner
        AND    ai.table_name  = :tab
        GROUP  BY ai.index_name, ai.uniqueness
        ORDER  BY ai.index_name
    """
    cols, rows = _fetchall(cur, idx_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Row count
    _print_section("Row Count")
    total_sql = f"SELECT COUNT(*) AS total_rows FROM {OWNER}.{table}"
    cols, rows = _fetchall(cur, total_sql, {})
    _print_table(cols, rows)

    # Quick value distributions (label-ish)
    _print_section("Quick value distributions (top 10)")
    label_cols = _label_like_columns(columns)
    for col in label_cols:
        try:
            sql = f"""
                SELECT {col} AS value, COUNT(*) AS cnt
                FROM   {OWNER}.{table}
                GROUP  BY {col}
                ORDER  BY cnt DESC
                FETCH FIRST 10 ROWS ONLY
            """
            print(f"\n-- {col}")
            cols, rows = _fetchall(cur, sql, {})
            _print_table(cols, rows)
        except Exception as e:
            print(f"-- {col} (skipped, error: {e})")

# ----------------------------
# Family-specific quick profiles
# ----------------------------
def quick_rejections_profile(cur):
    """
    Snapshot for Rejections domain (if tables exist):
      - recency of rejected orders
      - top rejection reasons (7/30 days)
      - breakdown by broker and client (last 7 days)
    """
    _print_section("REJECTIONS — quick profile (recency / reasons / broker-client)")

    # existence check
    cols, rows = _fetchall(cur, """
        SELECT
          SUM(CASE WHEN table_name='REJECTED_ORDERS' THEN 1 ELSE 0 END) AS HAS_REJ_ORD,
          SUM(CASE WHEN table_name='REJECTIONS' THEN 1 ELSE 0 END) AS HAS_REASONS
        FROM all_tables
        WHERE owner = :owner
          AND table_name IN ('REJECTED_ORDERS','REJECTIONS')
    """, {"owner": OWNER})
    has_rej = rows and rows[0][0] > 0
    has_reasons = rows and rows[0][1] > 0
    if not has_rej:
        print("(REJECTED_ORDERS not found under this owner)")
        return

    # last rejected order timestamp + totals
    q = f"""
    SELECT
      (SELECT MAX(CREATED_AT) FROM {OWNER}.REJECTED_ORDERS) AS LAST_REJECT_AT,
      (SELECT COUNT(*) FROM {OWNER}.REJECTED_ORDERS) AS TOTAL_REJECTIONS
    FROM dual
    """
    try:
        cols, rows = _fetchall(cur, q, {})
        _print_table(cols, rows)
    except Exception as e:
        print("Basic recency/total — error", repr(e))

    # top reasons last 7/30 days
    if has_reasons:
        print("\n-- Top rejection reasons (last 7 days)")
        cols, rows = _fetchall(cur, f"""
          SELECT COALESCE(r.DESCRIPTION, TO_CHAR(ro.REJECTION_ID)) AS REASON_OR_ID,
                 COUNT(*) AS cnt
          FROM {OWNER}.REJECTED_ORDERS ro
          LEFT JOIN {OWNER}.REJECTIONS r ON ro.REJECTION_ID = r.REJECTION_ID
          WHERE ro.CREATED_AT >= TRUNC(SYSDATE)-7
          GROUP BY COALESCE(r.DESCRIPTION, TO_CHAR(ro.REJECTION_ID))
          ORDER BY cnt DESC
          FETCH FIRST 10 ROWS ONLY
        """)
        _print_table(cols, rows)

        print("\n-- Top rejection reasons (last 30 days)")
        cols, rows = _fetchall(cur, f"""
          SELECT COALESCE(r.DESCRIPTION, TO_CHAR(ro.REJECTION_ID)) AS REASON_OR_ID,
                 COUNT(*) AS cnt
          FROM {OWNER}.REJECTED_ORDERS ro
          LEFT JOIN {OWNER}.REJECTIONS r ON ro.REJECTION_ID = r.REJECTION_ID
          WHERE ro.CREATED_AT >= TRUNC(SYSDATE)-30
          GROUP BY COALESCE(r.DESCRIPTION, TO_CHAR(ro.REJECTION_ID))
          ORDER BY cnt DESC
          FETCH FIRST 10 ROWS ONLY
        """)
        _print_table(cols, rows)

    # broker + client breakdown last 7 days (best-effort)
    print("\n-- Rejections by broker (last 7 days)")
    try:
        cols, rows = _fetchall(cur, f"""
          SELECT COALESCE(sb.BROKER_NAME, TO_CHAR(ro.BROKER_ID)) AS BROKER,
                 COUNT(*) AS cnt
          FROM {OWNER}.REJECTED_ORDERS ro
          LEFT JOIN {OWNER}.SUBSCRIBED_BROKERS sb ON ro.BROKER_ID = sb.BROKER_ID
          WHERE ro.CREATED_AT >= TRUNC(SYSDATE)-7
          GROUP BY COALESCE(sb.BROKER_NAME, TO_CHAR(ro.BROKER_ID))
          ORDER BY cnt DESC
          FETCH FIRST 10 ROWS ONLY
        """)
        _print_table(cols, rows)
    except Exception as e:
        print("Broker breakdown — skipped", repr(e))

    print("\n-- Rejections by client (last 7 days)")
    try:
        cols, rows = _fetchall(cur, f"""
          SELECT COALESCE(c.CLIENT_NAME, TO_CHAR(ro.CLIENT_ID)) AS CLIENT,
                 COUNT(*) AS cnt
          FROM {OWNER}.REJECTED_ORDERS ro
          LEFT JOIN {OWNER}.EDS_CLIENTS c ON ro.CLIENT_ID = c.CLIENT_ID
          WHERE ro.CREATED_AT >= TRUNC(SYSDATE)-7
          GROUP BY COALESCE(c.CLIENT_NAME, TO_CHAR(ro.CLIENT_ID))
          ORDER BY cnt DESC
          FETCH FIRST 10 ROWS ONLY
        """)
        _print_table(cols, rows)
    except Exception as e:
        print("Client breakdown — skipped", repr(e))

def quick_levy_profile(cur):
    """
    Snapshot for Levy domain (if tables exist):
      - recency and totals in ATS_LEVY_DATA_LOG
      - totals by levy type (via LEVY_TYPES/LEVIES if present)
      - recurrence breakdown
    """
    _print_section("LEVIES — quick profile (recency / types / recurrence)")

    # existence check
    cols, rows = _fetchall(cur, """
        SELECT
          SUM(CASE WHEN table_name='ATS_LEVY_DATA_LOG' THEN 1 ELSE 0 END) AS HAS_LOG,
          SUM(CASE WHEN table_name='LEVIES' THEN 1 ELSE 0 END) AS HAS_LEVIES,
          SUM(CASE WHEN table_name='LEVY_TYPES' THEN 1 ELSE 0 END) AS HAS_TYPES
        FROM all_tables
        WHERE owner = :owner
          AND table_name IN ('ATS_LEVY_DATA_LOG','LEVIES','LEVY_TYPES')
    """, {"owner": OWNER})
    has_log = rows and rows[0][0] > 0
    has_levies = rows and rows[0][1] > 0
    has_types = rows and rows[0][2] > 0

    if not has_log:
        print("(ATS_LEVY_DATA_LOG not found under this owner)")
    else:
        # recency + totals
        try:
            cols, rows = _fetchall(cur, f"""
              SELECT
                (SELECT MAX(CREATED_AT) FROM {OWNER}.ATS_LEVY_DATA_LOG) AS LAST_LOG_AT,
                (SELECT COUNT(*) FROM {OWNER}.ATS_LEVY_DATA_LOG) AS TOTAL_LOG_ROWS
              FROM dual
            """)
            _print_table(cols, rows)
        except Exception as e:
            print("Basic recency/total — error", repr(e))

        # totals by type if possible (join via LEVIES/LEVY_TYPES)
        if has_levies and has_types:
            print("\n-- Totals by levy type (last 90 days)")
            try:
                cols, rows = _fetchall(cur, f"""
                  SELECT COALESCE(lt.DESCRIPTION, lt.CODE) AS LEVY_TYPE,
                         COUNT(*) AS rows_cnt
                  FROM {OWNER}.ATS_LEVY_DATA_LOG d
                  LEFT JOIN {OWNER}.LEVIES l      ON d.LEVY_ID = l.LEVY_ID
                  LEFT JOIN {OWNER}.LEVY_TYPES lt ON l.LEVY_TYPE_ID = lt.ID
                  WHERE d.TRANSACTION_DATE >= TRUNC(SYSDATE)-90
                  GROUP BY COALESCE(lt.DESCRIPTION, lt.CODE)
                  ORDER BY rows_cnt DESC
                  FETCH FIRST 10 ROWS ONLY
                """)
                _print_table(cols, rows)
            except Exception as e:
                print("Totals by type — skipped", repr(e))

        # recurrence breakdown if recurrences present
        print("\n-- Levy recurrences (counts)")
        try:
            cols, rows = _fetchall(cur, f"""
              SELECT COALESCE(lr.RECURRENCE_NAME, TO_CHAR(l.LEVY_RECURRENCE_ID)) AS RECURRENCE,
                     COUNT(*) AS rows_cnt
              FROM {OWNER}.ATS_LEVY_DATA_LOG d
              LEFT JOIN {OWNER}.LEVIES l ON d.LEVY_ID = l.LEVY_ID
              LEFT JOIN {OWNER}.LEVY_RECURRENCES lr ON l.RECURRENCE_CODE = lr.RECURRENCE_CODE
              GROUP BY COALESCE(lr.RECURRENCE_NAME, TO_CHAR(l.LEVY_RECURRENCE_ID))
              ORDER BY rows_cnt DESC
              FETCH FIRST 10 ROWS ONLY
            """)
            _print_table(cols, rows)
        except Exception as e:
            print("Recurrence breakdown — skipped", repr(e))

# ----------------------------
# Main
# ----------------------------
def main():
    argv_like = list(sys.argv[1:])
    argv_like = _maybe_wrap_stdout_with_file(argv_like)
    tables: Sequence[str] = [t.upper() for t in (argv_like if len(argv_like) > 0 else INSPECT_TABLES)]

    _print_section(f"INSPECT — OWNER={OWNER}")
    print(f"Tables: {', '.join(tables)}")

    with connect_ro() as conn, conn.cursor() as cur:
        # Family quick-profiles (best-effort; safe if tables absent)
        try:
            quick_rejections_profile(cur)
        except Exception as e:
            _print_section("Rejections quick profile — error")
            print(repr(e))

        try:
            quick_levy_profile(cur)
        except Exception as e:
            _print_section("Levy quick profile — error")
            print(repr(e))

        # Per-table deep inspection
        for t in tables:
            try:
                inspect_table(cur, t)
            except Exception as e:
                _print_section(f"ERROR while inspecting {OWNER}.{t}")
                print(repr(e))

    _print_section("Done ✅")

if __name__ == "__main__":
    main()
