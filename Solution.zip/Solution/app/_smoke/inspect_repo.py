# app/_smoke/inspect_repo.py
from __future__ import annotations

"""
Inspector for Repo domain:
  - REPO_CONTRACTS
  - REPO_CONTRACTS_CANCELLED
  - REPO_LOG

It mirrors the style of your rejections/levies inspector (env, tee-to-file, FK/index/rowcount,
label-like distributions), and adds a Repo-specific quick profile that auto-detects date/timestamp
columns to report recency & recent activity.

Usage:
  # default (all 3)
  python -m app._smoke.inspect_repo

  # custom subset
  python -m app._smoke.inspect_repo REPO_CONTRACTS REPO_LOG

  # via env
  INSPECT_TABLES="REPO_CONTRACTS,REPO_LOG" python -m app._smoke.inspect_repo

  # save output to a file
  python -m app._smoke.inspect_repo --out ./reports/inspect_repo.txt
  OUT_FILE=./reports/inspect_repo.txt python -m app._smoke.inspect_repo

Env:
  ORACLE_OWNER / ORACLE_USER (/DB_USER) / ORACLE_PASSWORD (/DB_PASSWORD) / ORACLE_DSN (/DB_DSN)
  STATEMENT_TIMEOUT_MS (default 60000)
  SAMPLE_ROWS (default 2)
  EXTRA_DIST_COLS (comma separated; added to label-like distributions)
"""

import io
import os
import sys
from contextlib import contextmanager
from typing import Iterable, List, Tuple, Dict, Sequence, Optional

from dotenv import load_dotenv
load_dotenv()

import oracledb

# ---- Connection / session env ----
OWNER = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
USER = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
PASSWORD = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")
DSN = os.getenv("ORACLE_DSN") or os.getenv("DB_DSN")
STATEMENT_TIMEOUT_MS = int(os.getenv("STATEMENT_TIMEOUT_MS", "60000"))

# ---- Tables to inspect ----
DEFAULT_TABLES = [
    "REPO_CONTRACTS",
    "REPO_CONTRACTS_CANCELLED",
    "REPO_LOG",
]
INSPECT_TABLES = [
    t.strip().upper()
    for t in (os.getenv("INSPECT_TABLES") or "").split(",")
    if t.strip()
] or DEFAULT_TABLES

SAMPLE_ROWS = int(os.getenv("SAMPLE_ROWS", "2"))
EXTRA_DIST_COLS = [c.strip().upper() for c in os.getenv("EXTRA_DIST_COLS", "").split(",") if c.strip()]

# Heuristic to find label-like columns
LABEL_LIKE_SUBSTRINGS = (
    "NAME", "CODE", "DESC", "SYMBOL", "VENUE",
    "BROKER", "CLIENT", "SIDE",
    "STATE", "STATUS", "TYPE", "REASON",
)

# ----------------------------
# Tee (save console output to file too)
# ----------------------------
class _Tee(io.TextIOBase):
    def __init__(self, stream_a, stream_b):
        self.a = stream_a
        self.b = stream_b
    def write(self, s):
        self.a.write(s); self.b.write(s); return len(s)
    def flush(self):
        self.a.flush(); self.b.flush()

def _maybe_wrap_stdout_with_file(argv_like: List[str]) -> List[str]:
    out_path = None
    if "--out" in argv_like:
        try:
            i = argv_like.index("--out")
            out_path = argv_like[i+1]
            del argv_like[i:i+2]
        except Exception:
            pass
    out_path = out_path or os.getenv("OUT_FILE")
    if out_path:
        try:
            import pathlib
            pathlib.Path(out_path).parent.mkdir(parents=True, exist_ok=True)
            f = open(out_path, "w", encoding="utf-8")
            sys.stdout = _Tee(sys.stdout, f)
            print(f"[tee] Saving a copy of this report to: {out_path}")
        except Exception as e:
            print(f"[tee] Could not open {out_path} for writing: {e}")
    return argv_like

# ----------------------------
# Helpers
# ----------------------------
def _die(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(1)

def _require_env():
    missing = [k for k, v in {
        "ORACLE_USER/DB_USER": USER,
        "ORACLE_PASSWORD/DB_PASSWORD": PASSWORD,
        "ORACLE_DSN/DB_DSN": DSN,
    }.items() if not v]
    if missing:
        _die(f"Missing connection envs: {', '.join(missing)}")

@contextmanager
def connect_ro():
    _require_env()
    conn = oracledb.connect(user=USER, password=PASSWORD, dsn=DSN)
    try:
        try:
            conn.callTimeout = STATEMENT_TIMEOUT_MS
        except Exception:
            pass
        with conn.cursor() as cur:
            cur.execute(f"alter session set current_schema = {OWNER}")
            try:
                cur.execute("alter session set optimizer_dynamic_sampling = 0")
            except Exception:
                pass
        yield conn
    finally:
        conn.close()

def _fetchall(cur, sql: str, params: dict | tuple | None = None) -> Tuple[List[str], List[tuple]]:
    cur.execute(sql, params or {})
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    return cols, rows

def _print_section(title: str):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)

def _print_table(cols: Iterable[str], rows: Iterable[Iterable], max_rows: int | None = None):
    cols = list(cols)
    rows = list(rows if max_rows is None else rows[:max_rows])
    if not rows:
        print("(no rows)")
        return
    widths = [max(len(c), *(len(str(r[i])) for r in rows if r is not None and i < len(r))) for i, c in enumerate(cols)]
    line = " | ".join(c.ljust(widths[i]) for i, c in enumerate(cols))
    print(line)
    print("-" * len(line))
    for r in rows:
        print(" | ".join(str(r[i]).ljust(widths[i]) for i in range(len(cols))))

def _label_like_columns(columns: List[Dict[str, str]]) -> List[str]:
    out = []
    for c in columns:
        cn = c["COLUMN_NAME"]
        up = cn.upper()
        if any(sub in up for sub in LABEL_LIKE_SUBSTRINGS):
            out.append(cn)
    for c in EXTRA_DIST_COLS:
        if c not in out:
            out.append(c)
    return out

def _load_columns(cur, table: str) -> List[Dict[str, str]]:
    sql_cols = """
        SELECT column_id,
               column_name,
               data_type,
               data_length,
               data_precision,
               data_scale,
               nullable
        FROM   all_tab_columns
        WHERE  owner = :owner AND table_name = :tab
        ORDER  BY column_id
    """
    _, rows = _fetchall(cur, sql_cols, {"owner": OWNER, "tab": table})
    return [
        {
            "COLUMN_ID": r[0],
            "COLUMN_NAME": r[1],
            "DATA_TYPE": r[2],
            "DATA_LENGTH": r[3],
            "DATA_PRECISION": r[4],
            "DATA_SCALE": r[5],
            "NULLABLE": r[6],
        }
        for r in rows
    ]

# ----------------------------
# Date/Timestamp auto-detect
# ----------------------------
_DATE_TYPES = ("DATE", "TIMESTAMP(6)", "TIMESTAMP", "TIMESTAMP WITH TIME ZONE", "TIMESTAMP WITH LOCAL TIME ZONE")
_DATE_NAME_HINTS = ("CREATE", "CREATED", "ENTRY", "INSERT", "EVENT", "EFFECTIVE", "TRADE", "CONTRACT", "EXEC", "LOG", "TS", "TIME", "DATE")

def pick_best_datetime_column(columns: List[Dict[str, str]]) -> Optional[str]:
    # prefer timestamp-like types; then ‘DATE’; favor names with hints
    candidates = [c for c in columns if (c["DATA_TYPE"] or "").upper() in _DATE_TYPES]
    if not candidates:
        return None
    # score by name hints
    def score(colname: str) -> int:
        up = colname.upper()
        return sum(1 for h in _DATE_NAME_HINTS if h in up)
    candidates.sort(key=lambda c: (0 if c["DATA_TYPE"].upper().startswith("TIMESTAMP") else 1, -score(c["COLUMN_NAME"])))
    return candidates[0]["COLUMN_NAME"]

# ----------------------------
# Deep per-table inspection
# ----------------------------
def inspect_table(cur, table: str):
    _print_section(f"TABLE PROFILE — {OWNER}.{table}")

    # Columns
    _print_section("Columns / Types / Nullability")
    columns = _load_columns(cur, table)
    if not columns:
        print("(no column metadata — does the table exist?)")
        return
    _print_table(
        ["COLUMN_ID", "COLUMN_NAME", "DATA_TYPE", "DATA_LENGTH", "DATA_PRECISION", "DATA_SCALE", "NULLABLE"],
        [[c[k] for k in ["COLUMN_ID", "COLUMN_NAME", "DATA_TYPE", "DATA_LENGTH", "DATA_PRECISION", "DATA_SCALE", "NULLABLE"]] for c in columns],
        None
    )

    # Sample rows
    _print_section(f"Sample rows (ROWNUM <= {SAMPLE_ROWS})")
    sql_sample = f"SELECT * FROM {OWNER}.{table} WHERE ROWNUM <= :n"
    cols, rows = _fetchall(cur, sql_sample, {"n": SAMPLE_ROWS})
    _print_table(cols, rows, None)

    # PK/UK
    _print_section("Primary / Unique Constraints")
    pk_sql = """
        SELECT ac.constraint_name, ac.constraint_type
        FROM   all_constraints ac
        WHERE  ac.owner = :owner
        AND    ac.table_name = :tab
        AND    ac.constraint_type IN ('P','U')
        ORDER  BY ac.constraint_type, ac.constraint_name
    """
    cols, rows = _fetchall(cur, pk_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # PK columns
    _print_section("Primary Key Columns")
    pk_cols_sql = """
        SELECT cols.column_name
        FROM   all_constraints cons
        JOIN   all_cons_columns cols
               ON cons.owner = cols.owner
              AND cons.constraint_name = cols.constraint_name
              AND cons.table_name = cols.table_name
        WHERE  cons.owner = :owner
        AND    cons.table_name = :tab
        AND    cons.constraint_type = 'P'
        ORDER  BY cols.position
    """
    cols, rows = _fetchall(cur, pk_cols_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Foreign Keys (outgoing)
    _print_section("Foreign Keys (outgoing)")
    fk_out_sql = """
        SELECT a.constraint_name,
               a.column_name,
               c_pk.owner      AS ref_owner,
               c_pk.table_name AS ref_table,
               b.column_name   AS ref_column
        FROM   all_cons_columns a
        JOIN   all_constraints c
               ON a.owner = c.owner
              AND a.constraint_name = c.constraint_name
        JOIN   all_constraints c_pk
               ON c.r_owner = c_pk.owner
              AND c.r_constraint_name = c_pk.constraint_name
        JOIN   all_cons_columns b
               ON c_pk.constraint_name = b.constraint_name
              AND b.position = a.position
        WHERE  c.owner = :owner
        AND    c.table_name = :tab
        AND    c.constraint_type = 'R'
        ORDER  BY a.constraint_name, a.position
    """
    cols, rows = _fetchall(cur, fk_out_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Foreign Keys (incoming)
    _print_section("Foreign Keys (incoming)")
    fk_in_sql = """
        SELECT c.owner       AS ref_owner,
               c.table_name  AS ref_table,
               acc.column_name AS ref_column,
               c.constraint_name
        FROM   all_constraints c
        JOIN   all_cons_columns acc
               ON c.owner = acc.owner
              AND c.constraint_name = acc.constraint_name
        WHERE  c.constraint_type = 'R'
        AND    (c.r_owner, c.r_constraint_name) IN (
            SELECT owner, constraint_name
            FROM   all_constraints
            WHERE  owner = :owner AND table_name = :tab AND constraint_type IN ('P','U')
        )
        ORDER BY ref_owner, ref_table, c.constraint_name, acc.position
    """
    cols, rows = _fetchall(cur, fk_in_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Indexes
    _print_section("Indexes")
    idx_sql = """
        SELECT ai.index_name,
               ai.uniqueness,
               listagg(aic.column_name, ', ') within group (order by aic.column_position) AS columns
        FROM   all_indexes ai
        JOIN   all_ind_columns aic
               ON ai.index_name = aic.index_name
              AND ai.table_owner = aic.table_owner
              AND ai.table_name  = aic.table_name
        WHERE  ai.table_owner = :owner
        AND    ai.table_name  = :tab
        GROUP  BY ai.index_name, ai.uniqueness
        ORDER  BY ai.index_name
    """
    cols, rows = _fetchall(cur, idx_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Row count
    _print_section("Row Count")
    total_sql = f"SELECT COUNT(*) AS total_rows FROM {OWNER}.{table}"
    cols, rows = _fetchall(cur, total_sql, {})
    _print_table(cols, rows)

    # Quick value distributions (label-ish)
    _print_section("Quick value distributions (top 10)")
    label_cols = _label_like_columns(columns)
    for col in label_cols:
        try:
            sql = f"""
                SELECT {col} AS value, COUNT(*) AS cnt
                FROM   {OWNER}.{table}
                GROUP  BY {col}
                ORDER  BY cnt DESC
                FETCH FIRST 10 ROWS ONLY
            """
            print(f"\n-- {col}")
            cols, rows = _fetchall(cur, sql, {})
            _print_table(cols, rows)
        except Exception as e:
            print(f"-- {col} (skipped, error: {e})")

# ----------------------------
# Repo-specific quick profile
# ----------------------------
def quick_repo_profile(cur):
    _print_section("REPO — quick profile (recency / volumes / cancellations)")

    # Which tables are present?
    cols, rows = _fetchall(cur, """
        SELECT table_name
        FROM   all_tables
        WHERE  owner = :owner
        AND    table_name IN ('REPO_CONTRACTS','REPO_CONTRACTS_CANCELLED','REPO_LOG')
        ORDER  BY table_name
    """, {"owner": OWNER})
    present = {r[0] for r in rows}

    # Helper: find a good datetime column for a table
    def _best_dt_for(table: str) -> Optional[str]:
        cols_meta = _load_columns(cur, table)
        return pick_best_datetime_column(cols_meta)

    # Recency + totals for contracts
    if "REPO_CONTRACTS" in present:
        dt_col = _best_dt_for("REPO_CONTRACTS")
        print(f"\n-- REPO_CONTRACTS recency/total (using {dt_col or 'N/A'})")
        try:
            if dt_col:
                q = f"""
                  SELECT
                    (SELECT MAX({dt_col}) FROM {OWNER}.REPO_CONTRACTS) AS LAST_AT,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_CONTRACTS) AS TOTAL_ROWS,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_CONTRACTS WHERE {dt_col} >= TRUNC(SYSDATE)-7)  AS LAST_7D,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_CONTRACTS WHERE {dt_col} >= TRUNC(SYSDATE)-30) AS LAST_30D
                  FROM dual
                """
            else:
                q = f"""
                  SELECT
                    NULL AS LAST_AT,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_CONTRACTS) AS TOTAL_ROWS
                  FROM dual
                """
            cols2, rows2 = _fetchall(cur, q, {})
            _print_table(cols2, rows2)
        except Exception as e:
            print("REPO_CONTRACTS recency — skipped", repr(e))

        # Daily counts last 14 days (if dt)
        if dt_col:
            print("\n-- REPO_CONTRACTS daily counts (last 14 days)")
            try:
                q = f"""
                  SELECT TRUNC({dt_col}) AS DAY, COUNT(*) AS CNT
                  FROM   {OWNER}.REPO_CONTRACTS
                  WHERE  {dt_col} >= TRUNC(SYSDATE)-14
                  GROUP  BY TRUNC({dt_col})
                  ORDER  BY DAY
                """
                cols2, rows2 = _fetchall(cur, q, {})
                _print_table(cols2, rows2)
            except Exception as e:
                print("Daily counts — skipped", repr(e))

    # Cancellations
    if "REPO_CONTRACTS_CANCELLED" in present:
        dt_col = _best_dt_for("REPO_CONTRACTS_CANCELLED")
        print(f"\n-- REPO_CONTRACTS_CANCELLED recency/total (using {dt_col or 'N/A'})")
        try:
            if dt_col:
                q = f"""
                  SELECT
                    (SELECT MAX({dt_col}) FROM {OWNER}.REPO_CONTRACTS_CANCELLED) AS LAST_AT,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_CONTRACTS_CANCELLED) AS TOTAL_ROWS,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_CONTRACTS_CANCELLED WHERE {dt_col} >= TRUNC(SYSDATE)-30) AS LAST_30D
                  FROM dual
                """
            else:
                q = f"""
                  SELECT
                    NULL AS LAST_AT,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_CONTRACTS_CANCELLED) AS TOTAL_ROWS
                  FROM dual
                """
            cols2, rows2 = _fetchall(cur, q, {})
            _print_table(cols2, rows2)
        except Exception as e:
            print("REPO_CONTRACTS_CANCELLED recency — skipped", repr(e))

    # Log activity
    if "REPO_LOG" in present:
        dt_col = _best_dt_for("REPO_LOG")
        print(f"\n-- REPO_LOG recency/total (using {dt_col or 'N/A'})")
        try:
            if dt_col:
                q = f"""
                  SELECT
                    (SELECT MAX({dt_col}) FROM {OWNER}.REPO_LOG) AS LAST_AT,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_LOG) AS TOTAL_ROWS,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_LOG WHERE {dt_col} >= TRUNC(SYSDATE)-7)  AS LAST_7D,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_LOG WHERE {dt_col} >= TRUNC(SYSDATE)-30) AS LAST_30D
                  FROM dual
                """
            else:
                q = f"""
                  SELECT
                    NULL AS LAST_AT,
                    (SELECT COUNT(*) FROM {OWNER}.REPO_LOG) AS TOTAL_ROWS
                  FROM dual
                """
            cols2, rows2 = _fetchall(cur, q, {})
            _print_table(cols2, rows2)
        except Exception as e:
            print("REPO_LOG recency — skipped", repr(e))

# ----------------------------
# Main
# ----------------------------
def main():
    argv_like = list(sys.argv[1:])
    argv_like = _maybe_wrap_stdout_with_file(argv_like)
    tables: Sequence[str] = [t.upper() for t in (argv_like if len(argv_like) > 0 else INSPECT_TABLES)]

    _print_section(f"INSPECT — OWNER={OWNER}")
    print(f"Tables: {', '.join(tables)}")

    with connect_ro() as conn, conn.cursor() as cur:
        try:
            quick_repo_profile(cur)
        except Exception as e:
            _print_section("Repo quick profile — error")
            print(repr(e))

        for t in tables:
            try:
                inspect_table(cur, t)
            except Exception as e:
                _print_section(f"ERROR while inspecting {OWNER}.{t}")
                print(repr(e))

    _print_section("Done ✅")

if __name__ == "__main__":
    main()
