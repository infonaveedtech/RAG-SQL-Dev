# app/_smoke/inspect_trades.py
from __future__ import annotations

import os
import sys
from contextlib import contextmanager
from typing import Iterable, List, Tuple, Dict, Sequence
from dotenv import load_dotenv

load_dotenv()

import oracledb

# --- Connection / session env ---
OWNER = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
USER = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
PASSWORD = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")
DSN = os.getenv("ORACLE_DSN") or os.getenv("DB_DSN")           # e.g. "host:1521/service"
STATEMENT_TIMEOUT_MS = int(os.getenv("STATEMENT_TIMEOUT_MS", "60000"))

# --- Which tables to inspect ---
# By default we target the TRADES family + common lookups.
DEFAULT_TABLES = [
    "TRADES",
    "CANCELLED_TRADES",
    "NEGOTIATED_TRADES",
    # lookups used for labels:
    "SYMBOLS", "EXCHANGES",
    "SUBSCRIBED_BROKERS",
    "EDS_CLIENTS",
    "USERS",
]
INSPECT_TABLES = [
    t.strip().upper()
    for t in (os.getenv("INSPECT_TABLES") or "").split(",")
    if t.strip()
] or DEFAULT_TABLES

SAMPLE_ROWS = int(os.getenv("SAMPLE_ROWS", "2"))

# Extra columns to try distributions on (comma separated)
EXTRA_DIST_COLS = [c.strip().upper() for c in os.getenv("EXTRA_DIST_COLS", "").split(",") if c.strip()]

# Heuristic to find label-like columns
LABEL_LIKE_SUBSTRINGS = ("NAME", "CODE", "DESC", "SYMBOL", "VENUE")


def _die(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(1)


def _require_env():
    missing = [k for k, v in {
        "ORACLE_USER/DB_USER": USER,
        "ORACLE_PASSWORD/DB_PASSWORD": PASSWORD,
        "ORACLE_DSN/DB_DSN": DSN,
    }.items() if not v]
    if missing:
        _die(f"Missing connection envs: {', '.join(missing)}")


@contextmanager
def connect_ro():
    """
    Create a python-oracledb Thin connection, set call timeout & CURRENT_SCHEMA
    to mimic GUI tool behavior (TOAD/SQLDev often run under a specific schema).
    """
    _require_env()
    conn = oracledb.connect(user=USER, password=PASSWORD, dsn=DSN)
    try:
        try:
            conn.callTimeout = STATEMENT_TIMEOUT_MS
        except Exception:
            pass
        with conn.cursor() as cur:
            cur.execute(f"alter session set current_schema = {OWNER}")
            # keep deterministic behavior in smoke runs
            try:
                cur.execute("alter session set optimizer_dynamic_sampling = 0")
            except Exception:
                pass
        yield conn
    finally:
        conn.close()


def _fetchall(cur, sql: str, params: dict | tuple | None = None) -> Tuple[List[str], List[tuple]]:
    cur.execute(sql, params or {})
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    return cols, rows


def _print_section(title: str):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def _print_table(cols: Iterable[str], rows: Iterable[Iterable], max_rows: int | None = None):
    cols = list(cols)
    rows = list(rows if max_rows is None else rows[:max_rows])
    if not rows:
        print("(no rows)")
        return
    widths = [max(len(c), *(len(str(r[i])) for r in rows if r is not None and i < len(r))) for i, c in enumerate(cols)]
    line = " | ".join(c.ljust(widths[i]) for i, c in enumerate(cols))
    print(line)
    print("-" * len(line))
    for r in rows:
        print(" | ".join(str(r[i]).ljust(widths[i]) for i in range(len(cols))))


def _label_like_columns(columns: List[Dict[str, str]]) -> List[str]:
    out = []
    for c in columns:
        cn = c["COLUMN_NAME"]
        up = cn.upper()
        if any(sub in up for sub in LABEL_LIKE_SUBSTRINGS):
            out.append(cn)
    # include any extra the user specified
    for c in EXTRA_DIST_COLS:
        if c not in out:
            out.append(c)
    return out


def _load_columns(cur, table: str) -> List[Dict[str, str]]:
    sql_cols = """
        SELECT column_id,
               column_name,
               data_type,
               data_length,
               data_precision,
               data_scale,
               nullable
        FROM   all_tab_columns
        WHERE  owner = :owner AND table_name = :tab
        ORDER  BY column_id
    """
    _, rows = _fetchall(cur, sql_cols, {"owner": OWNER, "tab": table})
    return [
        {
            "COLUMN_ID": r[0],
            "COLUMN_NAME": r[1],
            "DATA_TYPE": r[2],
            "DATA_LENGTH": r[3],
            "DATA_PRECISION": r[4],
            "DATA_SCALE": r[5],
            "NULLABLE": r[6],
        }
        for r in rows
    ]


def inspect_table(cur, table: str):
    _print_section(f"TABLE PROFILE — {OWNER}.{table}")

    # Columns
    _print_section("Columns / Types / Nullability")
    columns = _load_columns(cur, table)
    if not columns:
        print("(no column metadata — does the table exist?)")
        return
    _print_table(
        ["COLUMN_ID", "COLUMN_NAME", "DATA_TYPE", "DATA_LENGTH", "DATA_PRECISION", "DATA_SCALE", "NULLABLE"],
        [[c[k] for k in ["COLUMN_ID","COLUMN_NAME","DATA_TYPE","DATA_LENGTH","DATA_PRECISION","DATA_SCALE","NULLABLE"]] for c in columns],
        None
    )

    # Sample rows
    _print_section(f"Sample rows (ROWNUM <= {SAMPLE_ROWS})")
    sql_sample = f"SELECT * FROM {OWNER}.{table} WHERE ROWNUM <= :n"
    cols, rows = _fetchall(cur, sql_sample, {"n": SAMPLE_ROWS})
    _print_table(cols, rows, None)

    # Primary / Unique constraints
    _print_section("Primary / Unique Constraints")
    pk_sql = """
        SELECT ac.constraint_name, ac.constraint_type
        FROM   all_constraints ac
        WHERE  ac.owner = :owner
        AND    ac.table_name = :tab
        AND    ac.constraint_type IN ('P','U')
        ORDER  BY ac.constraint_type, ac.constraint_name
    """
    cols, rows = _fetchall(cur, pk_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Primary Key columns
    _print_section("Primary Key Columns")
    pk_cols_sql = """
        SELECT cols.column_name
        FROM   all_constraints cons
        JOIN   all_cons_columns cols
               ON cons.owner = cols.owner
              AND cons.constraint_name = cols.constraint_name
              AND cons.table_name = cols.table_name
        WHERE  cons.owner = :owner
        AND    cons.table_name = :tab
        AND    cons.constraint_type = 'P'
        ORDER  BY cols.position
    """
    cols, rows = _fetchall(cur, pk_cols_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Foreign Keys (outgoing)
    _print_section("Foreign Keys (outgoing)")
    fk_out_sql = """
        SELECT a.constraint_name,
               a.column_name,
               c_pk.owner      AS ref_owner,
               c_pk.table_name AS ref_table,
               b.column_name   AS ref_column
        FROM   all_cons_columns a
        JOIN   all_constraints c
               ON a.owner = c.owner
              AND a.constraint_name = c.constraint_name
        JOIN   all_constraints c_pk
               ON c.r_owner = c_pk.owner
              AND c.r_constraint_name = c_pk.constraint_name
        JOIN   all_cons_columns b
               ON c_pk.constraint_name = b.constraint_name
              AND b.position = a.position
        WHERE  c.owner = :owner
        AND    c.table_name = :tab
        AND    c.constraint_type = 'R'
        ORDER  BY a.constraint_name, a.position
    """
    cols, rows = _fetchall(cur, fk_out_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Foreign Keys (incoming) — who references this table?
    _print_section("Foreign Keys (incoming)")
    fk_in_sql = """
        SELECT c.owner       AS ref_owner,
               c.table_name  AS ref_table,
               acc.column_name AS ref_column,
               c.constraint_name
        FROM   all_constraints c
        JOIN   all_cons_columns acc
               ON c.owner = acc.owner
              AND c.constraint_name = acc.constraint_name
        WHERE  c.constraint_type = 'R'
        AND    (c.r_owner, c.r_constraint_name) IN (
            SELECT owner, constraint_name
            FROM   all_constraints
            WHERE  owner = :owner AND table_name = :tab AND constraint_type IN ('P','U')
        )
        ORDER BY ref_owner, ref_table, c.constraint_name, acc.position
    """
    cols, rows = _fetchall(cur, fk_in_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Indexes
    _print_section("Indexes")
    idx_sql = """
        SELECT ai.index_name,
               ai.uniqueness,
               listagg(aic.column_name, ', ') within group (order by aic.column_position) AS columns
        FROM   all_indexes ai
        JOIN   all_ind_columns aic
               ON ai.index_name = aic.index_name
              AND ai.table_owner = aic.table_owner
              AND ai.table_name  = aic.table_name
        WHERE  ai.table_owner = :owner
        AND    ai.table_name  = :tab
        GROUP  BY ai.index_name, ai.uniqueness
        ORDER  BY ai.index_name
    """
    cols, rows = _fetchall(cur, idx_sql, {"owner": OWNER, "tab": table})
    _print_table(cols, rows)

    # Row count
    _print_section("Row Count")
    total_sql = f"SELECT COUNT(*) AS total_rows FROM {OWNER}.{table}"
    cols, rows = _fetchall(cur, total_sql, {})
    _print_table(cols, rows)

    # Quick value distributions (label-ish)
    _print_section("Quick value distributions (top 10)")
    label_cols = _label_like_columns(columns)
    for col in label_cols:
        try:
            sql = f"""
                SELECT {col} AS value, COUNT(*) AS cnt
                FROM   {OWNER}.{table}
                GROUP  BY {col}
                ORDER  BY cnt DESC
                FETCH FIRST 10 ROWS ONLY
            """
            print(f"\n-- {col}")
            cols, rows = _fetchall(cur, sql, {})
            _print_table(cols, rows)
        except Exception as e:
            print(f"-- {col} (skipped, error: {e})")


def quick_trades_profile(cur):
    """
    Optional mini-profile for TRADES so we instantly understand recency and basic health.
    Runs only if TRADES exists for OWNER.
    """
    _print_section("TRADES — quick profile (recency / sides / top symbols)")
    # existence check
    cols, rows = _fetchall(cur, """
        SELECT COUNT(*) FROM all_tables WHERE owner=:owner AND table_name='TRADES'
    """, {"owner": OWNER})
    if rows and rows[0][0] == 0:
        print("(TRADES not found under this owner)")
        return

    q = f"""
    WITH base AS (
      SELECT
        TRUNC(TRADE_DATETIME,'DD') AS day,
        SIDE,
        SUM(VOLUME) AS vol,
        SUM(PRICE*VOLUME) AS notional
      FROM {OWNER}.TRADES
      WHERE TRADE_DATETIME >= TRUNC(SYSDATE) - 14
      GROUP BY TRUNC(TRADE_DATETIME,'DD'), SIDE
    )
    SELECT
      (SELECT MAX(TRADE_DATETIME) FROM {OWNER}.TRADES) AS LAST_TRADE_AT,
      (SELECT COUNT(*) FROM {OWNER}.TRADES) AS TOTAL_TRADES,
      (SELECT SUM(VOLUME) FROM {OWNER}.TRADES WHERE TRADE_DATETIME >= TRUNC(SYSDATE)-1) AS VOL_1D,
      (SELECT SUM(PRICE*VOLUME) FROM {OWNER}.TRADES WHERE TRADE_DATETIME >= TRUNC(SYSDATE)-1) AS NOTIONAL_1D
    FROM dual
    """
    cols, rows = _fetchall(cur, q, {})
    _print_table(cols, rows)

    # Side breakdown last 7d
    print("\n-- Side breakdown (last 7 days)")
    cols, rows = _fetchall(cur, f"""
      SELECT SIDE, COUNT(*) AS trades_cnt,
             SUM(VOLUME) AS volume,
             SUM(PRICE*VOLUME) AS notional
      FROM {OWNER}.TRADES
      WHERE TRADE_DATETIME >= TRUNC(SYSDATE)-7
      GROUP BY SIDE
      ORDER BY notional DESC
    """)
    _print_table(cols, rows)

    # Top symbols by notional last 7d (join to SYMBOLS if present)
    print("\n-- Top symbols by notional (last 7 days)")
    cols, rows = _fetchall(cur, f"""
      SELECT COALESCE(s.SYMBOL, TO_CHAR(t.SYMBOL_ID)) AS SYMBOL_OR_ID,
             SUM(t.PRICE*t.VOLUME) AS notional
      FROM {OWNER}.TRADES t
      LEFT JOIN {OWNER}.SYMBOLS s ON t.SYMBOL_ID = s.SYMBOL_ID
      WHERE t.TRADE_DATETIME >= TRUNC(SYSDATE)-7
      GROUP BY COALESCE(s.SYMBOL, TO_CHAR(t.SYMBOL_ID))
      ORDER BY notional DESC
      FETCH FIRST 10 ROWS ONLY
    """)
    _print_table(cols, rows)


def main():
    # Accept CLI list or ENV; defaults cover TRADES family + lookups
    tables: Sequence[str] = [t.upper() for t in (sys.argv[1:] if len(sys.argv) > 1 else INSPECT_TABLES)]

    _print_section(f"INSPECT — OWNER={OWNER}")
    print(f"Tables: {', '.join(tables)}")

    with connect_ro() as conn, conn.cursor() as cur:
        # Optional quick health profile for TRADES
        try:
            quick_trades_profile(cur)
        except Exception as e:
            _print_section("TRADES quick profile — error")
            print(repr(e))

        for t in tables:
            try:
                inspect_table(cur, t)
            except Exception as e:
                _print_section(f"ERROR while inspecting {OWNER}.{t}")
                print(repr(e))

    _print_section("Done ✅")


if __name__ == "__main__":
    main()
