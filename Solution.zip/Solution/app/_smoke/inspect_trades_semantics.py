# app/_smoke/inspect_trades_semantics.py
from __future__ import annotations
import os, sys
from contextlib import contextmanager
from typing import List, Tuple, Iterable, Sequence, Optional, Dict
from dotenv import load_dotenv

load_dotenv()
import oracledb

OWNER   = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
USER    = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
PWD     = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")
DSN     = os.getenv("ORACLE_DSN") or os.getenv("DB_DSN")
TIMEOUT = int(os.getenv("STATEMENT_TIMEOUT_MS", "60000"))
SAMPLE_ROWS = int(os.getenv("SAMPLE_ROWS", "3"))

# ---------- utils ----------
def _die(msg: str): print(f"[ERROR] {msg}", file=sys.stderr); sys.exit(1)
def _need_env():
    missing = [k for k, v in {
        "ORACLE_USER/DB_USER": USER,
        "ORACLE_PASSWORD/DB_PASSWORD": PWD,
        "ORACLE_DSN/DB_DSN": DSN,
    }.items() if not v]
    if missing: _die(f"Missing connection envs: {', '.join(missing)}")

@contextmanager
def connect_ro():
    _need_env()
    conn = oracledb.connect(user=USER, password=PWD, dsn=DSN)
    try:
        try: conn.callTimeout = TIMEOUT
        except Exception: pass
        with conn.cursor() as c:
            c.execute(f"alter session set current_schema = {OWNER}")
            try: c.execute("alter session set optimizer_dynamic_sampling = 0")
            except Exception: pass
        yield conn
    finally:
        conn.close()

def _fetch(cur, sql: str, params: dict|tuple|None=None) -> Tuple[List[str], List[tuple]]:
    cur.execute(sql, params or {})
    cols = [d[0] for d in (cur.description or [])]
    rows = cur.fetchall() if cur.description else []
    return cols, rows

def _hdr(title: str):
    print("\n" + "="*98); print(title); print("="*98)

def _tbl(cols: Iterable[str], rows: Iterable[Iterable], limit: int|None=None):
    cols = list(cols); rows = list(rows if limit is None else rows[:limit])
    if not rows: print("(no rows)"); return
    widths = [max(len(cols[i]), *(len(str(r[i])) for r in rows)) for i in range(len(cols))]
    line = " | ".join(cols[i].ljust(widths[i]) for i in range(len(cols)))
    print(line); print("-" * len(line))
    for r in rows:
        print(" | ".join(str(r[i]).ljust(widths[i]) for i in range(len(cols))))

def _exists(cur, owner: str, table: str) -> bool:
    _, rows = _fetch(cur, "select count(*) from all_tables where owner=:o and table_name=:t",
                     {"o": owner, "t": table})
    return rows and rows[0][0] > 0

def _table_columns(cur, owner: str, table: str) -> List[str]:
    cols, rows = _fetch(cur, """
        SELECT column_name FROM all_tab_columns
        WHERE owner=:o AND table_name=:t
        ORDER BY column_id
    """, {"o": owner, "t": table})
    return [r[0] for r in rows]

def _pick_label_column(cur, owner: str, table: str,
                       candidates: Sequence[str]) -> Optional[str]:
    cols = set(_table_columns(cur, owner, table))
    for c in candidates:
        if c in cols:
            return c
    # last resort: pick the first NVARCHAR2/VARCHAR2-ish column
    cands_sql = """
      SELECT column_name
      FROM all_tab_columns
      WHERE owner=:o AND table_name=:t
        AND data_type IN ('NVARCHAR2','VARCHAR2')
      ORDER BY column_id
    """
    _, rows = _fetch(cur, cands_sql, {"o": owner, "t": table})
    return rows[0][0] if rows else None

# ---------- inspections ----------
def sanity_counts(cur):
    _hdr("Row counts — core + lookups")
    for t in ["TRADES","CANCELLED_TRADES","NEGOTIATED_TRADES",
              "SYMBOLS","SYMBOL_TYPES","SYMBOL_MARKETS",
              "EXCHANGES","SUBSCRIBED_BROKERS","EDS_CLIENTS","USERS",
              "TRADE_STATES","SETTLEMENT_TYPES","ORDERS"]:
        if _exists(cur, OWNER, t):
            cols, rows = _fetch(cur, f"select '{t}' as table_name, count(*) as cnt from {OWNER}.{t}")
            _tbl(cols, rows)
        else:
            print(f"{t}: (not found)")

def soft_join_checks(cur):
    _hdr("Soft-join validation (multiple heuristics)")

    # 1) CANCELLED_TRADES -> TRADES
    if _exists(cur, OWNER, "CANCELLED_TRADES"):
        # a) by TICKET_NO
        cols, rows = _fetch(cur, f"""
            WITH ct AS (SELECT TICKET_NO, EXCHANGE_ID, BUYER_ORDER_NO, SELLER_ORDER_NO FROM {OWNER}.CANCELLED_TRADES)
            SELECT
              (SELECT COUNT(*) FROM ct) AS ct_total,
              (SELECT COUNT(*) FROM ct c JOIN {OWNER}.TRADES t ON t.TICKET_NO = c.TICKET_NO) AS match_ticket,
              (SELECT COUNT(*) FROM ct c JOIN {OWNER}.TRADES t ON t.TICKET_NO = c.TICKET_NO AND t.EXCHANGE_ID=c.EXCHANGE_ID) AS match_ticket_xch
            FROM dual
        """)
        print("CANCELLED_TRADES → TRADES by TICKET_NO[/EXCHANGE_ID]")
        _tbl(cols, rows)

        # b) by ORDER pairs (BUYER/SELLER)
        cols, rows = _fetch(cur, f"""
            WITH ct AS (SELECT EXCHANGE_ID, BUYER_ORDER_NO, SELLER_ORDER_NO FROM {OWNER}.CANCELLED_TRADES),
                 tt AS (SELECT EXCHANGE_ID, BUYER_ORDER_NO, SELLER_ORDER_NO FROM {OWNER}.TRADES)
            SELECT
              (SELECT COUNT(*) FROM ct) AS ct_total,
              (SELECT COUNT(*) FROM ct c JOIN tt t
                ON t.EXCHANGE_ID=c.EXCHANGE_ID
               AND t.BUYER_ORDER_NO=c.BUYER_ORDER_NO
               AND t.SELLER_ORDER_NO=c.SELLER_ORDER_NO) AS match_order_pair
            FROM dual
        """)
        print("CANCELLED_TRADES → TRADES by (BUYER_ORDER_NO, SELLER_ORDER_NO, EXCHANGE_ID)")
        _tbl(cols, rows)

    # 2) NEGOTIATED_TRADES -> ORDERS (expected) and -> TRADES (possible)
    if _exists(cur, OWNER, "NEGOTIATED_TRADES"):
        if _exists(cur, OWNER, "ORDERS"):
            cols, rows = _fetch(cur, f"""
                WITH nt AS (SELECT ORDER_NO, COUNTER_ORDER_NO FROM {OWNER}.NEGOTIATED_TRADES)
                SELECT
                  (SELECT COUNT(*) FROM nt) AS nt_total,
                  (SELECT COUNT(*) FROM nt n JOIN {OWNER}.ORDERS o ON o.ORDER_NO = n.ORDER_NO) AS match_order,
                  (SELECT COUNT(*) FROM nt n JOIN {OWNER}.ORDERS o ON o.ORDER_NO = n.COUNTER_ORDER_NO) AS match_counter
                FROM dual
            """)
            print("NEGOTIATED_TRADES → ORDERS by ORDER_NO / COUNTER_ORDER_NO")
            _tbl(cols, rows)

        # try mapping negotiations to the eventual trade via the component order numbers
        cols, rows = _fetch(cur, f"""
            WITH nt AS (SELECT ORDER_NO, COUNTER_ORDER_NO, EXCHANGE_ID FROM {OWNER}.NEGOTIATED_TRADES),
                 tt AS (SELECT BUYER_ORDER_NO, SELLER_ORDER_NO, EXCHANGE_ID FROM {OWNER}.TRADES)
            SELECT
              (SELECT COUNT(*) FROM nt) AS nt_total,
              (SELECT COUNT(*) FROM nt n JOIN tt t
                 ON t.EXCHANGE_ID=n.EXCHANGE_ID
                AND t.BUYER_ORDER_NO = n.ORDER_NO) AS match_nt_to_trade_buyer,
              (SELECT COUNT(*) FROM nt n JOIN tt t
                 ON t.EXCHANGE_ID=n.EXCHANGE_ID
                AND t.SELLER_ORDER_NO = n.ORDER_NO) AS match_nt_to_trade_seller,
              (SELECT COUNT(*) FROM nt n JOIN tt t
                 ON t.EXCHANGE_ID=n.EXCHANGE_ID
                AND t.BUYER_ORDER_NO = n.COUNTER_ORDER_NO) AS match_counter_to_trade_buyer,
              (SELECT COUNT(*) FROM nt n JOIN tt t
                 ON t.EXCHANGE_ID=n.EXCHANGE_ID
                AND t.SELLER_ORDER_NO = n.COUNTER_ORDER_NO) AS match_counter_to_trade_seller
            FROM dual
        """)
        print("NEGOTIATED_TRADES → TRADES by mapping ORDER_NO/COUNTER_ORDER_NO to trade’s BUYER/SELLER_ORDER_NO")
        _tbl(cols, rows)

    # 3) TRADES -> SYMBOL_MARKETS tri-key
    if _exists(cur, OWNER, "SYMBOL_MARKETS"):
        cols, rows = _fetch(cur, f"""
            SELECT
              (SELECT COUNT(*) FROM {OWNER}.TRADES) AS trades_total,
              (SELECT COUNT(*) 
                 FROM {OWNER}.TRADES t
                 JOIN {OWNER}.SYMBOL_MARKETS sm
                   ON sm.SYMBOL_ID=t.SYMBOL_ID AND sm.MARKET_ID=t.MARKET_ID AND sm.EXCHANGE_ID=t.EXCHANGE_ID) AS tri_key_match,
              (SELECT COUNT(*) 
                 FROM {OWNER}.TRADES t
                 LEFT JOIN {OWNER}.SYMBOL_MARKETS sm
                   ON sm.SYMBOL_ID=t.SYMBOL_ID AND sm.MARKET_ID=t.MARKET_ID AND sm.EXCHANGE_ID=t.EXCHANGE_ID
                WHERE sm.SYMBOL_ID IS NULL) AS tri_key_unmatched
            FROM dual
        """)
        print("TRADES → SYMBOL_MARKETS by (SYMBOL_ID, MARKET_ID, EXCHANGE_ID)")
        _tbl(cols, rows)

def decode_labels(cur):
    _hdr("Label decoding — quick samples (TRADES)")
    cols, rows = _fetch(cur, f"""
        SELECT *
        FROM (
          SELECT
            t.TICKET_NO,
            t.ENTRY_DATETIME,
            s.SYMBOL,
            e.EXCHANGE_CODE,
            bb.BROKER_NAME AS buyer_broker,
            sb.BROKER_NAME AS seller_broker,
            bc.NAME        AS buyer_client,
            sc.NAME        AS seller_client,
            bu.COMPLETE_NAME AS buyer_user,
            su.COMPLETE_NAME AS seller_user
          FROM {OWNER}.TRADES t
          LEFT JOIN {OWNER}.SYMBOLS s ON s.SYMBOL_ID = t.SYMBOL_ID
          LEFT JOIN {OWNER}.EXCHANGES e ON e.EXCHANGE_ID = t.EXCHANGE_ID
          LEFT JOIN {OWNER}.SUBSCRIBED_BROKERS bb ON bb.BROKER_ID = t.BUYER_BROKER_ID
          LEFT JOIN {OWNER}.SUBSCRIBED_BROKERS sb ON sb.BROKER_ID = t.SELLER_BROKER_ID
          LEFT JOIN {OWNER}.EDS_CLIENTS bc ON bc.CLIENT_ID = t.BUYER_CLIENT_ID
          LEFT JOIN {OWNER}.EDS_CLIENTS sc ON sc.CLIENT_ID = t.SELLER_CLIENT_ID
          LEFT JOIN {OWNER}.USERS bu ON bu.USER_ID = t.BUYER_USER_ID
          LEFT JOIN {OWNER}.USERS su ON su.USER_ID = t.SELLER_USER_ID
          WHERE ROWNUM <= :n
        )
    """, {"n": SAMPLE_ROWS})
    _tbl(cols, rows)

def type_and_state_decoding(cur):
    _hdr("Instrument type & trade state decoding (adaptive labels)")

    # SYMBOL_TYPES
    if _exists(cur, OWNER, "SYMBOL_TYPES"):
        label_col = _pick_label_column(cur, OWNER, "SYMBOL_TYPES",
                                       ["SYMBOL_TYPE","NAME","TYPE","DESCRIPTION","SYMBOL_TYPE_NAME"])
        sel_label = label_col or "'<no_label>'"
        cols, rows = _fetch(cur, f"""
          SELECT st.SYMBOL_TYPE_ID, {sel_label} AS SYMBOL_TYPE, COUNT(*) AS trades_cnt
          FROM {OWNER}.TRADES t
          JOIN {OWNER}.SYMBOLS s  ON s.SYMBOL_ID = t.SYMBOL_ID
          JOIN {OWNER}.SYMBOL_TYPES st ON st.SYMBOL_TYPE_ID = s.SYMBOL_TYPE_ID
          GROUP BY st.SYMBOL_TYPE_ID, {sel_label}
          ORDER BY trades_cnt DESC
        """)
        _tbl(cols, rows)
    else:
        print("(SYMBOL_TYPES not found)")

    # TRADE_STATES
    if _exists(cur, OWNER, "TRADE_STATES"):
        label_col = _pick_label_column(cur, OWNER, "TRADE_STATES",
                                       ["STATE_NAME","NAME","DESCRIPTION","STATE_DESC","LABEL","TITLE"])
        sel_label = label_col or "'<no_label>'"
        cols, rows = _fetch(cur, f"""
          SELECT ts.STATE_ID, {sel_label} AS STATE_LABEL, COUNT(*) AS trades_cnt
          FROM {OWNER}.TRADES t
          JOIN {OWNER}.TRADE_STATES ts ON ts.STATE_ID = t.STATE_ID
          GROUP BY ts.STATE_ID, {sel_label}
          ORDER BY trades_cnt DESC
        """)
        _tbl(cols, rows)
    else:
        print("(TRADE_STATES not found)")

def settlement_semantics(cur):
    _hdr("Settlement semantics & price fields")

    cols, rows = _fetch(cur, f"""
      SELECT
        COUNT(*) AS trades_total,
        SUM(CASE WHEN DIRTY_PRICE IS NOT NULL THEN 1 ELSE 0 END) AS dirty_price_n,
        AVG(CASE WHEN DIRTY_PRICE IS NOT NULL THEN DIRTY_PRICE END) AS dirty_price_avg,
        SUM(CASE WHEN REPURCHASE_PRICE IS NOT NULL THEN 1 ELSE 0 END) AS repurchase_n,
        AVG(CASE WHEN REPURCHASE_PRICE IS NOT NULL THEN REPURCHASE_PRICE END) AS repurchase_avg,
        SUM(CASE WHEN SETTLEMENT_AMOUNT IS NOT NULL THEN 1 ELSE 0 END) AS settlement_amt_n,
        AVG(CASE WHEN SETTLEMENT_AMOUNT IS NOT NULL THEN SETTLEMENT_AMOUNT END) AS settlement_amt_avg
      FROM {OWNER}.TRADES
    """)
    _tbl(cols, rows)

    if _exists(cur, OWNER, "SETTLEMENT_TYPES"):
        label_col = _pick_label_column(cur, OWNER, "SETTLEMENT_TYPES",
                                       ["SETTLEMENT_TYPE","NAME","DESCRIPTION","TYPE","LABEL","TITLE"])
        sel_label = label_col or "'<no_label>'"
        cols, rows = _fetch(cur, f"""
          SELECT st.SETTLEMENT_TYPE_ID, {sel_label} AS SETTLEMENT_TYPE,
                 COUNT(*) AS trades_cnt,
                 SUM(CASE WHEN t.DIRTY_PRICE IS NOT NULL THEN 1 ELSE 0 END) AS dirty_n
          FROM {OWNER}.TRADES t
          JOIN {OWNER}.SETTLEMENT_TYPES st ON st.SETTLEMENT_TYPE_ID = t.SETTLEMENT_TYPE_ID
          GROUP BY st.SETTLEMENT_TYPE_ID, {sel_label}
          ORDER BY trades_cnt DESC
        """)
        _tbl(cols, rows)
    else:
        print("(SETTLEMENT_TYPES not found)")

def remaining_volume_health(cur):
    _hdr("Remaining volume health (ideally zero after trade)")

    cols, rows = _fetch(cur, f"""
      SELECT
        SUM(CASE WHEN NVL(BUYER_REMAINING_VOLUME,0)  <> 0 THEN 1 ELSE 0 END) AS buyer_rem_nonzero,
        SUM(CASE WHEN NVL(SELLER_REMAINING_VOLUME,0) <> 0 THEN 1 ELSE 0 END) AS seller_rem_nonzero,
        COUNT(*) AS trades_total
      FROM {OWNER}.TRADES
    """)
    _tbl(cols, rows)

    print("\n-- sample rows where remaining volume is nonzero (up to 5)")
    cols, rows = _fetch(cur, f"""
      SELECT TICKET_NO, ENTRY_DATETIME, PRICE, VOLUME,
             BUYER_REMAINING_VOLUME, SELLER_REMAINING_VOLUME
      FROM {OWNER}.TRADES
      WHERE NVL(BUYER_REMAINING_VOLUME,0) <> 0 OR NVL(SELLER_REMAINING_VOLUME,0) <> 0
      FETCH FIRST 5 ROWS ONLY
    """)
    _tbl(cols, rows)

def accrued_yield_by_type(cur):
    _hdr("Accrued & Yield prevalence by symbol type")

    if not _exists(cur, OWNER, "SYMBOL_TYPES"):
        print("(SYMBOL_TYPES not found; skipping)"); return

    label_col = _pick_label_column(cur, OWNER, "SYMBOL_TYPES",
                                   ["SYMBOL_TYPE","NAME","TYPE","DESCRIPTION","SYMBOL_TYPE_NAME"])
    sel_label = label_col or "'<no_label>'"
    cols, rows = _fetch(cur, f"""
      SELECT {sel_label} AS SYMBOL_TYPE,
             COUNT(*) AS trades_cnt,
             SUM(CASE WHEN t.ACCRUED_PROFIT IS NOT NULL THEN 1 ELSE 0 END) AS accrued_n,
             SUM(CASE WHEN t.YIELD          IS NOT NULL THEN 1 ELSE 0 END) AS yield_n,
             AVG(CASE WHEN t.YIELD          IS NOT NULL THEN t.YIELD END)   AS avg_yield
      FROM {OWNER}.TRADES t
      JOIN {OWNER}.SYMBOLS s  ON s.SYMBOL_ID = t.SYMBOL_ID
      JOIN {OWNER}.SYMBOL_TYPES st ON st.SYMBOL_TYPE_ID = s.SYMBOL_TYPE_ID
      GROUP BY {sel_label}
      ORDER BY trades_cnt DESC
    """)
    _tbl(cols, rows)

def notional_and_price_checks(cur):
    _hdr("Notional & price sanity")

    cols, rows = _fetch(cur, f"""
      SELECT
        TRUNC(ENTRY_DATETIME,'DD') AS trade_day,
        SUM(VOLUME) AS volume,
        SUM(PRICE*VOLUME) AS notional,
        AVG(PRICE) AS avg_price
      FROM {OWNER}.TRADES
      WHERE ENTRY_DATETIME >= TRUNC(SYSDATE) - 7
      GROUP BY TRUNC(ENTRY_DATETIME,'DD')
      ORDER BY trade_day
    """)
    _tbl(cols, rows)

    print("\n-- sample PRICE vs DIRTY_PRICE where both present (up to 10)")
    cols, rows = _fetch(cur, f"""
      SELECT TICKET_NO, PRICE, DIRTY_PRICE
      FROM {OWNER}.TRADES
      WHERE DIRTY_PRICE IS NOT NULL AND PRICE IS NOT NULL
      FETCH FIRST 10 ROWS ONLY
    """)
    _tbl(cols, rows)

def main():
    _hdr(f"TRADES semantics & soft-join inspection — OWNER={OWNER}")
    with connect_ro() as conn, conn.cursor() as cur:
        sanity_counts(cur)
        soft_join_checks(cur)
        decode_labels(cur)
        type_and_state_decoding(cur)
        settlement_semantics(cur)
        remaining_volume_health(cur)
        accrued_yield_by_type(cur)
        notional_and_price_checks(cur)
    _hdr("Done ✅")

if __name__ == "__main__":
    main()
