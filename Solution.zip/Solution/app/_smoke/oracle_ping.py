"""
Minimal connectivity + capability check for Oracle.

Reads env vars:
  ORACLE_DSN, ORACLE_USER, ORACLE_PASSWORD, ORACLE_OWNER
Also uses:
  RESULT_ROW_LIMIT (optional; defaults 200)
"""

from __future__ import annotations
import os
import sys
import oracledb

def env(name: str, default: str | None = None) -> str:
    v = os.getenv(name, default)
    if not v:
        print(f"Missing env: {name}", file=sys.stderr)
        sys.exit(1)
    return v

def main() -> None:
    dsn = env("ORACLE_DSN")
    user = env("ORACLE_USER")
    pwd = env("ORACLE_PASSWORD")
    owner = env("ORACLE_OWNER")
    limit = int(os.getenv("RESULT_ROW_LIMIT", "200"))

    # Use Thin mode (no Instant Client)
    # oracledb.init_oracle_client(lib_dir=None)

    print("→ Connecting (Thin mode)…")
    with oracledb.connect(user=user, password=pwd, dsn=dsn, mode=oracledb.AUTH_MODE_DEFAULT) as conn:
        with conn.cursor() as cur:
            # Basic server info
            cur.execute("select * from v$version")
            version_lines = [row[0] for row in cur.fetchmany(3)]
            print("Oracle version:")
            for line in version_lines:
                print("  ", line)

            # Set current schema so we don’t have to prefix OWNER.TABLE
            cur.execute(f"alter session set current_schema = {owner}")
            cur.execute("select sys_context('USERENV','CURRENT_SCHEMA') from dual")
            print("Current schema:", cur.fetchone()[0])

            # Capability check: FETCH FIRST … ROWS ONLY (12c+)
            try:
                cur.execute(f"select 1 as one from dual fetch first {limit} rows only")
                _ = cur.fetchone()
                print("FETCH FIRST … ROWS ONLY: ✅ supported")
            except Exception as e:
                print("FETCH FIRST … ROWS ONLY: ❌", e)

            # Harmless dictionary query scoped to OWNER
            cur.execute("""
                select table_name, num_rows
                from all_tables
                where owner = :owner
                order by table_name
                fetch first 5 rows only
            """, dict(owner=owner))
            rows = cur.fetchall()
            print(f"Sample tables under {owner}:")
            for t, n in rows:
                print(f"  {t:30s}  approx_rows={n}")

            # Optional: ensure read-only privilege really applies
            try:
                cur.execute("create table __sqlbot_tmp(n number)")
                print("WARNING: This user can CREATE objects (not read-only) ❌")
                # Cleanup in case it created:
                try:
                    cur.execute("drop table __sqlbot_tmp purge")
                except Exception:
                    pass
            except Exception:
                print("DML/DDL attempt blocked as expected: ✅ (read-only likely)")

    print("Smoke test complete ✅")

if __name__ == "__main__":
    main()
