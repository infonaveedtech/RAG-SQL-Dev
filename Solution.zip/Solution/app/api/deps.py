# app/api/deps.py
import os
from typing import Literal, Tuple, Optional , List, Dict
from functools import lru_cache


# We import oracledb lazily in try_db_ping to keep /health fast without db=1
OWNER_ENV = "ORACLE_OWNER"

def get_owner() -> str:
    """
    Returns the configured Oracle owner (schema), defaulting to 'ATS'.
    """
    return (os.getenv(OWNER_ENV) or "ATS").upper()

def try_db_ping() -> Tuple[Literal["up","down"], Optional[str]]:
    """
    Attempts a very short DB check by running 'SELECT 1 FROM DUAL'.
    Returns:
        ("up", None) on success
        ("down", reason) on failure (reason is a short, sanitized string)
    Notes:
        - We purposely don't log credentials or DSNs.
        - If oracledb isn't installed or env is missing, we return 'down'.
    """
    try:
        import oracledb  # local import keeps cold-start fast if DB check isn't requested
    except Exception as e:
        return "down", "oracledb-not-installed"

    user = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
    pwd = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")
    dsn = os.getenv("ORACLE_DSN")
    if not (user and pwd and dsn):
        return "down", "db-env-missing"

    try:
        # Thin mode default; we keep it simple and fast.
        with oracledb.connect(user=user, password=pwd, dsn=dsn) as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 FROM DUAL")
                cur.fetchone()
        return "up", None
    except Exception as e:
        # Don’t leak internals; map to a short label (ORA/DPI errors are common)
        msg = str(e)
        reason = "db-unauthorized" if "ORA-01017" in msg else \
                 "db-unreachable" if "DPI-" in msg or "ORA-12154" in msg else \
                 "db-error"
        return "down", reason

# -------- owner & allowlist helpers --------

def get_owner_aliases() -> List[str]:
    """
    ORACLE_OWNER_ALIASES: comma- or space-separated, e.g. 'DNS INDICES'
    """
    raw = os.getenv("ORACLE_OWNER_ALIASES", "")
    # accept commas or spaces
    parts = [p.strip() for chunk in raw.split(",") for p in chunk.split() if p.strip()]
    # Normalize to UPPER and drop dupes while keeping order
    seen, out = set(), []
    for p in parts:
        up = p.upper()
        if up not in seen:
            seen.add(up); out.append(up)
    return out

def get_allowlist() -> List[str]:
    """
    Prefer SAFETY_ALLOWED_TABLES (space/comma separated).
    Fall back to ALLOWED_TABLES for back-compat.
    Normalize to UPPER and owner-qualify if not already.
    """
    raw = os.getenv("SAFETY_ALLOWED_TABLES") or os.getenv("ALLOWED_TABLES") or ""
    parts = [p.strip() for chunk in raw.split(",") for p in chunk.split() if p.strip()]
    owner = get_owner()
    out = []
    for p in parts:
        up = p.upper()
        if "." not in up:
            up = f"{owner}.{up}"
        out.append(up)
    # dedupe, keep order
    seen, uniq = set(), []
    for t in out:
        if t not in seen:
            seen.add(t); uniq.append(t)
    return uniq

# -------- schema card loading (reuse your prompting module) --------

@lru_cache(maxsize=1)
def load_schema_tables() -> List[Dict[str, List[str]]]:
    """
    Returns a list of {"name": "<OWNER.TABLE>", "columns": ["COL1","COL2",...]}.
    Uses your existing schema card loader from app/services/prompting.py.
    If anything fails, returns an empty list (endpoint should still work).
    """
    try:
        from app.services.prompting import load_schema_card  # your loader
    except Exception:
        return []

    try:
        card = load_schema_card()  # expect something like { "tables": {...} } OR similar
    except Exception:
        return []

    # Normalize into a list of {name, columns}
    tables = []
    # Support either dict or list depending on your loader’s format
    if isinstance(card, dict) and "tables" in card:
        items = card["tables"].items() if isinstance(card["tables"], dict) else card["tables"]
    else:
        items = card.items() if isinstance(card, dict) else []

    owner = get_owner()
    for entry in items:
        # entry could be ("ATS.MARKETS", ["COL.."]) OR {"name":..., "columns":[...]}
        if isinstance(entry, tuple):
            tname, cols = entry
        else:
            tname = entry.get("name")
            cols = entry.get("columns", [])
        if not tname:
            continue
        upname = tname.upper()
        if "." not in upname:
            upname = f"{owner}.{upname}"
        tables.append({"name": upname, "columns": [c.upper() for c in cols]})
    # sort for stable output
    tables.sort(key=lambda x: x["name"])
    return tables
