# app/api/dto/query_models.py
from typing import Optional, List, Any, Dict
from pydantic import BaseModel, Field

class Claim(BaseModel):
    role: str = Field(default="Trader")         # future RLS hook
    trader_id: Optional[str] = None
    broker_id: Optional[str] = None

class QueryRequest(BaseModel):
    question: str
    strategy: Optional[str] = Field(default=None, description="auto|gemini| gpt-oss")
    claim: Optional[Claim] = None
    preview_row_limit: Optional[int] = Field(default=None, ge=1, le=1000)

class GuardReport(BaseModel):
    safety: str
    schema_check: str
    labels: str
    labels_hint: Optional[str] = None


class Preview(BaseModel):
    columns: List[str]
    rows: List[List[Any]]

class QueryResponse(BaseModel):
    sql: str
    guards: GuardReport
    preview: Preview

class ErrorResponse(BaseModel):
    sql: Optional[str] = None
    guards: Optional[GuardReport] = None
    error: Dict[str, Any]


class SqlValidateRequest(BaseModel):
    sql: str

class Issue(BaseModel):
    type: str
    message: str

class SqlValidateResponse(BaseModel):
    ok: bool
    sql_normalized: Optional[str] = None
    issues: List[Issue] = []
    
# --- NEW: raw SQL execute DTOs ---

class SqlExecuteRequest(BaseModel):
    sql: str
    row_limit: Optional[int] = Field(default=None, ge=1, le=200000)

class SqlExecuteResponse(BaseModel):
    columns: List[str]
    rows: List[List[Any]]
    row_limit_applied: int
    guards: GuardReport
    

# --- NEW: export DTOs ---

class ExportRequest(BaseModel):
    sql: str
    format: str = Field(description="csv|html|pdf")
    title: Optional[str] = None
    row_limit: Optional[int] = Field(default=None, ge=1, le=200000)
