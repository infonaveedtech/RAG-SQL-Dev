# app/api/main.py
from fastapi import FastAPI
from .routers import health, schema, query

from dotenv import load_dotenv
load_dotenv()  # loads .env from the current working directory

def create_app() -> FastAPI:
    """
    App factory so tests can import a fresh instance.
    We mount all v1 routers under /api/v1.
    """
    app = FastAPI(title="ATS/DNS API", version="v1")
    app.include_router(health.router, prefix="/api/v1")
    app.include_router(schema.router, prefix="/api/v1")
    app.include_router(query.router, prefix="/api/v1")
    return app

# Uvicorn entrypoint: uvicorn app.api.main:app --reload --port 8080
app = create_app()
