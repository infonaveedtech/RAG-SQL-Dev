# app/api/routers/health.py
from fastapi import APIRouter, Query, Response, status
from app.api.deps import get_owner, try_db_ping

router = APIRouter(tags=["health"])

@router.get("/health")
def get_health(db: int = Query(default=0, ge=0, le=1)):
    """
    Liveness probe for the service.
    - If db=0 (default): quick check; no DB access.
    - If db=1       : also attempts a short Oracle ping.

    Returns JSON:
    {
      "status": "ok",
      "db": "skipped" | "up" | "down",
      "owner": "<ORACLE_OWNER or ATS>",
      "version": "v1"
    }

    On DB failure when db=1, returns HTTP 503 with db:"down".
    """
    owner = get_owner()
    if db == 0:
        return {"status": "ok", "db": "skipped", "owner": owner, "version": "v1"}

    db_status, reason = try_db_ping()
    if db_status == "up":
        return {"status": "ok", "db": "up", "owner": owner, "version": "v1"}

    # db down → 503 to help k8s/ALB readiness checks
    return Response(
        content=(f'{{"status":"ok","db":"down","owner":"{owner}","version":"v1"}}'),
        media_type="application/json",
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
    )
