# app/api/routers/query.py
from fastapi import APIRouter, HTTPException
from app.pipeline.pipeline import run_nl_query
from ..dto.query_models import (
    QueryRequest, QueryResponse, ErrorResponse, GuardReport, Preview,
    SqlValidateRequest, SqlValidateResponse, Issue,
    SqlExecuteRequest, SqlExecuteResponse, ExportRequest
)
from ..deps import get_owner
import os

router = APIRouter(tags=["query"])
@router.post("/query", response_model=QueryResponse, responses={400: {"model": ErrorResponse}})
def post_query(payload: QueryRequest):
    try:
        res = run_nl_query(
            question=payload.question,
            strategy=(payload.strategy or os.getenv("MODEL_STRATEGY", "gemini")),
            preview_row_limit=payload.preview_row_limit,
        )
    except Exception as e:
        # mirror current error shape
        raise HTTPException(status_code=400, detail={
            "error": {"code": "GENERATION_ERROR", "message": str(e)}
        })

    # Shape response like before
    return QueryResponse(
        sql=res.sql,
        guards=GuardReport(
            safety=res.guards.safety,
            schema_check=res.guards.schema_check,
            labels=res.guards.labels,
            labels_hint=res.guards.labels_hint,
        ),
        preview=Preview(columns=res.preview.columns, rows=res.preview.rows),
    )


from app.pipeline.pipeline import validate_sql

@router.post("/sql/validate", response_model=SqlValidateResponse)
def sql_validate(payload: SqlValidateRequest):
    res = validate_sql(payload.sql)
    return SqlValidateResponse(
        ok=res.ok,
        sql_normalized=res.sql_normalized,
        issues=[Issue(type=i.type, message=i.message) for i in res.issues],
    )


from app.pipeline.pipeline import execute_sql

@router.post("/sql/execute", response_model=SqlExecuteResponse)
def sql_execute(payload: SqlExecuteRequest):
    try:
        res = execute_sql(payload.sql, row_limit=payload.row_limit)
    except Exception as e:
        raise HTTPException(status_code=400, detail={
            "sql": (payload.sql or "").strip(),
            "error": {"code": "EXECUTION_ERROR", "message": str(e)}
        })

    return SqlExecuteResponse(
        columns=res.columns,
        rows=res.rows,
        row_limit_applied=res.row_limit_applied,
        guards=GuardReport(
            safety=res.guards.safety,
            schema_check=res.guards.schema_check,
            labels=res.guards.labels,
            labels_hint=res.guards.labels_hint,
        ),
    )


from fastapi.responses import StreamingResponse
from io import BytesIO, StringIO
import csv
import datetime

from app.pipeline.pipeline import export_sql

@router.post("/exports")
def export_result(payload: ExportRequest):
    fmt = (payload.format or "").lower()
    if fmt not in {"csv", "html", "pdf"}:
        raise HTTPException(status_code=400, detail={"error": {"code": "INPUT", "message": "format must be csv|html|pdf"}})
    try:
        art = export_sql(
            sql=(payload.sql or ""),
            fmt=fmt, 
            title=payload.title,
            row_limit=payload.row_limit,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail={"error": {"code": "EXECUTION_ERROR", "message": str(e)}})

    return StreamingResponse(
        BytesIO(art.data),
        media_type=art.media_type,
        headers={"Content-Disposition": f'attachment; filename="{art.filename}"'},
    )
