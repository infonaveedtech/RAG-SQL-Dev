# app/api/routers/schema.py
from fastapi import APIRouter
from app.api.deps import get_owner, get_owner_aliases, get_allowlist, load_schema_tables

router = APIRouter(tags=["schema"])

@router.get("/schema")
def get_schema():
    """
    Returns the effective schema and safety view that the API enforces.
    - owner: primary Oracle owner (schema)
    - aliases: additional owners considered equivalent for validation
    - allowlist: fully-qualified tables allowed by safety guard
    - tables: list of tables with their column names (from schema card)

    Never exposes secrets; does not hit the database.
    """
    return {
        "owner": get_owner(),
        "aliases": get_owner_aliases(),
        "allowlist": get_allowlist(),
        "tables": load_schema_tables(),
    }
