# app/guards/labels.py
from __future__ import annotations
import os
import re

# If you truly want to allow projecting raw IDs (rare), set ALLOW_ID_PROJECTION=1
ALLOW_IDS = os.getenv("ALLOW_ID_PROJECTION", "0") == "1"

# Very light heuristic: block if certain *_ID or enum-like fields appear in the SELECT list
# (we only scan the SELECT clause, not the joins/where/group by).
_SELECT_RE = re.compile(r"^\s*SELECT\s+(.*?)\s+FROM\b", re.I | re.S)

# Block list targets (upper-cased tokens, matched as whole words in SELECT clause)
# Market/Orders baseline:
#   SYMBOL_ID, EXCHANGE_ID, MARKET_ID, CLIENT_ID, BROKER_ID, USER_ID, TRADER_ID, FLAG_ID, ORDER_TYPE, STATE
# ----New---- Trades/Cancelled/Negotiated-specific tokens are added below.
_BLOCK_TOKENS = [
    # core market + orders
    "SYMBOL_ID",
    "EXCHANGE_ID",
    "MARKET_ID",
    "CLIENT_ID",
    "BROKER_ID",
    "USER_ID",
    "TRADER_ID",
    "FLAG_ID",
    "ORDER_TYPE",
    "STATE",
    "TRADE_ID",  # general trade identifier

    # ----New---- TRADES buyer/seller participant IDs
    "BUYER_CLIENT_ID",
    "SELLER_CLIENT_ID",
    "BUYER_BROKER_ID",
    "SELLER_BROKER_ID",
    "BUYER_USER_ID",
    "SELLER_USER_ID",
    "BUYER_TRADER_ID",
    "SELLER_TRADER_ID",

    # ----New---- TRADES state/settlement enums
    "STATE_ID",
    "SETTLEMENT_TYPE_ID",
    "TRADE_TYPE",

    # ----New---- CANCELLED_TRADES mirrors TRADES columns
    # (same IDs as above; STATE_ID/SETTLEMENT_TYPE_ID/TRADE_TYPE are already included)

    # ----New---- NEGOTIATED_TRADES counterparty IDs + enums
    "COUNTER_CLIENT_ID",
    "COUNTER_BROKER_ID",
    "NEGOTIATED_STATE",
    "NEGOTIATED_STATUS",
    "PRICE_TYPE",

    # other common custodial IDs in these tables (safe to treat as IDs)
    "CUSTODIAN_ID",
    "BUYER_CUSTODIAN_ID",
    "SELLER_CUSTODIAN_ID",
    "COUNTER_CUSTODIAN_ID",
    
    # ----New (Rejections)
    "REJECTION_ID",

    # ----New (Levies)
    "LEVY_ID",
    "ACCOUNT_ID",  # no user-friendly label table; avoid projecting raw
]

# Compile a single regex: \b(T1|T2|...)\b
_BLOCK_RE = re.compile(r"\b(" + "|".join(map(re.escape, _BLOCK_TOKENS)) + r")\b", re.I)


def selects_ids(sql: str) -> bool:
    """
    Return True if the SELECT-list projects raw IDs or enum-like numeric fields.
    We allow override with ALLOW_ID_PROJECTION=1.

    Notes:
      - This is a simple lexical check. It will also block aliases like "c.CLIENT_ID client_id".
      - Aggregations that still project the ID (e.g., SELECT CLIENT_ID, SUM(...)) are considered
        user-hostile for NL answers (prefer label columns).
    """
    if ALLOW_IDS:
        return False
    if not sql:
        return False
    m = _SELECT_RE.search(sql)
    if not m:
        return False
    select_clause = m.group(1)
    return bool(_BLOCK_RE.search(select_clause))

REPAIR_HINT = (
    "Do not project raw *_ID or numeric enum columns in the SELECT list. Join lookups and select labels.\n"
    "\n"
    "Labels for core lookups:\n"
    "- SYMBOL label:    JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = <fact>.SYMBOL_ID\n"
    "                   → SELECT s.SYMBOL AS symbol\n"
    "- EXCHANGE label:  JOIN ATS.EXCHANGES e ON e.EXCHANGE_ID = <fact>.EXCHANGE_ID\n"
    "                   → SELECT e.EXCHANGE_CODE AS exchange  -- or e.EXCHANGE_NAME\n"
    "- MARKET label:    JOIN ATS.MARKETS mkt ON mkt.MARKET_ID = <fact>.MARKET_ID\n"
    "                   → SELECT COALESCE(mkt.MARKET_CODE, mkt.MARKET_NAME) AS market\n"
    "- BROKER name:     JOIN ATS.SUBSCRIBED_BROKERS b ON b.BROKER_ID = <fact>.BROKER_ID\n"
    "                   → SELECT b.BROKER_NAME AS broker\n"
    "- CLIENT name:     JOIN ATS.EDS_CLIENTS c ON c.CLIENT_ID = <fact>.CLIENT_ID\n"
    "                   → SELECT c.NAME AS client\n"
    "- USER/TRADER:     JOIN ATS.USERS u  ON u.USER_ID  = <fact>.USER_ID\n"
    "                   → SELECT u.COMPLETE_NAME AS user_name\n"
    "                   JOIN ATS.USERS ut ON ut.USER_ID = <fact>.TRADER_ID\n"
    "                   → SELECT ut.COMPLETE_NAME AS trader_name\n"
    "- Flags/Types/States (Orders):\n"
    "  FLAG code:       JOIN ATS.FLAGS f ON f.FLAG_ID = <fact>.FLAG_ID\n"
    "                   → SELECT f.FLAG_CODE AS flag_code\n"
    "  ORDER TYPE:      JOIN ATS.ORDER_TYPES t ON t.ID = <fact>.ORDER_TYPE\n"
    "                   → SELECT t.CODE AS order_type\n"
    "  ORDER STATE:     JOIN ATS.ORDER_STATES st ON st.STATE_ID = <fact>.STATE\n"
    "                   → SELECT st.STATE_CODE AS order_state\n"
    "- Market triple (when needed):\n"
    "  JOIN ATS.SYMBOL_MARKETS m ON m.SYMBOL_ID = <fact>.SYMBOL_ID\n"
    "                             AND m.EXCHANGE_ID = <fact>.EXCHANGE_ID\n"
    "                             AND m.MARKET_ID = <fact>.MARKET_ID\n"
    "\n"
    "----New---- Trades-specific labels:\n"
    "- Buyer/Seller brokers:\n"
    "  JOIN ATS.SUBSCRIBED_BROKERS bb ON bb.BROKER_ID = <fact>.BUYER_BROKER_ID\n"
    "  JOIN ATS.SUBSCRIBED_BROKERS sb ON sb.BROKER_ID = <fact>.SELLER_BROKER_ID\n"
    "  → SELECT bb.BROKER_NAME AS buyer_broker, sb.BROKER_NAME AS seller_broker\n"
    "- Buyer/Seller clients:\n"
    "  JOIN ATS.EDS_CLIENTS bc ON bc.CLIENT_ID = <fact>.BUYER_CLIENT_ID\n"
    "  JOIN ATS.EDS_CLIENTS sc ON sc.CLIENT_ID = <fact>.SELLER_CLIENT_ID\n"
    "  → SELECT bc.NAME AS buyer_client, sc.NAME AS seller_client\n"
    "- Buyer/Seller users:\n"
    "  JOIN ATS.USERS bu ON bu.USER_ID = <fact>.BUYER_USER_ID\n"
    "  JOIN ATS.USERS su ON su.USER_ID = <fact>.SELLER_USER_ID\n"
    "  → SELECT bu.COMPLETE_NAME AS buyer_user, su.COMPLETE_NAME AS seller_user\n"
    "- Settlement type label:\n"
    "  JOIN ATS.SETTLEMENT_TYPES sty ON sty.SETTLEMENT_TYPE_ID = <fact>.SETTLEMENT_TYPE_ID\n"
    "  → SELECT NVL(sty.SETTLEMENT_TYPE_NAME, sty.SETTLEMENT_TYPE) AS settlement_type\n"
    "- Trade state label:\n"
    "  JOIN ATS.TRADE_STATES ts ON ts.STATE_ID = <fact>.STATE_ID\n"
    "  → SELECT NVL(ts.STATE_NAME, ts.STATE_CODE) AS trade_state\n"
    "\n"
    "----New---- Negotiated-specific labels:\n"
    "- Counterparty brokers/clients:\n"
    "  JOIN ATS.SUBSCRIBED_BROKERS cb ON cb.BROKER_ID = NEGOTIATED_TRADES.COUNTER_BROKER_ID\n"
    "  JOIN ATS.EDS_CLIENTS      cc ON cc.CLIENT_ID  = NEGOTIATED_TRADES.COUNTER_CLIENT_ID\n"
    "  → SELECT cb.BROKER_NAME AS counter_broker, cc.NAME AS counter_client\n"
    "\n"
    "----Repo notes----\n"
    "- For REPO_CONTRACTS / REPO_LOG, the same buyer/seller label joins apply (brokers/clients/users).\n"
    "- Do not project LEG or CONTRACT_ID/NO as user-facing labels unless explicitly requested; prefer labels above.\n"
    "\n"
    "If you explicitly need raw IDs (diagnostics), set ALLOW_ID_PROJECTION=1 (not recommended for user-facing answers)."
)

