# app/guards/safety.py
from __future__ import annotations

import os
import re
from typing import Set

import sqlglot
from sqlglot import exp

# ── Env / configuration ─────────────────────────────────────────────────────────

OWNER: str = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
OWNER_ALIASES: Set[str] = {
    OWNER,
    *{s.strip().upper() for s in os.getenv("ORACLE_OWNER_ALIASES", "").split(",") if s.strip()},
}

def _parse_list_env(name: str) -> Set[str]:
    raw = os.getenv(name, "")
    if not raw or not raw.strip():
        return set()
    return {x.strip().upper() for x in raw.replace(",", " ").split() if x.strip()}

def _env_allowed_tables() -> Set[str]:
    # prefer SAFETY_ALLOWED_TABLES; fall back to legacy ALLOWED_TABLES
    return _parse_list_env("SAFETY_ALLOWED_TABLES") or _parse_list_env("ALLOWED_TABLES")

EXTRA_ALLOWED_BARE: Set[str] = _parse_list_env("SAFETY_EXTRA_TABLES")

DEFAULT_ALLOWED_BARE: Set[str] = {
    "SYMBOL_DAILY_INDICATORS",
    "SYMBOL_INDICATORS",
    "BEST_MKT",
    "SYMBOLS",
    "EXCHANGES",
    "ORDERS",
    "FLAGS",
    "ORDER_TYPES",
    "ORDER_STATES",
    "SUBSCRIBED_BROKERS",
    "EDS_CLIENTS",
    "USERS",
    "SYMBOL_MARKETS",
    # Trades domain
    "TRADES",
    "CANCELLED_TRADES",
    "NEGOTIATED_TRADES",
    "TRADE_STATES",
    "SETTLEMENT_TYPES",
    "SYMBOL_TYPES",
    # ----New (Rejections)
    "REJECTED_ORDERS",
    "REJECTIONS",

    # ----New (Levies)
    "ATS_LEVY_DATA_LOG",
    "SETTLEMENT_LEVY_DATA",
    "LEVIES",
    "LEVY_TYPES",
    "LEVY_RANGES",
    "LEVY_CRITERIA",
    "LEVY_INFO",
    "LEVY_MEMBER_TYPES",
    "LEVY_SECURITIES",
        # ----New (Repo)----
    "REPO_CONTRACTS",
    "REPO_CONTRACTS_CANCELLED",
    "REPO_LOG",

    # ----New (Lookup)----
    "MARKETS",

}

ALLOWED_BARE: Set[str] = (_env_allowed_tables() or DEFAULT_ALLOWED_BARE) | EXTRA_ALLOWED_BARE
BUILTIN_BARE: Set[str] = {"DUAL"}

SAFETY_DEBUG: bool = os.getenv("SAFETY_DEBUG", "0") == "1"

def _dbg(*args):
    if SAFETY_DEBUG:
        print("[SAFETY]", *args)

# ── Basic gates ─────────────────────────────────────────────────────────────────

DANGEROUS = re.compile(r"\b(UPDATE|INSERT|DELETE|MERGE|TRUNCATE|ALTER|DROP|CREATE|GRANT|REVOKE)\b", re.I)
SELECTY   = re.compile(r"\b(SELECT|WITH)\b", re.I)

def is_readonly_select(sql: str) -> bool:
    return bool(SELECTY.search(sql)) and not DANGEROUS.search(sql)

def ensure_row_limit(sql: str, default_limit: int = 200) -> str:
    if re.search(r"\bFETCH\s+FIRST\s+\d+\s+ROWS\s+ONLY\b", sql, re.I) or re.search(r"\bROWNUM\s*<=\s*\d+\b", sql, re.I):
        return sql
    s = sql.strip().rstrip(";")
    return f"{s}\nFETCH FIRST {default_limit} ROWS ONLY;"

# ── Helpers: comments & CTEs ────────────────────────────────────────────────────

def _strip_comments(sql: str) -> str:
    # remove -- line comments and /* ... */ blocks
    return re.sub(r"--.*?$|/\*.*?\*/", "", sql or "", flags=re.M | re.S)

def _collect_cte_names(tree: exp.Expression) -> Set[str]:
    """Upper-cased CTE names defined in WITH clauses."""
    ctes: Set[str] = set()
    # exp.With → .expressions → exp.CTE items
    for with_ in tree.find_all(exp.With):
        for cte in (with_.expressions or []):
            alias = getattr(cte, "alias_or_name", None)
            if alias:
                ctes.add(str(alias).upper())
                continue
            alias_expr = getattr(cte, "alias", None)
            if isinstance(alias_expr, exp.Expression):
                this = getattr(alias_expr, "this", None)
                ctes.add(str(this).upper() if this is not None else str(alias_expr).upper())
            elif alias_expr:
                ctes.add(str(alias_expr).upper())
    # also iterate exp.CTE directly (older sqlglot versions)
    for cte in tree.find_all(exp.CTE):
        alias = getattr(cte, "alias_or_name", None)
        if alias:
            ctes.add(str(alias).upper())
            continue
        alias_expr = getattr(cte, "alias", None)
        if alias_expr:
            ctes.add(str(alias_expr).upper())
    return ctes

def _normalize_table(schema: str | None, name_upper: str) -> str:
    """Normalize SCHEMA.NAME to compare on bare; keep SCHEMA for debug if foreign."""
    if schema and schema.upper() in OWNER_ALIASES:
        return name_upper
    return name_upper if not schema else f"{schema.upper()}.{name_upper}"

# ── Public API: allow-list check ────────────────────────────────────────────────

def tables_whitelisted(sql: str) -> bool:
    """
    True if all *real* tables referenced by the query are in ALLOWED_BARE.
    Ignores:
      - CTE names
      - Oracle DUAL
    """
    # helpful when debugging: show the SQL body too
    if SAFETY_DEBUG:
        _dbg("SQL:", sql.strip())

    try:
        s = _strip_comments(sql)
        tree = sqlglot.parse_one(s, read="oracle")

        cte_names = _collect_cte_names(tree)

        found_raw: Set[str] = set()
        found_bare: Set[str] = set()
        foreign_raw: Set[str] = set()

        for t in tree.find_all(exp.Table):
            # schema can be in db/catalog, or nested on t.this.db depending on version
            schema = (
                t.args.get("db")
                or t.args.get("catalog")
                or (t.args.get("this") and t.args["this"].args.get("db"))
            )

            # table name (Identifier)
            name = t.this.name if hasattr(t, "this") and t.this else t.name
            if not name:
                continue
            name_u = str(name).upper()

            # skip CTE and built-ins
            if name_u in cte_names or name_u in BUILTIN_BARE:
                continue

            norm = _normalize_table(schema, name_u)
            found_raw.add(norm)

            bare = norm.split(".")[-1]
            found_bare.add(bare)

            if schema and schema.upper() not in OWNER_ALIASES:
                foreign_raw.add(norm)

        ok = found_bare.issubset(ALLOWED_BARE)

        if SAFETY_DEBUG or not ok:
            _dbg(f"[SQLGLOT] OWNER={OWNER} OWNER_ALIASES={sorted(OWNER_ALIASES)}")
            _dbg(f"[SQLGLOT] ALLOWED_BARE={sorted(ALLOWED_BARE)}")
            _dbg(f"[SQLGLOT] CTE_NAMES={sorted(cte_names)}")
            _dbg(f"[SQLGLOT] FOUND_RAW={sorted(found_raw)}")
            _dbg(f"[SQLGLOT] FOUND_BARE={sorted(found_bare)}")
            if foreign_raw:
                _dbg(f"[SQLGLOT] FOREIGN_SCHEMA_TABLES={sorted(foreign_raw)}")

        return ok

    except Exception as e:
        # Robust regex fallback: multi-CTE aware and comment-safe
        s = _strip_comments(sql)

        # capture ALL CTE names: WITH a AS (...), b(col) AS ( ... )
        cte_names = {
            m.upper()
            for m in re.findall(r"(?is)(?:\bWITH|,)\s+([A-Za-z0-9_]+)\s*(?:\([^)]+\))?\s+AS\s*\(", s)
        }

        # capture FROM/JOIN references
        candidates = re.findall(r"(?is)\bfrom\s+([a-z0-9_.]+)|\bjoin\s+([a-z0-9_.]+)", s)

        found_raw: Set[str] = set()
        found_bare: Set[str] = set()
        foreign_raw: Set[str] = set()

        for a, b in candidates:
            raw = (a or b).strip().strip('"')
            nm = raw.upper()

            # skip CTE + DUAL
            if nm in cte_names or nm.endswith(".DUAL") or nm == "DUAL":
                continue

            parts = nm.split(".")
            if len(parts) == 2:
                sch, tbl = parts[0], parts[1]
                if sch in OWNER_ALIASES:
                    found_raw.add(nm)
                    found_bare.add(tbl)
                else:
                    found_raw.add(nm)
                    foreign_raw.add(nm)
                    found_bare.add(tbl)
            else:
                found_raw.add(nm)
                found_bare.add(nm)

        ok = found_bare.issubset(ALLOWED_BARE)

        if SAFETY_DEBUG or not ok:
            _dbg(f"[FALLBACK] OWNER={OWNER} OWNER_ALIASES={sorted(OWNER_ALIASES)}")
            _dbg(f"[FALLBACK] ALLOWED_BARE={sorted(ALLOWED_BARE)}")
            _dbg(f"[FALLBACK] CTE_NAMES={sorted(cte_names)}")
            _dbg(f"[FALLBACK] FOUND_RAW={sorted(found_raw)}")
            _dbg(f"[FALLBACK] FOUND_BARE={sorted(found_bare)}")
            if foreign_raw:
                _dbg(f"[FALLBACK] FOREIGN_SCHEMA_TABLES={sorted(foreign_raw)}")
            _dbg(f"[FALLBACK] ERROR={e!r}")

        return ok
