from __future__ import annotations

import os
import time
import datetime
from io import StringIO, BytesIO
from typing import Literal, Optional, Tuple, List, Any

# Reuse your existing modules (no new deps):
from app.services.prompting import load_prompt_pack
from app.services.models.router import generate_sql_by_strategy
from app.guards.safety import ensure_row_limit, is_readonly_select, tables_whitelisted
from app.guards.labels import selects_ids, REPAIR_HINT
from app.services.execution import safe_run_with_gate

# Optional schema validation (best-effort; skipped if not wired)
try:
    from app.guards.schema_validate import validate_columns as _validate_columns
except Exception:  # pragma: no cover
    _validate_columns = None  # type: ignore

from .types import (
    GuardReport, Preview, NLQueryResult,
    SqlValidateResult, SqlValidateIssue, SqlExecuteResult,
    ExportArtifact,
)


# ───────────────────────────────────────────────────────────────────────────────
# Env / knobs (same behavior as your existing code)
# ───────────────────────────────────────────────────────────────────────────────

OWNER = os.getenv("ORACLE_OWNER", "ATS")
ROW_LIM_DEFAULT = int(os.getenv("ROW_LIMIT_DEFAULT", os.getenv("RESULT_ROW_LIMIT", "200")))
MAX_EST = int(os.getenv("MAX_ESTIMATED_ROWS", "5000000"))
MODEL_STRATEGY_DEFAULT = (os.getenv("MODEL_STRATEGY", "gemini") or "gemini").lower()
WKHTMLTOPDF_PATH = os.getenv("WKHTMLTOPDF_PATH", "").strip()


def _pick_strategy(user_strategy: Optional[str]) -> str:
    """
    Normalize strategy; treat "auto" as "gemini" per your current behavior.
    """
    s = (user_strategy or MODEL_STRATEGY_DEFAULT or "gemini").lower()
    return "gemini" if s == "auto" else s


def _row_limits(preview_row_limit: Optional[int] = None) -> Tuple[int, int]:
    """
    Returns (limit_to_use, hard_cap). We keep a hard cap only for execute/export.
    """
    limit = int(preview_row_limit) if preview_row_limit else ROW_LIM_DEFAULT
    hard_cap = int(os.getenv("EXECUTE_ROW_LIMIT_MAX", "2000"))
    return limit, hard_cap


# ───────────────────────────────────────────────────────────────────────────────
# Public API (backend-only)
# ───────────────────────────────────────────────────────────────────────────────

def run_nl_query(
    question: str,
    strategy: Optional[str] = None,
    preview_row_limit: Optional[int] = None,
) -> NLQueryResult:
    """
    Natural language → SQL → guards → EXECUTE (preview).
    Mirrors the Streamlit flow in chatbot.py but without any UI code.
    """
    if not question or not question.strip():
        raise ValueError("question is empty")

    limit, _ = _row_limits(preview_row_limit)

    # 1) Load prompt pack (system, schema, fewshots, glossary)
    pack = load_prompt_pack(owner=OWNER, row_limit=limit)

    # 2) Generate SQL (Gemini by default; "auto" → "gemini")
    strat = _pick_strategy(strategy)
    t0 = time.perf_counter()
    sql_text, used_model = generate_sql_by_strategy(
        strategy=strat,
        prompt_pack=pack,
        question=question.strip(),
        repair_hint=None,
    )
    gen_ms = (time.perf_counter() - t0) * 1000.0
    if not sql_text:
        raise RuntimeError(f"{used_model} returned no SQL")

    # 3) Optional repair if raw IDs projected
    if selects_ids(sql_text):
        try:
            sql_text2, used_model2 = generate_sql_by_strategy(
                strategy=strat,
                prompt_pack=pack,
                question=question.strip(),
                repair_hint=REPAIR_HINT,
            )
            if sql_text2:
                sql_text = sql_text2
                used_model = used_model2
        except Exception:
            # If repair fails, we still continue with the original and let guards act
            pass

    # 4) Read-only + allowlist quick checks (mirror API guards)
    # sql_text = ensure_row_limit(sql_text, ROW_LIM_DEFAULT)
    if not is_readonly_select(sql_text):
        raise RuntimeError("Generated SQL is not a read-only SELECT/WITH")

    # if not tables_whitelisted(sql_text):
    #     raise RuntimeError("Generated SQL references tables outside the allowlist")

    # 5) Optional schema validation (best-effort; generally used for non-Gemini)
    try:
        # Only if the function is available
        if _validate_columns:
            ok, msg = _validate_columns(sql_text, owner=OWNER)
            if not ok:
                raise RuntimeError(f"Schema validation failed: {msg}")
    except Exception:
        # Skip silently to mirror current behavior where schema validate may be absent
        pass

    # 6) Enforce row limit (final defense)
    limited_sql = ensure_row_limit(sql_text, limit)

    # 7) Execute with gate (explain/estimate, same as Streamlit)
    t1 = time.perf_counter()
    final_sql, plan_text, est_rows, cols, rows = safe_run_with_gate(
        limited_sql,
        row_limit_default=limit,
        max_estimated_rows=MAX_EST,
    )
    exec_ms = (time.perf_counter() - t1) * 1000.0

    guards = GuardReport(
        safety="passed",
        schema_check="skipped",  # set to "passed" if you wire strict schema checks
        labels="passed",
    )

    return NLQueryResult(
        sql=final_sql,
        used_model=str(used_model),
        guards=guards,
        preview=Preview(columns=[str(c) for c in cols], rows=rows[:limit]),
        plan=plan_text,
        estimated_rows=est_rows,
        gen_ms=gen_ms,
        exec_ms=exec_ms,
    )


def validate_sql(sql: str) -> SqlValidateResult:
    """
    Validate raw SQL (no LLM, no DB execution).
    Same checks as /sql/validate: read-only, allowlist, (optional) schema, labels.
    """
    raw = (sql or "").strip()
    if not raw:
        return SqlValidateResult(ok=False, sql_normalized=None, issues=[
            SqlValidateIssue(type="INPUT", message="SQL is empty")
        ])

    sql_norm = raw.rstrip().rstrip(";").strip()
    issues: List[SqlValidateIssue] = []

    # safety + allowlist
    if not is_readonly_select(sql_norm):
        issues.append(SqlValidateIssue(type="SAFETY", message="Only single SELECT/WITH queries are allowed"))

    # if not tables_whitelisted(sql_norm):
    #     issues.append(SqlValidateIssue(type="SAFETY", message="Query references tables outside the allowlist"))

    # optional schema validation (best-effort)
    try:
        if _validate_columns:
            ok, msg = _validate_columns(sql_norm, owner=OWNER)
            if not ok:
                issues.append(SqlValidateIssue(type="SCHEMA", message=msg))
    except Exception:
        pass

    # labels (no raw IDs)
    try:
        if selects_ids(sql_norm):
            issues.append(SqlValidateIssue(
                type="LABELS",
                message=f"Raw IDs are restricted; join to label tables. Hint: {REPAIR_HINT}"
            ))
    except Exception:
        pass

    return SqlValidateResult(ok=(len(issues) == 0), sql_normalized=sql_norm, issues=issues)


def execute_sql(sql: str, row_limit: Optional[int] = None) -> SqlExecuteResult:
    """
    Execute provided SQL after running guards. No LLM call.
    Mirrors /sql/execute but returns a backend object.
    """
    if not sql or not sql.strip():
        raise ValueError("SQL is empty")

    limit, hard_cap = _row_limits(row_limit)
    limit = min(limit, hard_cap)

    if not is_readonly_select(sql):
        raise RuntimeError("Only single SELECT/WITH queries are allowed")

    # if not tables_whitelisted(sql):
    #     raise RuntimeError("Query references tables outside the allowlist")

    # Optional schema validation
    try:
        if _validate_columns:
            ok, msg = _validate_columns(sql, owner=OWNER)
            if not ok:
                raise RuntimeError(f"Schema validation failed: {msg}")
    except Exception:
        pass

    # labels
    try:
        if selects_ids(sql):
            raise RuntimeError("Raw IDs are restricted; join to label tables instead")
    except Exception:
        pass

    # Execute with safe gate (estimate + explain)
    final_sql, plan_text, est_rows, cols, rows = safe_run_with_gate(
        ensure_row_limit(sql, limit),
        row_limit_default=limit,
        max_estimated_rows=MAX_EST,
    )

    guards = GuardReport(
        safety="passed",
        schema_check="skipped",
        labels="passed",
    )

    return SqlExecuteResult(
        columns=[str(c) for c in cols],
        rows=rows[:limit],
        row_limit_applied=limit,
        guards=guards,
        plan=plan_text,
        estimated_rows=est_rows,
    )


def export_sql(
    sql: str,
    fmt: Literal["csv", "html", "pdf"],
    title: Optional[str] = None,
    row_limit: Optional[int] = None,
) -> ExportArtifact:
    """
    Execute the SQL (with guards + limits) and export rows as CSV/HTML/PDF.
    Uses a minimal in-code HTML template for HTML/PDF to avoid UI dependencies.
    """
    # First, reuse the execution path (guards + run + limit)
    exec_res = execute_sql(sql, row_limit=row_limit)

    # Filenames
    ts = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    base = (title or "report").strip() or "report"
    safe_base = "".join(c for c in base if c.isalnum() or c in ("-", "_", " ")).strip().replace(" ", "-") or "report"

    cols = exec_res.columns
    rows = exec_res.rows

    if fmt == "csv":
        import csv
        text_buf = StringIO()
        w = csv.writer(text_buf, lineterminator="\n")
        w.writerow(cols)
        for r in rows:
            w.writerow([("" if c is None else c) for c in r])
        data = text_buf.getvalue().encode("utf-8")
        filename = f"{safe_base}-{ts}.csv"
        return ExportArtifact(filename=filename, media_type="text/csv; charset=utf-8", data=data)

    # Build a minimal HTML table (standalone document)
    html_rows = "\n".join("<tr>" + "".join(f"<td>{'' if c is None else c}</td>" for c in row) + "</tr>" for row in rows)
    html_cols = "".join(f"<th>{c}</th>" for c in cols)
    html = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8"><title>{title or "Report"}</title>
<style>
body {{ font-family: Arial, sans-serif; }}
h1 {{ font-size: 18px; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #ddd; padding: 8px; font-size: 12px; }}
th {{ background: #f5f5f5; text-align: left; }}
tfoot td {{ font-size: 11px; color: #666; }}
</style>
</head>
<body>
<h1>{title or "Report"}</h1>
<table>
<thead><tr>{html_cols}</tr></thead>
<tbody>
{html_rows}
</tbody>
<tfoot><tr><td colspan="{len(cols)}">Rows: {len(rows)} • Generated {ts}</td></tr></tfoot>
</table>
</body>
</html>
"""

    if fmt == "html":
        data = html.encode("utf-8")
        filename = f"{safe_base}-{ts}.html"
        return ExportArtifact(filename=filename, media_type="text/html; charset=utf-8", data=data)

    # fmt == "pdf"
    # Try wkhtmltopdf, fallback to HTML if unavailable
    if not WKHTMLTOPDF_PATH or not os.path.exists(WKHTMLTOPDF_PATH):
        data = html.encode("utf-8")
        filename = f"{safe_base}-{ts}.html"
        return ExportArtifact(filename=filename, media_type="text/html; charset=utf-8", data=data)

    import tempfile, subprocess
    with tempfile.TemporaryDirectory() as tmpd:
        html_path = os.path.join(tmpd, f"{safe_base}.html")
        pdf_path = os.path.join(tmpd, f"{safe_base}.pdf")
        with open(html_path, "w", encoding="utf-8") as f:
            f.write(html)
        try:
            subprocess.run([WKHTMLTOPDF_PATH, html_path, pdf_path], check=True)
            with open(pdf_path, "rb") as f:
                data = f.read()
        except Exception:
            # Fallback to HTML on failure
            data = html.encode("utf-8")
            filename = f"{safe_base}-{ts}.html"
            return ExportArtifact(filename=filename, media_type="text/html; charset=utf-8", data=data)

    filename = f"{safe_base}-{ts}.pdf"
    return ExportArtifact(filename=filename, media_type="application/pdf", data=data)
