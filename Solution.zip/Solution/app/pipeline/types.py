from __future__ import annotations

from typing import Any, List, Optional
from pydantic import BaseModel


class GuardReport(BaseModel):
    safety: str                      # "passed" | "failed" | "skipped"
    schema_check: str                # "passed" | "failed" | "skipped"
    labels: str                      # "passed" | "failed" | "skipped"
    labels_hint: Optional[str] = None


class Preview(BaseModel):
    columns: List[str]
    rows: List[List[Any]]


class NLQueryResult(BaseModel):
    sql: str
    used_model: str                  # e.g., "gemini-2.5-flash" or strategy tag
    guards: GuardReport
    preview: Preview
    plan: Optional[str] = None       # DBMS_XPLAN text if available
    estimated_rows: Optional[int] = None
    gen_ms: Optional[float] = None
    exec_ms: Optional[float] = None


class SqlValidateIssue(BaseModel):
    type: str                        # "SAFETY" | "SCHEMA" | "LABELS" | ...
    message: str


class SqlValidateResult(BaseModel):
    ok: bool
    sql_normalized: Optional[str]
    issues: List[SqlValidateIssue]


class SqlExecuteResult(BaseModel):
    columns: List[str]
    rows: List[List[Any]]
    row_limit_applied: int
    guards: GuardReport
    plan: Optional[str] = None
    estimated_rows: Optional[int] = None


class ExportArtifact(BaseModel):
    filename: str
    media_type: str
    data: bytes                      # raw bytes payload you can write to disk
