### 1) MoM turnover (last 6 months) from daily indicators
Question: What is month-over-month turnover for the last 6 months?
```sql
-- MoM turnover from SYMBOL_DAILY_INDICATORS (last 6 months)
WITH m AS (
  SELECT TRUNC(STATS_DATE, 'MM') AS month,
         SUM(TURNOVER_VALUE) AS turnover
  FROM ATS.SYMBOL_DAILY_INDICATORS
  WHERE STATS_DATE >= ADD_MONTHS(TRUNC(SYSDATE, 'MM'), -6)
  GROUP BY TRUNC(STATS_DATE, 'MM')
)
SELECT month,
       turnover,
       (turnover - LAG(turnover) OVER (ORDER BY month))
         / NULLIF(LAG(turnover) OVER (ORDER BY month), 0) AS mom
FROM m
ORDER BY month
FETCH FIRST 200 ROWS ONLY
```

### 2) Top 10 symbols by median daily close in the most recent full month (with labels)

Question: Which 10 symbols had the highest median daily close in the most recent full month?

```sql
-- Top 10 symbols by median CLOSE_PRICE in the most recent full calendar month
WITH bounds AS (
  SELECT ADD_MONTHS(TRUNC(SYSDATE,'MM'), -1) AS d0,
         TRUNC(SYSDATE,'MM') AS d1
  FROM dual
),
d AS (
  SELECT SYMBOL_ID,
         TRUNC(STATS_DATE, 'DD') AS day,
         CLOSE_PRICE
  FROM ATS.SYMBOL_DAILY_INDICATORS, bounds
  WHERE STATS_DATE >= bounds.d0
    AND STATS_DATE <  bounds.d1
)
SELECT s.SYMBOL,
       d.SYMBOL_ID,
       MEDIAN(d.CLOSE_PRICE) AS median_close
FROM d
JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = d.SYMBOL_ID
GROUP BY s.SYMBOL, d.SYMBOL_ID
ORDER BY median_close DESC
FETCH FIRST 10 ROWS ONLY
```

### 3) P95 spread (offer - bid) per exchange over the last 30 days

Question: What is the 95th percentile spread by exchange for the last 30 days?
```sql
-- P95 spread (OFFER_PRICE - BID_PRICE) per exchange (30 days)
SELECT e.EXCHANGE_NAME,
       PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY (b.OFFER_PRICE - b.BID_PRICE)) AS p95_spread
FROM ATS.BEST_MKT b
JOIN ATS.EXCHANGES e ON e.EXCHANGE_ID = b.EXCHANGE_ID
WHERE b.ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
GROUP BY e.EXCHANGE_NAME
ORDER BY p95_spread DESC
FETCH FIRST 200 ROWS ONLY
```

### 4) 7-day rolling average of daily turnover per symbol (last 60 days, preview)

Question: Show a preview of 7-day rolling average of daily turnover per symbol for the last 60 days.
```sql
-- 7-day rolling average of daily turnover per symbol (preview)
WITH d AS (
  SELECT SYMBOL_ID,
         TRUNC(STATS_DATE, 'DD') AS day,
         SUM(TURNOVER_VALUE) AS turnover
  FROM ATS.SYMBOL_DAILY_INDICATORS
  WHERE STATS_DATE >= TRUNC(SYSDATE) - 60
  GROUP BY SYMBOL_ID, TRUNC(STATS_DATE, 'DD')
)
SELECT s.SYMBOL,
       d.SYMBOL_ID,
       d.day,
       AVG(d.turnover) OVER (
         PARTITION BY d.SYMBOL_ID
         ORDER BY d.day
         ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
       ) AS turnover_7d_avg
FROM d
JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = d.SYMBOL_ID
ORDER BY d.SYMBOL_ID, d.day
FETCH FIRST 200 ROWS ONLY
```

### 5) Daily volume & average close by exchange (last 14 days)

Question: For each exchange, what are daily volume and average close in the last 14 days?
```sql
-- Daily volume and average close by exchange (14 days)
SELECT TRUNC(si.ENTRY_DATETIME, 'DD') AS day,
       e.EXCHANGE_NAME,
       SUM(si.VOLUME) AS volume,
       AVG(si.CLOSE)  AS avg_close
FROM ATS.SYMBOL_INDICATORS si
JOIN ATS.EXCHANGES e ON e.EXCHANGE_ID = si.EXCHANGE_ID
WHERE si.ENTRY_DATETIME >= TRUNC(SYSDATE) - 14
GROUP BY TRUNC(si.ENTRY_DATETIME, 'DD'), e.EXCHANGE_NAME
ORDER BY day, e.EXCHANGE_NAME
FETCH FIRST 200 ROWS ONLY
```

### 6) Top 20 symbols by trades_count in a date range (with labels)

Question: Which 20 symbols had the highest trades count between two dates?
```sql
-- Top 20 by trades_count with labels in a date window (last 60 days)
-- Top 20 by trades_count with labels in a date window (last 60 days) — FIXED (ANSI joins only)
WITH bounds AS (
  SELECT TRUNC(SYSDATE) - 60 AS d0,
         TRUNC(SYSDATE)       AS d1
  FROM dual
)
SELECT s.SYMBOL,
       d.SYMBOL_ID,
       SUM(d.TRADES_COUNT) AS trades_count
FROM ATS.SYMBOL_DAILY_INDICATORS d
JOIN ATS.SYMBOLS s       ON s.SYMBOL_ID    = d.SYMBOL_ID
CROSS JOIN bounds
WHERE d.STATS_DATE >= bounds.d0
  AND d.STATS_DATE <  bounds.d1
GROUP BY s.SYMBOL, d.SYMBOL_ID
ORDER BY trades_count DESC
FETCH FIRST 20 ROWS ONLY

```

### 7) Mid price and spread series for a symbol on a day (preview)

Question: Show mid and spread intraday for a single symbol on a chosen day.
```sql
-- Mid and spread series (BEST_MKT) for a symbol on a day (preview)
WITH bounds AS (
  SELECT TRUNC(SYSDATE) - 1 AS d0,  -- yesterday
         TRUNC(SYSDATE)     AS d1
  FROM dual
)
SELECT TRUNC(b.ENTRY_DATETIME, 'DD') AS day,
       b.ENTRY_DATETIME,
       ((b.BID_PRICE + b.OFFER_PRICE) / 2) AS mid_price,
       (b.OFFER_PRICE - b.BID_PRICE) AS spread
FROM ATS.BEST_MKT b, bounds
WHERE b.SYMBOL_ID = {{SYMBOL_ID}}
  AND b.ENTRY_DATETIME >= bounds.d0
  AND b.ENTRY_DATETIME <  bounds.d1
ORDER BY b.ENTRY_DATETIME
FETCH FIRST 200 ROWS ONLY
```
### 8) Trades count and OHLC per symbol
```sql
-- Example: May 2024 trades count and OHLC per symbol
WITH bounds AS (
  SELECT DATE '2024-05-01' AS d0, DATE '2024-06-01' AS d1 FROM dual
)
SELECT s.SYMBOL,
       SUM(d.TRADES_COUNT) AS total_trades,
       AVG(d.OPEN_PRICE) AS avg_open,
       MAX(d.HIGH_PRICE) AS high,
       MIN(d.LOW_PRICE) AS low,
       AVG(d.CLOSE_PRICE) AS avg_close
FROM ATS.SYMBOL_DAILY_INDICATORS d
JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = d.SYMBOL_ID
WHERE d.STATS_DATE >= (SELECT d0 FROM bounds)
  AND d.STATS_DATE <  (SELECT d1 FROM bounds)
GROUP BY s.SYMBOL
ORDER BY total_trades DESC
FETCH FIRST 20 ROWS ONLY;
```

### 9) Distribution of orders by FLAG_CODE in the last 90 days

Question: What is the distribution of orders by flag code (e.g. SL, MIT, etc.) over the last 90 days?
```sql
-- Distribution of orders by FLAG_CODE (last 90 days)
SELECT f.FLAG_CODE,
       COUNT(*) AS orders,
       SUM(o.PRICE * o.VOLUME) AS notional
FROM ATS.ORDERS o
JOIN ATS.FLAGS f ON f.FLAG_ID = o.FLAG_ID
WHERE o.ENTRY_DATETIME >= TRUNC(SYSDATE) - 90
GROUP BY f.FLAG_CODE
ORDER BY orders DESC
FETCH FIRST 100 ROWS ONLY;
```

### 10) State breakdown by SYMBOL for the current year

Question: For each symbol, show the number of orders by state in the current year.
```sql
-- State breakdown by SYMBOL for the current year
WITH year_bounds AS (
  SELECT TRUNC(ADD_MONTHS(SYSDATE, -EXTRACT(MONTH FROM SYSDATE)+1), 'YYYY') AS y0,
         ADD_MONTHS(TRUNC(SYSDATE, 'YYYY'), 12) AS y1
  FROM dual
)
SELECT s.SYMBOL,
       st.STATE_CODE,
       COUNT(*) AS orders
FROM ATS.ORDERS o
JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = o.SYMBOL_ID
JOIN ATS.ORDER_STATES st ON st.STATE_ID = o.STATE
WHERE o.ENTRY_DATETIME >= (SELECT y0 FROM year_bounds)
  AND o.ENTRY_DATETIME <  (SELECT y1 FROM year_bounds)
GROUP BY s.SYMBOL, st.STATE_CODE
ORDER BY s.SYMBOL, st.STATE_CODE
FETCH FIRST 200 ROWS ONLY;
```

### 11) Top brokers by notional (Year-To-Date)

Question: Which brokers have the highest total notional this year?
```sql
-- Top brokers by notional (YTD)
SELECT b.BROKER_NAME,
       COUNT(*) AS orders,
       SUM(o.PRICE * o.VOLUME) AS notional
FROM ATS.ORDERS o
JOIN ATS.SUBSCRIBED_BROKERS b ON b.BROKER_ID = o.BROKER_ID
WHERE EXTRACT(YEAR FROM o.ENTRY_DATETIME) = EXTRACT(YEAR FROM SYSDATE)
GROUP BY b.BROKER_NAME
ORDER BY notional DESC
FETCH FIRST 20 ROWS ONLY;
```

### 12) Daily notional by SIDE (last 30 days)

Question: Show the daily total notional value split by buy/sell side for the last 30 days.
```sql
-- Daily notional by SIDE (last 30 days)
SELECT TRUNC(o.ENTRY_DATETIME, 'DD') AS day,
       o.SIDE,
       SUM(o.PRICE * o.VOLUME) AS notional
FROM ATS.ORDERS o
WHERE o.ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
GROUP BY TRUNC(o.ENTRY_DATETIME, 'DD'), o.SIDE
ORDER BY day, o.SIDE
FETCH FIRST 200 ROWS ONLY;
```

### 13) Daily traded notional by exchange (last 14 days)

Question: Show the total traded notional per exchange for the last 14 days.

```sql
-- Daily traded notional by exchange (last 14 days)
WITH d AS (
  SELECT TRUNC(t.ENTRY_DATETIME, 'DD') AS trade_day,
         t.EXCHANGE_ID,
         SUM(t.PRICE * t.VOLUME) AS notional
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE) - 14
  GROUP BY TRUNC(t.ENTRY_DATETIME, 'DD'), t.EXCHANGE_ID
)
SELECT d.trade_day,
       e.EXCHANGE_CODE,
       d.notional
FROM d
JOIN ATS.EXCHANGES e ON e.EXCHANGE_ID = d.EXCHANGE_ID
ORDER BY d.trade_day DESC, d.notional DESC
FETCH FIRST 200 ROWS ONLY;
```

### 14) Top clients by traded volume (this month; buyer + seller attribution)

Question: Which clients have the highest total traded volume this month?

```sql
-- Top clients by traded volume this month (buyer + seller)
WITH party AS (
  SELECT t.BUYER_CLIENT_ID AS CLIENT_ID, t.VOLUME AS VOL
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE, 'MM')
  UNION ALL
  SELECT t.SELLER_CLIENT_ID, t.VOLUME
  FROM ATS.TRADES t
  WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE, 'MM')
)
SELECT c.NAME AS CLIENT_NAME,
       SUM(p.VOL) AS traded_volume
FROM party p
JOIN ATS.EDS_CLIENTS c ON c.CLIENT_ID = p.CLIENT_ID
GROUP BY c.NAME
ORDER BY traded_volume DESC
FETCH FIRST 200 ROWS ONLY;
```

### 15) Daily cancellations by exchange (last 30 days)

Question: For the last 30 days, how many trades were cancelled per day and exchange?

```sql
-- Daily cancellations by exchange (last 30 days)
SELECT TRUNC(ct.CANCELLATION_DATETIME, 'DD') AS cancel_day,
       e.EXCHANGE_CODE,
       COUNT(*) AS cancellations
FROM ATS.CANCELLED_TRADES ct
JOIN ATS.EXCHANGES e ON e.EXCHANGE_ID = ct.EXCHANGE_ID
WHERE ct.CANCELLATION_DATETIME >= TRUNC(SYSDATE) - 30
GROUP BY TRUNC(ct.CANCELLATION_DATETIME, 'DD'), e.EXCHANGE_CODE
ORDER BY cancel_day DESC, cancellations DESC
FETCH FIRST 200 ROWS ONLY;
```

### 16) Negotiated → executed mapping: notional by symbol (last 30 days)

Question: For negotiated orders in the last 30 days, what executed notional did they lead to by symbol?

```sql
-- Negotiated → executed mapping: executed notional by symbol (last 30 days)
-- Map NEGOTIATED_TRADES order numbers to TRADES buyer/seller order numbers on the same exchange.
WITH nt_orders AS (
  SELECT EXCHANGE_ID, ORDER_NO AS ORD_NO
  FROM ATS.NEGOTIATED_TRADES
  WHERE ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
  UNION ALL
  SELECT EXCHANGE_ID, COUNTER_ORDER_NO
  FROM ATS.NEGOTIATED_TRADES
  WHERE ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
),
t_match AS (
  SELECT t.SYMBOL_ID,
         t.EXCHANGE_ID,
         (t.PRICE * t.VOLUME) AS notional
  FROM ATS.TRADES t
  JOIN nt_orders n
    ON n.EXCHANGE_ID = t.EXCHANGE_ID
   AND (t.BUYER_ORDER_NO = n.ORD_NO OR t.SELLER_ORDER_NO = n.ORD_NO)
  WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
)
SELECT s.SYMBOL,
       SUM(m.notional) AS negotiated_executed_notional
FROM t_match m
JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = m.SYMBOL_ID
GROUP BY s.SYMBOL
ORDER BY negotiated_executed_notional DESC
FETCH FIRST 200 ROWS ONLY;
```


### 17) Bonds: average yield and total settlement by settlement type (YTD)

Question: For bond trades year-to-date, show average yield and total settlement amount by settlement type.

```sql
-- Bonds: avg YIELD and sum SETTLEMENT_AMOUNT by settlement type (YTD)
WITH ytd AS (
  SELECT TRUNC(ADD_MONTHS(SYSDATE, -EXTRACT(MONTH FROM SYSDATE)+1), 'YYYY') AS y0
  FROM dual
)
SELECT NVL(sty.SETTLEMENT_TYPE, TO_CHAR(t.SETTLEMENT_TYPE_ID)) AS settlement_type,
       COUNT(*) AS trades_cnt,
       AVG(t.YIELD) AS avg_yield,
       SUM(t.SETTLEMENT_AMOUNT) AS settlement_amount
FROM ATS.TRADES t
JOIN ATS.SYMBOLS s       ON s.SYMBOL_ID = t.SYMBOL_ID
JOIN ATS.SYMBOL_TYPES st ON st.SYMBOL_TYPE_ID = s.SYMBOL_TYPE_ID
LEFT JOIN ATS.SETTLEMENT_TYPES sty ON sty.SETTLEMENT_TYPE_ID = t.SETTLEMENT_TYPE_ID
CROSS JOIN ytd
WHERE t.ENTRY_DATETIME >= ytd.y0
  AND UPPER(st.SYMBOL_TYPE) LIKE 'BOND%'
GROUP BY NVL(sty.SETTLEMENT_TYPE, TO_CHAR(t.SETTLEMENT_TYPE_ID))
ORDER BY settlement_amount DESC
FETCH FIRST 200 ROWS ONLY;
```

### 18) Rejected Orders — daily counts by reason (last 30 days)

Question: For the last 30 days, show daily counts of rejected orders grouped by human-readable rejection reason.

```sql
-- Rejected orders by reason (last 30 days)
SELECT
  TRUNC(ro.entry_datetime) AS day,
  NVL(r.description, TO_CHAR(ro.rejection_id)) AS rejection_reason,
  COUNT(*) AS rejected_orders
FROM ATS.REJECTED_ORDERS ro
LEFT JOIN ATS.REJECTIONS r
  ON r.rejection_id = ro.rejection_id
WHERE ro.entry_datetime >= TRUNC(SYSDATE) - 30
GROUP BY TRUNC(ro.entry_datetime),
         NVL(r.description, TO_CHAR(ro.rejection_id))
ORDER BY day DESC, rejected_orders DESC
FETCH FIRST 200 ROWS ONLY;
```
### 19) Settlement Levies — totals by levy type (last 90 days)

Question: Show total levy amount and record counts by levy type for the past 90 days.

```sql
-- Settlement levy totals by type (last 90 days)
SELECT
  COALESCE(lt.description, lt.code) AS levy_type,
  SUM(s.levy_amount)                AS total_levy_amount,
  COUNT(*)                          AS records
FROM ATS.SETTLEMENT_LEVY_DATA s
LEFT JOIN ATS.LEVIES      l  ON l.levy_id = s.levy_id
LEFT JOIN ATS.LEVY_TYPES  lt ON lt.id     = l.levy_type_id
WHERE s.transaction_date >= TRUNC(SYSDATE) - 90
GROUP BY COALESCE(lt.description, lt.code)
ORDER BY total_levy_amount DESC
FETCH FIRST 200 ROWS ONLY;
```

### 20) Settlement Levies — top clients by levy amount (this quarter)

Question: List the top clients by total levy amount in the current quarter.

```sql
-- Top clients by levy amount (this quarter)
WITH this_q AS (SELECT TRUNC(SYSDATE, 'Q') AS qstart FROM dual)
SELECT
  NVL(c.name, TO_CHAR(s.client_id)) AS client_name,
  SUM(s.levy_amount)                AS total_levy_amount,
  COUNT(*)                          AS records
FROM ATS.SETTLEMENT_LEVY_DATA s
JOIN this_q q ON 1=1
LEFT JOIN ATS.EDS_CLIENTS c ON c.client_id = s.client_id
WHERE s.transaction_date >= q.qstart
GROUP BY NVL(c.name, TO_CHAR(s.client_id))
ORDER BY total_levy_amount DESC
FETCH FIRST 200 ROWS ONLY;
```


### 21) Levy Log — daily levy by market & side (last 30 days)

Question: Show daily levy totals from the levy log for the last 30 days, grouped by market and side (label nulls as ‘UNSPECIFIED’).

```sql
-- Daily levy totals by market & side (last 30 days)
SELECT
  TRUNC(d.transaction_date) AS day,
  COALESCE(d.market, 'UNSPECIFIED')   AS market,
  COALESCE(d.buy_sell, 'UNSPECIFIED') AS buy_sell,
  SUM(d.levy_amount) AS sum_levy_amount,
  AVG(d.levy_amount) AS avg_levy_amount,
  COUNT(*)           AS rows_cnt
FROM ATS.ATS_LEVY_DATA_LOG d
WHERE d.transaction_date >= TRUNC(SYSDATE) - 30
GROUP BY TRUNC(d.transaction_date),
         COALESCE(d.market, 'UNSPECIFIED'),
         COALESCE(d.buy_sell, 'UNSPECIFIED')
ORDER BY day DESC, sum_levy_amount DESC
FETCH FIRST 200 ROWS ONLY;
```
### 22) Levy Log — daily levy by reason (Textual description)

Question: 10 biggest trades rejected due to invalid client or invalid market, or invalid symbol

```sql
-- Top 10 biggest rejected orders due to invalid client, market, or symbol in the last 180 days
SELECT
    sym.SYMBOL AS symbol,
    ex.EXCHANGE_NAME AS exchange,
    c.NAME AS client_name,
    sb.BROKER_NAME AS broker_name,
    ro.VOLUME AS rejected_volume,
    ro.PRICE AS rejected_price,
    (ro.VOLUME * ro.PRICE) AS rejected_notional,
    r.DESCRIPTION AS rejection_reason,
    ro.ENTRY_DATETIME AS rejection_datetime
FROM ATS.REJECTED_ORDERS ro
JOIN ATS.REJECTIONS r ON r.REJECTION_ID = ro.REJECTION_ID
JOIN ATS.SYMBOLS sym ON sym.SYMBOL_ID = ro.SYMBOL_ID
JOIN ATS.EXCHANGES ex ON ex.EXCHANGE_ID = ro.EXCHANGE_ID
JOIN ATS.EDS_CLIENTS c ON c.CLIENT_ID = ro.CLIENT_ID
JOIN ATS.SUBSCRIBED_BROKERS sb ON sb.BROKER_ID = ro.BROKER_ID
WHERE ro.ENTRY_DATETIME >= TRUNC(SYSDATE) - 180 -- Defaulting to the last 180 days
  AND (r.DESCRIPTION) LIKE '%client is invalid%'
       OR (r.DESCRIPTION) LIKE '%market is invalid%'
       OR (r.DESCRIPTION) LIKE '%symbol is invalid%'
ORDER BY ro.VOLUME DESC, (ro.VOLUME * ro.PRICE) DESC
FETCH FIRST 10 ROWS ONLY
```

### 23) Repo — daily cash flow by exchange & leg (last 30 days)

Question: Show daily repo cash flow (sum of settlement amounts) by exchange and leg for the last 30 days. Also show repo type.

```sql
-- Daily repo cash flow by exchange & leg (last 30 days)
WITH w AS (
  SELECT
    TRUNC(rc.ENTRY_DATETIME) AS day,
    e.EXCHANGE_CODE          AS exchange,
    rc.LEG,
    rc.REPO_TYPE,
    rc.SETTLEMENT_AMOUNT
  FROM ATS.REPO_CONTRACTS rc
  JOIN ATS.EXCHANGES e
    ON e.EXCHANGE_ID = rc.EXCHANGE_ID
  WHERE rc.ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
)
SELECT
  w.day,
  w.exchange,
  w.LEG,
  w.REPO_TYPE,
  ROUND(SUM(w.SETTLEMENT_AMOUNT), 2) AS cash_flow,
  COUNT(*)                            AS contracts
FROM w
GROUP BY w.day, w.exchange, w.LEG, w.REPO_TYPE
ORDER BY w.day DESC, cash_flow DESC
FETCH FIRST 200 ROWS ONLY;
```

### 24) Repo — active repos average rate & haircut by maturity bucket and symbol

Question: For active repo contracts today, show average repo rate and average haircut by maturity bucket and symbol.

```sql
-- Active repos: average repo rate & haircut by maturity bucket and symbol
WITH active AS (
  SELECT
    rc.SYMBOL_ID,
    rc.REPO_RATE,
    rc.REPO_HAIRCUT,
    rc.INITIAL_DATE,
    rc.TERMINATION_DATE
  FROM REPO_CONTRACTS rc
  WHERE rc.TERMINATION_DATE > SYSDATE
    AND rc.INITIAL_DATE IS NOT NULL
),
bucketed AS (
  SELECT
    s.SYMBOL,
    CASE
      WHEN (a.TERMINATION_DATE - a.INITIAL_DATE) <= 7  THEN '0–7d'
      WHEN (a.TERMINATION_DATE - a.INITIAL_DATE) <= 30 THEN '8–30d'
      WHEN (a.TERMINATION_DATE - a.INITIAL_DATE) <= 90 THEN '31–90d'
      ELSE '>90d'
    END AS MATURITY_BUCKET,
    a.REPO_RATE,
    a.REPO_HAIRCUT
  FROM active a
  JOIN SYMBOLS s
    ON s.SYMBOL_ID = a.SYMBOL_ID
)
SELECT
  b.MATURITY_BUCKET,
  b.SYMBOL,
  ROUND(AVG(b.REPO_RATE),   4) AS AVG_REPO_RATE,
  ROUND(AVG(b.REPO_HAIRCUT),4) AS AVG_HAIRCUT,
  COUNT(*)                    AS CONTRACT_LEGS
FROM bucketed b
GROUP BY b.MATURITY_BUCKET, b.SYMBOL
ORDER BY
  CASE b.MATURITY_BUCKET
    WHEN '0–7d' THEN 1
    WHEN '8–30d' THEN 2
    WHEN '31–90d' THEN 3
    ELSE 4
  END,
  b.SYMBOL
FETCH FIRST 200 ROWS ONLY

```

### 25) Repo — cancellations vs executed ratio by symbol (current quarter)

Question: For the current quarter, show symbols with most cancelled repo legs and their cancellation ratio versus executed legs.

```sql
-- Repo cancellations vs executed ratio by symbol (current quarter)
WITH q AS (SELECT TRUNC(SYSDATE, 'Q') AS qstart FROM dual),
execs AS (
  SELECT
    rc.SYMBOL_ID,
    COUNT(*) AS exec_legs
  FROM ATS.REPO_CONTRACTS rc
  JOIN q ON 1=1
  WHERE rc.ENTRY_DATETIME >= q.qstart
  GROUP BY rc.SYMBOL_ID
),
canc AS (
  SELECT
    cc.SYMBOL_ID,
    COUNT(*) AS cancelled_legs
  FROM ATS.REPO_CONTRACTS_CANCELLED cc
  JOIN q ON 1=1
  WHERE cc.ENTRY_DATETIME >= q.qstart
  GROUP BY cc.SYMBOL_ID
)
SELECT
  s.SYMBOL,
  NVL(canc.cancelled_legs, 0) AS cancelled_legs,
  NVL(execs.exec_legs, 0)     AS exec_legs,
  CASE
    WHEN NVL(canc.cancelled_legs, 0) + NVL(execs.exec_legs, 0) = 0 THEN 0
    ELSE ROUND(NVL(canc.cancelled_legs, 0) / (NVL(canc.cancelled_legs, 0) + NVL(execs.exec_legs, 0)), 4)
  END AS cancel_ratio
FROM (
  SELECT DISTINCT SYMBOL_ID FROM (
    SELECT SYMBOL_ID FROM ATS.REPO_CONTRACTS           WHERE ENTRY_DATETIME >= (SELECT qstart FROM q)
    UNION
    SELECT SYMBOL_ID FROM ATS.REPO_CONTRACTS_CANCELLED WHERE ENTRY_DATETIME >= (SELECT qstart FROM q)
  )
) ids
LEFT JOIN execs ON execs.SYMBOL_ID = ids.SYMBOL_ID
LEFT JOIN canc  ON canc.SYMBOL_ID  = ids.SYMBOL_ID
LEFT JOIN ATS.SYMBOLS s ON s.SYMBOL_ID = ids.SYMBOL_ID
ORDER BY cancelled_legs DESC, cancel_ratio DESC, s.SYMBOL
FETCH FIRST 100 ROWS ONLY;
```