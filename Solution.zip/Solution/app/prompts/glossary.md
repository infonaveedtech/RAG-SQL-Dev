# Glossary (ATS)

## Market data
- **turnover (daily)** — SUM(TURNOVER_VALUE) from ATS.SYMBOL_DAILY_INDICATORS.
- **trades_count (daily)** — SUM(TRADES_COUNT) from ATS.SYMBOL_DAILY_INDICATORS.
- **average price (daily)** — AVG(CLOSE_PRICE) from ATS.SYMBOL_DAILY_INDICATORS.
- **volume (intraday)** — SUM(VOLUME) from ATS.SYMBOL_INDICATORS.
- **turnover (intraday)** — SUM(VALUE) from ATS.SYMBOL_INDICATORS.
- **spread** — (OFFER_PRICE - BID_PRICE) from ATS.BEST_MKT.
- **mid** — (BID_PRICE + OFFER_PRICE) / 2 from ATS.BEST_MKT.
- **symbol label** — ATS.SYMBOLS.SYMBOL via SYMBOL_ID.
- **exchange label** — ATS.EXCHANGES.EXCHANGE_NAME via EXCHANGE_ID.

## Orders domain
- **orders (count)** — COUNT(*) from ATS.ORDERS.
- **order volume** — SUM(ORDERS.VOLUME).
- **notional (computed)** — SUM(ORDERS.VOLUME * ORDERS.PRICE); default metric for order amounts across instruments.
- **value (stored)** — SUM(ORDERS.VALUE); may include multipliers or accrued adjustments (especially for bonds).
- **average order price** — AVG(ORDERS.PRICE).


### Order classifications & lookups
- **side** — ORDERS.SIDE where 'B'=Buy, 'S'=Sell. Treat ORDERS.IS_SHORT as stringy boolean ('0'/'1').
- **flag (execution constraint)** — via ORDERS.FLAG_ID → ATS.FLAGS.FLAG_CODE (examples: IOC, FOK, GTC, GTD, SL, MIT, MF). Use FLAGS.DESC_ for descriptions.
- **order type** — via ORDERS.ORDER_TYPE → ATS.ORDER_TYPES.CODE (examples: Market, Limit, etc.).
- **order state** — via ORDERS.STATE → ATS.ORDER_STATES.STATE_CODE (examples: Submit, Received, Change, PartialFill, Fill, Cancel, Reject, Purge).
- **broker label** — ORDERS.BROKER_ID → ATS.SUBSCRIBED_BROKERS.BROKER_NAME.
- **client label** — ORDERS.CLIENT_ID → ATS.EDS_CLIENTS.NAME.
- **user/trader label** — ORDERS.USER_ID / ORDERS.TRADER_ID → ATS.USERS.USER_NAME (or COMPLETE_NAME).

### Time semantics for orders
- **default order date key** — ORDERS.ENTRY_DATETIME (order creation time).
- **state change timestamp** — ORDERS.STATE_TIME (use when the question is about lifecycle transitions).
- **TIF (time-in-force)** — ORDERS.TIF (DATE). When FLAG_CODE indicates GTD/GTC/IOC/FOK etc., treat TIF as expiry date (for GTD) or ignore for immediate policies (IOC/FOK).

### Fixed-income specifics
- **yield** — ORDERS.YIELD (mainly for bonds), average with AVG(YIELD).
- **accrued profit** — ORDERS.ACCRUED_PROFIT (accrued interest/amount component), sum with SUM(ACCRUED_PROFIT).
- Prefer filtering bond-only analytics using instrument metadata from ATS.SYMBOLS (e.g., CFI or SYMBOL_TYPE_ID) when required.

### Rejected orders

* **rejected orders (count)** — `COUNT(*)` from `ATS.REJECTED_ORDERS`; failed validations/routing attempts.
* **time semantics (rejected)**

  * **default rejected date key** — `REJECTED_ORDERS.ENTRY_DATETIME` (creation time of the rejected order).
  * **state change timestamp** — `REJECTED_ORDERS.STATE_TIME` (when the rejection state was recorded).
* **rejection reason (label)** — `REJECTED_ORDERS.REJECTION_ID → ATS.REJECTIONS.DESCRIPTION`.
* **participants & lookups (same as orders)**

  * **broker** — `REJECTED_ORDERS.BROKER_ID → ATS.SUBSCRIBED_BROKERS.BROKER_NAME`
  * **client** — `REJECTED_ORDERS.CLIENT_ID → ATS.EDS_CLIENTS.NAME` (fallback: `CLIENT_CODE`)
  * **user/trader** — `REJECTED_ORDERS.USER_ID / TRADER_ID → ATS.USERS.USER_NAME` (or `COMPLETE_NAME`)
  * **symbol** — `REJECTED_ORDERS.SYMBOL_ID → ATS.SYMBOLS.SYMBOL`
  * **exchange** — `REJECTED_ORDERS.EXCHANGE_ID → ATS.EXCHANGES.EXCHANGE_NAME`
* **typical joins (rejected)**

  | Context    | Join logic                                                 |
  | ---------- | ---------------------------------------------------------- |
  | **Reason** | `REJECTED_ORDERS.REJECTION_ID = REJECTIONS.REJECTION_ID`   |
  | **Broker** | `REJECTED_ORDERS.BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID` |
  | **Client** | `REJECTED_ORDERS.CLIENT_ID = EDS_CLIENTS.CLIENT_ID`        |
  | **Symbol** | `REJECTED_ORDERS.SYMBOL_ID = SYMBOLS.SYMBOL_ID`            |

## Rejections (lookup)
- Table: REJECTIONS(REJECTION_ID, DESCRIPTION)
- Join rule: When showing or filtering reasons for rejected orders, ALWAYS join to REJECTIONS on REJECTED_ORDERS.REJECTION_ID = REJECTIONS.REJECTION_ID and project REJECTIONS.DESCRIPTION as "rejection_reason".
- Matching rule: If user asks by reason text (e.g., "short sale"), filter WHERE UPPER(REJECTIONS.DESCRIPTION) LIKE '%SHORT%' AND '%SALE%' rather than relying on numeric codes.
- Canonical examples:
  - Code 22 → "Short sale is NOT allowed."
  - Use Code first, Its shared down, otherwise use Textual Description

### Rejection keyword cues (non-exhaustive)
- short sale → '%short%' AND '%sale%'  (code 22)
- invalid client → '%specified client is invalid%' (code 2)
- invalid exchange → '%specified exchange is invalid%' (code 3)
- invalid market → '%specified market is invalid%' (code 4)
- invalid symbol → '%specified symbol is invalid%' (code 5)
- user suspended → '%user placing orders is suspended%' (code 10)
- not multiple of board lot → '%multiple of board lot%' (codes 11, 27, 75)
- not multiple of tick size → '%multiple of tick size%' (codes 12, 63)
- price not in valid range → '%price is not in the valid range%' (codes 13, 86)
- volume exceeds upper limit → '%volume exceeds volume upper limit%' (14)
- value exceeds upper limit → '%value exceeds value upper limit%' (16)
- no opposite side for market order → '%no opposite side for a market order%' (19, 82)
- dynamic circuit breaker → '%dynamic circuit breaker%' (93, 96)


## Trades domain

### Core trade metrics

* **trades (count)** — `COUNT(*)` from `ATS.TRADES`.
* **trade notional** — `SUM(TRADES.VALUE)` or `SUM(TRADES.PRICE * TRADES.VOLUME)`.
* **settlement amount** — `TRADES.SETTLEMENT_AMOUNT`; the post-accrued amount due after pricing.
* **dirty price** — `TRADES.DIRTY_PRICE`; the price inclusive of accrued interest (bonds only).
* **repurchase price** — `TRADES.REPURCHASE_PRICE`; relevant for repo/leg trades.
* **remaining volume** — buyer/seller remaining quantity after fill (ideally 0 post-trade).
* **trade type** — via `TRADES.TRADE_TYPE` (numeric; local to system).
* **state** — via `TRADES.STATE_ID → ATS.TRADE_STATES.STATE_LABEL` (e.g. Normal, Repriced).

### Participants & lookups

* **buyer/seller client** — `TRADES.BUYER_CLIENT_ID`, `TRADES.SELLER_CLIENT_ID → ATS.EDS_CLIENTS.NAME`.
* **buyer/seller broker** — `TRADES.BUYER_BROKER_ID`, `TRADES.SELLER_BROKER_ID → ATS.SUBSCRIBED_BROKERS.BROKER_NAME`.
* **buyer/seller user** — `TRADES.BUYER_USER_ID`, `TRADES.SELLER_USER_ID → ATS.USERS.COMPLETE_NAME`.
* **symbol lookup** — `TRADES.SYMBOL_ID → ATS.SYMBOLS.SYMBOL`.
* **exchange lookup** — `TRADES.EXCHANGE_ID → ATS.EXCHANGES.EXCHANGE_CODE`.
* **settlement type** — via `TRADES.SETTLEMENT_TYPE_ID → ATS.SETTLEMENT_TYPES.SETTLEMENT_TYPE_NAME`.

### Time semantics (Trades)

* **trade timestamp** — `TRADES.ENTRY_DATETIME`.
* **contract duration** — `TRADES.INITIAL_DATE` → `TRADES.TERMINATION_DATE`.
* **leg** — `TRADES.LEG`; identifies legs in repo or structured deals.

### Bond-specific trade fields

* **yield** — `TRADES.YIELD`; annualized bond yield (numeric).
* **accrued profit** — `TRADES.ACCRUED_PROFIT`; accrued interest component.
* **dirty price** — as above; `PRICE + accrued_interest`.

### Typical joins (Trades)

| Context             | Join logic                                                                                 |
| ------------------- | ------------------------------------------------------------------------------------------ |
| **Client**          | `BUYER_CLIENT_ID/SELLER_CLIENT_ID = EDS_CLIENTS.CLIENT_ID`                                 |
| **Broker**          | `BUYER_BROKER_ID/SELLER_BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID`                          |
| **User**            | `BUYER_USER_ID/SELLER_USER_ID = USERS.USER_ID`                                             |
| **Symbol/Market**   | `(SYMBOL_ID, MARKET_ID, EXCHANGE_ID) = SYMBOL_MARKETS.(SYMBOL_ID, MARKET_ID, EXCHANGE_ID)` |
| **Exchange**        | `EXCHANGE_ID = EXCHANGES.EXCHANGE_ID`                                                      |
| **Settlement Type** | `SETTLEMENT_TYPE_ID = SETTLEMENT_TYPES.SETTLEMENT_TYPE_ID`                                 |

---

## Cancelled trades

* **cancelled trades** — records from `ATS.CANCELLED_TRADES`; similar schema to `TRADES` but with cancellation info.
* **cancellation timestamp** — `CANCELLED_TRADES.CANCELLATION_DATETIME`.
* **trade timestamp** — `CANCELLED_TRADES.TRADE_DATETIME`.
* **joinable key** — typically by `(BUYER_ORDER_NO, SELLER_ORDER_NO, EXCHANGE_ID)` to `TRADES`.
* **use case** — helps identify trades reversed after execution.

---
## Repo domain

### Core repo metrics

* **repo contracts (count)** — `COUNT(*)` from `ATS.REPO_CONTRACTS`; active and settled repo contract legs.
* **repo contracts (cancelled)** — `COUNT(*)` from `ATS.REPO_CONTRACTS_CANCELLED`; contracts voided prior to maturity.
* **repo log events (count)** — `COUNT(*)` from `ATS.REPO_LOG`; trade/order-level events tied to repo contracts.
* **repo cash flow (daily)** — `SUM(REPO_CONTRACTS.SETTLEMENT_AMOUNT)` grouped by `TRUNC(ENTRY_DATETIME)` and `EXCHANGE_ID`.
* **repo notional** — `SUM(REPO_CONTRACTS.PRICE * REPO_CONTRACTS.VOLUME)` or use `SETTLEMENT_AMOUNT` if available.
* **repo rate** — `AVG(REPO_CONTRACTS.REPO_RATE)`; effective interest for the financing leg.
* **haircut (discount)** — `AVG(REPO_CONTRACTS.REPO_HAIRCUT)`; percentage difference between collateral value and cash provided.
* **accrued profit / yield** — `SUM(REPO_CONTRACTS.ACCRUED_PROFIT)` / `AVG(REPO_CONTRACTS.YIELD)`.

### Structural concepts

* **leg** — `REPO_CONTRACTS.LEG` (1 = initial leg / sell, 2 = repurchase leg / buy-back).
* **repo type** — `REPO_CONTRACTS.REPO_TYPE` where `BuyBack` and `SellBack` reflect each party’s perspective.
* **contract number** — `REPO_CONTRACTS.CONTRACT_NO`; pair identifier joining the two legs (e.g., `153685_153686`).
* **initial & termination dates** — `INITIAL_DATE`, `TERMINATION_DATE`; define repo duration (maturity buckets 0–7 d, 8–30 d, 31–90 d, > 90 d).
* **repurchase price / settlement amount** — closing-leg cash value (`REPURCHASE_PRICE`, `REPURCHASE_SETTLEMENT_AMOUNT`).
* **state / lifecycle** — `TRADE_STATE` / `STATE_ID` indicate current lifecycle (Normal, Repriced, Substituted, Cancelled).
* **processed flag** — `IS_PROCESSED` marks ingestion status within post-trade pipelines.

### Participants & lookups

* **buyer/seller client** — `BUYER_CLIENT_ID`, `SELLER_CLIENT_ID → ATS.EDS_CLIENTS.NAME`.
* **buyer/seller broker** — `BUYER_BROKER_ID`, `SELLER_BROKER_ID → ATS.SUBSCRIBED_BROKERS.BROKER_NAME`.
* **buyer/seller user** — `BUYER_USER_ID`, `SELLER_USER_ID → ATS.USERS.COMPLETE_NAME`.
* **symbol** — `SYMBOL_ID → ATS.SYMBOLS.SYMBOL`.
* **exchange** — `EXCHANGE_ID → ATS.EXCHANGES.EXCHANGE_CODE`.
* **market** — `MARKET_ID → ATS.MARKETS.MARKET_CODE`.
* **settlement type** — `SETTLEMENT_TYPE_ID → ATS.SETTLEMENT_TYPES.SETTLEMENT_TYPE_NAME`.

### Time semantics (Repos)

* **repo timestamp (contracts)** — `REPO_CONTRACTS.ENTRY_DATETIME`.
* **repo timestamp (log)** — `REPO_LOG.ENTRY_DATETIME`.
* **initial vs termination** — use `INITIAL_DATE` and `TERMINATION_DATE` for maturity or duration calculations.
* **cancelled timestamp** — `REPO_CONTRACTS_CANCELLED.ENTRY_DATETIME`.

### Typical joins (Repos)

| Context               | Join logic                                                                       |
| --------------------- | -------------------------------------------------------------------------------- |
| **Log → Contract**    | `REPO_LOG.CONTRACT_ID = REPO_CONTRACTS.CONTRACT_NO`                              |
| **Leg pairing**       | `REPO_CONTRACTS.CONTRACT_NO` shared by `LEG=1` and `LEG=2`                       |
| **Symbol label**      | `REPO_CONTRACTS.SYMBOL_ID = SYMBOLS.SYMBOL_ID`                                   |
| **Exchange label**    | `REPO_CONTRACTS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID`                             |
| **Client/Broker**     | `REPO_CONTRACTS.BUYER_CLIENT_ID/SELLER_CLIENT_ID → EDS_CLIENTS.CLIENT_ID`        |
|                       | `REPO_CONTRACTS.BUYER_BROKER_ID/SELLER_BROKER_ID → SUBSCRIBED_BROKERS.BROKER_ID` |
| **User label**        | `REPO_CONTRACTS.BUYER_USER_ID/SELLER_USER_ID → USERS.USER_ID`                    |
| **Cancelled mapping** | `REPO_CONTRACTS.CONTRACT_NO = REPO_CONTRACTS_CANCELLED.CONTRACT_NO`              |

### Derived measures & analytics

| Metric                     | Expression / Comment                                            |
| -------------------------- | --------------------------------------------------------------- |
| **Repo notional (by leg)** | `PRICE * VOLUME`                                                |
| **Repo cash flow (daily)** | `SUM(SETTLEMENT_AMOUNT)` grouped by `TRUNC(ENTRY_DATETIME)`     |
| **Average repo rate**      | `AVG(REPO_RATE)`                                                |
| **Average haircut**        | `AVG(REPO_HAIRCUT)`                                             |
| **Outstanding repos**      | filter `TERMINATION_DATE > SYSDATE`                             |
| **Cancelled ratio**        | cancelled / (total executed + cancelled) per symbol or exchange |

### Notes

* Repos represent *secured financing*; leg 1 and leg 2 mirror each other.
* `BuyBack` legs imply cash → collateral, `SellBack` imply collateral → cash.
* Always group or aggregate symmetrically across both legs for volume-based analytics.
* When joining to other trade domains, align by `SYMBOL_ID`, `EXCHANGE_ID`, and date.

---

## Negotiated trades

* **negotiated trades** — from `ATS.NEGOTIATED_TRADES`.
* **core linkage** — `ORDER_NO` or `COUNTER_ORDER_NO` join to `ORDERS.ORDER_NO`.
* **negotiated state** — `NEGOTIATED_STATE` and `NEGOTIATED_STATUS` fields indicate lifecycle state.
* **participants** — `CLIENT_ID`, `COUNTER_CLIENT_ID`, `BROKER_ID`, `COUNTER_BROKER_ID`.
* **pricing semantics** — `PRICE`, `YIELD`, `ACCRUED_PROFIT`, and `VALUE` same as in trades.
* **used for** — pre-trade bilateral negotiation records before final trade settlement.

---

## Levies domain

### Core levy facts & metrics

* **levy amount (settlement)** — `SUM(SETTLEMENT_LEVY_DATA.LEVY_AMOUNT)`; settled/posted charges.
* **levy amount (log)** — `SUM(ATS_LEVY_DATA_LOG.LEVY_AMOUNT)`; operational/log view, may include entries without market/side.
* **records (count)** — `COUNT(*)` from either source as appropriate.
* **buy/sell & market (log)** — use `ATS_LEVY_DATA_LOG.BUY_SELL` and `MARKET` for trading-context pivots; label missing values as `'UNSPECIFIED'` in outputs when needed.

### Participants & lookups

* **levy** — `*_LEVY_* .LEVY_ID → ATS.LEVIES.LEVY_ID`
* **levy type** — `LEVIES.LEVY_TYPE_ID → ATS.LEVY_TYPES.(ID, CODE, DESCRIPTION)` (prefer `DESCRIPTION`, fallback `CODE`)
* **broker** — `*_LEVY_* .BROKER_ID → ATS.SUBSCRIBED_BROKERS.BROKER_ID`
* **client (settlement)** — `SETTLEMENT_LEVY_DATA.CLIENT_ID → ATS.EDS_CLIENTS.CLIENT_ID`

### Time semantics (Levies)

* **default levy date key (settlement)** — `SETTLEMENT_LEVY_DATA.TRANSACTION_DATE`
* **default levy date key (log)** — `ATS_LEVY_DATA_LOG.TRANSACTION_DATE`
* **entry timestamp** — `*_LEVY_* .LEVY_ENTRY_DATE` (when the row was inserted/logged)

### Configuration tables (for slabs/eligibility)

* **levy config** — `ATS.LEVY_INFO` (`VALUE_TYPE` = `FIXED`/`PERCENT`, `VALUE`, optional `MIN_VALUE`/`MAX_VALUE`, `PERCENT_OFF`)
* **levy ranges (slabs)** — `ATS.LEVY_RANGES` (`RANGE_FROM/TO`, `VALUE_TYPE`, `FIXED_RATE`, `PERCENT`, links to criteria)
* **criteria** — `ATS.LEVY_CRITERIA` (`ID`, `CRITERIA_CODE` such as `DAYS`, `REPO_DAYS`, `VALUE`, `REC_COUNT`)
* **member types** — `ATS.LEVY_MEMBER_TYPES` (mapping to `BROKER_TYPES`)
* **securities applicability** — `ATS.LEVY_SECURITIES` (by `BOND_TYPE_ID` / `BOND_CATEGORY_ID`)

### Typical joins (Levies)

| Context                 | Join logic                                                                 |
| ----------------------- | -------------------------------------------------------------------------- |
| **Type label**          | `*_LEVY_* .LEVY_ID = LEVIES.LEVY_ID → LEVY_TYPES.ID = LEVIES.LEVY_TYPE_ID` |
| **Client (settlement)** | `SETTLEMENT_LEVY_DATA.CLIENT_ID = EDS_CLIENTS.CLIENT_ID`                   |
| **Broker**              | `*_LEVY_* .BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID`                       |
| **Slab criteria**       | `LEVY_RANGES.LEVY_CRITERIA = LEVY_CRITERIA.ID`                             |
| **Levy one-to-one**     | `LEVY_INFO.LEVY_ID = LEVIES.LEVY_ID`                                       |

> Note: if a question is purely about configuration (e.g., “slabs for levy X”), favor `LEVIES + LEVY_RANGES (+ LEVY_CRITERIA)`; for amounts, use `SETTLEMENT_LEVY_DATA` (client/broker ready) or `ATS_LEVY_DATA_LOG` (operational view).


## Instrument & market context

* **instrument type** — `SYMBOLS.SYMBOL_TYPE_ID → SYMBOL_TYPES.SYMBOL_TYPE_NAME` (e.g. Bond, Equities).
* **symbol to exchange/market** — via `SYMBOL_MARKETS`.
* **currency** — `SYMBOLS.CURRENCY_ID → CURRENCY.CURRENCY_CODE`.

## Joins (labels & market context)
- **instrument** — ORDERS.SYMBOL_ID = SYMBOLS.SYMBOL_ID
- **exchange** — ORDERS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID
- **market triple (canonical)** — (ORDERS.SYMBOL_ID, EXCHANGE_ID, MARKET_ID) = SYMBOL_MARKETS.(SYMBOL_ID, EXCHANGE_ID, MARKET_ID)
- **flags** — ORDERS.FLAG_ID = FLAGS.FLAG_ID
- **order types** — ORDERS.ORDER_TYPE = ORDER_TYPES.ID
- **states** — ORDERS.STATE = ORDER_STATES.STATE_ID
- **brokers** — ORDERS.BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID
- **clients** — ORDERS.CLIENT_ID = EDS_CLIENTS.CLIENT_ID
- **users/traders** — ORDERS.USER_ID = USERS.USER_ID, ORDERS.TRADER_ID = USERS.USER_ID

## Time grains & limits
- **time grains allowed (v2)** — day, month, year (no intraday bucketing by default; keep result sets bounded with FETCH FIRST <N> ROWS ONLY).

## Date keys by source
- **daily indicators** — ATS.SYMBOL_DAILY_INDICATORS.STATS_DATE
- **intraday indicators** — ATS.SYMBOL_INDICATORS.ENTRY_DATETIME
- **best market** — ATS.BEST_MKT.ENTRY_DATETIME
- **orders** — ATS.ORDERS.ENTRY_DATETIME (default) and ATS.ORDERS.STATE_TIME (state changes)
* **rejected orders** — `ATS.REJECTED_ORDERS.ENTRY_DATETIME` (default) and `ATS.REJECTED_ORDERS.STATE_TIME` (state changes)
* **levies (settlement)** — `ATS.SETTLEMENT_LEVY_DATA.TRANSACTION_DATE`
* **levies (log)** — `ATS.ATS_LEVY_DATA_LOG.TRANSACTION_DATE`