from __future__ import annotations
import os
import re
from typing import Optional

import google.generativeai as genai


def _extract_sql_block(text: str) -> Optional[str]:
    """Grab the first ```sql ... ``` fenced block, else return None."""
    m = re.search(r"```sql\s*(.*?)```", text, flags=re.S | re.I)
    return m.group(1).strip() if m else None


# ... keep your existing imports and code ...

def generate_sql_gemini(pack: dict, question: str, repair_error: str | None = None) -> str | None:
    api_key = os.getenv("GEMINI_API_KEY")
    model_name = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    if not api_key:
        return None

    import google.generativeai as genai
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(model_name)

    system = pack["system"]; schema = pack["schema"]
    fewshots = pack["fewshots"]; glossary = pack.get("glossary", "")

    task = f"User question: {question}"
    if repair_error:
        task += f"\n\nFix prior SQL error (keep intent):\n{repair_error}"

    prompt = (
        f"{system}\n\n[Schema Card]\n{schema}\n\n[Glossary]\n{glossary}\n\n"
        f"[Few-shots]\n{fewshots}\n\n[Task]\n{task}\n"
    )

    resp = model.generate_content(prompt)
    text = ""
    if hasattr(resp, "text") and resp.text:
        text = resp.text
    elif getattr(resp, "candidates", None):
        parts = getattr(resp.candidates[0], "content", None)
        if parts and getattr(parts, "parts", None):
            text = "".join(getattr(p, "text", "") for p in parts.parts if getattr(p, "text", None))
    if not text:
        raise RuntimeError("Gemini returned empty response")

    m = re.search(r"```sql\s*(.*?)```", text, flags=re.S | re.I)
    sql = (m.group(1).strip() if m else text.strip()) or None
    if not sql:
        raise RuntimeError("Could not extract SQL from Gemini response")
    return sql

