from __future__ import annotations
import os, re, json, requests
from textwrap import dedent
from typing import Optional, Dict

# Same Ollama endpoint; model chosen per request
OLLAMA_URL = os.getenv("OLLAMA_GENERATE_URL", "http://localhost:11434/api/generate")
GPTOSS_MODEL = os.getenv("OLLAMA_GPTOSS_MODEL", "gpt-oss:20b")

# Tweakables
GPTOSS_TEMPERATURE = float(os.getenv("GPTOSS_TEMPERATURE", "0.1"))

# Timeouts: (connect timeout, read timeout)
# Give the server longer for big models / cold starts
CONNECT_TIMEOUT = int(os.getenv("LLM_CONNECT_TIMEOUT", "10"))
READ_TIMEOUT    = int(os.getenv("LLM_READ_TIMEOUT", "300"))   # was 120

# To avoid runaway generations; SQL is short
NUM_PREDICT = int(os.getenv("GPTOSS_NUM_PREDICT", "768"))

# Keep the model hot between calls (saves load time)
KEEP_ALIVE = os.getenv("OLLAMA_KEEP_ALIVE", "5m")  # e.g., "5m", "30m", or "0" to disable

# top-level (replace your _SQL_FENCE and _extract_sql)

_SQL_FENCE_ANY = re.compile(
    r"(?:^[ \t]*```(?:sql)?[ \t]*\n?|\Z)(.*?)(?:\n?[ \t]*```[ \t]*$|\Z)",
    re.IGNORECASE | re.DOTALL | re.MULTILINE,
)

def _extract_sql(text: str) -> str:
    """
    Robustly extract the first SQL block:
    - prefer fenced ```sql ... ``` (any case, any indentation)
    - else take the first statement that starts with SELECT/WITH and ends with ';'
    - strip stray backticks/quotes, ensure exactly ONE trailing semicolon
    """
    t = (text or "").strip()

    # 1) Try any fenced block (```sql or ```), take the first group
    m = _SQL_FENCE_ANY.search(t)
    if m:
        candidate = m.group(1).strip()
    else:
        # 2) Fallback to a rough SELECT/WITH slice up to the first semicolon
        m2 = re.search(r"(?is)\b(SELECT|WITH)\b.*?;", t)
        candidate = (m2.group(0) if m2 else t).strip()

    # 3) Remove any lingering fences/backticks/quotes
    candidate = re.sub(r"^[`\"']+|[`\"']+$", "", candidate).strip()

    # 4) Ensure one trailing semicolon
    candidate = candidate.rstrip(";") + ";"

    return candidate

def _build_prompt(pack: Dict[str, str], question: str, repair_hint: Optional[str]) -> str:
    system   = (pack.get("system")   or "").strip()
    schema   = (pack.get("schema")   or "").strip()
    fewshots = (pack.get("fewshots") or "").strip()
    glossary = (pack.get("glossary") or "").strip()

    sections = [
        "# System Instructions", system, "",
        "# Schema Card", schema, "",
        "# Few-shot SQL Exemplars", fewshots,
    ]
    if glossary:
        sections += ["", "# Domain Glossary", glossary]

    sections += [
        "",
        "# Task",
        dedent("""\
        You are a senior Oracle SQL analyst. Write exactly **one** Oracle-compatible SQL query
        that best answers the user question. Use only the allowed schema from the Schema Card.
        Respect safety constraints and row limits provided in the System Instructions.
        Answer directly without explaining or very minimal reasoning step-by-step: 
        """).strip(),
        "",
        f"User question:\n{question.strip()}",
    ]
    if repair_hint:
        sections += ["", "## Repair Hint (from validator)", repair_hint.strip()]

    sections += [
    "",
    "## Output format (STRICT)",
    "Return only ONE complete SQL statement inside a fenced block. It must include SELECT ... FROM ... and end with a semicolon.",
    "```sql",
    "SELECT 1 FROM DUAL FETCH FIRST 10 ROWS ONLY;",
    "```",
    ]

    return "\n".join(sections)

def _stream_ollama(payload: dict) -> str:
    """
    Stream chunks from Ollama and assemble the full text.
    Ollama streams NDJSON lines: each line is a JSON object with a 'response' fragment.
    """
    with requests.post(
        OLLAMA_URL,
        json=payload,
        stream=True,
        timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
    ) as resp:
        resp.raise_for_status()
        parts: list[str] = []
        for line in resp.iter_lines(decode_unicode=True):
            if not line:
                continue
            # Some proxies can add junk; ignore non-JSON lines
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            chunk = obj.get("response")
            if chunk:
                parts.append(chunk)
            # Stop early if the model signals done
            if obj.get("done"):
                break
        return "".join(parts)

def generate_sql_gptoss(prompt_pack: Dict[str, str], question: str, repair_hint: Optional[str] = None) -> str:
    prompt = _build_prompt(prompt_pack, question, repair_hint)

    payload = {
        "model": GPTOSS_MODEL,
        "prompt": prompt,
        "stream": True,               # <-- stream to avoid long single-read timeouts
        "keep_alive": KEEP_ALIVE,     # <-- keep model in memory for faster subsequent calls
        "options": {
            "temperature": GPTOSS_TEMPERATURE,
            "num_predict": NUM_PREDICT,  # cap output length (SQL is short)
            # You can add: "num_ctx": 4096 or 8192 if your prompt is very large
        },
    }

    # Helpful for debugging which model actually ran:
    print(f"[gpt-oss] POST {OLLAMA_URL} model={GPTOSS_MODEL} stream=True keep_alive={KEEP_ALIVE}")

    try:
        text = _stream_ollama(payload)
        if not text:
            raise RuntimeError("gpt-oss returned empty response")
        sql = _extract_sql(text)
        if not sql:
            # Last resort: sometimes models print SQL without fences
            sql = _extract_sql("```sql\n" + text.strip() + "\n```")
        if not sql:
            raise RuntimeError("Could not extract SQL from gpt-oss response")
        return sql
    except requests.RequestException as e:
        raise RuntimeError(f"gpt-oss generation failed: {e}") from e
