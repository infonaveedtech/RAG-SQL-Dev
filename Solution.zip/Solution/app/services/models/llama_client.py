from __future__ import annotations
import os
import json
import requests
from typing import Optional, Dict


# Ollama endpoint + defaults (Windows-friendly; same as mac/linux)
OLLAMA_GENERATE_URL = os.getenv("OLLAMA_GENERATE_URL", "http://localhost:11434/api/generate")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
LLAMA_TEMPERATURE = float(os.getenv("LLAMA_TEMPERATURE", "0.0"))
LLM_TIMEOUT = int(os.getenv("LLM_TIMEOUT", "120"))  # seconds


def _json_prompt(pack: dict, question: str, repair_error: Optional[str]):
    system_text = (pack.get("system") or "").strip()

    schema   = (pack.get("schema") or "").strip()
    glossary = (pack.get("glossary") or "").strip()
    fewshots = (pack.get("fewshots") or "").strip()

    # User message (instructions structured for better grounding)
    user_prompt = f"""
You are an Oracle SQL analyst. Convert the user's request into a single, safe, read-only SQL query.

Rules:
1) Use ONLY tables/columns from the schema.
2) Always join labels:
   - ATS.SYMBOLS for symbol name (never project *_ID)
   - ATS.EXCHANGES only if exchange is requested
3) Prefer SYMBOL_DAILY_INDICATORS for OHLC/trades metrics:
   OPEN_PRICE, HIGH_PRICE, LOW_PRICE, CLOSE_PRICE, TRADES_COUNT.
4) Do NOT invent joins (avoid BEST_MKT unless the user asks about spreads).
5) End with FETCH FIRST {{ROW_LIMIT}} ROWS ONLY if no limit given.
6) Output must be valid Oracle SQL (SELECT / WITH ... SELECT).
7) Each CTE can only reference tables, not columns from previous CTEs.
   If you need constants (like date ranges), select them from the CTE in a scalar subquery
   or join to it in the main query (CROSS JOIN bounds b ...).

[SCHEMA]
{schema}

[GLOSSARY]
{glossary}

[FEWSHOTS]
{fewshots}

[USER QUESTION]
{question}

{f"[REPAIR] Fix prior SQL but keep intent: {repair_error}" if repair_error else ""}

Return ONLY a JSON object:
{{"sql": "<the SQL query>"}}
""".strip()

    return system_text, user_prompt


def _ollama_generate_json(system_text: str,prompt: str, model: str, temperature: float, timeout: int) -> Dict:
    payload = {
        "model": model,
        "prompt": prompt,
        'system':system_text,
        "format": "json",       # enforce JSON output
        "stream": False,
        "options": {"temperature": temperature},
    }
    resp = requests.post(OLLAMA_GENERATE_URL, json=payload, timeout=timeout)
    if resp.status_code >= 400:
        raise RuntimeError(f"Ollama error {resp.status_code}: {resp.text}")

    data = resp.json()
    text = (data.get("response") or "").strip()
    if not text:
        raise RuntimeError("Ollama returned empty response")
    return json.loads(text)


def generate_sql_llama(pack: dict, question: str, repair_error: str | None = None) -> Optional[str]:
    """
    Returns SQL string from local Ollama only.
    Expects Ollama to respond with: { "sql": "<...>" }.
    """
    system_text,prompt = _json_prompt(pack, question, repair_error)
    try:
        obj = _ollama_generate_json(system_text,prompt, OLLAMA_MODEL, LLAMA_TEMPERATURE, LLM_TIMEOUT)
        sql = obj.get("sql", "").strip()
        return sql or None
    except Exception as e:
        print(f"❌ Ollama failed: {e}")
        return None
