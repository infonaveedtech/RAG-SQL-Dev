
# app/services/models/router.py
from enum import Enum
from typing import Tuple, Optional, Dict

from app.services.models.gemini_client import generate_sql_gemini
from app.services.models.llama_client import generate_sql_llama            # v1 (pack, question, repair_hint)
from app.services.models.llama_client_v2 import generate_sql_llama_v2      # v2 (question, repair_error=None)
from app.services.models.gptoss_client import generate_sql_gptoss          # (pack, question, repair_hint)

class ModelStrategy(str, Enum):
    AUTO = "auto"
    GEMINI = "gemini"
    LLAMA = "llama"
    GPT_OSS = "gpt-oss"

def _call_gemini(pack: Dict[str, str], question: str, repair_hint: Optional[str]) -> str:
    # Your Gemini client already expects (pack, question, repair_hint) and returns a plain SQL string
    return generate_sql_gemini(pack, question, repair_hint)

def _call_llama(pack: Dict[str, str], question: str, repair_hint: Optional[str]) -> str:
    """
    Prefer schema-aware Llama v2 first (no pack argument!), then fall back to v1 which uses pack.
    """
    sql = generate_sql_llama_v2(question, repair_hint)  # <-- IMPORTANT: v2 signature (question, repair_error)
    if not sql:
        sql = generate_sql_llama(pack, question, repair_hint)  # v1 fallback uses pack
    if not sql:
        raise RuntimeError("Llama returned no SQL")
    return sql

def _call_gptoss(pack: Dict[str, str], question: str, repair_hint: Optional[str]) -> str:
    sql = generate_sql_gptoss(pack, question, repair_hint)
    if not sql:
        raise RuntimeError("gpt-oss returned no SQL")
    return sql

def generate_sql_by_strategy(
    strategy,                                # accepts str or ModelStrategy
    prompt_pack: Dict[str, str],
    question: str,
    repair_hint: Optional[str] = None
) -> Tuple[str, str]:

    # normalize user input (string or enum)
    try:
        strat = ModelStrategy(strategy)
    except ValueError:
        strat = ModelStrategy.AUTO

    if strat == ModelStrategy.GEMINI:
        return _call_gemini(prompt_pack, question, repair_hint), "gemini"

    if strat == ModelStrategy.LLAMA:
        return _call_llama(prompt_pack, question, repair_hint), "llama"

    if strat == ModelStrategy.GPT_OSS:
        return _call_gptoss(prompt_pack, question, repair_hint), "gpt-oss"

    # AUTO (keep existing order; change if you want gpt-oss earlier)
    try:
        return _call_gemini(prompt_pack, question, repair_hint), "gemini"
    except Exception:
        return _call_llama(prompt_pack, question, repair_hint), "llama"
