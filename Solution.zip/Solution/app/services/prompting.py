from __future__ import annotations
import os
import pathlib
from typing import Dict

PROMPTS_DIR = pathlib.Path("app/prompts")

SYSTEM_PATH = PROMPTS_DIR / "system_oracle.txt"
SCHEMA_PATH = PROMPTS_DIR / "schema_card.txt"
FEWSHOTS_PATH = PROMPTS_DIR / "fewshots.sql.md"
GLOSSARY_PATH = PROMPTS_DIR / "glossary.md"
SCHEMA_JSON_PATH  = PROMPTS_DIR / "schema_card.json"   # optional (Llama path)


def read_file(path: pathlib.Path, required: bool = True) -> str:
    if not path.exists():
        if required:
            raise FileNotFoundError(f"Prompt asset missing: {path}")
        return ""
    return path.read_text(encoding="utf-8").strip()

def _fill_placeholders(text: str, owner: str, row_limit: int) -> str:
    # simple placeholder replacement; safe no-ops if not present
    return (
        text
        .replace("{OWNER}", owner)
        .replace("{ROW_LIMIT}", str(row_limit))
    )

def load_prompt_pack(owner: str, row_limit: int) -> Dict[str, str]:
    """
    Load prompt assets into a dict. Backward-compatible keys:
      - system: system prompt text (placeholders filled)
      - schema: schema card text
      - fewshots: fewshot examples (markdown with fenced SQL)
      - glossary: glossary text (optional; '' if missing)
    """
    system = _fill_placeholders(read_file(SYSTEM_PATH), owner, row_limit)
    schema = read_file(SCHEMA_PATH)
    fewshots = read_file(FEWSHOTS_PATH)
    glossary = read_file(GLOSSARY_PATH, required=False)

    return {
        "system": system,
        "schema": schema,
        "fewshots": fewshots,
        "glossary": glossary,
    }
    
def load_prompt_pack_with_json(owner: str, row_limit: int) -> Dict[str, str]:
    """
    Same as load_prompt_pack but also returns (optionally) the JSON schema card
    under key 'schema_json' for the Llama flow. If the JSON file doesn't exist,
    'schema_json' is set to ''.
    """
    pack = load_prompt_pack(owner, row_limit)
    schema_json = read_file(SCHEMA_JSON_PATH, required=False)
    pack["schema_json"] = schema_json
    return pack

def assemble_system_message(pack: Dict[str, str]) -> str:
    """
    Compose a single system message string for the model by concatenating:
      system spec + SCHEMA CARD + (optional) GLOSSARY.
    Fewshots are typically sent as separate example messages; we do not inline them here.
    """
    parts = [pack.get("system", "")]
    schema = pack.get("schema", "")
    if schema:
        parts.append("\n\n--- SCHEMA CARD ---\n")
        parts.append(schema)
    glossary = pack.get("glossary", "")
    if glossary:
        parts.append("\n\n--- GLOSSARY ---\n")
        parts.append(glossary)
    return "".join(parts).strip()
