# app/build_schema_card_json.py
"""
Build a JSON Schema Card for NL→SQL prompting (Llama-friendly).

Reads env vars (.env):
  ORACLE_DSN, ORACLE_USER, ORACLE_PASSWORD, ORACLE_OWNER
Writes:
  app/prompts/schema_card.json

Scope (v3): ATS.SYMBOL_DAILY_INDICATORS, ATS.SYMBOL_INDICATORS, ATS.BEST_MKT,
            ATS.SYMBOLS, ATS.EXCHANGES,
            ATS.ORDERS, ATS.SYMBOL_MARKETS, ATS.FLAGS, ATS.ORDER_TYPES, ATS.ORDER_STATES,
            ATS.SUBSCRIBED_BROKERS, ATS.EDS_CLIENTS, ATS.USERS,
            ----New---- ATS.TRADES, ATS.CANCELLED_TRADES, ATS.NEGOTIATED_TRADES,
            ----New---- ATS.TRADE_STATES, ATS.SETTLEMENT_TYPES, ATS.SYMBOL_TYPES
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Tuple

import oracledb
from dotenv import load_dotenv

# --------------------------
# Config & enrichment (same as build_schema_card.py)
# --------------------------

OWNER_TABLES = [
    # existing stats scope
    "SYMBOL_DAILY_INDICATORS",
    "SYMBOL_INDICATORS",
    "BEST_MKT",
    "SYMBOLS",
    "EXCHANGES",

    # existing orders scope
    "ORDERS",
    "SYMBOL_MARKETS",
    "FLAGS",
    "ORDER_TYPES",
    "ORDER_STATES",
    "SUBSCRIBED_BROKERS",
    "EDS_CLIENTS",
    "USERS",

    # ----New---- trades scope
    "TRADES",
    "CANCELLED_TRADES",
    "NEGOTIATED_TRADES",

    # ----New---- extra lookups
    "TRADE_STATES",
    "SETTLEMENT_TYPES",
    "SYMBOL_TYPES",
    
        # ---- New (Repo) ----
    "REPO_CONTRACTS",
    "REPO_CONTRACTS_CANCELLED",
    "REPO_LOG",

    
]

NEW_TABLES = {
    "TRADES", "CANCELLED_TRADES", "NEGOTIATED_TRADES",
    "TRADE_STATES", "SETTLEMENT_TYPES", "SYMBOL_TYPES"
}

CATALOG = {
    "version": "stats+orders+trades-catalog-v3",
    "facts": {
        "SYMBOL_DAILY_INDICATORS": {
            "id": "SDI",
            "grain": "symbol_day",
            "date_key": "STATS_DATE",
            "measures": {
                "turnover": {"expr": "TURNOVER_VALUE", "agg": "SUM"},
                "avg_price": {"expr": "CLOSE_PRICE", "agg": "AVG"},
                "open": {"expr": "OPEN_PRICE", "agg": None},
                "high": {"expr": "HIGH_PRICE", "agg": None},
                "low": {"expr": "LOW_PRICE", "agg": None},
                "close": {"expr": "CLOSE_PRICE", "agg": None},
                "trades_count": {"expr": "TRADES_COUNT", "agg": "SUM"},
            },
            "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
        },
        "SYMBOL_INDICATORS": {
            "id": "SI",
            "grain": "symbol_timestamp",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "volume": {"expr": "VOLUME", "agg": "SUM"},
                "turnover": {"expr": "VALUE", "agg": "SUM"},
                "avg_price": {"expr": "CLOSE", "agg": "AVG"},
                "open": {"expr": "OPEN", "agg": None},
                "high": {"expr": "HIGH", "agg": None},
                "low": {"expr": "LOW", "agg": None},
                "close": {"expr": "CLOSE", "agg": None},
            },
            "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
        },
        "BEST_MKT": {
            "id": "BM",
            "grain": "symbol_timestamp",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "bid_price": {"expr": "BID_PRICE", "agg": "AVG"},
                "offer_price": {"expr": "OFFER_PRICE", "agg": "AVG"},
                "spread": {"expr": "OFFER_PRICE - BID_PRICE", "agg": "AVG"},
                "mid": {"expr": "(BID_PRICE + OFFER_PRICE)/2", "agg": "AVG"},
                "bid_volume": {"expr": "BID_VOLUME", "agg": "SUM"},
                "offer_volume": {"expr": "OFFER_VOLUME", "agg": "SUM"},
            },
            "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
        },
        "ORDERS": {
            "id": "O",
            "grain": "order_event",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "orders": {"expr": "*", "agg": "COUNT"},
                "volume": {"expr": "VOLUME", "agg": "SUM"},
                "notional_computed": {"expr": "VOLUME * PRICE", "agg": "SUM"},
                "value_stored": {"expr": "VALUE", "agg": "SUM"},
                "avg_price": {"expr": "PRICE", "agg": "AVG"},
                "avg_yield": {"expr": "YIELD", "agg": "AVG"},
                "accrued_profit": {"expr": "ACCRUED_PROFIT", "agg": "SUM"},
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "SIDE", "FLAG_ID", "ORDER_TYPE", "STATE",
                "CLIENT_ID", "BROKER_ID", "USER_ID", "TRADER_ID"
            ],
            "notes": [
                "Use ENTRY_DATETIME unless a different timestamp is specified (STATE_TIME for state changes).",
                "For generic notional, prefer SUM(VOLUME * PRICE). SUM(VALUE) may include multipliers (esp. bonds).",
                "SIDE is 'B'/'S'; IS_SHORT is a stringy boolean ('0'/'1').",
            ],
        },
        # ----New----
        "TRADES": {
            "id": "T",
            "grain": "trade_event",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "trades": {"expr": "*", "agg": "COUNT"},
                "volume": {"expr": "VOLUME", "agg": "SUM"},
                "notional_computed": {"expr": "PRICE * VOLUME", "agg": "SUM"},
                "settlement_amount": {"expr": "SETTLEMENT_AMOUNT", "agg": "SUM"},
                "avg_price": {"expr": "PRICE", "agg": "AVG"},
                "avg_dirty_price": {"expr": "DIRTY_PRICE", "agg": "AVG"},
                "avg_yield": {"expr": "YIELD", "agg": "AVG"},
                "accrued_profit": {"expr": "ACCRUED_PROFIT", "agg": "SUM"},
                "avg_repurchase_price": {"expr": "REPURCHASE_PRICE", "agg": "AVG"},
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "BUYER_CLIENT_ID", "SELLER_CLIENT_ID",
                "BUYER_BROKER_ID", "SELLER_BROKER_ID",
                "BUYER_USER_ID", "SELLER_USER_ID",
                "BUYER_TRADER_ID", "SELLER_TRADER_ID",
                "STATE_ID", "SETTLEMENT_TYPE_ID", "TRADE_TYPE", "IS_SHORT"
            ],
            "notes": [
                "TRADES has buyer_* and seller_* party columns; no explicit SIDE.",
                "DIRTY_PRICE is clean+accrued (primarily bonds). SETTLEMENT_AMOUNT is the cash consideration.",
                "Remaining volumes may be non-zero due to partial fills (do not assume zero).",
                "Use (SYMBOL_ID, MARKET_ID, EXCHANGE_ID) to join venue info via SYMBOL_MARKETS when needed."
            ],
            "new": True
        },
        # ----New----
        "CANCELLED_TRADES": {
            "id": "CT",
            "grain": "cancel_event",
            "date_key": "CANCELLATION_DATETIME",
            "measures": {
                "cancellations": {"expr": "*", "agg": "COUNT"},
                "volume": {"expr": "VOLUME", "agg": "SUM"},
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "BUYER_CLIENT_ID", "SELLER_CLIENT_ID",
                "BUYER_BROKER_ID", "SELLER_BROKER_ID",
                "BUYER_USER_ID", "SELLER_USER_ID",
                "STATE_ID", "SETTLEMENT_TYPE_ID", "TRADE_TYPE", "IS_SHORT"
            ],
            "notes": [
                "Treat as standalone cancellation events; do not assume 1:1 linkage to TRADES by TICKET_NO.",
                "For exploratory linkage, try (BUYER_ORDER_NO, SELLER_ORDER_NO, EXCHANGE_ID) → TRADES."
            ],
            "new": True
        },
        # ----New----
        "NEGOTIATED_TRADES": {
            "id": "NT",
            "grain": "negotiation_event",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "negotiations": {"expr": "*", "agg": "COUNT"},
                "volume": {"expr": "VOLUME", "agg": "SUM"},
                "notional_computed": {"expr": "PRICE * VOLUME", "agg": "SUM"},
                "avg_price": {"expr": "PRICE", "agg": "AVG"},
                "avg_yield": {"expr": "YIELD", "agg": "AVG"},
                "accrued_profit": {"expr": "ACCRUED_PROFIT", "agg": "SUM"},
                "value_stored": {"expr": "VALUE", "agg": "SUM"},
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "CLIENT_ID", "COUNTER_CLIENT_ID",
                "BROKER_ID", "COUNTER_BROKER_ID",
                "USER_ID", "TRADER_ID",
                "NEGOTIATED_STATE", "NEGOTIATED_STATUS",
                "ORDER_TYPE", "PRICE_TYPE", "IS_SHORT", "SIDE"
            ],
            "notes": [
                "Empirically maps to executed TRADES via order numbers:",
                "(NEGOTIATED_TRADES.ORDER_NO or COUNTER_ORDER_NO) ↔ (TRADES.BUYER_ORDER_NO or SELLER_ORDER_NO) with same EXCHANGE_ID.",
                "Do not assume linkage to ORDERS.ORDER_NO in this dataset."
            ],
            "new": True
        },
        
                # ===== ---- New (Repo) ---- =====
        "REPO_CONTRACTS": {
            "id": "RC",
            "grain": "repo_leg",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "contract_legs": ("*", "COUNT"),
                "cash_flow": ("SETTLEMENT_AMOUNT", "SUM"),
                "notional_computed": ("PRICE * VOLUME", "SUM"),
                "avg_repo_rate": ("REPO_RATE", "AVG"),
                "avg_haircut": ("REPO_HAIRCUT", "AVG"),
                "avg_yield": ("YIELD", "AVG"),
                "accrued_profit": ("ACCRUED_PROFIT", "SUM"),
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "BUYER_CLIENT_ID", "SELLER_CLIENT_ID",
                "BUYER_BROKER_ID", "SELLER_BROKER_ID",
                "BUYER_USER_ID", "SELLER_USER_ID",
                "LEG", "REPO_TYPE", "SETTLEMENT_TYPE_ID", "STATE_ID"
            ],
            "notes": [
                "LEG pairs mirrored rows (1=initial, 2=repurchase).",
                "Use INITIAL_DATE and TERMINATION_DATE for maturity buckets.",
                "Prefer SETTLEMENT_AMOUNT for cash-flow; PRICE*VOLUME for generic notional."
            ],
        },
        "REPO_CONTRACTS_CANCELLED": {
            "id": "RCC",
            "grain": "repo_cancel_leg",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "cancellations": ("*", "COUNT"),
                "volume": ("VOLUME", "SUM"),
                "cancelled_cash": ("SETTLEMENT_AMOUNT", "SUM"),
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "LEG", "REPO_TYPE", "STATE_ID"
            ],
            "notes": [
                "Structurally mirrors REPO_CONTRACTS; only voided legs.",
            ],
        },
        "REPO_LOG": {
            "id": "RL",
            "grain": "repo_log_event",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "log_events": ("*", "COUNT"),
                "volume": ("VOLUME", "SUM"),
                "notional_computed": ("PRICE * VOLUME", "SUM"),
                "cash_flow": ("SETTLEMENT_AMOUNT", "SUM"),
                "avg_yield": ("YIELD", "AVG"),
                "avg_repo_rate": ("REPO_RATE", "AVG"),
                "avg_haircut": ("REPO_HAIRCUT", "AVG"),
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID",
                "CLIENT_ID", "COUNTER_CLIENT_ID",
                "BROKER_ID", "COUNTER_BROKER_ID",
                "USER_ID", "COUNTER_USER_ID",
                "SIDE", "LEG", "NEGOTIATED_STATE", "NEGOTIATED_STATUS"
            ],
            "notes": [
                "Soft-join to REPO_CONTRACTS via CONTRACT_ID = CONTRACT_NO.",
            ],
        },
        
        
    },
    "lookups": {
        "SYMBOLS":            {"key": "SYMBOL_ID", "label": ["SYMBOL"]},
        "EXCHANGES":          {"key": "EXCHANGE_ID", "label": ["EXCHANGE_CODE", "EXCHANGE_NAME"]},
        "FLAGS":              {"key": "FLAG_ID", "label": ["FLAG_CODE", "DESC_"]},
        "ORDER_TYPES":        {"key": "ID", "label": ["CODE", "DESCRIPTION"]},
        "ORDER_STATES":       {"key": "STATE_ID", "label": ["STATE_CODE"]},
        "SUBSCRIBED_BROKERS": {"key": "BROKER_ID", "label": ["BROKER_NAME", "BROKER_CODE"]},
        "EDS_CLIENTS":        {"key": "CLIENT_ID", "label": ["NAME", "CLIENT_CODE"]},
        "USERS":              {"key": "USER_ID", "label": ["USER_NAME", "COMPLETE_NAME"]},
        # ----New----
        "TRADE_STATES":       {"key": "STATE_ID", "label": ["STATE_NAME", "STATE_CODE", "DESCRIPTION"], "new": True},
        "SETTLEMENT_TYPES":   {"key": "SETTLEMENT_TYPE_ID", "label": ["SETTLEMENT_TYPE", "NAME", "DESCRIPTION"], "new": True},
        "SYMBOL_TYPES":       {"key": "SYMBOL_TYPE_ID", "label": ["SYMBOL_TYPE", "NAME", "DESCRIPTION"], "new": True},
    },
    "notes": {
        "allowed_grains": ["day", "month", "year"],
        "safety": "No intraday bucketing in v1; aggregate to day/month/year only."
    },
}

# --------------------------
# Data structures
# --------------------------

@dataclass
class Column:
    name: str
    data_type: str
    nullable: bool
    comment: Optional[str] = None
    is_pk: bool = False
    is_fk: bool = False
    fk_ref: Optional[Tuple[str, str, str]] = None  # (owner, table, column)

@dataclass
class TableMeta:
    owner: str
    name: str
    comment: Optional[str]
    columns: List[Column]
    new: bool = False

# --------------------------
# Helpers
# --------------------------

def env(name: str, required: bool = True, default: Optional[str] = None) -> str:
    v = os.getenv(name, default)
    if required and not v:
        print(f"Missing env: {name}", file=sys.stderr)
        sys.exit(1)
    return v or ""

def connect_oracle() -> oracledb.Connection:
    dsn = env("ORACLE_DSN")
    user = env("ORACLE_USER")
    pwd = env("ORACLE_PASSWORD")
    owner = env("ORACLE_OWNER")
    conn = oracledb.connect(user=user, password=pwd, dsn=dsn)
    with conn.cursor() as cur:
        cur.execute(f"alter session set current_schema = {owner}")
        try:
            cur.execute("alter session set nls_date_format = 'YYYY-MM-DD HH24:MI:SS'")
        except Exception:
            pass
    return conn

def fetch_columns(cur: oracledb.Cursor, owner: str) -> Dict[str, List[Column]]:
    placeholders = ", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)])
    q = f"""
    SELECT
      c.table_name,
      c.column_name,
      c.data_type ||
        CASE
          WHEN c.data_type IN ('NUMBER') AND c.data_precision IS NOT NULL
            THEN '('||c.data_precision||
                 CASE WHEN c.data_scale IS NOT NULL THEN ','||c.data_scale END||')'
          WHEN c.data_type IN ('VARCHAR2','CHAR','NVARCHAR2','NCHAR') AND c.char_length IS NOT NULL
            THEN '('||c.char_length||')'
        END AS dtype,
      c.nullable,
      cc.comments
    FROM all_tab_columns c
    LEFT JOIN all_col_comments cc
      ON cc.owner = c.owner AND cc.table_name = c.table_name AND cc.column_name = c.column_name
    WHERE c.owner = :owner
      AND c.table_name IN ({placeholders})
    ORDER BY c.table_name, c.column_id
    """
    binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
    cur.execute(q, binds)
    out: Dict[str, List[Column]] = {t: [] for t in OWNER_TABLES}
    for tname, col, dtype, nullable, comment in cur:
        out[tname].append(Column(
            name=col,
            data_type=dtype or "UNKNOWN",
            nullable=(nullable == "Y"),
            comment=comment
        ))
    return out

def fetch_table_comments(cur: oracledb.Cursor, owner: str) -> Dict[str, Optional[str]]:
    placeholders = ", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)])
    q = f"""
    SELECT table_name, comments
    FROM all_tab_comments
    WHERE owner = :owner
      AND table_name IN ({placeholders})
    """
    binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
    cur.execute(q, binds)
    comments = {t: None for t in OWNER_TABLES}
    for t, c in cur:
        comments[t] = c
    return comments

def fetch_constraints(cur: oracledb.Cursor, owner: str):
    placeholders = ", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)])
    q = f"""
    WITH cons AS (
      SELECT owner, table_name, constraint_name, constraint_type, r_owner, r_constraint_name
      FROM all_constraints
      WHERE owner = :owner
        AND table_name IN ({placeholders})
    )
    SELECT
      c.constraint_type,
      c.table_name,
      cols.column_name,
      c.constraint_name,
      rc.owner AS r_owner,
      rc.table_name AS r_table,
      rcols.column_name AS r_col
    FROM cons c
    JOIN all_cons_columns cols
      ON cols.owner = c.owner AND cols.constraint_name = c.constraint_name
    LEFT JOIN all_constraints rc
      ON c.r_owner = rc.owner AND c.r_constraint_name = rc.constraint_name
    LEFT JOIN all_cons_columns rcols
      ON rcols.owner = rc.owner AND rcols.constraint_name = rc.constraint_name
         AND rcols.position = cols.position
    ORDER BY c.table_name, c.constraint_type DESC, cols.position
    """
    binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
    cur.execute(q, binds)

    pk_map: Dict[Tuple[str, str], bool] = {}
    fk_map: Dict[Tuple[str, str], Tuple[str, str, str]] = {}
    for ctype, table, col, _cname, r_owner, r_table, r_col in cur:
        if ctype == "P":
            pk_map[(table, col)] = True
        elif ctype == "R":
            if r_owner and r_table and r_col:
                fk_map[(table, col)] = (r_owner, r_table, r_col)
    return pk_map, fk_map

def build_table_meta(owner: str, columns: Dict[str, List[Column]],
                     comments: Dict[str, Optional[str]],
                     pk_map, fk_map) -> List[TableMeta]:
    metas: List[TableMeta] = []
    for t in OWNER_TABLES:
        cols = []
        for c in columns.get(t, []):
            is_pk = pk_map.get((t, c.name), False)
            fk_ref = fk_map.get((t, c.name))
            cols.append(Column(
                name=c.name, data_type=c.data_type, nullable=c.nullable,
                comment=c.comment, is_pk=is_pk, is_fk=bool(fk_ref), fk_ref=fk_ref
            ))
        metas.append(TableMeta(
            owner=owner, name=t, comment=comments.get(t), columns=cols, new=(t in NEW_TABLES)
        ))
    return metas

def synthesize_joins_json() -> List[dict]:
    joins = []

    def add(left, right, on, kind="inner", new=False, soft=False):
        joins.append({
            "left": left, "right": right, "on": on, "kind": kind,
            "new": new, "soft": soft
        })

    # existing
    add("SYMBOL_DAILY_INDICATORS", "SYMBOLS",   "SYMBOL_DAILY_INDICATORS.SYMBOL_ID = SYMBOLS.SYMBOL_ID")
    add("SYMBOL_DAILY_INDICATORS", "EXCHANGES", "SYMBOL_DAILY_INDICATORS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID")
    add("SYMBOL_INDICATORS", "SYMBOLS",   "SYMBOL_INDICATORS.SYMBOL_ID = SYMBOLS.SYMBOL_ID")
    add("SYMBOL_INDICATORS", "EXCHANGES", "SYMBOL_INDICATORS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID")
    add("BEST_MKT", "SYMBOLS",   "BEST_MKT.SYMBOL_ID = SYMBOLS.SYMBOL_ID")
    add("BEST_MKT", "EXCHANGES", "BEST_MKT.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID")
    add("ORDERS", "SYMBOLS", "ORDERS.SYMBOL_ID = SYMBOLS.SYMBOL_ID")
    add("ORDERS", "EXCHANGES", "ORDERS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID")
    add("ORDERS", "SYMBOL_MARKETS",
        "ORDERS.SYMBOL_ID = SYMBOL_MARKETS.SYMBOL_ID AND "
        "ORDERS.MARKET_ID = SYMBOL_MARKETS.MARKET_ID AND "
        "ORDERS.EXCHANGE_ID = SYMBOL_MARKETS.EXCHANGE_ID")
    add("ORDERS", "FLAGS", "ORDERS.FLAG_ID = FLAGS.FLAG_ID")
    add("ORDERS", "ORDER_TYPES", "ORDERS.ORDER_TYPE = ORDER_TYPES.ID")
    add("ORDERS", "ORDER_STATES", "ORDERS.STATE = ORDER_STATES.STATE_ID")
    add("ORDERS", "SUBSCRIBED_BROKERS", "ORDERS.BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID")
    add("ORDERS", "EDS_CLIENTS", "ORDERS.CLIENT_ID = EDS_CLIENTS.CLIENT_ID")
    add("ORDERS", "USERS", "ORDERS.USER_ID = USERS.USER_ID")
    add("ORDERS", "USERS", "ORDERS.TRADER_ID = USERS.USER_ID")

    # ----New---- TRADES
    add("TRADES", "SYMBOLS", "TRADES.SYMBOL_ID = SYMBOLS.SYMBOL_ID", new=True)
    add("TRADES", "EXCHANGES", "TRADES.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID", new=True)
    add("TRADES", "SYMBOL_MARKETS",
        "TRADES.SYMBOL_ID = SYMBOL_MARKETS.SYMBOL_ID AND "
        "TRADES.MARKET_ID = SYMBOL_MARKETS.MARKET_ID AND "
        "TRADES.EXCHANGE_ID = SYMBOL_MARKETS.EXCHANGE_ID", new=True)
    add("TRADES", "SUBSCRIBED_BROKERS", "TRADES.BUYER_BROKER_ID  = SUBSCRIBED_BROKERS.BROKER_ID", new=True)
    add("TRADES", "SUBSCRIBED_BROKERS", "TRADES.SELLER_BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID", new=True)
    add("TRADES", "EDS_CLIENTS", "TRADES.BUYER_CLIENT_ID  = EDS_CLIENTS.CLIENT_ID", new=True)
    add("TRADES", "EDS_CLIENTS", "TRADES.SELLER_CLIENT_ID = EDS_CLIENTS.CLIENT_ID", new=True)
    add("TRADES", "USERS", "TRADES.BUYER_USER_ID  = USERS.USER_ID", new=True)
    add("TRADES", "USERS", "TRADES.SELLER_USER_ID = USERS.USER_ID", new=True)
    add("TRADES", "SETTLEMENT_TYPES", "TRADES.SETTLEMENT_TYPE_ID = SETTLEMENT_TYPES.SETTLEMENT_TYPE_ID", new=True)
    add("TRADES", "TRADE_STATES", "TRADES.STATE_ID = TRADE_STATES.STATE_ID", new=True)

    # ----New---- CANCELLED_TRADES
    add("CANCELLED_TRADES", "EXCHANGES", "CANCELLED_TRADES.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID", new=True)
    add("CANCELLED_TRADES", "SYMBOLS", "CANCELLED_TRADES.SYMBOL_ID = SYMBOLS.SYMBOL_ID", new=True)
    add("CANCELLED_TRADES", "SUBSCRIBED_BROKERS", "CANCELLED_TRADES.BUYER_BROKER_ID  = SUBSCRIBED_BROKERS.BROKER_ID", new=True)
    add("CANCELLED_TRADES", "SUBSCRIBED_BROKERS", "CANCELLED_TRADES.SELLER_BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID", new=True)
    add("CANCELLED_TRADES", "EDS_CLIENTS", "CANCELLED_TRADES.BUYER_CLIENT_ID  = EDS_CLIENTS.CLIENT_ID", new=True)
    add("CANCELLED_TRADES", "EDS_CLIENTS", "CANCELLED_TRADES.SELLER_CLIENT_ID = EDS_CLIENTS.CLIENT_ID", new=True)
    add("CANCELLED_TRADES", "TRADES",
        "(CANCELLED_TRADES.BUYER_ORDER_NO, CANCELLED_TRADES.SELLER_ORDER_NO, CANCELLED_TRADES.EXCHANGE_ID) "
        "↔ (TRADES.BUYER_ORDER_NO, TRADES.SELLER_ORDER_NO, TRADES.EXCHANGE_ID)", new=True, soft=True)

    # ----New---- NEGOTIATED_TRADES
    add("NEGOTIATED_TRADES", "SYMBOLS", "NEGOTIATED_TRADES.SYMBOL_ID = SYMBOLS.SYMBOL_ID", new=True)
    add("NEGOTIATED_TRADES", "EXCHANGES", "NEGOTIATED_TRADES.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID", new=True)
    add("NEGOTIATED_TRADES", "SUBSCRIBED_BROKERS", "NEGOTIATED_TRADES.BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID", new=True)
    add("NEGOTIATED_TRADES", "SUBSCRIBED_BROKERS", "NEGOTIATED_TRADES.COUNTER_BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID", new=True)
    add("NEGOTIATED_TRADES", "EDS_CLIENTS", "NEGOTIATED_TRADES.CLIENT_ID = EDS_CLIENTS.CLIENT_ID", new=True)
    add("NEGOTIATED_TRADES", "EDS_CLIENTS", "NEGOTIATED_TRADES.COUNTER_CLIENT_ID = EDS_CLIENTS.CLIENT_ID", new=True)
    add("NEGOTIATED_TRADES", "TRADES",
        "(NEGOTIATED_TRADES.ORDER_NO or NEGOTIATED_TRADES.COUNTER_ORDER_NO) "
        "↔ (TRADES.BUYER_ORDER_NO or TRADES.SELLER_ORDER_NO) with same EXCHANGE_ID", new=True, soft=True)


    
    

    return joins

# --------------------------
# Writer
# --------------------------

def write_schema_json(path: str, owner: str, metas: List[TableMeta]) -> str:
    data = {
        "version": CATALOG["version"],
        "owner": owner,
        "scope": [f"{owner}.{t}" for t in OWNER_TABLES],
        "allowed_grains": CATALOG["notes"]["allowed_grains"],
        "safety_notes": CATALOG["notes"]["safety"],
        "oracle_helpers": [
            "TRUNC(<date_col>, 'DD'|'MM'|'YYYY')",
            "col >= DATE 'YYYY-MM-DD' AND col < DATE 'YYYY-MM-DD'",
            "FETCH FIRST <N> ROWS ONLY (or WHERE ROWNUM <= N)",
            "PERCENTILE_CONT(p) WITHIN GROUP (ORDER BY expr)",
            "MEDIAN(expr)",
            "Window functions: LAG/LEAD, AVG(...) OVER (PARTITION BY ... ORDER BY ...)"
        ],
        "joins": synthesize_joins_json(),
        "facts": CATALOG["facts"],      # already JSON-safe
        "lookups": CATALOG["lookups"],  # already JSON-safe
        "tables": []
    }

    for tm in metas:
        table_dict = {
            "owner": tm.owner,
            "name": tm.name,
            "comment": tm.comment,
            "new": tm.new,
            "columns": []
        }
        for c in tm.columns:
            col = {
                "name": c.name,
                "data_type": c.data_type,
                "nullable": c.nullable,
                "comment": c.comment,
                "is_pk": c.is_pk,
                "is_fk": c.is_fk,
            }
            if c.is_fk and c.fk_ref:
                ro, rt, rc = c.fk_ref
                col["fk_ref"] = {"owner": ro, "table": rt, "column": rc}
            table_dict["columns"].append(col)
        data["tables"].append(table_dict)

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    return path

# --------------------------
# Main
# --------------------------

def main() -> None:
    load_dotenv()
    owner = os.getenv("ORACLE_OWNER")
    if not owner:
        print("Missing env: ORACLE_OWNER", file=sys.stderr)
        sys.exit(1)

    out_path = os.path.join("app", "prompts", "schema_card.json")

    print("→ Connecting to Oracle…")
    conn = connect_oracle()
    try:
        with conn.cursor() as cur:
            print(f"→ Introspecting columns/constraints/comments for {owner}…")
            columns = fetch_columns(cur, owner)
            comments = fetch_table_comments(cur, owner)
            pk_map, fk_map = fetch_constraints(cur, owner)
            metas = build_table_meta(owner, columns, comments, pk_map, fk_map)

        print("→ Writing JSON schema card…")
        p = write_schema_json(out_path, owner, metas)
        print(f"Done. JSON written to: {p}")

        # small preview for sanity
        with open(out_path, "r", encoding="utf-8") as f:
            head = "".join(f.readlines()[:80])
        print("=== schema_card.json (top lines) ===")
        print(head)
        print("… (truncated)")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
