# app/_smoke/run_orders_fewshots.py
from __future__ import annotations

import os, sys, csv, pathlib
from typing import List, Tuple
import oracledb
from dotenv import load_dotenv

load_dotenv()

OWNER = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
DSN = os.getenv("ORACLE_DSN")
USER = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
PWD  = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")

SAVE_CSV = (os.getenv("SAVE_CSV", "true").lower() == "true")
OUT_DIR = pathlib.Path("evaluation/run_fewshots_results")
ROW_PREVIEW = int(os.getenv("ROW_PREVIEW", "25"))

def die(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(1)

def connect():
    if not (DSN and USER and PWD and OWNER):
        die("Missing ORACLE_DSN/USER/PASSWORD/OWNER envs")
    conn = oracledb.connect(user=USER, password=PWD, dsn=DSN)
    cur = conn.cursor()
    cur.execute(f"alter session set current_schema = {OWNER}")
    return conn, cur

def run(cur, title: str, sql: str) -> Tuple[List[str], List[tuple]]:
    cur.execute(sql)
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchmany(ROW_PREVIEW)
    return cols, rows

def save_csv(title: str, cols: List[str], rows: List[tuple]):
    if not SAVE_CSV: return
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in title)[:80]
    path = OUT_DIR / f"{safe}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if cols: w.writerow(cols)
        for r in rows: w.writerow(list(r))
    print(f"Saved CSV → {path}")

def main():
    conn, cur = connect()
    try:
        fewshots: List[Tuple[str, str]] = [

            # 1) Orders by flag (last 90 days)
            ("ORDERS • distribution by FLAG_CODE (last 90d)",
             f"""
             SELECT
               f.FLAG_CODE,
               COUNT(*) AS orders,
               SUM(o.VOLUME * o.PRICE) AS notional
             FROM {OWNER}.ORDERS o
             JOIN {OWNER}.FLAGS f ON f.FLAG_ID = o.FLAG_ID
             WHERE o.ENTRY_DATETIME >= TRUNC(SYSDATE) - 90
             GROUP BY f.FLAG_CODE
             ORDER BY orders DESC
             FETCH FIRST 25 ROWS ONLY
             """),

            # 2) Order state breakdown by symbol (2024)
            ("ORDERS • state breakdown by SYMBOL (2024)",
             f"""
             SELECT
               s.SYMBOL,
               st.STATE_CODE,
               COUNT(*) AS orders
             FROM {OWNER}.ORDERS o
             JOIN {OWNER}.SYMBOLS s       ON s.SYMBOL_ID = o.SYMBOL_ID
             JOIN {OWNER}.ORDER_STATES st ON st.STATE_ID = o.STATE
             WHERE o.ENTRY_DATETIME >= DATE '2024-01-01'
               AND o.ENTRY_DATETIME <  DATE '2025-01-01'
             GROUP BY s.SYMBOL, st.STATE_CODE
             ORDER BY s.SYMBOL, orders DESC
             FETCH FIRST 25 ROWS ONLY
             """),

            # 3) Top brokers by notional (YTD)
            ("ORDERS • top brokers by notional (YTD)",
             f"""
             SELECT
               b.BROKER_NAME,
               COUNT(*) AS orders,
               SUM(o.VOLUME * o.PRICE) AS notional
             FROM {OWNER}.ORDERS o
             JOIN {OWNER}.SUBSCRIBED_BROKERS b ON b.BROKER_ID = o.BROKER_ID
             WHERE o.ENTRY_DATETIME >= TRUNC(ADD_MONTHS(SYSDATE, -EXTRACT(MONTH FROM SYSDATE)+1))
             GROUP BY b.BROKER_NAME
             ORDER BY notional DESC
             FETCH FIRST 25 ROWS ONLY
             """),

            # 4) Daily Buy vs Sell notional (last 30 days)
            ("ORDERS • daily notional by SIDE (last 30d)",
             f"""
             SELECT
               TRUNC(o.ENTRY_DATETIME) AS day,
               o.SIDE,
               SUM(o.VOLUME * o.PRICE) AS notional
             FROM {OWNER}.ORDERS o
             WHERE o.ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
             GROUP BY TRUNC(o.ENTRY_DATETIME), o.SIDE
             ORDER BY day DESC, o.SIDE
             FETCH FIRST 25 ROWS ONLY
             """),
        ]

        print(f"Running {len(fewshots)} few-shots against {OWNER}…\n")
        passed = 0
        for i, (title, sql) in enumerate(fewshots, 1):
            print(f"[{i}/{len(fewshots)}] {title}")
            print("—"*80)
            try:
                cols, rows = run(cur, title, sql)
                print(f"OK: {len(rows)} row(s); columns: {', '.join(cols) if cols else '(none)'}")
                for r in rows[:5]:
                    print("  ", r)
                save_csv(title, cols, rows)
                passed += 1
            except Exception as e:
                print("ERROR:", e)
                print("SQL (first lines):")
                print("\n".join(sql.splitlines()[:12]))
            print()

        print(f"Done. {passed}/{len(fewshots)} succeeded.")
    finally:
        cur.close()
        conn.close()

if __name__ == "__main__":
    main()
