# app/tools/run_rejections_levies_fewshots.py
from __future__ import annotations

import os, sys, csv, pathlib, datetime
from typing import List, Tuple
import oracledb
from dotenv import load_dotenv

load_dotenv()

OWNER = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
DSN   = os.getenv("ORACLE_DSN")
USER  = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
PWD   = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")

# Tunables (env overrides)
SAVE_CSV            = (os.getenv("SAVE_CSV", "true").lower() == "true")
OUT_DIR             = pathlib.Path(os.getenv("OUT_DIR", "evaluation/run_fewshots_results"))
ROW_PREVIEW         = int(os.getenv("ROW_PREVIEW", "25"))
LOOKBACK_REJ_DAYS   = int(os.getenv("LOOKBACK_REJ_DAYS", "30"))   # rejected orders
LOOKBACK_SETT_DAYS  = int(os.getenv("LOOKBACK_SETT_DAYS", "90"))  # settlement levies
LOOKBACK_LOG_DAYS   = int(os.getenv("LOOKBACK_LOG_DAYS", "30"))   # levy log
NLS_DATE_FORMAT     = os.getenv("NLS_DATE_FORMAT", "YYYY-MM-DD HH24:MI:SS")

def die(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(1)

def connect():
    if not (DSN and USER and PWD and OWNER):
        die("Missing ORACLE_DSN/USER/PASSWORD/OWNER envs")
    conn = oracledb.connect(user=USER, password=PWD, dsn=DSN)
    cur = conn.cursor()
    cur.execute(f"alter session set current_schema = {OWNER}")
    try:
        cur.execute(f"alter session set nls_date_format = '{NLS_DATE_FORMAT}'")
    except Exception:
        pass
    return conn, cur

def run(cur, title: str, sql: str) -> Tuple[List[str], List[tuple]]:
    cur.execute(sql)
    cols = [d[0] for d in (cur.description or [])]
    rows = cur.fetchmany(ROW_PREVIEW)
    return cols, rows

def save_csv(title: str, cols: List[str], rows: List[tuple]):
    if not SAVE_CSV:
        return
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in title)[:120]
    path = OUT_DIR / f"{safe}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if cols: w.writerow(cols)
        for r in rows: w.writerow(list(r))
    print(f"Saved CSV → {path}")

def banner(title: str):
    rule = "—" * 80
    print(f"[{title}]\n{rule}")

def main():
    conn, cur = connect()
    try:
        # Capture SYSDATE so printed windows are reproducible across queries in a single run
        cur.execute("SELECT SYSDATE FROM dual")
        sysdate: datetime.datetime = cur.fetchone()[0]
        print(f"Running 4 few-shots against {OWNER}… (SYSDATE = {sysdate})\n")

        fewshots: List[Tuple[str, str, str]] = [

            # 1) REJECTED ORDERS — daily counts by rejection reason (last N days)
            (
                f"1/4 REJECTED_ORDERS • daily counts by REJECTION reason (last {LOOKBACK_REJ_DAYS}d)",
                f"Window: TRUNC(SYSDATE) - {LOOKBACK_REJ_DAYS} .. TRUNC(SYSDATE)",
                f"""
                SELECT
                  TRUNC(ro.ENTRY_DATETIME) AS DAY,
                  NVL(r.DESCRIPTION, TO_CHAR(ro.REJECTION_ID)) AS REJECTION_REASON,
                  COUNT(*) AS REJECTED_ORDERS
                FROM {OWNER}.REJECTED_ORDERS ro
                LEFT JOIN {OWNER}.REJECTIONS r
                  ON r.REJECTION_ID = ro.REJECTION_ID
                WHERE ro.ENTRY_DATETIME >= TRUNC(SYSDATE) - {LOOKBACK_REJ_DAYS}
                GROUP BY TRUNC(ro.ENTRY_DATETIME),
                         NVL(r.DESCRIPTION, TO_CHAR(ro.REJECTION_ID))
                ORDER BY DAY DESC, REJECTED_ORDERS DESC
                FETCH FIRST 25 ROWS ONLY
                """
            ),

            # 2) SETTLEMENT — totals by levy type (last N days)
            (
                f"2/4 SETTLEMENT_LEVY_DATA • totals by LEVY TYPE (last {LOOKBACK_SETT_DAYS}d)",
                f"Window: TRUNC(SYSDATE) - {LOOKBACK_SETT_DAYS} .. TRUNC(SYSDATE)",
                f"""
                SELECT
                  COALESCE(lt.DESCRIPTION, lt.CODE) AS LEVY_TYPE,
                  SUM(s.LEVY_AMOUNT)                AS TOTAL_LEVY_AMOUNT,
                  COUNT(*)                          AS RECORDS
                FROM {OWNER}.SETTLEMENT_LEVY_DATA s
                LEFT JOIN {OWNER}.LEVIES      l  ON l.LEVY_ID     = s.LEVY_ID
                LEFT JOIN {OWNER}.LEVY_TYPES  lt ON lt.ID          = l.LEVY_TYPE_ID
                WHERE s.TRANSACTION_DATE >= TRUNC(SYSDATE) - {LOOKBACK_SETT_DAYS}
                GROUP BY COALESCE(lt.DESCRIPTION, lt.CODE)
                ORDER BY TOTAL_LEVY_AMOUNT DESC
                FETCH FIRST 25 ROWS ONLY
                """
            ),

            # 3) SETTLEMENT — top clients by levy amount (this quarter)
            (
                "3/4 SETTLEMENT_LEVY_DATA • top CLIENTS by levy amount (this quarter)",
                "Window: from TRUNC(SYSDATE, 'Q') .. SYSDATE",
                f"""
                WITH this_q AS (SELECT TRUNC(SYSDATE, 'Q') AS qstart FROM dual)
                SELECT
                  NVL(c.NAME, TO_CHAR(s.CLIENT_ID)) AS CLIENT_NAME,
                  SUM(s.LEVY_AMOUNT)               AS TOTAL_LEVY_AMOUNT,
                  COUNT(*)                         AS RECORDS
                FROM {OWNER}.SETTLEMENT_LEVY_DATA s
                JOIN this_q q ON 1=1
                LEFT JOIN {OWNER}.EDS_CLIENTS c
                  ON c.CLIENT_ID = s.CLIENT_ID
                WHERE s.TRANSACTION_DATE >= q.qstart
                GROUP BY NVL(c.NAME, TO_CHAR(s.CLIENT_ID))
                ORDER BY TOTAL_LEVY_AMOUNT DESC
                FETCH FIRST 25 ROWS ONLY
                """
            ),

            # 4) LOG — daily levy by MARKET & SIDE (last N days), with labeled NULLs
            (
                f"4/4 ATS_LEVY_DATA_LOG • daily levy by MARKET & SIDE (last {LOOKBACK_LOG_DAYS}d)",
                f"Window: TRUNC(SYSDATE) - {LOOKBACK_LOG_DAYS} .. TRUNC(SYSDATE)",
                f"""
                SELECT
                  TRUNC(d.TRANSACTION_DATE) AS DAY,
                  COALESCE(d.MARKET, 'UNSPECIFIED')   AS MARKET,
                  COALESCE(d.BUY_SELL, 'UNSPECIFIED') AS BUY_SELL,
                  SUM(d.LEVY_AMOUNT) AS SUM_LEVY_AMOUNT,
                  AVG(d.LEVY_AMOUNT) AS AVG_LEVY_AMOUNT,
                  COUNT(*)           AS ROWS_CNT
                FROM {OWNER}.ATS_LEVY_DATA_LOG d
                WHERE d.TRANSACTION_DATE >= TRUNC(SYSDATE) - {LOOKBACK_LOG_DAYS}
                GROUP BY TRUNC(d.TRANSACTION_DATE),
                         COALESCE(d.MARKET, 'UNSPECIFIED'),
                         COALESCE(d.BUY_SELL, 'UNSPECIFIED')
                ORDER BY DAY DESC, SUM_LEVY_AMOUNT DESC
                FETCH FIRST 25 ROWS ONLY
                """
            ),
        ]

        passed = 0
        for title, window_hint, sql in fewshots:
            banner(title)
            print(window_hint)
            try:
                cols, rows = run(cur, title, sql)
                print(f"OK: {len(rows)} row(s); columns: {', '.join(cols) if cols else '(none)'}")
                for r in rows[:5]:
                    print("  ", r)
                save_csv(title, cols, rows)
                passed += 1
            except Exception as e:
                print("ERROR:", e)
                print("SQL (first lines):")
                print("\n".join(sql.splitlines()[:18]))
            print()

        print(f"Done. {passed}/{len(fewshots)} succeeded.")
    finally:
        try: cur.close()
        except Exception: pass
        try: conn.close()
        except Exception: pass

if __name__ == "__main__":
    main()
