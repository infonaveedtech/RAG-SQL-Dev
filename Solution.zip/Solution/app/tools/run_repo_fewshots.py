# app/tools/run_repo_fewshots.py
from __future__ import annotations

"""
Run a small battery of REPO few-shots and save CSV + SQL artifacts.

Env (same as the rest of your app):
  ORACLE_OWNER, ORACLE_USER, ORACLE_PASSWORD, ORACLE_DSN
  STATEMENT_TIMEOUT_MS (optional; default 60000)

Outputs:
  evaluation/run_fewshots_results/<timestamp>/
    01_daily_cashflow_by_exchange_leg.csv
    01_daily_cashflow_by_exchange_leg.sql
    02_active_avg_rate_haircut_by_maturity_symboltype.csv
    02_active_avg_rate_haircut_by_maturity_symboltype.sql
    03_qtr_cancellations_ratio_by_symbol.csv
    03_qtr_cancellations_ratio_by_symbol.sql
"""

import csv
import os
import sys
import time
from datetime import datetime
from typing import List, Tuple, Dict, Any

from dotenv import load_dotenv
load_dotenv()

import oracledb

OWNER = (os.getenv("ORACLE_OWNER") or "ATS").upper().strip()
USER = os.getenv("ORACLE_USER")
PWD = os.getenv("ORACLE_PASSWORD")
DSN = os.getenv("ORACLE_DSN")
STATEMENT_TIMEOUT_MS = int(os.getenv("STATEMENT_TIMEOUT_MS", "60000"))

# -------- Few-shots (exactly as proposed) --------

SQL_01_DAILY_CASHFLOW = """
WITH w AS (
  SELECT
    TRUNC(rc.ENTRY_DATETIME) AS DAY,
    e.EXCHANGE_CODE          AS EXCHANGE,
    rc.LEG,
    rc.REPO_TYPE,
    rc.SETTLEMENT_AMOUNT
  FROM REPO_CONTRACTS rc
  JOIN EXCHANGES e
    ON e.EXCHANGE_ID = rc.EXCHANGE_ID
  WHERE rc.ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
)
SELECT
  w.DAY,
  w.EXCHANGE,
  w.LEG,
  w.REPO_TYPE,
  ROUND(SUM(w.SETTLEMENT_AMOUNT), 2) AS CASH_FLOW,
  COUNT(*)                            AS CONTRACTS
FROM w
GROUP BY w.DAY, w.EXCHANGE, w.LEG, w.REPO_TYPE
ORDER BY w.DAY DESC, CASH_FLOW DESC
FETCH FIRST 200 ROWS ONLY
"""

SQL_02_ACTIVE_RATE_HAIRCUT = """
WITH active AS (
  SELECT
    rc.SYMBOL_ID,
    rc.REPO_RATE,
    rc.REPO_HAIRCUT,
    rc.INITIAL_DATE,
    rc.TERMINATION_DATE
  FROM REPO_CONTRACTS rc
  WHERE rc.TERMINATION_DATE > SYSDATE
    AND rc.INITIAL_DATE IS NOT NULL
),
bucketed AS (
  SELECT
    s.SYMBOL,
    CASE
      WHEN (a.TERMINATION_DATE - a.INITIAL_DATE) <= 7  THEN '0–7d'
      WHEN (a.TERMINATION_DATE - a.INITIAL_DATE) <= 30 THEN '8–30d'
      WHEN (a.TERMINATION_DATE - a.INITIAL_DATE) <= 90 THEN '31–90d'
      ELSE '>90d'
    END AS MATURITY_BUCKET,
    a.REPO_RATE,
    a.REPO_HAIRCUT
  FROM active a
  JOIN SYMBOLS s
    ON s.SYMBOL_ID = a.SYMBOL_ID
)
SELECT
  b.MATURITY_BUCKET,
  b.SYMBOL,
  ROUND(AVG(b.REPO_RATE),   4) AS AVG_REPO_RATE,
  ROUND(AVG(b.REPO_HAIRCUT),4) AS AVG_HAIRCUT,
  COUNT(*)                    AS CONTRACT_LEGS
FROM bucketed b
GROUP BY b.MATURITY_BUCKET, b.SYMBOL
ORDER BY
  CASE b.MATURITY_BUCKET
    WHEN '0–7d' THEN 1
    WHEN '8–30d' THEN 2
    WHEN '31–90d' THEN 3
    ELSE 4
  END,
  b.SYMBOL
FETCH FIRST 200 ROWS ONLY
"""


SQL_03_QTR_CANCEL_RATIO = """
WITH q AS (SELECT TRUNC(SYSDATE, 'Q') AS QSTART FROM dual),
execs AS (
  SELECT
    rc.SYMBOL_ID,
    COUNT(*) AS EXEC_LEGS
  FROM REPO_CONTRACTS rc
  JOIN q ON 1=1
  WHERE rc.ENTRY_DATETIME >= q.QSTART
  GROUP BY rc.SYMBOL_ID
),
canc AS (
  SELECT
    cc.SYMBOL_ID,
    COUNT(*) AS CANCELLED_LEGS
  FROM REPO_CONTRACTS_CANCELLED cc
  JOIN q ON 1=1
  WHERE cc.ENTRY_DATETIME >= q.QSTART
  GROUP BY cc.SYMBOL_ID
)
SELECT
  s.SYMBOL,
  NVL(canc.CANCELLED_LEGS, 0)               AS CANCELLED_LEGS,
  NVL(execs.EXEC_LEGS, 0)                   AS EXEC_LEGS,
  CASE
    WHEN NVL(canc.CANCELLED_LEGS, 0) + NVL(execs.EXEC_LEGS, 0) = 0 THEN 0
    ELSE ROUND(NVL(canc.CANCELLED_LEGS, 0) / (NVL(canc.CANCELLED_LEGS, 0) + NVL(execs.EXEC_LEGS, 0)), 4)
  END AS CANCEL_RATIO
FROM (
  SELECT DISTINCT SYMBOL_ID FROM (
    SELECT SYMBOL_ID FROM REPO_CONTRACTS            WHERE ENTRY_DATETIME >= (SELECT QSTART FROM q)
    UNION
    SELECT SYMBOL_ID FROM REPO_CONTRACTS_CANCELLED  WHERE ENTRY_DATETIME >= (SELECT QSTART FROM q)
  )
) ids
LEFT JOIN execs ON execs.SYMBOL_ID = ids.SYMBOL_ID
LEFT JOIN canc  ON canc.SYMBOL_ID  = ids.SYMBOL_ID
LEFT JOIN SYMBOLS s ON s.SYMBOL_ID = ids.SYMBOL_ID
ORDER BY CANCELLED_LEGS DESC, CANCEL_RATIO DESC, s.SYMBOL
FETCH FIRST 100 ROWS ONLY
"""

TESTS: List[Dict[str, Any]] = [
    {
        "name": "01_daily_cashflow_by_exchange_leg",
        "sql": SQL_01_DAILY_CASHFLOW,
        "desc": "Daily repo cash flow (sum settlement amounts) by exchange & leg (last 30d) + repo type",
    },
    {
        "name": "02_active_avg_rate_haircut_by_maturity_symboltype",
        "sql": SQL_02_ACTIVE_RATE_HAIRCUT,
        "desc": "Active repos: avg repo rate & haircut by maturity bucket and symbol type",
    },
    {
        "name": "03_qtr_cancellations_ratio_by_symbol",
        "sql": SQL_03_QTR_CANCEL_RATIO,
        "desc": "Current quarter: repo cancellations vs executed legs, with cancel ratio, by symbol",
    },
]

def _ensure_env():
    missing = [k for k, v in {
        "ORACLE_USER": USER,
        "ORACLE_PASSWORD": PWD,
        "ORACLE_DSN": DSN
    }.items() if not v]
    if missing:
        print(f"[ERROR] Missing env: {', '.join(missing)}", file=sys.stderr)
        sys.exit(2)

def _connect():
    _ensure_env()
    conn = oracledb.connect(user=USER, password=PWD, dsn=DSN)
    try:
        conn.callTimeout = STATEMENT_TIMEOUT_MS
    except Exception:
        pass
    with conn.cursor() as cur:
        # align to your owner so unqualified names work
        cur.execute(f"alter session set current_schema = {OWNER}")
        try:
            cur.execute("alter session set optimizer_dynamic_sampling = 0")
        except Exception:
            pass
    return conn

def _mkdir_out() -> str:
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    outdir = os.path.join("evaluation", "run_fewshots_results", f"repo_{ts}")
    os.makedirs(outdir, exist_ok=True)
    return outdir

def _run_sql(cur, sql: str) -> Tuple[List[str], List[tuple]]:
    t0 = time.time()
    cur.execute(sql)
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchall()
    dt = time.time() - t0
    return cols, rows, dt

def _write_csv(path: str, cols: List[str], rows: List[tuple]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if cols:
            w.writerow(cols)
        for r in rows:
            w.writerow(list(r))

def _write_sql(path: str, sql: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(sql.strip() + "\n")

def main():
    print(f"OWNER={OWNER}")
    outdir = _mkdir_out()
    print(f"Writing artifacts to: {outdir}")

    with _connect() as con, con.cursor() as cur:
        passed = 0
        for t in TESTS:
            name = t["name"]
            sql = t["sql"].strip()
            desc = t["desc"]
            print("\n" + "="*80)
            print(f"{name}")
            print("-"*80)
            print(desc)
            print("-"*80)
            print(sql)
            print("-"*80)

            try:
                cols, rows, dt = _run_sql(cur, sql)
                n = len(rows)
                print(f"[OK] rows={n} time={dt:.3f}s")

                csv_path = os.path.join(outdir, f"{name}.csv")
                sql_path = os.path.join(outdir, f"{name}.sql")
                _write_csv(csv_path, cols, rows)
                _write_sql(sql_path, sql)
                print(f"Saved CSV: {csv_path}")
                print(f"Saved SQL: {sql_path}")
                passed += 1
            except Exception as e:
                print(f"[FAIL] {name}: {e}")

        print("\n" + "="*80)
        print(f"Summary: {passed}/{len(TESTS)} passed")
        if passed == len(TESTS):
            print("All repo few-shots ran successfully ✅")
        else:
            print("Some few-shots failed ❌ — check errors above.")

if __name__ == "__main__":
    main()
