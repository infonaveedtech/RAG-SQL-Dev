# app/_smoke/run_trades_fewshots.py
from __future__ import annotations

import os, sys, csv, pathlib
from typing import List, Tuple
import oracledb
from dotenv import load_dotenv

load_dotenv()

OWNER = os.getenv("ORACLE_OWNER", "ATS").upper().strip()
DSN   = os.getenv("ORACLE_DSN")
USER  = os.getenv("ORACLE_USER") or os.getenv("DB_USER")
PWD   = os.getenv("ORACLE_PASSWORD") or os.getenv("DB_PASSWORD")

SAVE_CSV    = (os.getenv("SAVE_CSV", "true").lower() == "true")
OUT_DIR     = pathlib.Path("evaluation/run_fewshots_results")
ROW_PREVIEW = int(os.getenv("ROW_PREVIEW", "25"))

def die(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)
    sys.exit(1)

def connect():
    if not (DSN and USER and PWD and OWNER):
        die("Missing ORACLE_DSN/USER/PASSWORD/OWNER envs")
    conn = oracledb.connect(user=USER, password=PWD, dsn=DSN)
    cur = conn.cursor()
    # align with schema the way you did in orders fewshots
    cur.execute(f"alter session set current_schema = {OWNER}")
    # deterministic dates
    try: cur.execute("alter session set nls_date_format = 'YYYY-MM-DD HH24:MI:SS'")
    except Exception: pass
    return conn, cur

def run(cur, title: str, sql: str) -> Tuple[List[str], List[tuple]]:
    cur.execute(sql)
    cols = [d[0] for d in (cur.description or [])]
    rows = cur.fetchmany(ROW_PREVIEW)
    return cols, rows

def save_csv(title: str, cols: List[str], rows: List[tuple]):
    if not SAVE_CSV: return
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    safe = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in title)[:80]
    path = OUT_DIR / f"{safe}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if cols: w.writerow(cols)
        for r in rows: w.writerow(list(r))
    print(f"Saved CSV → {path}")

def main():
    conn, cur = connect()
    try:
        fewshots: List[Tuple[str, str]] = [

            # 1) Trades — daily notional by exchange (last 14 days)
            ("TRADES • daily notional by EXCHANGE (last 14d)",
             f"""
             SELECT
               TRUNC(t.ENTRY_DATETIME, 'DD') AS trade_day,
               e.EXCHANGE_CODE,
               SUM(t.PRICE * t.VOLUME) AS notional
             FROM {OWNER}.TRADES t
             JOIN {OWNER}.EXCHANGES e ON e.EXCHANGE_ID = t.EXCHANGE_ID
             WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE) - 14
             GROUP BY TRUNC(t.ENTRY_DATETIME, 'DD'), e.EXCHANGE_CODE
             ORDER BY trade_day DESC, notional DESC
             FETCH FIRST 25 ROWS ONLY
             """),

            # 2) Trades — top clients by traded volume (this month; buyer+seller attributions)
            ("TRADES • top CLIENTS by traded volume (this month)",
             f"""
             WITH party AS (
               SELECT t.BUYER_CLIENT_ID AS CLIENT_ID, t.VOLUME AS VOL
               FROM {OWNER}.TRADES t
               WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE, 'MM')
               UNION ALL
               SELECT t.SELLER_CLIENT_ID, t.VOLUME
               FROM {OWNER}.TRADES t
               WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE, 'MM')
             )
             SELECT
               c.NAME AS CLIENT_NAME,
               SUM(p.VOL) AS traded_volume
             FROM party p
             JOIN {OWNER}.EDS_CLIENTS c ON c.CLIENT_ID = p.CLIENT_ID
             GROUP BY c.NAME
             ORDER BY traded_volume DESC
             FETCH FIRST 15 ROWS ONLY
             """),

            # 3) Cancelled trades — daily count by exchange (last 30 days)
            ("CANCELLED_TRADES • daily cancellations by EXCHANGE (last 30d)",
             f"""
             SELECT
               TRUNC(ct.CANCELLATION_DATETIME, 'DD') AS cancel_day,
               e.EXCHANGE_CODE,
               COUNT(*) AS cancellations
             FROM {OWNER}.CANCELLED_TRADES ct
             JOIN {OWNER}.EXCHANGES e ON e.EXCHANGE_ID = ct.EXCHANGE_ID
             WHERE ct.CANCELLATION_DATETIME >= TRUNC(SYSDATE) - 30
             GROUP BY TRUNC(ct.CANCELLATION_DATETIME, 'DD'), e.EXCHANGE_CODE
             ORDER BY cancel_day DESC, cancellations DESC
             FETCH FIRST 25 ROWS ONLY
             """),

            # 4) Negotiated → Trades mapping — executed notional for negotiated orders (last 30d) by symbol
            #    (map nt.ORDER_NO / nt.COUNTER_ORDER_NO to t.BUYER_ORDER_NO / t.SELLER_ORDER_NO on same exchange)
            ("NEGOTIATED→TRADES • executed notional for negotiated orders by SYMBOL (last 30d)",
             f"""
             WITH nt_orders AS (
               SELECT EXCHANGE_ID, ORDER_NO AS ORD_NO, ENTRY_DATETIME
               FROM {OWNER}.NEGOTIATED_TRADES
               WHERE ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
               UNION ALL
               SELECT EXCHANGE_ID, COUNTER_ORDER_NO AS ORD_NO, ENTRY_DATETIME
               FROM {OWNER}.NEGOTIATED_TRADES
               WHERE ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
             ),
             t_match AS (
               SELECT t.SYMBOL_ID, t.EXCHANGE_ID, t.PRICE*t.VOLUME AS notional
               FROM {OWNER}.TRADES t
               JOIN nt_orders n
                 ON n.EXCHANGE_ID = t.EXCHANGE_ID
                AND (t.BUYER_ORDER_NO = n.ORD_NO OR t.SELLER_ORDER_NO = n.ORD_NO)
               WHERE t.ENTRY_DATETIME >= TRUNC(SYSDATE) - 30
             )
             SELECT s.SYMBOL, SUM(m.notional) AS negotiated_executed_notional
             FROM t_match m
             JOIN {OWNER}.SYMBOLS s ON s.SYMBOL_ID = m.SYMBOL_ID
             GROUP BY s.SYMBOL
             ORDER BY negotiated_executed_notional DESC
             FETCH FIRST 25 ROWS ONLY
             """),

            # 5) Bond trades — avg yield & settlement amount by settlement type (YTD)
            ("TRADES • BONDS: avg YIELD and sum SETTLEMENT_AMOUNT by SETTLEMENT_TYPE (YTD)",
             f"""
             SELECT
               NVL(sty.SETTLEMENT_TYPE, TO_CHAR(t.SETTLEMENT_TYPE_ID)) AS settlement_type,
               COUNT(*) AS trades_cnt,
               AVG(t.YIELD) AS avg_yield,
               SUM(t.SETTLEMENT_AMOUNT) AS settlement_amount
             FROM {OWNER}.TRADES t
             JOIN {OWNER}.SYMBOLS s       ON s.SYMBOL_ID = t.SYMBOL_ID
             JOIN {OWNER}.SYMBOL_TYPES st ON st.SYMBOL_TYPE_ID = s.SYMBOL_TYPE_ID
             LEFT JOIN {OWNER}.SETTLEMENT_TYPES sty ON sty.SETTLEMENT_TYPE_ID = t.SETTLEMENT_TYPE_ID
             WHERE t.ENTRY_DATETIME >= TRUNC(ADD_MONTHS(SYSDATE, -EXTRACT(MONTH FROM SYSDATE)+1)) -- YTD start
               AND UPPER(st.SYMBOL_TYPE) LIKE 'BOND%'
             GROUP BY NVL(sty.SETTLEMENT_TYPE, TO_CHAR(t.SETTLEMENT_TYPE_ID))
             ORDER BY settlement_amount DESC
             FETCH FIRST 25 ROWS ONLY
             """),
        ]

        print(f"Running {len(fewshots)} few-shots against {OWNER}…\n")
        passed = 0
        for i, (title, sql) in enumerate(fewshots, 1):
            print(f"[{i}/{len(fewshots)}] {title}")
            print("—"*80)
            try:
                cols, rows = run(cur, title, sql)
                print(f"OK: {len(rows)} row(s); columns: {', '.join(cols) if cols else '(none)'}")
                for r in rows[:5]:
                    print("  ", r)
                save_csv(title, cols, rows)
                passed += 1
            except Exception as e:
                print("ERROR:", e)
                print("SQL (first lines):")
                print("\n".join(sql.splitlines()[:14]))
            print()

        print(f"Done. {passed}/{len(fewshots)} succeeded.")
    finally:
        cur.close()
        conn.close()

if __name__ == "__main__":
    main()
