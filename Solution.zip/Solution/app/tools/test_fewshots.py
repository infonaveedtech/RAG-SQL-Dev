"""
Execute all SQL code blocks in app/prompts/fewshots.sql.md against Oracle.

- Reads env: ORACLE_DSN, ORACLE_USER, ORACLE_PASSWORD, ORACLE_OWNER
- Optional env:
    SYMBOL_ID (default 123)
    RESULT_ROW_LIMIT (default 200)  # not injected here; queries already limit.
    SAVE_CSV ("true"/"false") default "true"
- Outputs:
    Prints status and first few rows per query.
    Saves CSVs under evaluation/run_fewshots_results/ if SAVE_CSV=true.
"""

from __future__ import annotations
import os, re, sys, csv, pathlib
from typing import List, Tuple
import oracledb
from dotenv import load_dotenv

FEWSHOTS_PATH = pathlib.Path("app/prompts/fewshots.sql.md")
OUT_DIR = pathlib.Path("evaluation/run_fewshots_results")

def env(name: str, default: str | None = None, required: bool = False) -> str:
    v = os.getenv(name, default)
    if required and not v:
        print(f"Missing env: {name}", file=sys.stderr)
        sys.exit(1)
    return v or ""

def read_markdown_sql(md_path: pathlib.Path) -> List[Tuple[str, str]]:
    """Return list of (title, sql) from fenced ```sql code blocks, grabbing the nearest preceding ### header as title."""
    text = md_path.read_text(encoding="utf-8")
    # Find titles (### headers) and positions
    headers = [(m.start(), m.group(0).strip("# ").strip()) for m in re.finditer(r"^###\s+.*$", text, flags=re.M)]
    # Find code blocks
    blocks = [(m.start(), m.group(1)) for m in re.finditer(r"```sql\s*(.*?)\s*```", text, flags=re.S)]
    # Map each block to the nearest header above it
    results: List[Tuple[str, str]] = []
    for bpos, sql in blocks:
        title = "Untitled"
        above = [h for h in headers if h[0] < bpos]
        if above:
            title = above[-1][1]
        results.append((title, sql.strip()))
    return results

def substitute_placeholders(sql: str) -> str:
    symbol_id = env("SYMBOL_ID", "123")
    sql = sql.replace("{{SYMBOL_ID}}", str(symbol_id))
    return sql

def connect_oracle():
    dsn = env("ORACLE_DSN", required=True)
    user = env("ORACLE_USER", required=True)
    pwd = env("ORACLE_PASSWORD", required=True)
    owner = env("ORACLE_OWNER", required=True)
    # oracledb.init_oracle_client(lib_dir=None)
    conn = oracledb.connect(user=user, password=pwd, dsn=dsn)
    cur = conn.cursor()
    cur.execute(f"alter session set current_schema = {owner}")
    return conn, cur, owner

def run_query(cur, sql: str):
    cur.execute(sql)
    cols = [d[0] for d in cur.description] if cur.description else []
    rows = cur.fetchmany(25)  # preview up to 25 rows
    return cols, rows

def save_csv(title: str, cols: List[str], rows: List[tuple]):
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_\-]+", "_", title)[:80]
    path = OUT_DIR / f"{safe}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if cols:
            w.writerow(cols)
        for r in rows:
            w.writerow(list(r))
    return path

def main() -> None:
    load_dotenv()
    if not FEWSHOTS_PATH.exists():
        print(f"Missing {FEWSHOTS_PATH}. Create it first.", file=sys.stderr)
        sys.exit(1)

    conn, cur, owner = connect_oracle()
    save = env("SAVE_CSV", "true").lower() == "true"

    blocks = read_markdown_sql(FEWSHOTS_PATH)
    if not blocks:
        print("No ```sql blocks found.", file=sys.stderr)
        sys.exit(1)

    print(f"Found {len(blocks)} SQL examples in {FEWSHOTS_PATH}.\n")

    ok = 0
    for i, (title, raw_sql) in enumerate(blocks, start=1):
        sql = substitute_placeholders(raw_sql)
        print(f"[{i}/{len(blocks)}] {title}")
        print("—"*80)
        try:
            cols, rows = run_query(cur, sql)
            print(f"OK: {len(rows)} row(s) preview; columns: {', '.join(cols) if cols else '(none)'}")
            for r in rows[:5]:
                print("  ", r)
            if save:
                path = save_csv(title, cols, rows)
                print(f"Saved preview CSV → {path}")
            ok += 1
        except Exception as e:
            print("ERROR executing SQL:")
            print("  ", e)
            # Show first lines of SQL for quick context
            snippet = "\n".join(sql.splitlines()[:8])
            print("SQL snippet:")
            print(snippet)
        print()

    cur.close()
    conn.close()
    print(f"Done. {ok}/{len(blocks)} executed without error.")

if __name__ == "__main__":
    main()