from app.pipeline.pipeline import run_nl_query, validate_sql, execute_sql, export_sql

# 1) NL → SQL → execute preview (one LLM call)
r = run_nl_query("Top 10 symbols by traded notional in the last 7 days", preview_row_limit=10)
print(r.sql)
print(r.preview.columns, r.preview.rows[:3])

# 2) Validate a raw SQL string (no LLM, no DB exec)
v = validate_sql("SELECT s.SYMBOL FROM ATS.SYMBOLS s FETCH FIRST 10 ROWS ONLY")
print(v.ok, v.issues)

# 3) Execute a raw SQL (no LLM), with safeguards
e = execute_sql(r.sql, row_limit=500)
print(e.columns, len(e.rows))

# 4) Export (csv/html/pdf), returns bytes to write
artifact = export_sql(r.sql, fmt="csv", title="Top-10-by-notional", row_limit=1000)
with open(artifact.filename, "wb") as f:
    f.write(artifact.data)
