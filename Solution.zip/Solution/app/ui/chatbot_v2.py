# chatbot.py  —  Frontend-only Streamlit client for SQLBot API
# ------------------------------------------------------------
# This app calls your FastAPI backend:
#   /api/v1/query         → NL → SQL + preview
#   /api/v1/sql/execute   → execute edited SQL
#   /api/v1/exports       → export CSV/HTML/PDF
#   /api/v1/schema        → schema/allowlist (optional)
#   /api/v1/health        → health check
#
# Configuration (recommended):
#   .streamlit/secrets.toml
#   [api]
#   base_url = "http://localhost:8080/api/v1"
#   key = ""   # optional (for future API key auth)
#
# Or environment variables:
#   API_BASE_URL, API_KEY
#
# Dependencies: streamlit, requests, pandas (optional pretty tables)

import os
import json
import time
import requests
import streamlit as st
import pandas as pd
from typing import Dict, Any, Optional, Tuple




# ----------------------------- Config helpers ------------------------------- #

def _get_api_base() -> str:
    # Priority: Streamlit secrets → env → default
    try:
        base = st.secrets["api"]["base_url"]
    except Exception:
        base = os.getenv("API_BASE_URL", "http://localhost:8080/api/v1")
    return base.rstrip("/")

def _get_api_key() -> Optional[str]:
    try:
        key = st.secrets["api"]["key"]
    except Exception:
        key = os.getenv("API_KEY", "")
    return key.strip() or None

API_BASE = _get_api_base()
API_KEY  = _get_api_key()


def _headers(extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    h = {"Content-Type": "application/json"}
    if API_KEY:
        h["X-API-Key"] = API_KEY  # future-proof: simple header auth
    if extra:
        h.update(extra)
    return h


# ----------------------------- HTTP wrappers -------------------------------- #

class ApiError(RuntimeError):
    def __init__(self, message: str, status: Optional[int] = None, detail: Any = None):
        super().__init__(message)
        self.status = status
        self.detail = detail

def api_get_json(path: str, timeout: int = 60) -> Dict[str, Any]:
    url = f"{API_BASE}/{path.lstrip('/')}"
    try:
        r = requests.get(url, headers=_headers(), timeout=timeout)
        if r.status_code >= 400:
            raise ApiError(f"GET {path} failed ({r.status_code})", r.status_code, _safe_json(r))
        return r.json()
    except requests.RequestException as e:
        raise ApiError(f"GET {path} error: {e}") from e

def api_post_json(path: str, payload: Dict[str, Any], timeout: int = 90) -> Dict[str, Any]:
    url = f"{API_BASE}/{path.lstrip('/')}"
    try:
        r = requests.post(url, headers=_headers(), json=payload, timeout=timeout)
        if r.status_code >= 400:
            raise ApiError(f"POST {path} failed ({r.status_code})", r.status_code, _safe_json(r))
        # Some endpoints return file streams; here we only call JSON endpoints.
        return r.json()
    except requests.RequestException as e:
        raise ApiError(f"POST {path} error: {e}") from e
    
# ------------------------------ Small helpers -------------------------------- #

def _format_error(e: ApiError) -> str:
    if e.detail:
        try:
            return json.dumps(e.detail, indent=2)
        except Exception:
            return f"{e} — detail: {e.detail}"
    return str(e)

def _filename_from_headers(headers: Dict[str, str]) -> Optional[str]:
    cd = headers.get("Content-Disposition", "")
    # Expect: attachment; filename="file.ext"
    if "filename=" in cd:
        part = cd.split("filename=", 1)[1].strip().strip(";")
        return part.strip('"')
    return None

def _ext_for_format(fmt: str) -> str:
    return {"csv": "csv", "html": "html", "pdf": "pdf"}.get(fmt.lower(), "dat")

def api_post_stream(path: str, payload: Dict[str, Any], timeout: int = 120) -> Tuple[bytes, Dict[str, str]]:
    """
    For /exports which returns a file stream. Returns (bytes, headers).
    """
    url = f"{API_BASE}/{path.lstrip('/')}"
    try:
        r = requests.post(url, headers=_headers({"Accept": "*/*"}), json=payload, timeout=timeout)
        if r.status_code >= 400:
            raise ApiError(f"POST {path} failed ({r.status_code})", r.status_code, _safe_json(r))
        return r.content, r.headers
    except requests.RequestException as e:
        raise ApiError(f"POST {path} error: {e}") from e

def _safe_json(resp: requests.Response) -> Any:
    try:
        return resp.json()
    except Exception:
        return resp.text


# ----------------------------- Streamlit UI --------------------------------- #

st.set_page_config(page_title="ATS SQLBot", page_icon="🧠", layout="wide")
st.title("🧠 ATS SQLBot — NL → SQL → Results → Export")

with st.sidebar:
    st.subheader("⚙️ Settings")
    st.caption("Backend API")
    api_url_in = st.text_input("API Base URL", value=API_BASE, help="e.g., http://localhost:8080/api/v1")
    if api_url_in.strip() != API_BASE:
        API_BASE = api_url_in.strip().rstrip("/")
        st.session_state["api_base_override"] = API_BASE

    strategy = st.selectbox("Model Strategy", options=["gemini", "auto"], index=0,
                            help="We default to Gemini. 'auto' currently routes to Gemini.")

    preview_limit = st.number_input("Preview row limit (/query)", min_value=1, max_value=1000, value=10, step=1)
    exec_limit    = st.number_input("Execution row limit (/sql/execute)", min_value=1, max_value=5000, value=500, step=50)

    st.divider()
    st.caption("Health & Schema")
    col_h1, col_h2 = st.columns(2)
    with col_h1:
        if st.button("🔎 Health"):
            with st.spinner("Checking health..."):
                try:
                    h = api_get_json("health")
                    st.success(json.dumps(h, indent=2))
                except ApiError as e:
                    st.error(_format_error(e))
    with col_h2:
        if st.button("📇 Schema"):
            with st.spinner("Fetching schema..."):
                try:
                    s = api_get_json("schema")
                    st.success(json.dumps(s, indent=2))
                except ApiError as e:
                    st.error(_format_error(e))

# Session state
if "last_sql" not in st.session_state:
    st.session_state.last_sql = ""
if "last_preview" not in st.session_state:
    st.session_state.last_preview = None
if "last_exec" not in st.session_state:
    st.session_state.last_exec = None


# ------------------------- NL → SQL → Preview block -------------------------- #

st.header("1) Ask a question (Natural Language)")
question = st.text_area(
    "Your question",
    value="Top 10 symbols by traded value last 7 days with symbol names",
    height=100,
    placeholder="e.g., Top 10 symbols by traded notional in the last week with symbol names",
)

c1, c2 = st.columns([1, 4])
with c1:
    gen_clicked = st.button("✨ Generate (NL → SQL)")

if gen_clicked:
    if not question.strip():
        st.warning("Please enter a question.")
    else:
        with st.spinner("Calling backend (Gemini → SQL → preview)..."):
            t0 = time.time()
            try:
                res = api_post_json("query", {
                    "question": question.strip(),
                    "strategy": strategy,
                    "preview_row_limit": int(preview_limit),
                })
                t1 = time.time()
                st.session_state.last_sql = res.get("sql", "")
                st.session_state.last_preview = res.get("preview", None)

                st.success(f"Generated in {(t1 - t0)*1000:.0f} ms")
            except ApiError as e:
                st.error(_format_error(e))

if st.session_state.last_sql:
    st.subheader("Generated SQL")
    st.code(st.session_state.last_sql, language="sql")

if st.session_state.last_preview:
    st.subheader("Preview")
    cols = st.session_state.last_preview.get("columns", [])
    rows = st.session_state.last_preview.get("rows", [])
    if cols and rows is not None:
        try:
            df_prev = pd.DataFrame(rows, columns=cols)
            st.dataframe(df_prev, width='stretch', hide_index=True)
        except Exception:
            st.write(rows)


# ---------------------------- Execute SQL block ------------------------------ #

st.header("2) Execute edited SQL (optional)")
sql_edit = st.text_area(
    "SQL to execute",
    value=st.session_state.last_sql,
    height=180,
    placeholder="Paste or edit SQL here…",
)
c3a, c3b = st.columns([1, 4])
with c3a:
    run_clicked = st.button("▶ Run SQL")

if run_clicked:
    if not sql_edit.strip():
        st.warning("Provide SQL to execute.")
    else:
        with st.spinner("Executing SQL with guardrails…"):
            try:
                res = api_post_json("sql/execute", {
                    "sql": sql_edit.strip(),
                    "row_limit": int(exec_limit),
                })
                st.session_state.last_exec = res
                st.success(f"Got {len(res.get('rows', []))} rows (limit applied: {res.get('row_limit_applied')})")
            except ApiError as e:
                st.error(_format_error(e))

if st.session_state.last_exec:
    st.subheader("Execution Result")
    cols = st.session_state.last_exec.get("columns", [])
    rows = st.session_state.last_exec.get("rows", [])
    if cols and rows is not None:
        try:
            df_exec = pd.DataFrame(rows, columns=cols)
            st.dataframe(df_exec, width='stretch', hide_index=True)
        except Exception:
            st.write(rows)


# ------------------------------- Export block -------------------------------- #

st.header("3) Export")
exp_format = st.selectbox("Format", options=["csv", "html", "pdf"], index=0)
exp_title  = st.text_input("Title (used in filename)", value="Report")
export_clicked = st.button("⬇ Export file")

if export_clicked:
    sql_for_export = sql_edit.strip() or st.session_state.last_sql
    if not sql_for_export:
        st.warning("No SQL to export. Generate or paste some SQL first.")
    else:
        with st.spinner(f"Exporting as {exp_format.upper()}…"):
            try:
                data, headers = api_post_stream("exports", {
                    "sql": sql_for_export,
                    "format": exp_format,
                    "title": exp_title.strip() or "Report",
                    "row_limit": int(exec_limit),
                })
                filename = _filename_from_headers(headers) or f"{exp_title}.{_ext_for_format(exp_format)}"
                st.download_button(
                    label=f"Download {filename}",
                    data=data,
                    file_name=filename,
                    mime=headers.get("Content-Type", "application/octet-stream"),
                )
                st.success("Export ready.")
            except ApiError as e:
                st.error(_format_error(e))



