import os, pdfkit, tempfile
from jinja2 import Environment, FileSystemLoader, select_autoescape
from datetime import datetime

# jinja env
TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "templates")
_jenv = Environment(
    loader=FileSystemLoader(TEMPLATES_DIR),
    autoescape=select_autoescape(["html"])
)

def render_report_html(context: dict) -> str:
    tpl = _jenv.get_template("report.html")
    return tpl.render(**context)

def html_to_pdf_bytes(html: str) -> bytes:
    wkhtml = os.getenv("WKHTMLTOPDF_PATH")
    cfg = pdfkit.configuration(wkhtmltopdf=wkhtml) if wkhtml else None
    # some sane printing options
    options = {
        "page-size": "A4",
        "margin-top": "10mm",
        "margin-right": "10mm",
        "margin-bottom": "12mm",
        "margin-left": "10mm",
        "encoding": "UTF-8",
        "print-media-type": None,
        "quiet": "",
    }
    with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
        f.write(html.encode("utf-8"))
        html_path = f.name
    try:
        pdf_bytes = pdfkit.from_file(html_path, False, configuration=cfg, options=options)
        return pdf_bytes
    finally:
        try: os.remove(html_path)
        except: pass

def build_report_pdf(context: dict) -> bytes:
    html = render_report_html(context)
    return html_to_pdf_bytes(html)
