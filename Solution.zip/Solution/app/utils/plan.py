from __future__ import annotations
import re
from typing import Optional

def parse_rows_estimate(plan_text: str) -> Optional[int]:
    """
    Parse DBMS_XPLAN.DISPLAY() table output and return a conservative max Rows estimate.
    Works with the ASCII table format:
      | Id | Operation ... | Rows | Bytes | ...
    """
    lines = plan_text.splitlines()

    # Find header line containing | Rows |
    header_idx = None
    for i, line in enumerate(lines):
        if re.search(r"\|\s*Rows\s*\|", line):
            header_idx = i
            break
    if header_idx is None:
        return None

    # Determine column boundaries by splitting on '|' and finding the index of 'Rows'
    header_parts = [p.strip() for p in lines[header_idx].split("|")]
    try:
        rows_col_idx = [i for i, p in enumerate(header_parts) if p.lower() == "rows"][0]
    except IndexError:
        return None

    # Walk subsequent lines until the table ends (blank or no leading '|')
    max_rows = 0
    for line in lines[header_idx + 1:]:
        if not line.strip() or "|" not in line:
            # likely end of table
            break
        parts = [p.strip() for p in line.split("|")]
        if len(parts) <= rows_col_idx:
            continue
        cell = parts[rows_col_idx]
        # Skip header dividers and non-numeric cells
        if not re.match(r"^\d+$", cell):
            continue
        max_rows = max(max_rows, int(cell))

    return max_rows or None