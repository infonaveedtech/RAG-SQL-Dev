# 🧩 SQLBot API – Integration Notice
## Overview
SQLBot API is a standalone Python FastAPI service that converts natural-language questions into safe, validated Oracle SQL, executes the query, and returns results or exports (CSV / HTML / PDF).  
It runs independently (not inside Tomcat) and is consumed over HTTPS via simple HTTP requests.

```
🔗 Base URL
https://sqlbot.mycompany.com/api/v1

```
*(replace with your deployed hostname or internal URL)*


## 🔐 Authentication
All routes (except `/health`) require an API key.

| Header | Example | Purpose |
|---------|----------|----------|
| `X-Api-Key` | `X-Api-Key: 3b17a91f-...` | Identifies authorized callers |

> Each integrated app will be issued its own key.  
> Keep it secret — do not embed in client-side JavaScript or logs.

---

## ⚙️ Endpoints

| Method | Path | Description |
|---------|------|--------------|
| **GET** | `/health` | Service & DB status check (no auth) |
| **GET** | `/schema` | Lists available tables / columns |
| **POST** | `/query` | NL question → generated SQL + preview |
| **POST** | `/sql/validate` | Validate supplied SQL (does not execute) |
| **POST** | `/sql/execute` | Execute safe SQL and return rows |
| **POST** | `/exports` | Execute SQL and download CSV / HTML / PDF |

All responses are JSON unless an export format is requested.

---

## 🧾 Example Request

```http
POST /api/v1/query HTTP/1.1
Host: sqlbot.mycompany.com
Content-Type: application/json
X-Api-Key: 3b17a91f-...

{
  "question": "show top 5 trades with price and volume"
}
````

### Example Response

```json
{
  "sql": "SELECT PRICE, VOLUME FROM TRADES FETCH FIRST 5 ROWS ONLY",
  "guards": { "read_only": true, "allowlist_ok": true },
  "preview": [
    {"PRICE": 12.5, "VOLUME": 1000},
    {"PRICE": 13.2, "VOLUME": 850}
  ]
}
```

---

## 💾 Export Example

```http
POST /api/v1/exports
Content-Type: application/json
X-Api-Key: 3b17a91f-...

{
  "sql": "SELECT * FROM TRADES FETCH FIRST 10 ROWS ONLY",
  "format": "csv",
  "title": "recent_trades"
}
```

The response is a downloadable file stream.

---

## 🧠 Notes for Integrators

* Call the API over **HTTPS** only.
* Add `X-Api-Key` on every request.
* Handle standard HTTP codes:

  * 200 OK = success
  * 401 Unauthorized = missing/invalid key
  * 400 Bad Request = invalid payload or SQL
  * 500 Server Error = unexpected issue
* The service runs in **Admin scope** for now; row-level security will be added later.
* Time-outs and row-limits are enforced server-side.

---

## 🧱 Deployment Summary (for Ops)

* Runs as Docker container or `uvicorn` process.
* Expose port 8080 internally; reverse-proxy to HTTPS domain.
* Required env vars:

  * `API_KEY` – shared secret for client auth
  * `ORACLE_DSN`, `ORACLE_USER`, `ORACLE_PASSWORD` – read-only DB access
  * `GEMINI_API_KEY` – internal LLM key (never shared)
* Health check: `GET /api/v1/health`

---