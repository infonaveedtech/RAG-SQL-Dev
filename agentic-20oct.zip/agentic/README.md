```
            ┌────────────┐         ┌──────────────┐         ┌──────────────┐
User NL ───▶│  Agent-0   │  JSON   │   Agent-1    │  Plan   │   Agent-2    │─┐
 query      │ (Intent)   ├────────▶│ (Selector)   ├────────▶│ (SQL+Runner) │ │
            └────────────┘         └──────────────┘         └──────────────┘ │
                   ▲                         │                results/binds   │
                   │                         ▼                               ▼
             Streamlit UI             META_* catalog                   HTML/preview
```



```
codes/
├─ app.py                        ← Streamlit front-end (single page app)
├─ crawler.py                    ← Oracle schema crawler → JSON snapshot
├─ db.py                         ← Simple connection test utility
├─ agents/
│  ├─ agent0_intent.py           ← Agent-0: NL intent → structured JSON (Ollama)
│  ├─ agent1_selector.py         ← Agent-1: deterministic selection plan from META_*
│  └─ agent2_sql.py              ← Agent-2: build+validate SQL, run, format
├─ cli/
│  ├─ agent0_demo.py             ← Quick CLI harnesses for each agent
│  ├─ agent1_demo.py
│  └─ agent2_demo.py
├─ core/
│  ├─ create_catalog.py          ← DDL for META_* (tables/cols/keys/comments/etc.)
│  ├─ load_catalog.py            ← Populate META_* from crawler JSON + keep lists
│  ├─ selector_sql.py            ← Small SQL helpers Agent-1 uses against META_*
│  ├─ db_conn.py                 ← Oracle/SQLite connection management (oracledb/sqlite)
│  ├─ llm_ollama.py              ← Minimal wrapper to call Ollama /api/generate (JSON)
│  └─ schemas.py                 ← Pydantic models for Agent-0 payload (+ order/math)
├─ data/raw/
│  └─ ats_schema_2025-10-16.json ← Full real schema snapshot (crawler output)
└─ selection_stats/              ← Keep/omit lists + selection summary snapshot
   ├─ must_keep_*.csv
   ├─ omit_now_*.csv
   ├─ candidate_*.csv
   └─ selection_summary_*.json
```