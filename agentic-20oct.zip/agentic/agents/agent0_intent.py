# agentic/agents/agent0_intent_v2.py
from __future__ import annotations
from pathlib import Path
from pydantic import ValidationError
from datetime import datetime, timedelta
from agentic.core.llm_ollama import generate_json
from agentic.core.schemas import IntentV2
from agentic.core.normalizers import normalize_intent_v2

PROMPT_PATH = Path(__file__).resolve().parents[1] / "core" / "prompt_templates" / "agent0_v2_system.txt"

def _coerce_nulls(obj):
    """Recursively turn string 'null'/'None' into None to avoid validation errors."""
    if isinstance(obj, dict):
        return {k: _coerce_nulls(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_coerce_nulls(x) for x in obj]
    if isinstance(obj, str) and obj.strip().lower() in ("null", "none"):
        return None
    return obj

def infer_intent_v2(
    user_text: str,
    model: str = "llama3.1:8b",
    temperature: float = 0.1,
    timeout: int = 60,
) -> IntentV2:
    if not user_text or not user_text.strip():
        raise ValueError("Empty input text.")

    system_prompt = PROMPT_PATH.read_text(encoding="utf-8")
    prompt = f"{system_prompt}\n\nUser: {user_text.strip()}\nAssistant:"

    raw = generate_json(prompt, model=model, temperature=temperature, timeout=timeout)
    raw.setdefault("original_text", user_text)

    try:
        intent = IntentV2(**raw)
    except ValidationError:
        # Try again after coercing 'null'/'None' strings → None
        raw2 = _coerce_nulls(raw)
        intent = IntentV2(**raw2)

    # Optional: light relative-date handling (today/yesterday) if user typed it as a filter
    text_lower = (user_text or "").lower()
    today = datetime.now().date()
    if "today" in text_lower and (not intent.time_range or not intent.time_range.from_date):
        # set to today's date, daily granularity
        from_to = today.isoformat()
        if intent.time_range is None:
            # create minimal inline object-like; normalizer will tidy
            intent.time_range = type("TR", (), {})()
        intent.time_range.from_date = from_to  # type: ignore
        intent.time_range.to_date = from_to    # type: ignore
        if getattr(intent.time_range, "granularity", None) is None:
            intent.time_range.granularity = "day"  # type: ignore

    if "yesterday" in text_lower and (not intent.time_range or not intent.time_range.from_date):
        y = (today - timedelta(days=1)).isoformat()
        if intent.time_range is None:
            intent.time_range = type("TR", (), {})()
        intent.time_range.from_date = y   # type: ignore
        intent.time_range.to_date = y     # type: ignore
        if getattr(intent.time_range, "granularity", None) is None:
            intent.time_range.granularity = "day"  # type: ignore

    # Gentle, schema-free normalization
    intent = normalize_intent_v2(intent, now=datetime.now())
    return intent
