# agentic/agents/agent1_solution_decider_llm.py
from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Dict, Any, List

from pydantic import ValidationError
from agentic.core.schemas import IntentV2, SolutionDecision
from agentic.core.llm_ollama import generate_json

# ---- minimal column probes for the three tables -------------------------

SDI_TABLE_PATTERNS = [r"^SYMBOL_DAILY_INDICATORS$", r"^SYMBOLS?_DAILY_?INDICATORS?$"]
SI_TABLE_PATTERNS  = [r"^SYMBOL_INDICATORS$", r"^SYMBOLS?_INDICATORS?$"]
BM_TABLE_PATTERNS  = [r"^BEST_?MKT$", r"^BEST_?MARKET$"]

def _matches(name: str, pats: List[str]) -> bool:
    u = name.upper()
    for p in pats:
        if re.search(p, u):
            return True
    return False

def _probe_table(entry: Dict[str, Any], wants: List[str]) -> Dict[str, bool]:
    cols = [c.get("column_name","").upper() for c in entry.get("columns", [])]
    return {w: (w.upper() in cols) for w in wants}

def _build_catalog_context(catalog_entries: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Build a minimal LLM context describing which signal columns exist in SDI/SI/BM.
    This stays abstract; we don't expose schema internals beyond top-level table names & column presence.
    """
    ctx: Dict[str, Any] = {"available": {"SDI": None, "SI": None, "BM": None}}
    for e in catalog_entries:
        tname = e.get("table_name","").upper()
        owner = e.get("owner","")
        fq = f"{owner}.{tname}" if owner else tname

        if _matches(tname, SDI_TABLE_PATTERNS):
            ctx["available"]["SDI"] = {
                "table": fq,
                "signals": _probe_table(e, [
                    "STATS_DATE", "TURNOVER_VALUE", "CLOSE_PRICE",
                    "OPEN_PRICE", "HIGH_PRICE", "LOW_PRICE",
                    "TRADES_COUNT", "SYMBOL_ID", "EXCHANGE_ID"
                ])
            }
        elif _matches(tname, SI_TABLE_PATTERNS):
            ctx["available"]["SI"] = {
                "table": fq,
                "signals": _probe_table(e, [
                    "ENTRY_DATETIME", "VOLUME", "VALUE",
                    "CLOSE", "OPEN", "HIGH", "LOW",
                    "SYMBOL_ID", "EXCHANGE_ID"
                ])
            }
        elif _matches(tname, BM_TABLE_PATTERNS):
            ctx["available"]["BM"] = {
                "table": fq,
                "signals": _probe_table(e, [
                    "ENTRY_DATETIME", "BID_PRICE", "OFFER_PRICE",
                    "BID_VOLUME", "OFFER_VOLUME", "SYMBOL_ID", "EXCHANGE_ID"
                ])
            }
    return ctx

# ---- public API ----------------------------------------------------------

def decide_solution_llm(
    intent: IntentV2,
    catalog_json_path: str | Path,
    model: str = "llama3.1:8b",
    temperature: float = 0.0,   # lower drift
    timeout: int = 60,
) -> SolutionDecision:
    """
    LLM-only Agent-1:
      - loads the crawled catalog JSON (ats_schema_YYYY-MM-DD.json)
      - builds a tiny availability context for SDI/SI/BM
      - prompts the LLM (system prompt file) with: context + user text + Agent-0 intent JSON
      - returns SolutionDecision
    """
    # Load prompt
    prompt_path = Path(__file__).resolve().parents[1] / "core" / "prompt_templates" / "agent1_system.txt"
    system_prompt = prompt_path.read_text(encoding="utf-8")

    # Load catalog
    cat_path = Path(catalog_json_path)
    entries = json.loads(cat_path.read_text(encoding="utf-8"))
    if not isinstance(entries, list):
        raise ValueError("Catalog JSON must be a list of table entries.")

    # Build LLM context
    ctx = _build_catalog_context(entries)

    # Compose single prompt (minified JSON payloads)
    prompt = (
        system_prompt
        + "\n\n# Catalog context (JSON)\n"
        + json.dumps(ctx, separators=(",", ":"))
        + "\n\n# User text\n"
        + (intent.original_text or "")
        + "\n\n# Agent-0 intent (JSON)\n"
        + intent.model_dump_json()
        + "\n\n# Respond now with the single decision JSON:\n"
    )

    raw = generate_json(prompt, model=model, temperature=temperature, timeout=timeout)

    try:
        decision = SolutionDecision(**raw)
    except ValidationError as ve:
        raise ValueError(f"Agent-1 LLM decision validation failed: {ve}\nRaw: {raw}") from ve

    return decision
