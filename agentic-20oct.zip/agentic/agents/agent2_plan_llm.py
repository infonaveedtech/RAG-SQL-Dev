# agentic/agents/agent2_plan_llm.py
from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict
from agentic.core.llm_ollama import generate_json

def plan_query_llm(
    user_text: str,
    intent_json: Dict[str, Any],
    decision_json: Dict[str, Any],
    stats_catalog_path: str | Path,
    system_prompt_path: str | Path,
    model: str = "llama3.1:8b",
    temperature: float = 0.0,   # reduce creativity; we want strict schema
    timeout: int = 90,
) -> Dict[str, Any]:
    """
    Compose Agent-2 prompt with:
      - system prompt (agent2_system.txt)
      - stats_catalog.json (enriched, minified)
      - user text
      - Agent-0 intent (JSON, minified)
      - Agent-1 decision (JSON, minified)
    Returns the LLM JSON (Plan) as a dict.
    """
    system_prompt = Path(system_prompt_path).read_text(encoding="utf-8")
    catalog_json = json.loads(Path(stats_catalog_path).read_text(encoding="utf-8"))

    prompt = (
        system_prompt
        + "\n\n# stats_catalog (JSON)\n"
        + json.dumps(catalog_json, separators=(",", ":"))
        + "\n\n# user_text\n"
        + (user_text or "")
        + "\n\n# agent0_intent (JSON)\n"
        + json.dumps(intent_json, separators=(",", ":"))
        + "\n\n# agent1_decision (JSON)\n"
        + json.dumps(decision_json, separators=(",", ":"))
        + "\n\n# Respond with ONE JSON object that begins with {\"plan_type\": and passes the COMPLIANCE GATE above:\n"
    )

    return generate_json(prompt, model=model, temperature=temperature, timeout=timeout)
