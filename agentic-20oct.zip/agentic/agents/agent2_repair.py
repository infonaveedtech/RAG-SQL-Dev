# agentic/agents/agent2_repair.py
from __future__ import annotations
from typing import Any, Dict, List, Tuple

def _norm_case(s: str | None) -> str:
    return (s or "").strip()

def _get_date_info(single: Dict[str, Any]) -> Tuple[str, str, str]:
    dk = single.get("date_key") or {}
    alias = dk.get("table_alias") or (single.get("fact") or {}).get("alias") or ""
    col   = dk.get("column") or ""
    gran  = (dk.get("granularity") or "day").lower()
    return alias, col, gran

def _ensure_joins(single: Dict[str, Any]) -> None:
    joins = single.setdefault("joins", [])
    have = { (j.get("name") or "").upper() for j in joins }
    if "ATS.SYMBOLS" not in have:
        fact_alias = (single.get("fact") or {}).get("alias") or "t"
        joins.append({
            "name":"ATS.SYMBOLS","alias":"sym",
            "on": f"{fact_alias}.SYMBOL_ID = sym.SYMBOL_ID","type":"inner"
        })
    if "ATS.EXCHANGES" not in have:
        fact_alias = (single.get("fact") or {}).get("alias") or "t"
        joins.append({
            "name":"ATS.EXCHANGES","alias":"ex",
            "on": f"{fact_alias}.EXCHANGE_ID = ex.EXCHANGE_ID","type":"inner"
        })

def _ensure_dimensions_labels(single: Dict[str, Any]) -> None:
    dims = single.setdefault("dimensions", [])
    # remove *_ID projections
    dims[:] = [d for d in dims if not (_norm_case(d.get("column","")).upper().endswith("_ID"))]

    aliases = { _norm_case(d.get("alias","")).lower() for d in dims }
    if "symbol" not in aliases:
        dims.append({"expr":"sym.SYMBOL","alias":"symbol"})
    if "exchange" not in aliases:
        dims.append({"expr":"ex.EXCHANGE_NAME","alias":"exchange"})

    # Ensure period
    fact_alias, date_col, gran = _get_date_info(single)
    if fact_alias and date_col:
        fmt = {"day":"DD","month":"MM","year":"YYYY"}.get(gran,"DD")
        period_expr = f"TRUNC({fact_alias}.{date_col},'{fmt}')"
        if not any(_norm_case(d.get("alias","")).lower()=="period" for d in dims):
            dims.insert(0, {"expr": period_expr, "alias":"period"})
        # group_by: normalize and ensure required keys
        gb = single.setdefault("group_by", [])
        gb_norm: List[str] = []
        for g in gb:
            if isinstance(g, dict) and "column" in g:
                gb_norm.append(g["column"])
            elif isinstance(g, str):
                gb_norm.append(g)
        # drop *_ID in group_by
        gb_norm = [g for g in gb_norm if not g.upper().endswith("_ID")]
        for w in (period_expr, "sym.SYMBOL", "ex.EXCHANGE_NAME"):
            if w not in gb_norm:
                gb_norm.append(w)
        # dedupe while preserving order
        seen = set(); gb_dedup = []
        for g in gb_norm:
            if g not in seen:
                seen.add(g); gb_dedup.append(g)
        single["group_by"] = gb_dedup

def _normalize_measures(single: Dict[str, Any]) -> None:
    fa = (single.get("fact") or {}).get("alias") or "t"
    m_new: List[Dict[str, Any]] = []
    for m in single.get("measures", []):
        if "expr" in m:
            if "alias" not in m:
                m["alias"] = _infer_alias_from_expr(m["expr"])
            m_new.append(m)
        else:
            name = m.get("name") or m.get("alias") or ""
            col  = m.get("column") or ""
            agg  = (m.get("agg") or "").upper()
            if agg and col:
                expr = f"{agg}({fa}.{col})"
                alias = name or col.lower()
                m_new.append({"expr": expr, "alias": alias})
    if m_new:
        single["measures"] = m_new

def _infer_alias_from_expr(expr: str) -> str:
    e = expr.upper()
    if "TURNOVER" in e and "VALUE" in e: return "turnover"
    if "VOLUME" in e: return "volume"
    if "CLOSE_PRICE" in e and "AVG" in e: return "avg_price"
    if "OFFER_PRICE" in e and "BID_PRICE" in e and ("-" in e): return "avg_spread"
    if "OFFER_PRICE - BID_PRICE" in e: return "spread"
    return "measure"

def _strip_non_expr_predicates(single: Dict[str, Any]) -> None:
    """Keep only normalized {'expr': '...'} predicates; drop LLM leftovers like {'field':...}."""
    preds = single.get("predicates", [])
    kept: List[Dict[str, str]] = []
    for p in preds:
        if isinstance(p, dict) and "expr" in p and isinstance(p["expr"], str) and p["expr"].strip():
            kept.append({"expr": p["expr"].strip()})
        elif isinstance(p, str) and p.strip():
            kept.append({"expr": p.strip()})
        # else drop
    if kept:
        single["predicates"] = kept
    else:
        single.pop("predicates", None)

def _ensure_time_predicate(single: Dict[str, Any], p_from: str | None, p_to: str | None) -> None:
    fa, dc, _ = _get_date_info(single)
    if not (fa and dc):
        return
    preds = single.setdefault("predicates", [])
    has_between = any(" BETWEEN " in (p.get("expr","").upper()) for p in preds)
    if not has_between:
        preds.append({"expr": f"{fa}.{dc} BETWEEN :p_from AND :p_to"})
    binds = single.setdefault("binds", {})
    if p_from: binds.setdefault("p_from", p_from)
    if p_to:   binds.setdefault("p_to",   p_to)

def _normalize_order_limit(single: Dict[str, Any], top_n: int | None) -> None:
    # order_by → dict with expr + direction
    ob = single.get("order_by")
    if isinstance(ob, list) and ob:
        item = ob[0]
        if isinstance(item, dict):
            expr = item.get("expr") or item.get("by") or item.get("column") or ""
            dirn = (item.get("direction") or "desc").lower()
        else:
            expr, dirn = str(item), "desc"
        single["order_by"] = {"expr": expr, "direction": dirn}
    elif isinstance(ob, dict):
        ob["expr"] = ob.get("expr") or ob.get("by") or ob.get("column") or ""
        ob["direction"] = (ob.get("direction") or "desc").lower()
        single["order_by"] = ob
    else:
        single["order_by"] = None

    # If expr missing/empty → use first measure alias
    if isinstance(single.get("order_by"), dict):
        if not single["order_by"].get("expr"):
            m = (single.get("measures") or [])
            if m:
                single["order_by"]["expr"] = m[0].get("alias") or "measure"
            else:
                single["order_by"]["expr"] = "measure"

    # limit → {"top_n": N, "bind":"p_top_n"}
    lim = single.get("limit")
    if isinstance(lim, dict) and "value" in lim:
        n = int(lim.get("value") or 0)
        single["limit"] = {"top_n": n, "bind":"p_top_n"} if n else None
    elif isinstance(lim, int):
        single["limit"] = {"top_n": int(lim), "bind":"p_top_n"}
    # ensure bind present
    if isinstance(single.get("limit"), dict) and "top_n" in single["limit"]:
        single.setdefault("binds", {}).setdefault("p_top_n", int(single["limit"]["top_n"]))
    elif top_n:
        single["limit"] = {"top_n": int(top_n), "bind":"p_top_n"}
        single.setdefault("binds", {}).setdefault("p_top_n", int(top_n))

def _remove_topn_filter_predicates(single: Dict[str, Any]) -> None:
    """Drop silly LLM filters like volume='top 5' since limit handles it."""
    preds = single.get("predicates") or []
    cleaned: List[Dict[str, str]] = []
    for p in preds:
        expr = (p.get("expr") or "").lower()
        if "top 5" in expr or "top 10" in expr or "top " in expr:
            continue
        cleaned.append(p)
    single["predicates"] = cleaned

def _maybe_add_handoff_predicate_for_multi(step_idx: int, steps: List[Dict[str, Any]]) -> None:
    if step_idx == 0:
        steps[0].setdefault("outputs", {"symbols":"symbol"})
        return
    cur = steps[step_idx]
    preds = cur.setdefault("predicates", [])
    has_in = any(":p_symbols_from_step(" in (p.get("expr","")) for p in preds)
    if not has_in:
        preds.append({"expr":"sym.SYMBOL IN :p_symbols_from_step('step0','symbols')"})

def _repair_single(single: Dict[str, Any], intent_json: Dict[str, Any]) -> None:
    _ensure_joins(single)
    _ensure_dimensions_labels(single)
    _normalize_measures(single)
    # normalize predicates (keep only expr), then ensure time, then drop topN noise
    _strip_non_expr_predicates(single)
    tr = intent_json.get("time_range") or {}
    p_from, p_to = tr.get("from_date"), tr.get("to_date")
    _ensure_time_predicate(single, p_from, p_to)
    _remove_topn_filter_predicates(single)
    # order/limit
    ord_spec = intent_json.get("ordering") or {}
    top_n = ord_spec.get("top_n")
    _normalize_order_limit(single, top_n)

def repair_plan(plan: Dict[str, Any], intent_json: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(plan, dict):
        return plan
    p = json_safe_copy(plan)

    if p.get("plan_type") == "single":
        _repair_single(p, intent_json)
        return p

    if p.get("plan_type") == "multi":
        steps = p.get("steps") or []
        for i, step in enumerate(steps):
            _repair_single(step, intent_json)
            _maybe_add_handoff_predicate_for_multi(i, steps)
        # bubble up binds
        top_binds = p.get("binds") or {}
        for st in steps:
            for k, v in (st.get("binds") or {}).items():
                top_binds.setdefault(k, v)
        if top_binds:
            p["binds"] = top_binds
        return p

    return p

def json_safe_copy(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: json_safe_copy(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [json_safe_copy(v) for v in obj]
    return obj
