# agentic/agents/agent3_executor.py
from __future__ import annotations
import oracledb
from typing import Any, Dict, List, Tuple
import re
import datetime as dt

from agentic.agents.sql_safety import (
    ensure_read_only,
    allowed_tables_from_catalog,
    vet_sql_or_raise as _vet_sql_or_raise,  # rename import to avoid shadowing
)

from dotenv import load_dotenv
load_dotenv()

# Get user pass dsn from env vars

# ---------------------------------------------------------
# Oracle connection helper
# ---------------------------------------------------------
def _get_conn() -> oracledb.Connection:
    import os
    user = os.environ.get("ORACLE_USER")
    pwd = os.environ.get("ORACLE_PASSWORD")
    dsn = os.environ.get("ORACLE_DSN")
    if not all([user, pwd, dsn]):
        raise ValueError("Missing DB credentials in environment (DB_USER, DB_PASS, DB_DSN).")
    return oracledb.connect(user=user, password=pwd, dsn=dsn)


# ---------------------------------------------------------
# Execute SQL safely
# ---------------------------------------------------------
# agentic/agents/agent3_executor.py


# ... keep your existing _get_conn() and dotenv-loading here ...

_DATE_ONLY_RE   = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_DATETIME_RE    = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$")
_INT_RE         = re.compile(r"^\d+$")

def _coerce_binds(binds: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert string binds to proper Python types Oracle expects:
      - 'YYYY-MM-DD'               -> datetime.date
      - 'YYYY-MM-DD HH:MM[:SS]'    -> datetime.datetime
      - numeric strings (e.g. p_top_n) -> int
    Leaves everything else as-is.
    """
    if not binds:
        return {}
    out: Dict[str, Any] = {}
    for k, v in binds.items():
        if isinstance(v, str):
            s = v.strip()
            if _DATE_ONLY_RE.match(s):
                # date-only
                out[k] = dt.datetime.strptime(s, "%Y-%m-%d").date()
                continue
            if _DATETIME_RE.match(s):
                # datetime; accept both " " and "T"
                s2 = s.replace("T", " ")
                fmt = "%Y-%m-%d %H:%M:%S" if len(s2) == 19 else "%Y-%m-%d %H:%M"
                out[k] = dt.datetime.strptime(s2, fmt)
                continue
            if _INT_RE.match(s):
                # plain integer (useful for p_top_n)
                try:
                    out[k] = int(s)
                    continue
                except Exception:
                    pass
            # leave other strings alone
            out[k] = v
        else:
            # if already numeric/date-like, keep as-is
            out[k] = v
    return out

def execute_sql(sql: str, binds: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[str]]:
    """
    Runs a SELECT and returns (rows, columns).
    rows -> list of dicts
    columns -> list of column names
    """
    conn = _get_conn()
    try:
        with conn.cursor() as cur:
            safe_binds = _coerce_binds(binds or {})
            cur.execute(sql, safe_binds)
            colnames = [d[0] for d in cur.description] if cur.description else []
            data = cur.fetchall() or []
            rows = [{colnames[i]: val for i, val in enumerate(r)} for r in data]
            return rows, colnames
    finally:
        try:
            conn.close()
        except Exception:
            pass



# ---------------------------------------------------------
# Safety validation wrapper
# ---------------------------------------------------------
def safe_vet_sql_or_raise(sql: str, stats_catalog: Dict[str, Any]) -> None:
    """
    Ensure read-only SQL and that all referenced tables are in stats_catalog.
    """
    ensure_read_only(sql)
    _vet_sql_or_raise(sql, stats_catalog)
