# # agentic/agents/agent3_orchestrator.py
# from __future__ import annotations
# from typing import Any, Dict, Tuple
# from .agent3_sql_compiler import compile_sql_single, compile_sql_multi
# from .agent3_executor import execute_sql, vet_sql_or_raise
# import copy

# # NEW: make plan safe/normalized for the compiler
# def _normalize_plan(plan: Dict[str, Any]) -> Dict[str, Any]:
#     p = copy.deepcopy(plan)

#     def _norm_joins(joins):
#         out = []
#         for j in joins or []:
#             # keep only entries that have the fields we actually compile
#             if isinstance(j, dict) and all(k in j for k in ("name", "alias", "on")):
#                 # ensure type present
#                 if "type" not in j or not j["type"]:
#                     j["type"] = "inner"
#                 out.append(j)
#         return out

#     def _norm_dimensions(dims, date_key):
#         out = []
#         for d in dims or []:
#             if isinstance(d, dict):
#                 # prefer expr+alias
#                 if "expr" in d and "alias" in d:
#                     out.append({"expr": d["expr"], "alias": d["alias"]})
#                 # turn {"column": "..."} into expr/alias if needed
#                 elif "column" in d:
#                     col = d["column"]
#                     out.append({"expr": col, "alias": col.split(".")[-1].lower()})
#                 # ignore name/column_id only items
#         # Always ensure period is present if date_key exists (helps group/order)
#         if date_key and not any(x.get("alias") == "period" for x in out):
#             ta = date_key.get("table_alias", "")
#             dc = date_key.get("column", "")
#             gran = (date_key.get("granularity") or "day").lower()
#             trunc_code = {"day": "DD", "month": "MM", "year": "YYYY"}.get(gran, "DD")
#             out.insert(0, {"expr": f"TRUNC({ta}.{dc},'{trunc_code}')", "alias": "period"})
#         return out

#     def _norm_measures(ms):
#         out = []
#         for m in ms or []:
#             if isinstance(m, dict):
#                 # already compiled expr+alias
#                 if "expr" in m and "alias" in m:
#                     out.append({"expr": m["expr"], "alias": m["alias"]})
#                 # convert name/column/agg triple to expr/alias
#                 elif "column" in m and "agg" in m and "name" in m:
#                     col = m["column"]
#                     agg = m["agg"]
#                     alias = m.get("name", col.split(".")[-1].lower())
#                     # if column is bare, expect fact alias to be used by Agent-2; otherwise leave as is
#                     if "." not in col:
#                         # best effort: try to find main fact alias from plan
#                         fact_alias = p.get("fact", {}).get("alias", "")
#                         col = f"{fact_alias}.{col}" if fact_alias else col
#                     out.append({"expr": f"{agg}({col})", "alias": alias})
#         return out

#     def _norm_predicates(preds, date_key):
#         out = []
#         for pr in preds or []:
#             if "expr" in pr:
#                 out.append({"expr": pr["expr"]})
#             else:
#                 # convert user-style into SQL expr
#                 col = pr.get("column") or pr.get("by")
#                 op = pr.get("operator") or pr.get("op")
#                 vals = pr.get("values")
#                 val = pr.get("value")
#                 if col and op:
#                     if op.upper() == "BETWEEN" and isinstance(vals, (list, tuple)) and len(vals) == 2:
#                         out.append({"expr": f"{col} BETWEEN :p_from AND :p_to"})
#                     elif op in ("=", ">=", "<=", ">", "<"):
#                         # try to bind a generic :p_value if literal given
#                         # (we won’t bind it here; compiler/executor may ignore or override)
#                         out.append({"expr": f"{col} {op} :p_value"})
#         # ensure date range predicate if we have from/to binds but model forgot it
#         has_between = any(" BETWEEN " in pr["expr"].upper() for pr in out if "expr" in pr)
#         if date_key and not has_between:
#             ta, dc = date_key.get("table_alias",""), date_key.get("column","")
#             if ta and dc:
#                 out.append({"expr": f"{ta}.{dc} BETWEEN :p_from AND :p_to"})
#         return out

#     def _norm_group_by(gb):
#         out = []
#         for g in gb or []:
#             if isinstance(g, str):
#                 out.append(g)
#             elif isinstance(g, dict):
#                 if "column" in g:
#                     out.append(g["column"])
#                 elif "expr" in g:
#                     out.append(g["expr"])
#         # drop dupes while preserving order
#         seen = set()
#         dedup = []
#         for x in out:
#             if x not in seen:
#                 seen.add(x)
#                 dedup.append(x)
#         return dedup

#     def _norm_order_by(ob, measures):
#         # Accept dict or list; choose first measure if expr is blank
#         if isinstance(ob, dict):
#             expr = ob.get("expr") or ob.get("by") or ""
#             if not expr and measures:
#                 expr = measures[0].get("alias") or measures[0].get("expr")
#             direction = (ob.get("direction") or "desc").lower()
#             return {"expr": expr, "direction": direction}
#         if isinstance(ob, list) and ob:
#             first = ob[0]
#             if isinstance(first, dict):
#                 expr = first.get("expr") or first.get("by") or ""
#                 if not expr and measures:
#                     expr = measures[0].get("alias") or measures[0].get("expr")
#                 direction = (first.get("direction") or "desc").lower()
#                 return {"expr": expr, "direction": direction}
#             if isinstance(first, str):
#                 return {"expr": first, "direction": "desc"}
#         # default fallback
#         return {"expr": measures[0]["alias"] if measures else "", "direction": "desc"}

#     if p.get("plan_type") == "single":
#         p["joins"] = _norm_joins(p.get("joins", []))
#         p["measures"] = _norm_measures(p.get("measures", []))
#         p["dimensions"] = _norm_dimensions(p.get("dimensions", []), p.get("date_key"))
#         p["predicates"] = _norm_predicates(p.get("predicates", []), p.get("date_key"))
#         p["group_by"] = _norm_group_by(p.get("group_by", []))
#         p["order_by"] = _norm_order_by(p.get("order_by", {}), p["measures"])
#     elif p.get("plan_type") == "multi":
#         for step in p.get("steps", []):
#             step["joins"] = _norm_joins(step.get("joins", []))
#             step["measures"] = _norm_measures(step.get("measures", []))
#             step["dimensions"] = _norm_dimensions(step.get("dimensions", []), step.get("date_key"))
#             step["predicates"] = _norm_predicates(step.get("predicates", []), step.get("date_key"))
#             step["group_by"] = _norm_group_by(step.get("group_by", []))
#             step["order_by"] = _norm_order_by(step.get("order_by", {}), step["measures"])
#     return p


# def build_and_run_sql(
#     plan: Dict[str, Any],
#     stats_catalog: Dict[str, Any],
#     prefer_llm_sql: bool = False,
#     logs: bool = False,
# ) -> Dict[str, Any]:
#     """
#     Normalize -> compile -> safety vet -> execute.
#     Returns dict with sql, binds, rows, columns, trace.
#     """
#     plan_norm = _normalize_plan(plan)

#     # compile
#     if plan_norm.get("plan_type") == "single":
#         sql, binds = compile_sql_single(plan_norm)
#     elif plan_norm.get("plan_type") == "multi":
#         sql, binds = compile_sql_multi(plan_norm)
#     else:
#         raise ValueError("Unsupported or missing plan_type in plan.")

#     if logs:
#         print("\n--- SQL (compiled) ---\n", sql)
#         print("\n--- Binds ---\n", binds)

#     # safety check
#     vet_sql_or_raise(sql, stats_catalog)

#     # run
#     rows, columns = execute_sql(sql, binds)

#     return {
#         "sql": sql,
#         "binds": binds,
#         "rows": rows,
#         "columns": columns,
#         "trace": {"normalized_plan": plan_norm},
#     }

# # NEW: helper so UI can still show SQL/binds even if DB execute fails
# def compile_only(plan: Dict[str, Any], stats_catalog: Dict[str, Any]) -> Dict[str, Any]:
#     plan_norm = _normalize_plan(plan)
#     if plan_norm.get("plan_type") == "single":
#         sql, binds = compile_sql_single(plan_norm)
#     else:
#         sql, binds = compile_sql_multi(plan_norm)
#     vet_sql_or_raise(sql, stats_catalog)
#     return {"sql": sql, "binds": binds, "plan": plan_norm}


# agentic/agents/agent3_orchestrator.py
from __future__ import annotations
import copy
from typing import Any, Dict

from .agent3_sql_compiler import compile_sql_single, compile_sql_multi
from .agent3_executor import execute_sql, safe_vet_sql_or_raise



# ---------- Normalization helpers (robust to LLM quirks) ----------

# agentic/agents/agent3_orchestrator.py  (ONLY the _normalize_plan function)

from collections import OrderedDict
import copy

def _normalize_plan(plan: Dict[str, Any]) -> Dict[str, Any]:
    """
    Make Agent-2 output deterministic & compiler-safe:
      - Keep only joins with {name, alias, on}
      - Dimensions: accept ONLY {expr, alias}; ignore name/table_alias/column variants
      - Auto-add period, symbol, exchange if missing (based on date_key & joins)
      - De-dup dimensions by alias; de-dup group_by; split accidental comma-joined strings
      - Measures: normalize to {expr, alias}
      - Order-by: fall back to first measure alias if empty
      - Add date BETWEEN predicate if missing and binds present
    """
    p = copy.deepcopy(plan)

    def _norm_joins(joins):
        out = []
        for j in joins or []:
            if isinstance(j, dict) and all(k in j for k in ("name", "alias", "on")):
                typ = j.get("type") or "inner"
                out.append({"name": j["name"], "alias": j["alias"], "on": j["on"], "type": typ})
        return out

    def _ensure_dim(dims_list, expr, alias):
        # keep first occurrence per alias
        if not any(d.get("alias") == alias for d in dims_list):
            dims_list.append({"expr": expr, "alias": alias})

    def _norm_dimensions(dims, date_key, joins):
        # keep only expr+alias dims
        out: List[Dict[str, str]] = []
        for d in dims or []:
            if isinstance(d, dict) and "expr" in d and "alias" in d:
                out.append({"expr": d["expr"], "alias": d["alias"]})
        # add period if missing
        if date_key:
            ta = date_key.get("table_alias", "")
            dc = date_key.get("column", "")
            gran = (date_key.get("granularity") or "day").lower()
            trunc_code = {"day": "DD", "month": "MM", "year": "YYYY"}.get(gran, "DD")
            _ensure_dim(out, f"TRUNC({ta}.{dc},'{trunc_code}')", "period")
        # add label dims if missing and joins exist
        join_aliases = {j.get("alias") for j in (joins or [])}
        if "sym" in join_aliases:
            _ensure_dim(out, "sym.SYMBOL", "symbol")
        if "ex" in join_aliases:
            _ensure_dim(out, "ex.EXCHANGE_NAME", "exchange")
        # de-dup by alias, preserve order
        dedup = OrderedDict()
        for d in out:
            a = d["alias"]
            if a not in dedup:
                dedup[a] = d
        return list(dedup.values())

    def _norm_measures(ms):
        out = []
        for m in ms or []:
            if isinstance(m, dict):
                if "expr" in m and "alias" in m:
                    out.append({"expr": m["expr"], "alias": m["alias"]})
                elif "column" in m and "agg" in m:
                    col = m["column"]
                    agg = m["agg"]
                    alias = m.get("name") or col.split(".")[-1].lower()
                    # ensure fact alias on bare column
                    if "." not in col:
                        fa = p.get("fact", {}).get("alias", "")
                        col = f"{fa}.{col}" if fa else col
                    out.append({"expr": f"{agg}({col})", "alias": alias})
        return out

    def _norm_predicates(preds, date_key):
        out = []
        for pr in preds or []:
            if isinstance(pr, dict) and "expr" in pr:
                out.append({"expr": pr["expr"]})
            else:
                col = pr.get("column") or pr.get("by")
                op = (pr.get("operator") or pr.get("op") or "").upper()
                vals = pr.get("values")
                if col and op == "BETWEEN" and isinstance(vals, (list, tuple)) and len(vals) == 2:
                    out.append({"expr": f"{col} BETWEEN :p_from AND :p_to"})
        # ensure date BETWEEN if date_key present and no BETWEEN
        has_between = any(" BETWEEN " in x["expr"].upper() for x in out)
        if date_key and not has_between:
            ta, dc = date_key.get("table_alias",""), date_key.get("column","")
            if ta and dc:
                out.append({"expr": f"{ta}.{dc} BETWEEN :p_from AND :p_to"})
        return out

    def _norm_group_by(gb, dims):
        # flatten strings that accidentally contain comma-joined exprs
        flat: List[str] = []
        for g in gb or []:
            if isinstance(g, str):
                parts = [x.strip() for x in g.split(",") if x.strip()]
                flat.extend(parts)
            elif isinstance(g, dict) and "expr" in g:
                flat.append(g["expr"])
            elif isinstance(g, dict) and "column" in g:
                flat.append(g["column"])
        # include all dimension expressions (non-agg) in group_by
        for d in dims or []:
            if d.get("expr"):
                flat.append(d["expr"])
        # de-dup, preserve order
        seen = set()
        out: List[str] = []
        for x in flat:
            if x not in seen:
                seen.add(x)
                out.append(x)
        return out

    def _norm_order_by(ob, measures):
        # prefer explicit; else first measure alias
        if isinstance(ob, dict):
            expr = ob.get("expr") or ob.get("by") or ""
            direction = (ob.get("direction") or "desc").lower()
            if not expr and measures:
                expr = measures[0].get("alias") or measures[0].get("expr")
            return {"expr": expr, "direction": direction}
        if isinstance(ob, list) and ob:
            first = ob[0]
            if isinstance(first, dict):
                expr = first.get("expr") or first.get("by") or ""
                direction = (first.get("direction") or "desc").lower()
                if not expr and measures:
                    expr = measures[0].get("alias") or measures[0].get("expr")
                return {"expr": expr, "direction": direction}
            if isinstance(first, str):
                return {"expr": first, "direction": "desc"}
        return {"expr": (measures[0]["alias"] if measures else ""), "direction": "desc"}

    if p.get("plan_type") == "single":
        p["joins"]      = _norm_joins(p.get("joins", []))
        p["measures"]   = _norm_measures(p.get("measures", []))
        p["dimensions"] = _norm_dimensions(p.get("dimensions", []), p.get("date_key"), p.get("joins"))
        p["predicates"] = _norm_predicates(p.get("predicates", []), p.get("date_key"))
        p["group_by"]   = _norm_group_by(p.get("group_by", []), p.get("dimensions"))
        p["order_by"]   = _norm_order_by(p.get("order_by", {}), p["measures"])
    elif p.get("plan_type") == "multi":
        for step in p.get("steps", []):
            step["joins"]      = _norm_joins(step.get("joins", []))
            step["measures"]   = _norm_measures(step.get("measures", []))
            step["dimensions"] = _norm_dimensions(step.get("dimensions", []), step.get("date_key"), step.get("joins"))
            step["predicates"] = _norm_predicates(step.get("predicates", []), step.get("date_key"))
            step["group_by"]   = _norm_group_by(step.get("group_by", []), step.get("dimensions"))
            step["order_by"]   = _norm_order_by(step.get("order_by", {}), step["measures"])
    return p



# ---------- Orchestrator entry points ----------

def build_and_run_sql(
    plan: Dict[str, Any],
    stats_catalog: Dict[str, Any],
    prefer_llm_sql: bool = False,  # reserved flag (we still compile deterministically)
    logs: bool = False,
) -> Dict[str, Any]:
    """
    Normalize -> compile -> safety vet -> execute.
    Returns: { sql, binds, rows, columns, trace }
    """
    plan_norm = _normalize_plan(plan)

    # compile
    ptype = (plan_norm.get("plan_type") or "").lower()
    if ptype == "single":
        sql, binds = compile_sql_single(plan_norm)
    elif ptype == "multi":
        sql, binds = compile_sql_multi(plan_norm)
    else:
        raise ValueError("Unsupported or missing plan_type in plan.")

    if logs:
        print("\n--- SQL (compiled) ---\n", sql)
        print("\n--- Binds ---\n", binds)

    # safety check against the provided catalog (dict)
    safe_vet_sql_or_raise(sql, stats_catalog)

    # execute
    rows, columns = execute_sql(sql, binds)

    return {
        "sql": sql,
        "binds": binds,
        "rows": rows,
        "columns": columns,
        "trace": {"normalized_plan": plan_norm},
    }


def compile_only(plan: Dict[str, Any], stats_catalog: Dict[str, Any]) -> Dict[str, Any]:
    """
    For UI: compile & vet only (no DB hit), return sql/binds/plan.
    """
    plan_norm = _normalize_plan(plan)
    ptype = (plan_norm.get("plan_type") or "").lower()
    if ptype == "single":
        sql, binds = compile_sql_single(plan_norm)
    elif ptype == "multi":
        sql, binds = compile_sql_multi(plan_norm)
    else:
        raise ValueError("Unsupported or missing plan_type in plan.")
    safe_vet_sql_or_raise(sql, stats_catalog)
    return {"sql": sql, "binds": binds, "plan": plan_norm}
