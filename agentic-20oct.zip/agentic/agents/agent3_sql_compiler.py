# agentic/agents/agent3_sql_compiler.py
from __future__ import annotations
from typing import Any, Dict, List, Tuple

def _q(s: str) -> str:
    return s  # keep raw; reserved words not expected for aliases here

def _extract_group_by(group_by) -> List[str]:
    out = []
    for g in group_by or []:
        if isinstance(g, str):
            out.append(g)
        elif isinstance(g, dict):
            if "expr" in g:
                out.append(g["expr"])
            elif "column" in g:
                out.append(g["column"])
    return out

def _extract_joins(joins) -> List[str]:
    out = []
    for j in joins or []:
        if isinstance(j, dict) and all(k in j for k in ("name", "alias", "on")):
            jt = (j.get("type") or "inner").upper()
            out.append(f"{jt} JOIN {j['name']} {j['alias']} ON {j['on']}")
    return out

# agentic/agents/agent3_sql_compiler.py  (ONLY the compile_sql_single function)

from collections import OrderedDict
from typing import Any, Dict, List, Tuple

def compile_sql_single(plan: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    fact = plan["fact"]
    fa   = fact["alias"]
    fqn  = fact["name"]

    # dims: ensure unique aliases and preserve order
    dims_in: List[Dict[str, str]] = plan.get("dimensions", [])
    dim_by_alias = OrderedDict()
    for d in dims_in:
        alias = d["alias"]
        if alias not in dim_by_alias:
            dim_by_alias[alias] = d
    dims = list(dim_by_alias.values())

    # measures (already normalized)
    measures = plan.get("measures", [])

    # SELECT list
    select_cols: List[str] = []
    for d in dims:
        select_cols.append(f"{d['expr']} AS {d['alias']}")
    for m in measures:
        select_cols.append(f"{m['expr']} AS {m['alias']}")

    # FROM + JOINS
    join_sql = []
    for j in plan.get("joins", []):
        typ = (j.get("type") or "inner").upper()
        join_sql.append(f"{typ} JOIN {j['name']} {j['alias']} ON {j['on']}")

    # WHERE predicates
    where_sql = []
    for pr in plan.get("predicates", []):
        where_sql.append(pr["expr"])
    where_clause = f"WHERE {' AND '.join(where_sql)}" if where_sql else ""

    # GROUP BY (dedup)
    gb_seen = set()
    gb_list: List[str] = []
    for g in plan.get("group_by", []):
        if g not in gb_seen:
            gb_seen.add(g)
            gb_list.append(g)
    group_clause = f"GROUP BY {', '.join(gb_list)}" if gb_list else ""

    # ORDER BY
    ob = plan.get("order_by", {}) or {}
    order_clause = ""
    if ob.get("expr"):
        order_clause = f"ORDER BY {ob['expr']} {ob.get('direction','desc').upper()}"

    # Base query
    inner = (
        "  SELECT\n    " + ", ".join(select_cols) + "\n"
        f"  FROM {fqn} {fa}\n"
        "  " + (" ".join(join_sql) if join_sql else "") + "\n"
        f"  {where_clause}\n"
        f"  {group_clause}\n"
        f"  {order_clause}\n"
    ).rstrip()

    top = plan.get("limit") or {}
    binds = plan.get("binds") or {}
    if top.get("top_n"):
        # ensure bind present for :p_top_n
        if "bind" in top and top["bind"]:
            binds.setdefault(top["bind"], top["top_n"])
            top_bind = f":{top['bind']}"
        else:
            binds.setdefault("p_top_n", top["top_n"])
            top_bind = ":p_top_n"
        sql = f"SELECT *\nFROM (\n{inner}\n)\nWHERE ROWNUM <= {top_bind}"
    else:
        sql = inner

    return sql, binds


def compile_sql_multi(plan: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    # very simple 2-step support; step[0] produces symbol list; step[1] aggregates
    steps = plan.get("steps") or []
    binds = plan.get("binds") or {}

    compiled_steps = []
    for s in steps:
        sql_s, b = compile_sql_single(s)
        compiled_steps.append(sql_s)
        binds.update(b)

    # naive chaining: return last step as the “executable” SQL; the earlier step assumed to be materialized inline via IN (:list)
    return compiled_steps[-1], binds
