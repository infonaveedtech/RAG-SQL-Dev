from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
from agentic.core.llm_ollama import generate_json

# --- PUBLIC API ------------------------------------------------------------

def llm_generate_sql(
    plan: Dict[str, Any],
    stats_catalog: Dict[str, Any],
    system_prompt_path: str | Path,
    model: str = "llama3.1:8b",
    temperature: float = 0.0,
    timeout: int = 90,
) -> Dict[str, Any]:
    """
    Ask LLM to produce SQL from plan + catalog, in STRICT JSON.
    Returns dict:
      - for single: {"sql":"...", "binds":{...}, "notes":"..."}
      - for multi:  {"steps":[{"sql":"...","binds":{...}},...], "notes":"..."}
    """
    system_prompt = Path(system_prompt_path).read_text(encoding="utf-8")

    prompt = (
        system_prompt
        + "\n\n# stats_catalog (JSON)\n"
        + json.dumps(stats_catalog, indent=2)
        + "\n\n# plan (JSON)\n"
        + json.dumps(plan, indent=2)
        + "\n\n# Respond now with the STRICT JSON as specified:\n"
    )
    out = generate_json(prompt, model=model, temperature=temperature, timeout=timeout)
    return out
