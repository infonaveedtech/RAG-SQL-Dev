# agentic/agents/sql_safety.py
from __future__ import annotations
import re
from typing import Dict, Any, List, Set


# --- Read-only guard -------------------------------------------------------

# Allow only SELECT or WITH ... SELECT; forbid DDL/DML/PL/EXEC
_DDL_DML_RE = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|TRUNCATE|ALTER|CREATE|DROP|GRANT|REVOKE|BEGIN|EXEC|CALL)\b",
    re.IGNORECASE,
)

def ensure_read_only(sql: str) -> None:
    s = (sql or "").strip()
    up = s.upper()
    if not (up.startswith("SELECT") or up.startswith("WITH")):
        raise ValueError("Only SELECT or WITH…SELECT is allowed.")
    if ";" in s:
        # avoid stacked statements
        raise ValueError("Multiple statements / semicolon not allowed.")
    if _DDL_DML_RE.search(up):
        raise ValueError("DDL/DML/PLSQL keywords not allowed in SQL.")


# --- Table reference extraction (FROM/JOIN only) ---------------------------

# Match OWNER.TABLE immediately following FROM/JOIN (robust, no alias.column hits)
_FROM_JOIN_FQN_RE = re.compile(
    r"\b(?:FROM|JOIN)\s+([A-Z][A-Z0-9_]{0,29}\.[A-Z][A-Z0-9_]{0,29})\b",
    re.IGNORECASE,
)

def extract_table_fqns(sql: str) -> List[str]:
    """Return OWNER.TABLE references that appear after FROM/JOIN."""
    return [m.group(1).upper() for m in _FROM_JOIN_FQN_RE.finditer(sql or "")]


# --- Allowed set builder from stats_catalog --------------------------------

def allowed_tables_from_catalog(stats_catalog: Dict[str, Any]) -> Set[str]:
    """
    Build whitelist of FQNs (OWNER.TABLE) from stats_catalog.
    Supports both list- and dict-based structures.
    """
    allowed: Set[str] = set()
    if not stats_catalog:
        return allowed

    # facts
    facts = stats_catalog.get("facts", [])
    if isinstance(facts, dict):
        for v in facts.values():
            fqn = (v or {}).get("fqn")
            if fqn:
                allowed.add(fqn.upper())
    elif isinstance(facts, list):
        for v in facts:
            fqn = (v or {}).get("fqn")
            if fqn:
                allowed.add(fqn.upper())

    # lookups
    lookups = stats_catalog.get("lookups", [])
    if isinstance(lookups, dict):
        for v in lookups.values():
            fqn = (v or {}).get("fqn")
            if fqn:
                allowed.add(fqn.upper())
    elif isinstance(lookups, list):
        for v in lookups:
            fqn = (v or {}).get("fqn")
            if fqn:
                allowed.add(fqn.upper())

    return allowed



# --- Safety vetter ---------------------------------------------------------

def vet_sql_or_raise(sql: str, stats_catalog: Dict[str, Any]) -> None:
    """
    Fail closed:
      - Read-only
      - Only FROM/JOIN table FQNs counted
      - All tables must be in stats_catalog allowlist
    """
    ensure_read_only(sql)

    allowed = allowed_tables_from_catalog(stats_catalog)
    refs = set(extract_table_fqns(sql))
    disallowed = [r for r in refs if r not in allowed]

    if disallowed:
        sample = sorted(list(allowed))[:5]
        raise ValueError(
            "SQL references tables outside allowed stats_catalog. "
            f"Disallowed: {disallowed} | Allowed (sample): {sample}"
        )

    # Column-level safety isn’t enforced here (the plan+compiler control that).
    # Add column vetting later if needed.

