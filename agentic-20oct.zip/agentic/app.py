# agentic/app.py
from __future__ import annotations
import os
import io
import json
import logging
from pathlib import Path
from typing import Any, Dict, List
from datetime import date, datetime
from decimal import Decimal

import streamlit as st
import pandas as pd

# load .env for DB creds (DB_USER, DB_PASS, DB_DSN)
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# ---- Pipeline (existing modules) -----------------------------------
# Intent → Decision → Plan → SQL+Run
from agentic.agents.agent0_intent import infer_intent_v2, IntentV2
from agentic.agents.agent1_solution_decider_llm import decide_solution_llm, SolutionDecision
from agentic.agents.agent2_plan_llm import plan_query_llm
from agentic.agents.agent2_repair import repair_plan  # if present; else try/except
from agentic.agents.agent3_orchestrator import build_and_run_sql
# optional debug helper if execute fails
from agentic.agents.agent3_orchestrator import compile_only

# ---- Defaults / Paths ---------------------------------------------------
BASE = Path(__file__).resolve().parent

DEFAULT_CRAWLER_CATALOG = (
    os.environ.get("CRAWLER_CATALOG_JSON")
    or str((BASE / "data" / "raw" / "ats_schema_2025-10-16.json").resolve())
)
DEFAULT_STATS_CATALOG = (
    os.environ.get("STATS_CATALOG_JSON")
    or str((BASE / "data" / "stats_catalog.json").resolve())
)
DEFAULT_AGENT1_SYSTEM = (
    os.environ.get("AGENT1_SYSTEM_PROMPT")
    or str((BASE / "core" / "prompt_templates" / "agent1_system.txt").resolve())
)
DEFAULT_AGENT2_SYSTEM = (
    os.environ.get("AGENT2_SYSTEM_PROMPT")
    or str((BASE / "core" / "prompt_templates" / "agent2_system.txt").resolve())
)
DEFAULT_AGENT3_SYSTEM = (
    os.environ.get("AGENT3_SYSTEM_PROMPT")
    or str((BASE / "core" / "prompt_templates" / "agent3_system.txt").resolve())
)

# ---- Streamlit setup ----------------------------------------------------
st.set_page_config(page_title="Agentic DW: NL → Plan → SQL → Oracle", layout="wide")
logging.getLogger().setLevel(logging.INFO)

# --------------------------
# Helpers
# --------------------------
def _jsonable(v: Any):
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if isinstance(v, Decimal):
        return float(v)
    return v

def df_to_csv_bytes(df: pd.DataFrame) -> bytes:
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")

def badge(text: str, color: str = "#334155"):
    st.markdown(
        f"<span style='background:{color};color:white;border-radius:6px;padding:3px 8px;font-size:12px;'>{text}</span>",
        unsafe_allow_html=True,
    )

def load_json_file(path_str: str) -> Any:
    p = Path(path_str)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {p}")
    return json.loads(p.read_text(encoding="utf-8"))

# --------------------------
# Sidebar (config)
# --------------------------
with st.sidebar:
    st.header("⚙️ Config")

    # LLM config (shared across agents)
    llm_model = st.selectbox("LLM model (Ollama)", ["llama3.1:8b", "mistral:7b-instruct"], index=0)
    temperature = st.slider("Temperature", min_value=0.0, max_value=1.0, value=0.1, step=0.1)

    st.markdown("---")
    st.caption("📦 Catalog & Prompts")
    crawler_catalog_path = st.text_input(
        "Crawler catalog (ats_schema_*.json) → used by Agent-1",
        value=DEFAULT_CRAWLER_CATALOG
    )
    stats_catalog_path = st.text_input(
        "Stats catalog (stats_catalog.json) → used by Agent-2/3",
        value=DEFAULT_STATS_CATALOG
    )
    agent1_system_path = st.text_input("Agent-1 system prompt", value=DEFAULT_AGENT1_SYSTEM)
    agent2_system_path = st.text_input("Agent-2 system prompt", value=DEFAULT_AGENT2_SYSTEM)
    agent3_system_path = st.text_input("Agent-3 system prompt (optional)", value=DEFAULT_AGENT3_SYSTEM)

    st.markdown("---")
    st.caption("🔧 Execution")
    prefer_llm = st.checkbox("Prefer LLM SQL (fallback to compiler)", value=True)
    show_logs = st.checkbox("Show execution logs", value=True)

# --------------------------
# Main UI
# --------------------------
st.title("🔎 Ask → 🧠 Decide → 🧭 Plan → 🗄️ Query (Oracle)")

query = st.text_area(
    "Natural language request",
    placeholder="e.g., Top 10 symbols by daily turnover in May 2023 with average price and exchange",
    height=110,
)

c1, c2, c3 = st.columns([1, 1, 1])
with c1:
    ui_from = st.date_input("From (YYYY-MM-DD)", value=None, format="YYYY-MM-DD")
with c2:
    ui_to = st.date_input("To (YYYY-MM-DD)", value=None, format="YYYY-MM-DD")
with c3:
    run_btn = st.button("Run 🚀", type="primary", use_container_width=True)

# --------------------------
# Pipeline
# --------------------------
if run_btn:
    if not query or not query.strip():
        st.error("Please enter a query.")
        st.stop()

    with st.status("Running pipeline…", expanded=True) as status:
        # Agent-0: Intent
        status.write("🧭 Agent-0: inferring intent")
        a0: IntentV2 = infer_intent_v2(query, model=llm_model, temperature=0.0)

        if a0.task != "DATA_QUERY":
            status.update(label="Not a data query.", state="error")
            st.warning(getattr(a0, "message", "This doesn't look like a data request."))
            st.stop()

        # Inject UI date overrides (non-destructive)
        if ui_from and ui_to:
            a0 = a0.model_copy(update={
                "time_range": {
                    "from_date": ui_from.isoformat(),
                    "to_date": ui_to.isoformat(),
                    "granularity": a0.time_range.granularity if a0.time_range else "day"
                }
            })

        # Agent-1: Decide solution family (+ light table hints)
        status.write("🧠 Agent-1: deciding solution (statistical_data?)")
        decision: SolutionDecision = decide_solution_llm(
            intent=a0,
            catalog_json_path=crawler_catalog_path,  # expects a PATH
            model=llm_model,
            temperature=temperature,
        )
        if decision.decision != "statistical_data":
            status.update(label="Out of scope / needs clarification", state="error")
            st.warning(decision.model_dump())
            st.stop()

        # Agent-2: Build plan (column picker)
        status.write("🧭 Agent-2: building query plan")
        plan_raw: Dict[str, Any] = plan_query_llm(
            user_text=query,
            intent_json=json.loads(a0.model_dump_json()),
            decision_json=json.loads(decision.model_dump_json()),
            stats_catalog_path=stats_catalog_path,        # expects a PATH
            system_prompt_path=agent2_system_path,
            model=llm_model,
            temperature=temperature,
        )

        # Optional: plan repair pass (if present)
        try:
            plan = repair_plan(plan_raw, stats_catalog_path)
        except Exception:
            plan = plan_raw

        # Load stats_catalog JSON (DICT) for Agent-3 vetting/execution
        try:
            stats_catalog_obj: Dict[str, Any] = load_json_file(stats_catalog_path)
        except Exception as e:
            status.update(label="Stats catalog missing/invalid", state="error")
            st.error(f"Failed to load stats_catalog.json: {e}")
            st.stop()

        # Agent-3: Generate SQL & Execute
        status.write("🗄️ Agent-3: generating SQL and executing")
        try:
            result = build_and_run_sql(
                plan=plan,
                stats_catalog=stats_catalog_obj,  # DICT here (not path)
                prefer_llm_sql=prefer_llm,
                logs=show_logs,
            )
        except Exception as e:
            st.error(f"Execution error: {getattr(e, 'args', [''])[0] or str(e)}")
            # Show compiled SQL & binds for debug
            try:
                debug_pack = compile_only(plan, stats_catalog_obj)
                st.subheader("Compiled SQL (debug)")
                st.code(debug_pack["sql"], language="sql")
                st.json(debug_pack["binds"])
                with st.expander("Normalized plan"):
                    st.json(debug_pack["plan"])
            except Exception as e2:
                st.warning("Could not compile SQL for debug.")
                st.code(str(e2))
            st.stop()

    # --------------------------
    # Results rendering
    # --------------------------
    st.subheader("Results")

    # normalize outputs from Agent-3 (support both shapes)
    rows: List[Dict[str, Any]] = []
    cols: List[str] = []
    sql_text = result.get("sql")
    binds = result.get("binds") or {}

    if "rows" in result and "columns" in result:
        # direct shape
        rows = result.get("rows") or []
        cols = result.get("columns") or (list(rows[0].keys()) if rows else [])
    elif "result" in result and isinstance(result["result"], dict):
        rows = result["result"].get("rows") or []
        cols = result["result"].get("columns") or (list(rows[0].keys()) if rows else [])
    else:
        # multi-step or unknown; try best effort
        final = result.get("steps", {}).get("final", {}) if isinstance(result.get("steps"), dict) else {}
        rows = final.get("rows") or []
        cols = final.get("columns") or (list(rows[0].keys()) if rows else [])

    df = pd.DataFrame(rows, columns=cols)
    st.dataframe(df, use_container_width=True, height=440)

    cdl, csql = st.columns([1, 2])
    with cdl:
        st.download_button(
            "Download CSV",
            data=df_to_csv_bytes(df),
            file_name="result.csv",
            mime="text/csv",
            use_container_width=True,
        )
    with csql:
        st.markdown("**SQL**")
        if sql_text:
            st.code(sql_text, language="sql")
        st.markdown("**Binds**")
        st.json({k: _jsonable(v) for k, v in (binds or {}).items()})

    # --------------------------
    # Trace panels
    # --------------------------
    st.markdown("---")
    st.subheader("Trace & Artifacts")
    c0, c1, c2 = st.columns(3)
    with c0:
        st.markdown("**Agent-0 (Intent JSON)**")
        st.json(json.loads(a0.model_dump_json()))
    with c1:
        st.markdown("**Agent-1 (Decision)**")
        st.json(json.loads(decision.model_dump_json()))
    with c2:
        st.markdown("**Agent-2 (Plan - final)**")
        st.json(plan)

    if show_logs:
        with st.expander("Execution logs"):
            for line in result.get("logs", []) or []:
                st.code(line)
