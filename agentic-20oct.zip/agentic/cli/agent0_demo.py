# agentic/cli/agent0_demo.py
import sys, json
from agentic.agents.agent0_intent import infer_intent_v2

if __name__ == "__main__":
    text = " ".join(sys.argv[1:]) or "Total revenue by region last 30 days limit 500"
    # Set your preferred model tag here:
    obj = infer_intent_v2(text, model="llama3.1:8b", temperature=0.0)
    print(json.dumps(obj.model_dump(by_alias=True), indent=2))
