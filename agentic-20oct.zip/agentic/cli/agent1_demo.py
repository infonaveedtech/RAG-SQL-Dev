# agentic/cli/agent1_demo.py
import sys, json
from pathlib import Path
from agentic.agents.agent0_intent import infer_intent_v2
from agentic.agents.agent1_solution_decider_llm import decide_solution_llm

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python -m agentic.cli.agent1_demo \"<user text>\" <path_to_catalog_json>")
        print("Example: python -m agentic.cli.agent1_demo \"Top 10 symbols by turnover in July\" ./data/raw/ats_schema_2025-10-16.json")
        sys.exit(1)

    user_text = sys.argv[1]
    catalog_json = Path(sys.argv[2])

    # Agent-0
    intent = infer_intent_v2(user_text, model="llama3.1:8b", temperature=0.0)

    # Agent-1
    decision = decide_solution_llm(intent, catalog_json_path=catalog_json, model="llama3.1:8b", temperature=0.0)

    print("\n--- Agent-0 Intent (V2) ---")
    print(json.dumps(intent.model_dump(), indent=2))
    print("\n--- Agent-1 Decision ---")
    print(decision.model_dump_json(indent=2))
