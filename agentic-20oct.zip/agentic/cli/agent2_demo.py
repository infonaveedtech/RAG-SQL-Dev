# agentic/cli/agent2_demo.py
from __future__ import annotations
import sys, json, argparse
from pathlib import Path
from typing import Any, Dict, List

from agentic.agents.agent0_intent import infer_intent_v2
from agentic.agents.agent1_solution_decider_llm import decide_solution_llm
from agentic.agents.agent2_plan_llm import plan_query_llm

# ---------- tiny validator to catch obvious mistakes ----------------------

def _load_json(p: str | Path) -> Dict[str, Any]:
    return json.loads(Path(p).read_text(encoding="utf-8"))

def _catalog_index(cat: Dict[str, Any]) -> Dict[str, Any]:
    facts = { f["fqn"].upper(): f for f in cat.get("facts", []) }
    lookups = { l["id"].upper(): l for l in cat.get("lookups", []) }
    return {"facts": facts, "lookups": lookups}

def _get_fact(cat_idx: Dict[str, Any], fqn: str) -> Dict[str, Any] | None:
    return cat_idx["facts"].get(fqn.upper())

def re_split_tokens(expr: str) -> List[str]:
    import re
    return [t for t in re.split(r"[^A-Za-z0-9_\.]+", expr or "") if t and not t[0].isdigit()]

def _allowed_columns_for_fact(fact: Dict[str, Any]) -> set:
    allowed = set()
    for dk in fact.get("date_keys", []):
        allowed.add(dk["column"].upper())
    for d in fact.get("dimensions", []):
        allowed.add(d["column"].upper())
    for m in fact.get("measures", []):
        col = m.get("column")
        if col:
            allowed.add(str(col).upper())
        expr = m.get("expr")
        if expr:
            for tok in re_split_tokens(expr):
                allowed.add(tok.upper())
    return allowed

def _validate_single(plan: Dict[str, Any], cat_idx: Dict[str, Any]) -> List[str]:
    errs: List[str] = []
    fact_name = (plan.get("fact") or {}).get("name")
    alias =     (plan.get("fact") or {}).get("alias")
    if not fact_name or not alias:
        errs.append("fact.name or fact.alias missing")
        return errs

    fact = _get_fact(cat_idx, fact_name)
    if not fact:
        errs.append(f"Unknown fact FQN: {fact_name}")
        return errs

    date_key = plan.get("date_key") or {}
    dk_col = date_key.get("column")
    if dk_col:
        dk_ok = any(dk_col.upper() == dk["column"].upper() for dk in fact.get("date_keys", []))
        if not dk_ok:
            errs.append(f"date_key.column '{dk_col}' not in catalog date_keys for {fact_name}")

    allowed = _allowed_columns_for_fact(fact)
    for m in plan.get("measures", []):
        expr = m.get("expr") or ""
        for tok in re_split_tokens(expr):
            col = tok.split(".")[-1] if "." in tok else tok
            if col.upper() in {"SUM","AVG","MIN","MAX","ROUND","TRUNC"}:
                continue
            if col.upper() not in allowed and col.upper() not in {"SYMBOL","EXCHANGE_NAME"}:
                errs.append(f"measure expr references '{col}' not in catalog for {fact_name}")

    join_fqns = { (j.get("name") or "").upper(): j for j in plan.get("joins", []) }
    if "ATS.SYMBOLS" not in join_fqns or "ATS.EXCHANGES" not in join_fqns:
        errs.append("joins must include ATS.SYMBOLS and ATS.EXCHANGES")

    dim_aliases = { (d.get("alias") or "").lower() for d in plan.get("dimensions", []) }
    if "symbol" not in dim_aliases or "exchange" not in dim_aliases:
        errs.append("dimensions must include symbol and exchange (labels)")
    return errs

def validate_plan_against_catalog(plan: Dict[str, Any], catalog: Dict[str, Any]) -> List[str]:
    idx = _catalog_index(catalog)
    if plan.get("plan_type") == "single":
        return _validate_single(plan, idx)
    if plan.get("plan_type") == "multi":
        errs: List[str] = []
        steps = plan.get("steps", [])
        if not steps:
            return ["multi plan has no steps"]
        for i, step in enumerate(steps):
            errs += [f"step[{i}]: {e}" for e in _validate_single(step, idx)]
        return errs
    if plan.get("needs_clarification"):
        return []
    return ["unknown plan_type; expected 'single' | 'multi' | clarification"]

# ---------- CLI ------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="Agent-2 demo: intent -> decision -> plan")
    ap.add_argument("text", help="user text in quotes")
    ap.add_argument("--stats_catalog", default="agentic/data/stats_catalog.json", help="path to stats_catalog.json")
    ap.add_argument("--agent2_prompt", default="agentic/core/prompt_templates/agent2_system.txt", help="path to Agent-2 system prompt")
    ap.add_argument("--agent1_catalog", default="agentic/data/raw/ats_schema_2025-10-16.json", help="raw catalog for Agent-1 (decision)")
    ap.add_argument("--model", default="llama3.1:8b")
    ap.add_argument("--temp", type=float, default=0.0)  # stricter output
    args = ap.parse_args()

    text = args.text
    intent = infer_intent_v2(text, model=args.model, temperature=args.temp)
    intent_json = intent.model_dump()

    decision = decide_solution_llm(intent, catalog_json_path=args.agent1_catalog, model=args.model, temperature=args.temp)
    decision_json = decision.model_dump()

    plan = plan_query_llm(
        user_text=text,
        intent_json=intent_json,
        decision_json=decision_json,
        stats_catalog_path=args.stats_catalog,
        system_prompt_path=args.agent2_prompt,
        model=args.model,
        temperature=args.temp
    )

    print("\n--- Agent-0 Intent ---")
    print(json.dumps(intent_json, indent=2))
    print("\n--- Agent-1 Decision ---")
    print(json.dumps(decision_json, indent=2))
    print("\n--- Agent-2 Plan (raw) ---")
    print(json.dumps(plan, indent=2))

    # NEW: repair pass
    try:
        from agentic.agents.agent2_repair import repair_plan
        repaired = repair_plan(plan, intent_json)
    except Exception as ex:
        print("\n[WARN] Repair step failed:", ex)
        repaired = plan

    print("\n--- Agent-2 Plan (repaired) ---")
    print(json.dumps(repaired, indent=2))

    # Validate the repaired plan
    try:
        catalog = _load_json(args.stats_catalog)
        errs = validate_plan_against_catalog(repaired, catalog)
        if errs:
            print("\n[WARN] Plan validation issues:")
            for e in errs:
                print(" -", e)
        else:
            print("\n[OK] Plan passes basic validation against stats_catalog.")
    except Exception as ex:
        print("\n[INFO] Skipped validation:", ex)


if __name__ == "__main__":
    main()
