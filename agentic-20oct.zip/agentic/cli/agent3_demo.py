import os, json, argparse
from pathlib import Path

from agentic.agents.agent0_intent import infer_intent_v2
from agentic.agents.agent1_solution_decider_llm import decide_solution_llm
from agentic.agents.agent2_plan_llm import plan_query_llm
from agentic.agents.agent2_repair import repair_plan
from agentic.agents.agent3_orchestrator import build_and_run_sql

def _load_json(p): return json.loads(Path(p).read_text(encoding="utf-8"))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("user_text", type=str)
    ap.add_argument("--catalog", default="agentic/data/stats_catalog.json")
    ap.add_argument("--agent2_system", default="agentic/core/prompt_templates/agent2_system.txt")
    ap.add_argument("--agent3_system", default="agentic/core/prompt_templates/agent3_system.txt")
    ap.add_argument("--prefer_llm", action="store_true")
    ap.add_argument("--model", default="llama3.1:8b")
    args = ap.parse_args()

    catalog = _load_json(args.catalog)

    # Agent-0
    intent = infer_intent_v2(args.user_text, model=args.model, temperature=0.1)
    print("\n--- Agent-0 Intent ---")
    print(intent.model_dump_json(indent=2))

    # Agent-1
    decision = decide_solution_llm(intent, catalog_json_path="agentic/data/raw/ats_schema_2025-10-16.json", model=args.model, temperature=0.0)
    print("\n--- Agent-1 Decision ---")
    print(decision.model_dump_json(indent=2))

    # Agent-2 (plan)
    plan_raw = plan_query_llm(
        user_text=args.user_text,
        intent_json=json.loads(intent.model_dump_json()),
        decision_json=json.loads(decision.model_dump_json()),
        stats_catalog_path=args.catalog,
        system_prompt_path=args.agent2_system,
        model=args.model,
        temperature=0.0,
    )
    print("\n--- Agent-2 Plan (raw) ---")
    print(json.dumps(plan_raw, indent=2))

    plan = repair_plan(plan_raw, json.loads(intent.model_dump_json()))
    print("\n--- Agent-2 Plan (repaired) ---")
    print(json.dumps(plan, indent=2))

    # Agent-3 (LLM SQL → vetted, else compiler) + execute
    res = build_and_run_sql(
        plan=plan,
        stats_catalog=catalog,
        # system_prompt_path=args.agent3_system,
        prefer_llm_sql=args.prefer_llm,
        # llm_model=args.model,
        # temperature=0.0,
        # timeout=120,
        logs=True,
    )
    

    print("\n--- Agent-3 Result ---")
    print(json.dumps(res, indent=2, default=str))

if __name__ == "__main__":
    main()
