# agentic/cli/run_sql_example.py
import os, json
import oracledb  # pip install oracledb
from datetime import date, datetime
from dotenv import load_dotenv
load_dotenv()  # take environment variables from .env file if present

SQL = """
SELECT *
FROM (
  SELECT
    TRUNC(sdi.STATS_DATE, 'DD')     AS period,
    sym.SYMBOL                      AS symbol,
    ex.EXCHANGE_NAME                AS exchange,
    SUM(sdi.TURNOVER_VALUE)         AS turnover,
    AVG(sdi.CLOSE_PRICE)            AS avg_price
  FROM ATS.SYMBOL_DAILY_INDICATORS sdi
  JOIN ATS.SYMBOLS   sym ON sdi.SYMBOL_ID   = sym.SYMBOL_ID
  JOIN ATS.EXCHANGES ex  ON sdi.EXCHANGE_ID = ex.EXCHANGE_ID
  WHERE sdi.STATS_DATE BETWEEN :p_from AND :p_to
  GROUP BY TRUNC(sdi.STATS_DATE, 'DD'), sym.SYMBOL, ex.EXCHANGE_NAME
  ORDER BY turnover DESC
)
WHERE ROWNUM <= :p_top_n
"""

# “Top 10 symbols by daily turnover between 2023-05-01 and 2023-05-31, also show average price and exchange name.”


def _as_date(obj):
    if isinstance(obj, date):
        return obj
    if isinstance(obj, str):
        # Expecting 'YYYY-MM-DD'
        return datetime.strptime(obj, "%Y-%m-%d").date()
    raise TypeError(f"Unsupported date type: {type(obj)}")

def get_conn():
    # Env vars:
    #   ORA_DSN="host:port/service"
    #   ORA_USER="..."
    #   ORA_PWD="..."
    dsn  = os.environ["ORACLE_DSN"]
    user = os.environ["ORACLE_USER"]
    pwd  = os.environ["ORACLE_PASSWORD"]
    return oracledb.connect(user=user, password=pwd, dsn=dsn)

def run_example(p_from="2023-05-01", p_to="2023-05-31", top_n=10):
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute(
                SQL,
                p_from=_as_date(p_from),   # <-- bind as Python date
                p_to=_as_date(p_to),       # <-- bind as Python date
                p_top_n=int(top_n),
            )
            cols = [d[0].lower() for d in cur.description]
            rows = cur.fetchall()
            out = {
                "query_info": {
                    "from": _as_date(p_from).isoformat(),
                    "to": _as_date(p_to).isoformat(),
                    "top_n": int(top_n),
                    "fact": "ATS.SYMBOL_DAILY_INDICATORS",
                    "labels": ["symbol", "exchange"],
                    "measures": ["turnover", "avg_price"],
                    "period_granularity": "day"
                },
                "columns": cols,
                "rows": [dict(zip(cols, r)) for r in rows[:20]]
            }
            print(json.dumps(out, indent=2, default=str))
    finally:
        conn.close()

if __name__ == "__main__":
    run_example()
