import logging
from textwrap import dedent
from pathlib import Path

# Re-use your existing connection utilities
from db_conn import db_session

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


DDL_STMTS = [
    # 1) META_TABLES
    dedent("""
    BEGIN
      EXECUTE IMMEDIATE q'[
        CREATE TABLE META_TABLES (
          owner             VARCHAR2(128)    NOT NULL,
          table_name        VARCHAR2(128)    NOT NULL,
          table_type        VARCHAR2(30),
          row_count         NUMBER,
          last_analyzed     DATE,
          table_comment     CLOB,
          keep_state        VARCHAR2(12)     DEFAULT 'CANDIDATE',
          has_date_col      CHAR(1)          DEFAULT 'N',
          created_at        DATE             DEFAULT SYSDATE,
          updated_at        DATE,
          CONSTRAINT pk_meta_tables PRIMARY KEY (owner, table_name)
        )
      ]';
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = -955 THEN NULL; ELSE RAISE; END IF; -- ORA-00955: name is already used
    END;
    """),

    # 2) META_COLUMNS
    dedent("""
    BEGIN
      EXECUTE IMMEDIATE q'[
        CREATE TABLE META_COLUMNS (
          owner             VARCHAR2(128)    NOT NULL,
          table_name        VARCHAR2(128)    NOT NULL,
          column_name       VARCHAR2(128)    NOT NULL,
          data_type         VARCHAR2(128)    NOT NULL,
          data_length       NUMBER,
          data_precision    NUMBER,
          data_scale        NUMBER,
          nullable          CHAR(1),
          is_pk             CHAR(1)          DEFAULT 'N',
          is_fk             CHAR(1)          DEFAULT 'N',
          fk_target_owner   VARCHAR2(128),
          fk_target_table   VARCHAR2(128),
          fk_target_column  VARCHAR2(128),
          is_date_like      CHAR(1)          DEFAULT 'N',
          column_comment    CLOB,
          synonyms          CLOB,
          created_at        DATE             DEFAULT SYSDATE,
          updated_at        DATE,
          CONSTRAINT pk_meta_columns PRIMARY KEY (owner, table_name, column_name),
          CONSTRAINT fk_meta_columns_table
            FOREIGN KEY (owner, table_name)
            REFERENCES META_TABLES (owner, table_name)
            ON DELETE CASCADE
        )
      ]';
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = -955 THEN NULL; ELSE RAISE; END IF;
    END;
    """),

    # 3) META_SAMPLES (optional)
    dedent("""
    BEGIN
      EXECUTE IMMEDIATE q'[
        CREATE TABLE META_SAMPLES (
          owner             VARCHAR2(128)    NOT NULL,
          table_name        VARCHAR2(128)    NOT NULL,
          column_name       VARCHAR2(128)    NOT NULL,
          sample_value      VARCHAR2(4000),
          CONSTRAINT fk_meta_samples_column
            FOREIGN KEY (owner, table_name, column_name)
            REFERENCES META_COLUMNS (owner, table_name, column_name)
            ON DELETE CASCADE
        )
      ]';
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = -955 THEN NULL; ELSE RAISE; END IF;
    END;
    """),

    # 4) META_SEARCH view (create or replace)
    dedent("""
    CREATE OR REPLACE VIEW META_SEARCH AS
    SELECT
      t.owner, t.table_name, t.table_type, t.row_count, t.keep_state, t.has_date_col,
      c.column_name, c.data_type, c.is_pk, c.is_fk, c.is_date_like,
      LOWER(t.table_comment)  AS table_comment,
      LOWER(c.column_comment) AS column_comment,
      LOWER(c.synonyms)       AS column_synonyms
    FROM META_TABLES t
    JOIN META_COLUMNS c
      ON c.owner = t.owner AND c.table_name = t.table_name
    """),

    # 5) Indexes (skip if already exist)
    dedent("""
    BEGIN
      EXECUTE IMMEDIATE 'CREATE INDEX ix_meta_tables_keep ON META_TABLES (owner, keep_state)';
    EXCEPTION
      WHEN OTHERS THEN
        -- Ignore: ORA-00955 (name already used), ORA-01408 (same column list already indexed)
        IF SQLCODE IN (-955, -1408) THEN
          NULL;
        ELSE
          RAISE;
        END IF;
    END;
    """),
    dedent("""
    BEGIN
      EXECUTE IMMEDIATE 'CREATE INDEX ix_meta_columns_name ON META_COLUMNS (owner, column_name)';
    EXCEPTION
      WHEN OTHERS THEN
        -- Ignore: ORA-00955 (name already used), ORA-01408 (same column list already indexed)
        IF SQLCODE IN (-955, -1408) THEN
          NULL;
        ELSE
          RAISE;
        END IF;
    END;
    """),
    dedent("""
    BEGIN
      EXECUTE IMMEDIATE 'CREATE INDEX ix_meta_columns_table ON META_COLUMNS (owner, table_name, column_name)';
    EXCEPTION
      WHEN OTHERS THEN
        -- Ignore: ORA-00955 (name already used), ORA-01408 (same column list already indexed)
        IF SQLCODE IN (-955, -1408) THEN
          NULL;
        ELSE
          RAISE;
        END IF;
    END;
    """),
]


def main():
    logging.info("Creating summary catalog objects (META_*) …")
    with db_session(mode="oracle") as conn:
        cur = conn.cursor()
        for i, stmt in enumerate(DDL_STMTS, start=1):
            logging.info("Applying DDL %d/%d …", i, len(DDL_STMTS))
            cur.execute(stmt)
        conn.commit()
    logging.info("✅ META_* objects are present (or already existed).")


if __name__ == "__main__":
    main()
