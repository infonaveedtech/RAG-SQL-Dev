# # agentic/core/llm_ollama.py
# import requests, json

# OLLAMA_GENERATE_URL = "http://localhost:11434/api/generate"

# def generate_json(prompt: str, model: str = "llama3.1:8b", temperature: float = 0.0, timeout: int = 120) -> dict:
#     """
#     Calls Ollama /api/generate with format='json' and returns a parsed dict.
#     """
#     resp = requests.post(
#         OLLAMA_GENERATE_URL,
#         json={
#             "model": model,            # e.g. "llama3.1:8b" or "mistral:7b"
#             "prompt": prompt,
#             "format": "json",          # forces JSON output
#             "stream": False,
#             "options": {"temperature": temperature}
#         },
#         timeout=timeout
#     )
#     resp.raise_for_status()
#     data = resp.json()
#     # Ollama wraps the model output in {"response": "<json string>"}
#     text = (data.get("response") or "").strip()
#     if not text:
#         raise RuntimeError("Ollama returned empty response")
#     return json.loads(text)
# agentic/core/llm_ollama.py
import os
import json
import requests
from typing import Dict

# --- Config ---
OLLAMA_GENERATE_URL = os.getenv("OLLAMA_GENERATE_URL", "http://localhost:11434/api/generate")
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"

# Toggle Groq via env: USE_GROQ=1
USE_GROQ = os.getenv("USE_GROQ", "0") == "1"

# When using Groq, default to a BIG model. Override via GROQ_MODEL if you like.
DEFAULT_GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

# Optional explicit cap for completions (Groq prefers this name)
GROQ_MAX_TOKENS = int(os.getenv("GROQ_MAX_TOKENS", "1024"))


def _print_banner(active_backend: str, model_name: str) -> None:
    # Print once per interpreter session
    if not getattr(_print_banner, "_printed", False):
        print(f"🔧 Using backend: {active_backend} — model: {model_name}")
        _print_banner._printed = True  # type: ignore[attr-defined]


def which_backend() -> str:
    """Returns 'Groq' or 'Ollama' based on current env toggle (and not runtime errors)."""
    return "Groq" if USE_GROQ else "Ollama"


def _groq_generate_json(prompt: str, temperature: float, timeout: int) -> Dict:
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key:
        raise RuntimeError("Missing GROQ_API_KEY")

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    # Use a clearly “large” default model for Groq
    model = DEFAULT_GROQ_MODEL

    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": temperature,
        # Ask Groq to return strict JSON
        "response_format": {"type": "json_object"},
        # Groq expects this field name (not max_tokens)
        "max_completion_tokens": GROQ_MAX_TOKENS,
        "n": 1,  # Groq requires n=1
    }

    _print_banner("Groq", model)
    resp = requests.post(GROQ_API_URL, headers=headers, json=payload, timeout=timeout)

    # Surface Groq’s error message verbatim to make debugging easy
    if resp.status_code >= 400:
        raise RuntimeError(f"Groq error {resp.status_code}: {resp.text}")

    data = resp.json()
    message = data["choices"][0]["message"]["content"]
    try:
        return json.loads(message)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Groq returned non-JSON content: {message!r}") from e


def _ollama_generate_json(prompt: str, model: str, temperature: float, timeout: int) -> Dict:
    payload = {
        "model": model,
        "prompt": prompt,
        "format": "json",          # force JSON from Ollama
        "stream": False,
        "options": {"temperature": temperature},
    }

    _print_banner("Ollama", model)
    resp = requests.post(OLLAMA_GENERATE_URL, json=payload, timeout=timeout)
    if resp.status_code >= 400:
        raise RuntimeError(f"Ollama error {resp.status_code}: {resp.text}")

    data = resp.json()
    text = (data.get("response") or "").strip()
    if not text:
        raise RuntimeError("Ollama returned empty response")
    return json.loads(text)


def generate_json(
    prompt: str,
    model: str = "llama3.1:8b",   # your local default stays the same for Ollama
    temperature: float = 0.0,
    timeout: int = 120,
) -> Dict:
    """
    Unified generator:
      - If USE_GROQ=1: call Groq with a BIG model (override via GROQ_MODEL).
      - Else: call your local Ollama using the provided 'model' arg.
    If Groq is enabled but errors, we fall back to Ollama automatically.
    """
    if USE_GROQ:
        try:
            return _groq_generate_json(prompt, temperature, timeout)
        except Exception as e:
            # Log+fallback to Ollama so your app still works locally
            print(f"⚠️  Groq failed ({e}). Falling back to Ollama…")

    # Local path (or fallback)
    return _ollama_generate_json(prompt, model, temperature, timeout)


# --- Quick CLI test: python -m agentic.core.llm_ollama ---
if __name__ == "__main__":
    test_prompt = "Return a JSON object with 'backend' and 'ok': true."
    try:
        result = generate_json(test_prompt)
        print("Result:", result)
    except Exception as e:
        print("Error:", e)
