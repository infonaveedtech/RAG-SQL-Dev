import json
import csv
import logging
import re
from pathlib import Path
from typing import Dict, Set, Tuple, Any, List

from db_conn import db_session

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# --- helpers -----------------------------------------------------------------

def _read_keep_lists(must_keep_csv: Path = None,
                     candidate_csv: Path = None,
                     omit_now_csv: Path = None) -> Dict[Tuple[str, str], str]:
    """
    Returns {(owner, table_name): keep_state}
    Priority: MUST_KEEP > OMIT > CANDIDATE
    """
    def read_set(p: Path) -> Set[Tuple[str, str]]:
        s: Set[Tuple[str, str]] = set()
        if not p:
            return s
        with p.open(newline="", encoding="utf-8") as f:
            rdr = csv.DictReader(f)
            # Accept flexible headers: owner/table_name or just table
            headers = {h.lower() for h in rdr.fieldnames or []}
            for row in rdr:
                owner = (row.get("owner") or row.get("schema") or "ATS").strip().upper()
                table = (row.get("table_name") or row.get("table") or "").strip().upper()
                if not table:
                    continue
                s.add((owner, table))
        return s

    keep: Dict[Tuple[str, str], str] = {}

    must = read_set(must_keep_csv) if must_keep_csv else set()
    omit = read_set(omit_now_csv) if omit_now_csv else set()
    cand = read_set(candidate_csv) if candidate_csv else set()

    for k in cand:
        keep[k] = "CANDIDATE"
    for k in omit:
        keep[k] = "OMIT"
    for k in must:
        keep[k] = "KEEP"

    return keep


_DATE_NAME_PAT = re.compile(r"(?:^|_)(date|dt|time|ts|timestamp|created|updated|modified)(?:_|$)", re.I)

def _is_date_like(col: Dict[str, Any]) -> bool:
    t = (col.get("data_type") or "").upper()
    n = (col.get("column_name") or "")
    if t.startswith("DATE") or t.startswith("TIMESTAMP"):
        return True
    return bool(_DATE_NAME_PAT.search(n))


def _table_has_date(cols: List[Dict[str, Any]]) -> bool:
    return any(_is_date_like(c) for c in cols)


def _normalize_owner(s: str) -> str:
    return (s or "ATS").upper()


def _normalize_table(s: str) -> str:
    return (s or "").upper()


def _normalize_column(s: str) -> str:
    return (s or "").upper()


# --- main loader --------------------------------------------------------------

def load_catalog(json_path: Path,
                 must_keep_csv: Path = None,
                 candidate_csv: Path = None,
                 omit_now_csv: Path = None,
                 default_owner: str = "ATS"):
    json_path = Path(json_path)
    assert json_path.exists(), f"JSON not found: {json_path}"

    logging.info("Reading crawl JSON: %s", json_path)
    raw = json.loads(json_path.read_text(encoding="utf-8"))

    # Accept either:
    # (A) {"owner":"ATS","tables":[...]}  OR
    # (B) [{"owner":"ATS","table_name":"...","columns":[...]}, ...]
    if isinstance(raw, dict):
        owner = _normalize_owner(raw.get("owner") or default_owner)
        tables = raw.get("tables") or raw.get("TABLES") or []
    elif isinstance(raw, list):
        tables = raw
        # try to infer owner from the first row if present, else fallback
        first_owner = None
        for t0 in raw:
            first_owner = t0.get("owner") or t0.get("OWNER")
            if first_owner:
                break
        owner = _normalize_owner(first_owner or default_owner)
    else:
        raise ValueError("Unsupported JSON structure for crawl output")

    # Normalize table entries (some crawlers use 'name', some 'table_name')
    def _get_table_name(t):
        return (t.get("table_name") or t.get("TABLE_NAME") or t.get("name") or t.get("NAME") or "").strip()

    def _get_columns(t):
        return t.get("columns") or t.get("COLUMNS") or []

    # Optional: if individual table objects carry their own owner, prefer that per-table later


    keep_map = _read_keep_lists(must_keep_csv, candidate_csv, omit_now_csv)
    logging.info("Keep map sizes → KEEP: %d, CANDIDATE: %d, OMIT: %d",
                 sum(1 for v in keep_map.values() if v == "KEEP"),
                 sum(1 for v in keep_map.values() if v == "CANDIDATE"),
                 sum(1 for v in keep_map.values() if v == "OMIT"))

    # Prepare rows
    meta_tables_rows = []
    meta_columns_rows = []

    for t in tables:
        table_owner = _normalize_owner(t.get("owner") or t.get("OWNER") or owner)
        table_name = _normalize_table(_get_table_name(t))
        if not table_name:
            continue
        cols = _get_columns(t)

        has_date = _table_has_date(cols)

        keep_state = keep_map.get((owner, table_name), "CANDIDATE")
        table_comment = (t.get("table_comment") or t.get("comment") or "")[:4000]  # safe trim

        meta_tables_rows.append({
            "owner": table_owner,
            "table_name": table_name,
            "table_type": t.get("table_type"),  # may be None; we may fill later
            "row_count": t.get("row_count"),
            "last_analyzed": t.get("last_analyzed"),
            "table_comment": table_comment,
            "keep_state": keep_state,
            "has_date_col": "Y" if has_date else "N",
        })

        for c in cols:
            col_name = _normalize_column(c.get("column_name") or c.get("name"))
            if not col_name:
                continue
            data_type = c.get("data_type")
            col_comment = (c.get("comment") or c.get("column_comment") or "")[:4000]

            meta_columns_rows.append({
                "owner": table_owner,
                "table_name": table_name,
                "column_name": col_name,
                "data_type": data_type,
                "data_length": c.get("data_length"),
                "data_precision": c.get("data_precision"),
                "data_scale": c.get("data_scale"),
                "nullable": ("Y" if (c.get("nullable") in (True, "Y", "y", "YES", "Yes")) else "N")
                            if c.get("nullable") is not None else None,
                "is_pk": "N",  # Step 3C will enrich PK/FK precisely
                "is_fk": "N",
                "fk_target_owner": None,
                "fk_target_table": None,
                "fk_target_column": None,
                "is_date_like": "Y" if _is_date_like({"data_type": data_type, "column_name": col_name}) else "N",
                "column_comment": col_comment,
                "synonyms": None,
            })

    logging.info("Prepared rows → tables: %d, columns: %d", len(meta_tables_rows), len(meta_columns_rows))

    # Upsert into Oracle
    with db_session(mode="oracle") as conn:
        cur = conn.cursor()

        # MERGE for META_TABLES
        cur.prepare("""
            MERGE INTO META_TABLES t
            USING (SELECT :owner AS owner,
                          :table_name AS table_name,
                          :table_type AS table_type,
                          :row_count AS row_count,
                          :last_analyzed AS last_analyzed,
                          :table_comment AS table_comment,
                          :keep_state AS keep_state,
                          :has_date_col AS has_date_col
                   FROM dual) s
            ON (t.owner = s.owner AND t.table_name = s.table_name)
            WHEN MATCHED THEN UPDATE SET
                t.table_type   = s.table_type,
                t.row_count    = s.row_count,
                t.last_analyzed= s.last_analyzed,
                t.table_comment= s.table_comment,
                t.keep_state   = s.keep_state,
                t.has_date_col = s.has_date_col,
                t.updated_at   = SYSDATE
            WHEN NOT MATCHED THEN INSERT
              (owner, table_name, table_type, row_count, last_analyzed, table_comment, keep_state, has_date_col, created_at)
            VALUES
              (s.owner, s.table_name, s.table_type, s.row_count, s.last_analyzed, s.table_comment, s.keep_state, s.has_date_col, SYSDATE)
        """)
        cur.executemany(None, meta_tables_rows)
        logging.info("Upserted META_TABLES: %d", cur.rowcount)

        # MERGE for META_COLUMNS
        cur.prepare("""
            MERGE INTO META_COLUMNS c
            USING (SELECT :owner AS owner,
                          :table_name AS table_name,
                          :column_name AS column_name,
                          :data_type AS data_type,
                          :data_length AS data_length,
                          :data_precision AS data_precision,
                          :data_scale AS data_scale,
                          :nullable AS nullable,
                          :is_pk AS is_pk,
                          :is_fk AS is_fk,
                          :fk_target_owner AS fk_target_owner,
                          :fk_target_table AS fk_target_table,
                          :fk_target_column AS fk_target_column,
                          :is_date_like AS is_date_like,
                          :column_comment AS column_comment,
                          :synonyms AS synonyms
                   FROM dual) s
            ON (c.owner = s.owner AND c.table_name = s.table_name AND c.column_name = s.column_name)
            WHEN MATCHED THEN UPDATE SET
                c.data_type        = s.data_type,
                c.data_length      = s.data_length,
                c.data_precision   = s.data_precision,
                c.data_scale       = s.data_scale,
                c.nullable         = s.nullable,
                c.is_pk            = s.is_pk,
                c.is_fk            = s.is_fk,
                c.fk_target_owner  = s.fk_target_owner,
                c.fk_target_table  = s.fk_target_table,
                c.fk_target_column = s.fk_target_column,
                c.is_date_like     = s.is_date_like,
                c.column_comment   = s.column_comment,
                c.synonyms         = s.synonyms,
                c.updated_at       = SYSDATE
            WHEN NOT MATCHED THEN INSERT
              (owner, table_name, column_name, data_type, data_length, data_precision, data_scale,
               nullable, is_pk, is_fk, fk_target_owner, fk_target_table, fk_target_column,
               is_date_like, column_comment, synonyms, created_at)
            VALUES
              (s.owner, s.table_name, s.column_name, s.data_type, s.data_length, s.data_precision, s.data_scale,
               s.nullable, s.is_pk, s.is_fk, s.fk_target_owner, s.fk_target_table, s.fk_target_column,
               s.is_date_like, s.column_comment, s.synonyms, SYSDATE)
        """)
        cur.executemany(None, meta_columns_rows)
        logging.info("Upserted META_COLUMNS: %d", cur.rowcount)

        conn.commit()
    logging.info("✅ Catalog load complete.")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Load META_* from crawl JSON + keep/candidate/omit CSVs")
    ap.add_argument("--json", required=True, help="Path to crawl JSON (e.g., data/raw/ats_schema_YYYY-MM-DD.json)")
    ap.add_argument("--must_keep_csv", required=False, help="must_keep CSV")
    ap.add_argument("--candidate_csv", required=False, help="candidate CSV")
    ap.add_argument("--omit_now_csv", required=False, help="omit_now CSV")
    args = ap.parse_args()

    load_catalog(
        json_path=Path(args.json),
        must_keep_csv=Path(args.must_keep_csv) if args.must_keep_csv else None,
        candidate_csv=Path(args.candidate_csv) if args.candidate_csv else None,
        omit_now_csv=Path(args.omit_now_csv) if args.omit_now_csv else None,
    )


# """
# python core/load_catalog.py --json data/raw/ats_schema_2025-10-16.json --must_keep_csv selection_stats\must_keep_20251013_230423.csv --candidate_csv selection_stats\candidate_20251013_230423.csv --omit_now_csv selection_stats\omit_now_20251013_230423.csv
# """