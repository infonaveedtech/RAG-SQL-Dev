# agentic/core/normalizers.py
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, date
from typing import Optional, Tuple
import re
from agentic.core.schemas import IntentV2

# Simple month name mapping (english, case-insensitive)
_MONTHS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

# crude month finder
_MONTH_REGEX = re.compile(r"\b(" + "|".join(sorted(_MONTHS.keys(), key=len, reverse=True)) + r")\b", re.I)
_YEAR_REGEX = re.compile(r"\b(20\d{2}|19\d{2})\b")

def _last_day_of_month(y: int, m: int) -> int:
    # simple month length (no external deps)
    if m in (1,3,5,7,8,10,12): return 31
    if m in (4,6,9,11): return 30
    # feb:
    leap = (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0))
    return 29 if leap else 28

def _extract_months_and_any_year(text: str) -> Tuple[list[int], Optional[int]]:
    months = [ _MONTHS[m.group(1).lower()] for m in _MONTH_REGEX.finditer(text or "") ]
    # keep order of occurrence but unique
    ordered_unique = []
    seen = set()
    for m in months:
        if m not in seen:
            ordered_unique.append(m)
            seen.add(m)
    year_match = _YEAR_REGEX.search(text or "")
    year = int(year_match.group(1)) if year_match else None
    return ordered_unique, year

def normalize_intent_v2(intent: IntentV2, now: Optional[datetime] = None) -> IntentV2:
    """
    Gentle, schema-agnostic tweaks:
      1) Month-only → infer current year (and granularity='month').
      2) Prefer ordering.top_n over limit unless 'limit' was explicitly mentioned.
      3) Drop duplicate date filter if time_range exists.
      4) If phrasing is month-range, set granularity to 'month' when not already set.
    """
    if now is None:
        now = datetime.now()

    # 1) Month-only → infer current year
    # If the model *didn't* put a year (or left time_range null) but months are present,
    # fill from/to for the current year. If end < start, wrap into next year.
    if intent.task == "DATA_QUERY":
        text = intent.original_text or ""
        months, year_in_text = _extract_months_and_any_year(text)

        # User rule: If not mentioned, pick the current year.
        # Apply only when the model did NOT already parse a concrete year.
        need_year_inference = False
        if year_in_text is None:
            # Either the model left time_range null OR it guessed wrong nonsense.
            if months:
                need_year_inference = True

        if need_year_inference:
            cy = now.year
            if len(months) == 1:
                m1 = months[0]
                from_d = date(cy, m1, 1)
                to_d = date(cy, m1, _last_day_of_month(cy, m1))
            else:
                m1 = months[0]
                m2 = months[-1]
                y_start, y_end = cy, cy
                if m2 < m1:
                    # wrap to next year
                    y_end = cy + 1
                from_d = date(y_start, m1, 1)
                to_d = date(y_end, m2, _last_day_of_month(y_end, m2))

            # Write back time_range
            if intent.time_range is None:
                # construct a bare dict; Pydantic will carry it fine in-memory
                intent.time_range = type(intent).model_fields["time_range"].annotation(  # type: ignore
                    from_date=from_d.isoformat(),
                    to_date=to_d.isoformat(),
                    granularity=intent.time_range.granularity if intent.time_range else None
                ) if False else None  # we'll just set fields below

            # set attributes safely (object may be a plain dict-like model)
            if intent.time_range is None:
                class _TR: pass
                tr = _TR()
                setattr(tr, "from_date", from_d.isoformat())
                setattr(tr, "to_date", to_d.isoformat())
                setattr(tr, "granularity", getattr(intent, "group_granularity", None) or "month")
                intent.time_range = tr  # type: ignore
            else:
                # has a time_range object already; just set fields
                intent.time_range.from_date = from_d.isoformat()  # type: ignore
                intent.time_range.to_date = to_d.isoformat()      # type: ignore
                if getattr(intent, "group_granularity", None) is None and getattr(intent.time_range, "granularity", None) is None:
                    intent.time_range.granularity = "month"       # type: ignore

        # 2) If phrasing was month-range and no explicit granularity, prefer 'month'
        if months and (intent.group_granularity is None) and (getattr(intent.time_range, "granularity", None) is None):
            intent.group_granularity = "month"

    # 3) Prefer ordering.top_n over limit (unless explicit "limit" text)
    if intent.ordering and intent.ordering.top_n is not None:
        # If user didn't explicitly say the word "limit", clear limit to avoid duplicates
        if "limit" not in (intent.original_text or "").lower():
            intent.limit = None

    # 4) Drop duplicate date filter if time_range exists
    if intent.time_range is not None and intent.filters:
        filtered = []
        for f in intent.filters:
            if (f.field.lower() in ("date","trade_date","as_of","timestamp") and f.op == "between"):
                # skip, since time_range exists
                continue
            filtered.append(f)
        intent.filters = filtered

    return intent
