# # agentic/core/schemas.py
# Agent0Any = Union[Agent0DataQuery, Agent0Chat, Agent0OutOfScope]
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Literal, Union

Op = Literal["=", "!=", "in", "not in", "between", ">", ">=", "<", "<=", "like"]

class Filter(BaseModel):
    field: str
    op: Op
    from_: Optional[Union[str, float, int]] = Field(None, alias="from")
    to: Optional[Union[str, float, int]] = None
    value: Optional[Union[str, float, int, List[Union[str, float, int]]]] = None

    @validator("field")
    def v_field(cls, v):
        if not v or not v.strip():
            raise ValueError("field is required")
        return v.strip()

class OrderSpec(BaseModel):
    by: Optional[str] = None                 # measure or column name (free text; Agent-2 will map)
    direction: Literal["asc", "desc"] = "desc"
    top_n: Optional[int] = None              # if present → top/bottom-N
    scope: Literal["overall", "per_group", "auto"] = "auto"  # "auto" → per_group if group_by present

class MathHints(BaseModel):
    weighted_by: Optional[str] = None        # e.g., "QUANTITY" or "VOLUME"
    percentile: Optional[float] = None       # e.g., 0.9 for P90
    moving_avg_window: Optional[int] = None  # e.g., 7 for 7-day MA
    running_sum: Optional[bool] = None

class Agent0DataQuery(BaseModel):
    task: Literal["DATA_QUERY"]
    entities: List[str] = []
    measures: List[str] = []
    filters: List[Filter] = []
    group_by: List[str] = []
    limit: Optional[int] = 1000
    owner_hint: Optional[str] = "ATS"
    order: Optional[OrderSpec] = None        # NEW (optional)
    math: Optional[MathHints] = None         # NEW (optional)

class Agent0Chat(BaseModel):
    task: Literal["CHAT"]
    message: str

class Agent0OutOfScope(BaseModel):
    task: Literal["OUT_OF_SCOPE"]
    message: str

Agent0Any = Union[Agent0DataQuery, Agent0Chat, Agent0OutOfScope]

# --- Agent-0 v2 (schema-agnostic intent) ---

from typing import List, Optional, Literal, Union
from pydantic import BaseModel, Field

class DateRangeV2(BaseModel):
    from_date: Optional[str] = Field(None, description="YYYY-MM-DD")
    to_date: Optional[str] = Field(None, description="YYYY-MM-DD")
    granularity: Optional[Literal["day", "month", "year"]] = None

OpV2 = Literal["=", "!=", "in", "not in", "between", ">", ">=", "<", "<=", "like"]

class FilterV2(BaseModel):
    field: str  # user wording, schema-agnostic
    op: OpV2
    value: Optional[Union[str, float, int, List[Union[str, float, int]]]] = None
    from_value: Optional[Union[str, float, int]] = None
    to_value: Optional[Union[str, float, int]] = None

class OrderSpecV2(BaseModel):
    by: Optional[str] = None
    direction: Literal["asc", "desc"] = "desc"
    top_n: Optional[int] = None

class IntentV2(BaseModel):
    task: Literal["DATA_QUERY", "CHAT", "OUT_OF_SCOPE"]
    time_range: Optional[DateRangeV2] = None
    measures_requested: List[str] = []
    entities_requested: List[str] = []
    filters: List[FilterV2] = []
    group_granularity: Optional[Literal["day", "month", "year"]] = None
    ordering: Optional[OrderSpecV2] = None
    limit: Optional[int] = None
    topic_keywords: List[str] = []
    ambiguities: List[str] = []
    original_text: str

# --- Agent-1 decision schema (LLM output) ---

from typing import Optional, Literal
from pydantic import BaseModel

class SolutionDecision(BaseModel):
    decision: Literal["statistical_data", "ASK_CLARIFICATION", "OUT_OF_SCOPE"]
    reason: Optional[str] = None
    question: Optional[str] = None
    hints: Optional[dict] = None
