# agentic/core/selector_sql.py
"""
Selector SQL helpers
--------------------
These helpers are intentionally small and deterministic. They:
  • shortlist fact table candidates from META_* using your keep_state
  • list columns for a given table
  • fetch FK edges (join keys) on demand from the Oracle dictionary
All queries are scoped to owner='ATS' by default.
"""

from typing import List, Dict, Any, Tuple, Set
from agentic.core.db_conn import db_session

OWNER = "ATS"


def _normalize_tokens(tokens: List[str]) -> List[str]:
    # Simple normalization for matching (UPPER + underscores preserved)
    out = []
    for t in tokens or []:
        t = (t or "").strip().upper()
        if not t:
            continue
        out.append(t.replace(" ", "_"))
    return out


def fetch_candidate_facts(
    required_tokens: List[str],
    require_date_col: bool = False,
    limit: int = 8
) -> List[Dict[str, Any]]:
    """
    Return up to {limit} candidate fact-like tables from META_*.
    Scoring is simple: column-name substring matches against required_tokens,
    keep_state preference (KEEP over CANDIDATE), and has_date_col if required.

    Output rows: {table_name, keep_state, has_date_col, score}
    """
    tokens = _normalize_tokens(required_tokens)
    # Build a WHERE clause that checks any of the tokens against column_name
    # e.g. UPPER(c.column_name) LIKE '%TRADE%' OR UPPER(c.column_name) LIKE '%INSTRUMENT%'
    token_pred = " OR ".join([f"UPPER(c.column_name) LIKE '%' || :tok{i} || '%'" for i in range(len(tokens))]) or "1=1"

    sql = f"""
        SELECT
          t.table_name,
          t.keep_state,
          t.has_date_col,
          NVL(SUM(CASE WHEN ({token_pred}) THEN 1 ELSE 0 END), 0) AS token_hits,
          /* prefer KEEP over CANDIDATE */
          MAX(CASE WHEN t.keep_state='KEEP' THEN 10 ELSE 0 END) AS keep_bonus
        FROM META_TABLES t
        JOIN META_COLUMNS c
          ON c.owner = t.owner AND c.table_name = t.table_name
        WHERE t.owner = :owner
          AND t.keep_state IN ('KEEP','CANDIDATE')
          { "AND t.has_date_col = 'Y'" if require_date_col else "" }
        GROUP BY t.table_name, t.keep_state, t.has_date_col
        ORDER BY (NVL(SUM(CASE WHEN ({token_pred}) THEN 1 ELSE 0 END), 0) + MAX(CASE WHEN t.keep_state='KEEP' THEN 10 ELSE 0 END)) DESC,
                 t.keep_state ASC, t.table_name ASC
        FETCH FIRST :lim ROWS ONLY
    """

    binds: Dict[str, Any] = {"owner": OWNER, "lim": limit}
    for i, tok in enumerate(tokens):
        binds[f"tok{i}"] = tok

    with db_session(mode="oracle") as conn:
        cur = conn.cursor()
        cur.execute(sql, binds)
        rows = []
        for r in cur:
            rows.append({
                "table_name": r[0],
                "keep_state": r[1],
                "has_date_col": r[2],
                "score": int(r[3]) + int(r[4]),
            })
        return rows


def fetch_table_columns(table_name: str) -> List[Dict[str, Any]]:
    sql = """
      SELECT column_name, data_type, is_date_like
      FROM META_COLUMNS
      WHERE owner = :owner AND table_name = :table_name
      ORDER BY column_name
    """
    with db_session(mode="oracle") as conn:
        cur = conn.cursor()
        cur.execute(sql, {"owner": OWNER, "table_name": table_name})
        return [
            {"column_name": r[0], "data_type": r[1], "is_date_like": r[2]}
            for r in cur
        ]


def fetch_fk_edges(among_tables: List[str]) -> List[Dict[str, Any]]:
    """
    Fetch FK join edges *only among* the given ATS tables by querying Oracle dictionary.
    Returns edges of the form:
      { "from_table":"TRADES", "from_col":"INSTRUMENT_ID",
        "to_table":"INSTRUMENTS", "to_col":"INSTRUMENT_ID" }

    We look for constraints where:
      child.owner=ATS and parent.owner=ATS,
      child.table_name in among_tables OR parent.table_name in among_tables
    """
    # De-duplicate & normalize to UPPER
    tables: Set[str] = {t.upper() for t in (among_tables or [])}
    if not tables:
        return []

    with db_session(mode="oracle") as conn:
        cur = conn.cursor()
        # 1) Get FK constraints (child -> parent PK/UK)
        cur.execute("""
            SELECT
              ac_child.table_name   AS child_table,
              acc_child.column_name AS child_col,
              ac_parent.table_name  AS parent_table,
              acc_parent.column_name AS parent_col
            FROM ALL_CONSTRAINTS ac_child
            JOIN ALL_CONS_COLUMNS acc_child
              ON acc_child.owner = ac_child.owner
             AND acc_child.constraint_name = ac_child.constraint_name
            JOIN ALL_CONSTRAINTS ac_parent
              ON ac_parent.owner = ac_child.r_owner
             AND ac_parent.constraint_name = ac_child.r_constraint_name
            JOIN ALL_CONS_COLUMNS acc_parent
              ON acc_parent.owner = ac_parent.owner
             AND acc_parent.constraint_name = ac_parent.constraint_name
             AND acc_parent.position = acc_child.position
            WHERE ac_child.owner = :owner
              AND ac_parent.owner = :owner
              AND ac_child.constraint_type = 'R'
              AND (ac_child.table_name IN ({placeholders})
                   OR ac_parent.table_name IN ({placeholders}))
        """.format(placeholders=", ".join([f":t{i}" for i in range(len(tables))])),
        dict({"owner": OWNER}, **{f"t{i}": t for i, t in enumerate(tables)}))
        edges = []
        for r in cur:
            edges.append({
                "from_table": r[0],
                "from_col": r[1],
                "to_table": r[2],
                "to_col": r[3],
            })
        return edges
