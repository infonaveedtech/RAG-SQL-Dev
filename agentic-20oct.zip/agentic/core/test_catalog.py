# from db_conn import db_session

# with db_session(mode="oracle") as conn:
#     cur = conn.cursor()
#     cur.execute("""
#         SELECT table_name FROM user_tables
#         WHERE table_name IN ('META_TABLES','META_COLUMNS','META_SAMPLES')
#         ORDER BY table_name
#     """)
#     print("Tables:", [r[0] for r in cur.fetchall()])

#     cur.execute("SELECT view_name FROM user_views WHERE view_name = 'META_SEARCH'")
#     print("View:", [r[0] for r in cur.fetchall()])

from db_conn import db_session
with db_session(mode="oracle") as conn:
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM META_TABLES"); print("tables:", cur.fetchone()[0])
    cur.execute("SELECT keep_state, COUNT(*) FROM META_TABLES GROUP BY keep_state ORDER BY keep_state"); print("keep:", cur.fetchall())
    cur.execute("SELECT COUNT(*) FROM META_COLUMNS"); print("columns:", cur.fetchone()[0])
