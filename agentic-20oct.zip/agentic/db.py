import logging
from core.db_conn import test_connection

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

ok = test_connection(mode="oracle")
print("RESULT:", "OK" if ok else "FAIL")
