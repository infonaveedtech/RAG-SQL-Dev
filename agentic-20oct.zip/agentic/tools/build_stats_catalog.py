# import json, re
# from pathlib import Path
# from typing import Any, Dict, List

# SRC_HINTS = {
#     "ATS.SYMBOL_DAILY_INDICATORS": {
#         "alias": "sdi", "grain": "symbol_per_day", "date_key_pref": ["STATS_DATE"],
#         "measure_tags": {
#             "TURNOVER_VALUE": ["turnover","value_traded"],
#             "CLOSE_PRICE": ["price","close","avg_price"],
#             "OPEN_PRICE": ["price","open"],
#             "HIGH_PRICE": ["price","high"],
#             "LOW_PRICE": ["price","low"],
#             "TRADES_COUNT": ["trades_count"],
#         },
#         "fk_names": ["SYMBOL_ID","EXCHANGE_ID"]
#     },
#     "ATS.SYMBOL_INDICATORS": {
#         "alias": "si", "grain": "symbol_snapshot", "date_key_pref": ["ENTRY_DATETIME"],
#         "measure_tags": {
#             "VOLUME": ["volume"],
#             "VALUE": ["turnover","value_traded"],
#             "CLOSE": ["price","close","avg_price"],
#             "OPEN": ["price","open"],
#             "HIGH": ["price","high"],
#             "LOW": ["price","low"],
#             "AVG": ["price","avg"],
#         },
#         "fk_names": ["SYMBOL_ID","EXCHANGE_ID"]
#     },
#     "ATS.BEST_MKT": {
#         "alias": "bm", "grain": "best_quote_snapshot", "date_key_pref": ["ENTRY_DATETIME"],
#         "measure_tags": {
#             "BID_PRICE": ["bid","price"],
#             "OFFER_PRICE": ["ask","offer","price"],
#             "BID_VOLUME": ["bid_volume"],
#             "OFFER_VOLUME": ["ask_volume"],
#         },
#         "fk_names": ["SYMBOL_ID","EXCHANGE_ID"],
#         "derived": [
#             {"name":"__DERIVED_SPREAD__","tags":["spread"],"formula":"OFFER_PRICE - BID_PRICE","aggregations":["avg"]},
#             {"name":"__DERIVED_MID__","tags":["mid"],"formula":"(BID_PRICE + BID_PRICE)/2","aggregations":["avg"]}  # fixed at runtime to OFFER+BID
#         ]
#     }
# }

# LOOKUPS = {
#     "ATS.SYMBOLS": {
#         "alias":"sym","keys":["SYMBOL_ID"],
#         "labels":[{"name":"SYMBOL","preferred":True},{"name":"SYMBOL_NAME","preferred":False}]
#     },
#     "ATS.EXCHANGES": {
#         "alias":"ex","keys":["EXCHANGE_ID"],
#         "labels":[{"name":"EXCHANGE_NAME","preferred":True},{"name":"EXCHANGE_CODE","preferred":False}]
#     }
# }

# NUMERIC_DT = {"NUMBER","FLOAT","BINARY_FLOAT","BINARY_DOUBLE","DECIMAL"}

# def build(enriched_from: Path) -> Dict[str, Any]:
#     raw = json.loads(enriched_from.read_text(encoding="utf-8"))
#     if not isinstance(raw, list):
#         raise ValueError("expected list of table entries")

#     # quick index
#     idx = {(e.get("owner","")+"."+e.get("table_name","")).upper(): e for e in raw}

#     facts = []
#     for fqn, cfg in SRC_HINTS.items():
#         entry = idx.get(fqn.upper())
#         if not entry:
#             continue
#         cols = entry.get("columns", [])
#         col_index = {c["column_name"].upper(): c for c in cols}
#         # date key
#         dk = None
#         for pref in cfg["date_key_pref"]:
#             if pref.upper() in col_index:
#                 dk = pref; break
#         if not dk:
#             # fallback: first DATE/TIMESTAMP
#             for c in cols:
#                 dt = (c.get("data_type") or "").upper()
#                 if "DATE" in dt or "TIMESTAMP" in dt:
#                     dk = c["column_name"]; break

#         # measures (numeric with semantic tags)
#         measures = []
#         for name, tags in cfg.get("measure_tags", {}).items():
#             c = col_index.get(name.upper())
#             if not c: 
#                 continue
#             dt = (c.get("data_type") or "").upper()
#             if not any(t in dt for t in NUMERIC_DT) and "DATE" not in dt:
#                 # still include—it might be NUMBER in Oracle shown as NVARCHAR in crawl; we keep lenient
#                 pass
#             aggs = []
#             # heuristic: turnover/volume/value default sum; price defaults avg/min/max
#             if any(t in {"turnover","value_traded","volume","trades_count","bid_volume","ask_volume"} for t in tags):
#                 aggs = ["sum"]
#             if any(t in {"price","close","open","high","low","avg","bid","ask","offer"} for t in tags):
#                 aggs = sorted(list(set(aggs + ["avg","min","max"])))
#             measures.append({"name": c["column_name"], "type": "number", "tags": tags, "aggregations": aggs or ["avg","sum"]})

#         # derived (BM)
#         for d in cfg.get("derived", []):
#             d2 = dict(d)
#             if d2["name"] == "__DERIVED_MID__":
#                 d2["formula"] = "(BID_PRICE + OFFER_PRICE)/2"
#             measures.append({"name": d2["name"], "type": "number", "tags": d2["tags"], "formula": d2["formula"], "aggregations": d2["aggregations"]})

#         facts.append({
#             "fqn": fqn, "alias": cfg["alias"], "grain": cfg["grain"],
#             "date_key": dk, "foreign_keys": [fk for fk in cfg["fk_names"] if fk in col_index],
#             "dimensions_inline": [],
#             "measures": measures,
#             "availability": {"row_count": entry.get("num_rows")},
#             "examples": (entry.get("examples") or [])[:1]
#         })

#     lookups = []
#     for fqn, meta in LOOKUPS.items():
#         entry = idx.get(fqn.upper())
#         if not entry: 
#             continue
#         lookups.append({
#             "fqn": fqn, "alias": meta["alias"], "keys": meta["keys"], "labels": meta["labels"]
#         })

#     joins = []
#     join_pairs = [
#         ("ATS.SYMBOL_DAILY_INDICATORS","ATS.SYMBOLS","sdi.SYMBOL_ID = sym.SYMBOL_ID"),
#         ("ATS.SYMBOL_DAILY_INDICATORS","ATS.EXCHANGES","sdi.EXCHANGE_ID = ex.EXCHANGE_ID"),
#         ("ATS.SYMBOL_INDICATORS","ATS.SYMBOLS","si.SYMBOL_ID = sym.SYMBOL_ID"),
#         ("ATS.SYMBOL_INDICATORS","ATS.EXCHANGES","si.EXCHANGE_ID = ex.EXCHANGE_ID"),
#         ("ATS.BEST_MKT","ATS.SYMBOLS","bm.SYMBOL_ID = sym.SYMBOL_ID"),
#         ("ATS.BEST_MKT","ATS.EXCHANGES","bm.EXCHANGE_ID = ex.EXCHANGE_ID"),
#     ]
#     for left, right, on in join_pairs:
#         if idx.get(left) and idx.get(right):
#             joins.append({"left": left, "right": right, "on": on, "type":"inner"})

#     return {
#         "generated_at": __import__("datetime").datetime.utcnow().isoformat()+"Z",
#         "facts": facts,
#         "lookups": lookups,
#         "join_templates": joins,
#         "constraints": {
#             "supported_granularities":["day","month","year"],
#             "intraday_supported": False,
#             "indexes_supported": False
#         }
#     }

# if __name__ == "__main__":
#     import argparse
#     ap = argparse.ArgumentParser()
#     ap.add_argument("--src", required=True, help="path to ats_schema_YYYY-MM-DD.json")
#     ap.add_argument("--out", required=True, help="path to write stats_catalog.json")
#     args = ap.parse_args()
#     out = build(Path(args.src))
#     Path(args.out).write_text(json.dumps(out, indent=2), encoding="utf-8")
#     print(f"wrote {args.out}")


import json, re, argparse
from pathlib import Path
from typing import Dict, Any, List

# patterns to find our three facts
PAT_SDI = [r"^SYMBOL_DAILY_INDICATORS$", r"^SYMBOLS?_DAILY_?INDICATORS?$"]
PAT_SI  = [r"^SYMBOL_INDICATORS$", r"^SYMBOLS?_INDICATORS?$"]
PAT_BM  = [r"^BEST_?MKT$", r"^BEST_?MARKET$"]

def _match(name: str, pats: List[str]) -> bool:
    u = name.upper()
    for p in pats:
        if re.search(p, u):
            return True
    return False

def _colset(entry: Dict[str, Any]) -> set:
    return { (c.get("column_name") or "").upper() for c in entry.get("columns", []) }

def _build_fact(entry: Dict[str, Any], fact_id: str) -> Dict[str, Any]:
    cols = _colset(entry)
    fqn = f"{entry.get('owner')}.{entry.get('table_name')}"
    if fact_id == "SDI":
        measures = []
        if "TURNOVER_VALUE" in cols: measures.append({"name":"turnover","column":"TURNOVER_VALUE","agg":"SUM"})
        if "CLOSE_PRICE" in cols:    measures.append({"name":"avg_price","column":"CLOSE_PRICE","agg":"AVG"})
        for nm, col in [("open","OPEN_PRICE"),("high","HIGH_PRICE"),("low","LOW_PRICE"),("close","CLOSE_PRICE")]:
            if col in cols: measures.append({"name":nm,"column":col,"agg":None})
        if "TRADES_COUNT" in cols: measures.append({"name":"trades_count","column":"TRADES_COUNT","agg":"SUM"})
        date_keys = [{"column":"STATS_DATE","supports":["day","month","year"]}] if "STATS_DATE" in cols else []
        dims = []
        if "SYMBOL_ID" in cols:   dims.append({"name":"symbol_id","column":"SYMBOL_ID"})
        if "EXCHANGE_ID" in cols: dims.append({"name":"exchange_id","column":"EXCHANGE_ID"})
        return {
            "id":"SDI","fqn":fqn,"grain":"symbol_day",
            "date_keys":date_keys, "keys":[{"column":"SYMBOL_ID"},{"column":"EXCHANGE_ID"}],
            "measures":measures, "dimensions":dims,
            "capabilities":{"supports_intraday_bucket": False}
        }
    if fact_id == "SI":
        measures = []
        if "VOLUME" in cols: measures.append({"name":"volume","column":"VOLUME","agg":"SUM"})
        if "VALUE" in cols:  measures.append({"name":"turnover","column":"VALUE","agg":"SUM","optional": True})
        if "CLOSE" in cols:  measures.append({"name":"avg_price","column":"CLOSE","agg":"AVG"})
        for nm, col in [("open","OPEN"),("high","HIGH"),("low","LOW"),("close","CLOSE")]:
            if col in cols: measures.append({"name":nm,"column":col,"agg":None})
        date_keys = [{"column":"ENTRY_DATETIME","supports":["day","month","year"]}] if "ENTRY_DATETIME" in cols else []
        dims = []
        if "SYMBOL_ID" in cols:   dims.append({"name":"symbol_id","column":"SYMBOL_ID"})
        if "EXCHANGE_ID" in cols: dims.append({"name":"exchange_id","column":"EXCHANGE_ID"})
        return {
            "id":"SI","fqn":fqn,"grain":"symbol_timestamp",
            "date_keys":date_keys,"keys":[{"column":"SYMBOL_ID"},{"column":"EXCHANGE_ID"}],
            "measures":measures,"dimensions":dims,
            "capabilities":{"supports_intraday_bucket": False}
        }
    if fact_id == "BM":
        measures = []
        if "BID_PRICE" in cols and "OFFER_PRICE" in cols:
            measures.append({"name":"bid_price","column":"BID_PRICE","agg":"AVG"})
            measures.append({"name":"offer_price","column":"OFFER_PRICE","agg":"AVG"})
            measures.append({"name":"spread","expr":"OFFER_PRICE - BID_PRICE","agg":"AVG"})
            measures.append({"name":"mid","expr":"(BID_PRICE + OFFER_PRICE)/2","agg":"AVG"})
        if "BID_VOLUME" in cols:   measures.append({"name":"bid_volume","column":"BID_VOLUME","agg":"SUM"})
        if "OFFER_VOLUME" in cols: measures.append({"name":"offer_volume","column":"OFFER_VOLUME","agg":"SUM"})
        date_keys = [{"column":"ENTRY_DATETIME","supports":["day","month","year"]}] if "ENTRY_DATETIME" in cols else []
        dims = []
        if "SYMBOL_ID" in cols:   dims.append({"name":"symbol_id","column":"SYMBOL_ID"})
        if "EXCHANGE_ID" in cols: dims.append({"name":"exchange_id","column":"EXCHANGE_ID"})
        return {
            "id":"BM","fqn":fqn,"grain":"symbol_timestamp",
            "date_keys":date_keys,"keys":[{"column":"SYMBOL_ID"},{"column":"EXCHANGE_ID"}],
            "measures":measures,"dimensions":dims,
            "capabilities":{"supports_intraday_bucket": False}
        }
    raise ValueError("unknown fact id")

def build_stats_catalog(src_json: Path) -> Dict[str, Any]:
    entries = json.loads(src_json.read_text(encoding="utf-8"))
    sdi = si = bm = None
    symbols = exchanges = None

    for e in entries:
        t = (e.get("table_name") or "").upper()
        if _match(t, PAT_SDI): sdi = _build_fact(e, "SDI")
        elif _match(t, PAT_SI): si = _build_fact(e, "SI")
        elif _match(t, PAT_BM): bm = _build_fact(e, "BM")
        elif t == "SYMBOLS":    symbols = {"id":"SYMBOLS","fqn": f"{e.get('owner')}.{e.get('table_name')}",
                                           "keys":[{"column":"SYMBOL_ID"}],
                                           "labels":[{"name":"symbol","column":"SYMBOL"}]}
        elif t == "EXCHANGES":  exchanges = {"id":"EXCHANGES","fqn": f"{e.get('owner')}.{e.get('table_name')}",
                                             "keys":[{"column":"EXCHANGE_ID"}],
                                             "labels":[{"name":"exchange","column":"EXCHANGE_NAME"}]}

    facts = [x for x in [sdi, si, bm] if x]
    lookups = [x for x in [symbols, exchanges] if x]

    join_rules = []
    for f in facts:
        fid = f["id"]
        if symbols:  join_rules.append({"from_fact":fid,"using":"SYMBOLS","on":f"{fid}.SYMBOL_ID = SYMBOLS.SYMBOL_ID"})
        if exchanges:join_rules.append({"from_fact":fid,"using":"EXCHANGES","on":f"{fid}.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID"})

    out = {
        "version":"stats-catalog-v1",
        "facts": facts,
        "lookups": lookups,
        "join_rules": join_rules,
        "notes": {
            "indexes": "out_of_scope_v1",
            "sector": "awaiting_symbol_sector_mapping",
            "safety": "no intraday bucketing in v1; aggregate to day/month/year only"
        }
    }
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True, help="path to ats_schema_YYYY-MM-DD.json")
    ap.add_argument("--out", required=True, help="path to write stats_catalog.json")
    args = ap.parse_args()

    src = Path(args.src)
    outp = Path(args.out)
    cat = build_stats_catalog(src)
    outp.write_text(json.dumps(cat, indent=2), encoding="utf-8")
    print(f"wrote {outp}")

if __name__ == "__main__":
    from pathlib import Path
    main()
