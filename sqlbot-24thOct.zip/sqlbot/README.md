# 🧠 ATS SQL Assistant — Oracle Natural Language → SQL Pipeline

End-to-end intelligent SQL generation system for **ATS (BODIVA)** datasets.  
It converts natural-language questions into **validated Oracle SQL**, executes them safely, and returns tabular + report outputs.

---

## 🚀 Overview

The system unifies **LLM-driven SQL generation**, **schema awareness**, and **runtime safety**.  
It supports multiple model back-ends (Gemini, Llama, GPT-OSS) and automatically routes requests for best reliability.

Key domains covered:
- **Market Data** → `SYMBOL_DAILY_INDICATORS`, `SYMBOL_INDICATORS`, `BEST_MKT`
- **Orders** → `ORDERS` + associated lookups
- **Trades** → `TRADES`, `CANCELLED_TRADES`, `NEGOTIATED_TRADES` + lookups
- **Shared lookups** → `SYMBOLS`, `EXCHANGES`, `SUBSCRIBED_BROKERS`, `EDS_CLIENTS`, `USERS`, etc.

---

## 🧱 Project Structure

```

app/
│
├── ui/
│   └── chatbot.py           ← Streamlit UI entrypoint (user interface)
│
├── clients/                 ← LLM adapters
│   ├── gemini_client.py
│   ├── gptoss_client.py
│   └── llama_client_v2.py   ← JSON-schema aware model path
│
├── guards/                  ← Safety, validation & label guards
│   ├── labels.py
│   ├── safety.py
│   └── schema_validate.py
│
├── tools/
│   ├── run_order_fewshots.py
│   └── run_trades_fewshots.py
│
├── _smoke/
│   ├── inspect_orders.py
│   └── inspect_trades_semantics.py  ← Table sanity / join inspection
│
├── prompts/                 ← Prompt assets loaded by the models
│   ├── system_oracle.txt
│   ├── schema_card.txt
│   ├── schema_card.json
│   ├── fewshots.sql.md
│   └── glossary.md
│
├── services/
│   ├── prompting.py         ← Load & assemble prompts
│   ├── execution.py         ← SQL execution + EXPLAIN plan gate
│   ├── router.py            ← Route to appropriate model
│   ├── pdf_utils.py         ← PDF / HTML report export
│   └── model_strategy.py    ← Strategy enum
│
├── utils/
│   └── plan.py              ← Parse DBMS_XPLAN output (row estimates)
│
├── build_schema_card.py     ← Builds text schema card
└── build_schema_card_json.py← Builds JSON version for Llama

````

---

## 🧩 System Flow

### 1️⃣ Data understanding
- Run `_smoke/inspect_*` scripts to **analyze and document** new tables and relationships.
- Example: `python -m app._smoke.inspect_trades_semantics`

### 2️⃣ Few-shot crafting
- Use `app/tools/run_*_fewshots.py` to execute and validate representative queries.
- Once verified, update `prompts/fewshots.sql.md`.

### 3️⃣ Schema representation
- Build or update:
  - `schema_card.txt` via `build_schema_card.py`
  - `schema_card.json` via `build_schema_card_json.py` (for Llama)

### 4️⃣ Glossary alignment
- Update `glossary.md` with any new business terms or metrics.

### 5️⃣ Guardrails & labels
- Verify / extend:
  - `guards/labels.py` (if new entity categories appear)
  - `guards/safety.py` (allow-list and regex fallback)
  - `guards/schema_validate.py` (column validation)
- Typically minimal changes once table names are whitelisted.

### 6️⃣ Model prompts
- `prompting.py` loads `system_oracle.txt`, `schema_card.txt`, `fewshots.sql.md`, `glossary.md`.
- For Llama, the JSON schema is also read.

### 7️⃣ Model clients
- `llama_client_v2.py` → JSON schema aware SQL generator
- `gemini_client.py`   → Text-only generator
- `gptoss_client.py`   → Fallback using Ollama GPT-OSS

### 8️⃣ Routing
- `router.py` decides which model to call depending on environment and user selection (AUTO / GEMINI / LLAMA / GPT-OSS).

### 9️⃣ Safety & execution
- `execution.py` enforces:
  - SQL read-only guard
  - Table allow-list
  - Row-limit enforcement
  - Optional `EXPLAIN PLAN` gate
- Only safe SQLs reach Oracle.

### 🔟 UI & reporting
- `chatbot.py` integrates everything:
  - Prompting → Model → Validation → Execution → Output
  - Interactive Streamlit app
  - CSV, PDF, and HTML report exports

---
### Flow diagram
```
User (NL)
  ↓
app/ui/chatbot.py  ← Streamlit UI: collects question + strategy + options
  ↓ loads
app/services/prompting.py  ← system prompt + schema card + fewshots + glossary
  ↓ calls
app/services/models/router.py  ← choose engine (AUTO/GEMINI/LLAMA/GPT-OSS)
   ├─ app/services/models/gemini_client.py       (text-only)
   ├─ app/services/models/llama_client_v2.py     (JSON schema aware)
   └─ app/services/models/gptoss_client.py       (Ollama fallback)
        ↓ returns candidate SQL
  ↓ validate & harden
app/guards/labels.py            ← label-join hints / repair triggers
app/guards/schema_validate.py    ← columns exist & belong to tables
app/guards/safety.py             ← read-only, allowlist, row limit, etc.
  ↓ if safe, then
app/services/execution.py        ← optional EXPLAIN PLan gate → execute preview
  ↓
Result (table) + exports via app/ui/pdf_utils.py
```


## ⚙️ Environment Setup

1. **Clone repo & install**
```bash
   conda create -n doc-rag python=3.10
   conda activate doc-rag
   pip install -r requirements.txt
```

2. **Configure `.env`**

   ```bash
   ORACLE_DSN=hostname:1521/service
   ORACLE_USER=ATS_READ
   ORACLE_PASSWORD=secret
   ORACLE_OWNER=ATS

   # Safe table scope (must include all used tables)
   SAFETY_DEBUG=1
   SAFETY_ALLOWED_TABLES=SYMBOL_DAILY_INDICATORS SYMBOL_INDICATORS BEST_MKT SYMBOLS EXCHANGES ORDERS FLAGS ORDER_TYPES ORDER_STATES SUBSCRIBED_BROKERS EDS_CLIENTS USERS SYMBOL_MARKETS TRADES CANCELLED_TRADES NEGOTIATED_TRADES TRADE_STATES SETTLEMENT_TYPES

   EXPLAIN_GATE_ENABLED=0
   RESULT_ROW_LIMIT=200
   MAX_ESTIMATED_ROWS=5000000
   ```

3. **Run Streamlit UI**

   ```bash
   streamlit run app/ui/chatbot.py
   ```

---

## 🧠 Example Queries (Trades Domain)

| Example                           | Description                                                                                        |
| --------------------------------- | -------------------------------------------------------------------------------------------------- |
| Daily traded notional by exchange | Aggregates `TRADES.PRICE*VOLUME` by `ENTRY_DATETIME` & `EXCHANGE`.                                 |
| Top clients by traded volume      | Sums buyer/seller volume for each client this month.                                               |
| Cancelled trades by exchange      | Counts `CANCELLED_TRADES` grouped by `EXCHANGE`.                                                   |
| Negotiated executed notional      | Maps `NEGOTIATED_TRADES` to executed `TRADES` by order numbers.                                    |
| Bond yields by settlement type    | For `SYMBOL_TYPE='Bond'`, computes `AVG(YIELD)` and `SUM(SETTLEMENT_AMOUNT)` by `SETTLEMENT_TYPE`. |

---

## 🧩 Adding New Tables or Columns (Future Updates)

When schema evolves, follow this exact checklist:

| Step                          | Description                                                                                                      |
| ----------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| **1. Inspect**                | Create a new `_smoke/inspect_*.py` script to profile the new table(s): row counts, soft joins, label decodes.    |
| **2. Understand semantics**   | Determine linkages to existing entities (e.g., joins to SYMBOLS, EXCHANGES, CLIENTS).                            |
| **3. Update allowlist**       | Add new table names to `.env → SAFETY_ALLOWED_TABLES` to prevent blocking.                                       |
| **4. Update schema card**     | Extend both `schema_card.txt` and `schema_card.json` using `build_schema_card.py` and its JSON variant.          |
| **5. Add few-shots**          | Create representative queries using `tools/run_*_fewshots.py`, validate outputs, then copy to `fewshots.sql.md`. |
| **6. Extend glossary**        | Add new terms or metrics in `prompts/glossary.md`.                                                               |
| **7. Verify guards**          | Usually no change needed, but confirm `safety.py` doesn’t misparse any new syntax (e.g., nested CTEs).           |
| **8. Test end-to-end**        | Run the Streamlit app, validate SQL generation + execution for new entities.                                     |
| **9. Commit updated prompts** | Commit updated schema, fewshots, glossary, and push.                                                             |

If only **columns** are added to existing tables:

* Update schema cards (text + JSON).
* No code changes required in guards or clients.

---

## 🔒 Guardrails Summary

| Guard               | Purpose                                                                  | Key Files                   |
| ------------------- | ------------------------------------------------------------------------ | --------------------------- |
| **Safety**          | Blocks non-read SQLs, enforces row limits, restricts to allowed tables.  | `guards/safety.py`          |
| **Schema Validate** | Ensures columns exist and belong to known tables.                        | `guards/schema_validate.py` |
| **Labels**          | Detects missing label joins and triggers repair prompts.                 | `guards/labels.py`          |
| **Execution**       | Adds `FETCH FIRST n ROWS`, validates plan row estimate before execution. | `services/execution.py`     |

---

## 🧩 Model Routing Summary

| Strategy  | Engine                       | Use Case                   |
| --------- | ---------------------------- | -------------------------- |
| `AUTO`    | Gemini → Llama fallback      | Default balanced mode      |
| `GEMINI`  | Google Gemini Pro            | Fast text-based generation |
| `LLAMA`   | Ollama Llama 3 + JSON schema | Schema-strict generation   |
| `GPT-OSS` | Local GPT model via Ollama   | Offline fallback / testing |

---

## 🧰 Debugging Checklist

| Symptom                                                           | Likely Cause                                              | Fix                                                                            |
| ----------------------------------------------------------------- | --------------------------------------------------------- | ------------------------------------------------------------------------------ |
| `Blocked: query references tables outside the allowed ATS scope.` | New tables not whitelisted or CTE fallback missed a name. | Add to `SAFETY_ALLOWED_TABLES` and ensure updated `safety.py` (multi-CTE fix). |
| Query works in TOAD but blocked here                              | Same as above (client-side safety).                       | Check env + safety debug logs.                                                 |
| Validation errors about missing columns                           | JSON schema card not rebuilt.                             | Re-run `build_schema_card_json.py`.                                            |
| Empty response from Llama                                         | Ollama context too small.                                 | Increase `OLLAMA_NUM_CTX=8192`.                                                |
| Explain Plan fails                                                | `PLAN_TABLE` privilege issue or semicolon in SQL.         | `EXPLAIN_GATE_ENABLED=0` (disable gate).                                       |

---

## 🧾 Licensing & Notes

* Internal use under Infotech Group license.
* Requires valid Oracle DB connectivity and read privileges for `ATS` schema.
* Tested with `python-oracledb` 2.x (thin mode).

---

## 📅 Maintainer Notes

If new schema changes are introduced (e.g., `TRADE_MODIFICATION_HIST`, `ORDER_AUDIT`):

* Extend schema cards & glossary only.
* Guards and pipeline will continue to work because table detection and join logic are declarative.
* Always test with `_smoke/inspect_*.py` before finalizing few-shots.

---

**Author:** *Infotech RAG / ATS SQL Assistant Team*
**Version:** v2.0 — Updated with Trades, Cancelled Trades, and Negotiated Trades Integration (October 2025)

```