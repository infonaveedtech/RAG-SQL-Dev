# app/guards/schema_validate.py
from __future__ import annotations
from typing import Dict, Set, Tuple, Iterable, Optional
import os
import difflib
import sqlglot
from sqlglot import exp

# Toggle verbose debug logs with SCHEMA_VALIDATE_DEBUG=1
DEBUG = os.getenv("SCHEMA_VALIDATE_DEBUG", "0") == "1"
def _dbg(*args):
    if DEBUG:
        print("[SCHEMA_VALIDATE]", *args)

# =============================================================================
# Schema helpers
# =============================================================================

def _flatten_schema(schema_json: Dict) -> Tuple[Dict[str, Set[str]], Set[str]]:
    """
    Accept both schema shapes:

    Legacy (v1):
      {
        "ATS.ORDERS": {"columns": {"ORDER_NO": "...", "CLIENT_ID": "...", ...}},
        "ATS.SYMBOLS": {"columns": {"SYMBOL_ID": "...", "SYMBOL": "..."}}
      }

    Rich (v3):
      {
        "version": "...",
        "owner": "ATS",
        "tables": [
          {
            "owner": "ATS",
            "name": "ORDERS",
            "comment": "...",
            "columns": [
              {"name": "ORDER_NO", "data_type": "...", "nullable": false, ...},
              ...
            ]
          },
          ...
        ],
        ...
      }

    Returns:
      tables: {"TABLE": {"COL1","COL2",...}, ...}
      allowed_tables: {"TABLE1","TABLE2",...}
    """
    tables: Dict[str, Set[str]] = {}
    allowed: Set[str] = set()

    if not schema_json:
        return tables, allowed

    # Rich format?
    if isinstance(schema_json, dict) and "tables" in schema_json and isinstance(schema_json["tables"], list):
        for t in schema_json["tables"]:
            try:
                name = str(t.get("name", "")).strip().upper()
                if not name:
                    continue
                allowed.add(name)
                cols: Set[str] = set()
                for c in (t.get("columns") or []):
                    cname = str(c.get("name", "")).strip().upper()
                    if cname:
                        cols.add(cname)
                tables[name] = cols
            except Exception:  # be defensive; skip bad items
                continue
        return tables, allowed

    # Legacy format (mapping owner.table -> { columns: {...} })
    if isinstance(schema_json, dict):
        for full, meta in schema_json.items():
            short = str(full).split(".")[-1].upper()
            cols_dict = (meta or {}).get("columns") or {}
            cols = {str(k).upper() for k in cols_dict.keys()}
            tables[short] = cols
            allowed.add(short)
        return tables, allowed

    # Unknown shape -> empty
    return tables, allowed


def _cte_names(tree: exp.Expression) -> Set[str]:
    """Return upper-cased CTE names (aliases defined in WITH)."""
    names: Set[str] = set()
    # sqlglot versions differ: exp.With/exp.CTE; iterate both paths
    for with_ in tree.find_all(exp.With):
        for cte in with_.expressions or []:
            alias = getattr(cte, "alias_or_name", None)
            if alias:
                names.add(str(alias).upper())
                continue
            alias_expr = getattr(cte, "alias", None)
            if isinstance(alias_expr, exp.Expression):
                this = getattr(alias_expr, "this", None)
                names.add(str(this).upper() if this is not None else str(alias_expr).upper())
            elif alias_expr:
                names.add(str(alias_expr).upper())
    # Fallback: older node type
    for cte in tree.find_all(exp.CTE):
        alias = getattr(cte, "alias_or_name", None)
        if alias:
            names.add(str(alias).upper())
            continue
        alias_expr = getattr(cte, "alias", None)
        if alias_expr:
            names.add(str(alias_expr).upper())
    return names


def _table_alias_and_name(t: exp.Table) -> Tuple[str, str]:
    """
    Robustly extract (alias, base_name) from a sqlglot Table node.
    - alias → preferred alias, else table name
    - base_name → bare table name without owner/schema
    """
    # alias handling across sqlglot versions
    alias_expr = getattr(t, "alias", None)
    if isinstance(alias_expr, exp.Expression):
        a = getattr(alias_expr, "this", None)
        alias = str(a).upper() if isinstance(a, exp.Expression) else str(alias_expr or "").upper()
    else:
        alias = str(alias_expr or "").upper()

    # base table (strip owner if present)
    # try .name first; fall back to t.this.name
    name = (getattr(t, "name", None) or (getattr(t, "this", None).name if getattr(t, "this", None) else "") or "")
    base = name.split(".")[-1].upper() if name else ""
    if not alias:
        alias = base
    return alias, base


def _iter_real_tables(tree: exp.Expression) -> Iterable[Tuple[str, str]]:
    """
    Yield (alias, base_table) for real tables, excluding:
      - CTE names (used later in the query)
      - Oracle DUAL
    """
    ctes = _cte_names(tree)
    for t in tree.find_all(exp.Table):
        # name may be owner-qualified
        nm = (getattr(t, "name", None) or (getattr(t, "this", None).name if getattr(t, "this", None) else "") or "").upper()
        if not nm:
            continue
        if nm.endswith(".DUAL") or nm == "DUAL":
            continue
        alias, base = _table_alias_and_name(t)
        if not base or base in ctes:
            continue
        yield alias, base


def _suggest(name: str, pool: Iterable[str], n: int = 3) -> str:
    cands = difflib.get_close_matches(name.upper(), list(pool), n=n)
    return f" Did you mean: {', '.join(cands)}?" if cands else ""


# =============================================================================
# Public API (backward compatible)
# =============================================================================

import re
def _strip_comments(sql: str) -> str:
    return re.sub(r"--.*?$|/\*.*?\*/", "", sql or "", flags=re.M | re.S)

def validate_columns(sql: str, schema_json: Dict) -> None:
    """
    Validate that all referenced columns exist in the provided schema_json.
    - Supports legacy { "ATS.TABLE": {"columns": {...}} } and rich { "tables": [...] } formats
    - CTE-aware
    - owner-qualified tolerant
    - ignores DUAL
    - raises ValueError with helpful messages on mismatch

    Usage (unchanged):
        validate_columns(sql, SCHEMA_JSON)
    """
    if not schema_json:
        # Nothing to validate against
        return

    try:
        s = _strip_comments(sql)
        tree = sqlglot.parse_one(sql, read="oracle")
    except Exception as e:
        raise ValueError(f"SQL parse error: {e}")

    tables, allowed_tables = _flatten_schema(schema_json)

    # Map alias -> base table for *real* tables in the query
    alias_to_table: Dict[str, str] = {}
    for alias, base in _iter_real_tables(tree):
        alias_to_table[alias] = base

    _dbg("ALIASES:", alias_to_table)
    _dbg("ALLOWED TABLES:", sorted(allowed_tables))

    # Soft presence check (debug only) for tables missing from schema
    unknown_tables = [t for t in set(alias_to_table.values()) if t not in allowed_tables]
    if unknown_tables:
        _dbg("WARNING: tables not present in schema_json:", unknown_tables)

    # Validate every Column occurrence (covers SELECT/WHERE/GROUP BY/ORDER BY)
    for col in tree.find_all(exp.Column):
        tbl_alias = (col.table or "").upper()
        col_name = col.name.upper()

        # Star selections (t.* / *) aren't represented as exp.Column; skip.
        if not col_name:
            continue

        if not tbl_alias:
            # Unqualified column: allow if the column exists in ANY referenced base table
            ok = any(
                col_name in tables.get(base, set())
                for base in alias_to_table.values()
            )
            if not ok:
                pool = set().union(*(tables.get(base, set()) for base in alias_to_table.values()))
                hint = _suggest(col_name, pool)
                raise ValueError(f"Unknown column: {col_name}.{hint}")
            continue

        # Qualified column: resolve alias → base table
        base = alias_to_table.get(tbl_alias)
        if not base:
            hint = _suggest(tbl_alias, alias_to_table.keys())
            raise ValueError(f"Unknown table alias: {tbl_alias}.{hint}")

        # If the base table isn't known to the schema_json, we can't validate columns reliably.
        if base not in tables:
            _dbg(f"SKIP column check for {tbl_alias}.{col_name} (table {base} not in schema_json)")
            continue

        if col_name not in tables[base]:
            hint = _suggest(col_name, tables[base])
            raise ValueError(f"Unknown column: {tbl_alias}.{col_name} on table {base}.{hint}")

    _dbg("VALIDATION: OK")
