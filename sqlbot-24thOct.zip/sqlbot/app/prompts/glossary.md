# Glossary (ATS v1)

## Market data
- **turnover (daily)** — SUM(TURNOVER_VALUE) from ATS.SYMBOL_DAILY_INDICATORS.
- **trades_count (daily)** — SUM(TRADES_COUNT) from ATS.SYMBOL_DAILY_INDICATORS.
- **average price (daily)** — AVG(CLOSE_PRICE) from ATS.SYMBOL_DAILY_INDICATORS.
- **volume (intraday)** — SUM(VOLUME) from ATS.SYMBOL_INDICATORS.
- **turnover (intraday)** — SUM(VALUE) from ATS.SYMBOL_INDICATORS.
- **spread** — (OFFER_PRICE - BID_PRICE) from ATS.BEST_MKT.
- **mid** — (BID_PRICE + OFFER_PRICE) / 2 from ATS.BEST_MKT.
- **symbol label** — ATS.SYMBOLS.SYMBOL via SYMBOL_ID.
- **exchange label** — ATS.EXCHANGES.EXCHANGE_NAME via EXCHANGE_ID.

## Orders domain
- **orders (count)** — COUNT(*) from ATS.ORDERS.
- **order volume** — SUM(ORDERS.VOLUME).
- **notional (computed)** — SUM(ORDERS.VOLUME * ORDERS.PRICE); default metric for order amounts across instruments.
- **value (stored)** — SUM(ORDERS.VALUE); may include multipliers or accrued adjustments (especially for bonds).
- **average order price** — AVG(ORDERS.PRICE).

### Order classifications & lookups
- **side** — ORDERS.SIDE where 'B'=Buy, 'S'=Sell. Treat ORDERS.IS_SHORT as stringy boolean ('0'/'1').
- **flag (execution constraint)** — via ORDERS.FLAG_ID → ATS.FLAGS.FLAG_CODE (examples: IOC, FOK, GTC, GTD, SL, MIT, MF). Use FLAGS.DESC_ for descriptions.
- **order type** — via ORDERS.ORDER_TYPE → ATS.ORDER_TYPES.CODE (examples: Market, Limit, etc.).
- **order state** — via ORDERS.STATE → ATS.ORDER_STATES.STATE_CODE (examples: Submit, Received, Change, PartialFill, Fill, Cancel, Reject, Purge).
- **broker label** — ORDERS.BROKER_ID → ATS.SUBSCRIBED_BROKERS.BROKER_NAME.
- **client label** — ORDERS.CLIENT_ID → ATS.EDS_CLIENTS.NAME.
- **user/trader label** — ORDERS.USER_ID / ORDERS.TRADER_ID → ATS.USERS.USER_NAME (or COMPLETE_NAME).

### Time semantics for orders
- **default order date key** — ORDERS.ENTRY_DATETIME (order creation time).
- **state change timestamp** — ORDERS.STATE_TIME (use when the question is about lifecycle transitions).
- **TIF (time-in-force)** — ORDERS.TIF (DATE). When FLAG_CODE indicates GTD/GTC/IOC/FOK etc., treat TIF as expiry date (for GTD) or ignore for immediate policies (IOC/FOK).

### Fixed-income specifics
- **yield** — ORDERS.YIELD (mainly for bonds), average with AVG(YIELD).
- **accrued profit** — ORDERS.ACCRUED_PROFIT (accrued interest/amount component), sum with SUM(ACCRUED_PROFIT).
- Prefer filtering bond-only analytics using instrument metadata from ATS.SYMBOLS (e.g., CFI or SYMBOL_TYPE_ID) when required.



## Trades domain

### Core trade metrics

* **trades (count)** — `COUNT(*)` from `ATS.TRADES`.
* **trade notional** — `SUM(TRADES.VALUE)` or `SUM(TRADES.PRICE * TRADES.VOLUME)`.
* **settlement amount** — `TRADES.SETTLEMENT_AMOUNT`; the post-accrued amount due after pricing.
* **dirty price** — `TRADES.DIRTY_PRICE`; the price inclusive of accrued interest (bonds only).
* **repurchase price** — `TRADES.REPURCHASE_PRICE`; relevant for repo/leg trades.
* **remaining volume** — buyer/seller remaining quantity after fill (ideally 0 post-trade).
* **trade type** — via `TRADES.TRADE_TYPE` (numeric; local to system).
* **state** — via `TRADES.STATE_ID → ATS.TRADE_STATES.STATE_LABEL` (e.g. Normal, Repriced).

### Participants & lookups

* **buyer/seller client** — `TRADES.BUYER_CLIENT_ID`, `TRADES.SELLER_CLIENT_ID → ATS.EDS_CLIENTS.NAME`.
* **buyer/seller broker** — `TRADES.BUYER_BROKER_ID`, `TRADES.SELLER_BROKER_ID → ATS.SUBSCRIBED_BROKERS.BROKER_NAME`.
* **buyer/seller user** — `TRADES.BUYER_USER_ID`, `TRADES.SELLER_USER_ID → ATS.USERS.COMPLETE_NAME`.
* **symbol lookup** — `TRADES.SYMBOL_ID → ATS.SYMBOLS.SYMBOL`.
* **exchange lookup** — `TRADES.EXCHANGE_ID → ATS.EXCHANGES.EXCHANGE_CODE`.
* **settlement type** — via `TRADES.SETTLEMENT_TYPE_ID → ATS.SETTLEMENT_TYPES.SETTLEMENT_TYPE_NAME`.

### Time semantics (Trades)

* **trade timestamp** — `TRADES.ENTRY_DATETIME`.
* **contract duration** — `TRADES.INITIAL_DATE` → `TRADES.TERMINATION_DATE`.
* **leg** — `TRADES.LEG`; identifies legs in repo or structured deals.

### Bond-specific trade fields

* **yield** — `TRADES.YIELD`; annualized bond yield (numeric).
* **accrued profit** — `TRADES.ACCRUED_PROFIT`; accrued interest component.
* **dirty price** — as above; `PRICE + accrued_interest`.

### Typical joins (Trades)

| Context             | Join logic                                                                                 |
| ------------------- | ------------------------------------------------------------------------------------------ |
| **Client**          | `BUYER_CLIENT_ID/SELLER_CLIENT_ID = EDS_CLIENTS.CLIENT_ID`                                 |
| **Broker**          | `BUYER_BROKER_ID/SELLER_BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID`                          |
| **User**            | `BUYER_USER_ID/SELLER_USER_ID = USERS.USER_ID`                                             |
| **Symbol/Market**   | `(SYMBOL_ID, MARKET_ID, EXCHANGE_ID) = SYMBOL_MARKETS.(SYMBOL_ID, MARKET_ID, EXCHANGE_ID)` |
| **Exchange**        | `EXCHANGE_ID = EXCHANGES.EXCHANGE_ID`                                                      |
| **Settlement Type** | `SETTLEMENT_TYPE_ID = SETTLEMENT_TYPES.SETTLEMENT_TYPE_ID`                                 |

---

## Cancelled trades

* **cancelled trades** — records from `ATS.CANCELLED_TRADES`; similar schema to `TRADES` but with cancellation info.
* **cancellation timestamp** — `CANCELLED_TRADES.CANCELLATION_DATETIME`.
* **trade timestamp** — `CANCELLED_TRADES.TRADE_DATETIME`.
* **joinable key** — typically by `(BUYER_ORDER_NO, SELLER_ORDER_NO, EXCHANGE_ID)` to `TRADES`.
* **use case** — helps identify trades reversed after execution.

---

## Negotiated trades

* **negotiated trades** — from `ATS.NEGOTIATED_TRADES`.
* **core linkage** — `ORDER_NO` or `COUNTER_ORDER_NO` join to `ORDERS.ORDER_NO`.
* **negotiated state** — `NEGOTIATED_STATE` and `NEGOTIATED_STATUS` fields indicate lifecycle state.
* **participants** — `CLIENT_ID`, `COUNTER_CLIENT_ID`, `BROKER_ID`, `COUNTER_BROKER_ID`.
* **pricing semantics** — `PRICE`, `YIELD`, `ACCRUED_PROFIT`, and `VALUE` same as in trades.
* **used for** — pre-trade bilateral negotiation records before final trade settlement.

---

## Instrument & market context

* **instrument type** — `SYMBOLS.SYMBOL_TYPE_ID → SYMBOL_TYPES.SYMBOL_TYPE_NAME` (e.g. Bond, Equities).
* **symbol to exchange/market** — via `SYMBOL_MARKETS`.
* **currency** — `SYMBOLS.CURRENCY_ID → CURRENCY.CURRENCY_CODE`.

## Joins (labels & market context)
- **instrument** — ORDERS.SYMBOL_ID = SYMBOLS.SYMBOL_ID
- **exchange** — ORDERS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID
- **market triple (canonical)** — (ORDERS.SYMBOL_ID, EXCHANGE_ID, MARKET_ID) = SYMBOL_MARKETS.(SYMBOL_ID, EXCHANGE_ID, MARKET_ID)
- **flags** — ORDERS.FLAG_ID = FLAGS.FLAG_ID
- **order types** — ORDERS.ORDER_TYPE = ORDER_TYPES.ID
- **states** — ORDERS.STATE = ORDER_STATES.STATE_ID
- **brokers** — ORDERS.BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID
- **clients** — ORDERS.CLIENT_ID = EDS_CLIENTS.CLIENT_ID
- **users/traders** — ORDERS.USER_ID = USERS.USER_ID, ORDERS.TRADER_ID = USERS.USER_ID

## Time grains & limits
- **time grains allowed (v2)** — day, month, year (no intraday bucketing by default; keep result sets bounded with FETCH FIRST <N> ROWS ONLY).

## Date keys by source
- **daily indicators** — ATS.SYMBOL_DAILY_INDICATORS.STATS_DATE
- **intraday indicators** — ATS.SYMBOL_INDICATORS.ENTRY_DATETIME
- **best market** — ATS.BEST_MKT.ENTRY_DATETIME
- **orders** — ATS.ORDERS.ENTRY_DATETIME (default) and ATS.ORDERS.STATE_TIME (state changes)
