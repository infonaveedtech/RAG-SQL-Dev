from __future__ import annotations
import os
from typing import List, Tuple, Optional

import oracledb
from dotenv import load_dotenv
# at top of file
import re

_SEMI_TRAIL_RE = re.compile(r";\s*$")

def _strip_trailing_semicolon(sql: str) -> str:
    # remove a single trailing semicolon (and trailing whitespace)
    return _SEMI_TRAIL_RE.sub("", (sql or "").strip())


from app.guards.safety import (
    is_readonly_select,
    ensure_row_limit,
    tables_whitelisted,
    OWNER_ALIASES,
    ALLOWED_BARE,
)
from app.utils.plan import parse_rows_estimate

load_dotenv()


def _env(name: str, default: str | None = None, required: bool = False) -> str:
    v = os.getenv(name, default)
    if required and not v:
        raise RuntimeError(f"Missing env: {name}")
    return v or ""


def _connect() -> oracledb.Connection:
    dsn = _env("ORACLE_DSN", required=True)
    user = _env("ORACLE_USER", required=True)
    pwd = _env("ORACLE_PASSWORD", required=True)
    owner = _env("ORACLE_OWNER", required=True)

    conn = oracledb.connect(user=user, password=pwd, dsn=dsn)

    # Client-side call timeout (ms) applied per round-trip
    call_timeout_ms = int(_env("STATEMENT_TIMEOUT_MS", "8000"))
    try:
        conn.callTimeout = call_timeout_ms
    except Exception:
        pass

    with conn.cursor() as cur:
        # pin schema
        cur.execute(f"alter session set current_schema = {owner}")
        # keep sampling conservative to avoid surprises
        try:
            cur.execute("alter session set optimizer_dynamic_sampling = 0")
        except Exception:
            pass
        # optional: consistent date rendering for preview
        try:
            cur.execute("alter session set nls_date_format = 'YYYY-MM-DD HH24:MI:SS'")
        except Exception:
            pass

    return conn


def explain_plan(sql: str) -> Tuple[str, Optional[int]]:
    """
    Run EXPLAIN PLAN FOR <sql>, return (plan_text, rows_estimate or None).
    If DBMS_XPLAN/PLAN_TABLE are not available, return ("", None) gracefully.
    """
    # allow disabling by env
    if os.getenv("EXPLAIN_GATE_ENABLED", "1") != "1":
        return "", None
    
    plan_sql = _strip_trailing_semicolon(sql)

    conn = _connect()
    try:
        cur = conn.cursor()
        # Best effort to keep the plan table readable
        try:
            cur.execute("DELETE FROM PLAN_TABLE")
            conn.commit()
        except Exception:
            pass

        try:
            cur.execute(f"EXPLAIN PLAN FOR {plan_sql}")
            cur.execute("SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY())")
            lines = [row[0] for row in cur.fetchall()]
            plan_text = "\n".join(lines)
            est = parse_rows_estimate(plan_text)
            return plan_text, est
        except Exception:
            # No plan available (privilege/plan table issues)
            return "", None
    finally:
        conn.close()


def execute_preview(sql: str, preview_rows: int = 200) -> Tuple[List[str], List[tuple]]:
    """
    Execute read-only SQL and fetch up to preview_rows (driver-level).
    Returns (columns, rows).
    """
    run_sql = _strip_trailing_semicolon(sql)
    conn = _connect()
    try:
        cur = conn.cursor()
        # cur.execute(sql)
        cur.execute(run_sql)
        cols = [d[0] for d in (cur.description or [])]
        rows = cur.fetchmany(preview_rows)
        return cols, rows
    finally:
        conn.close()


def safe_run_with_gate(
    sql: str,
    row_limit_default: int = 200,
    max_estimated_rows: int = 5_000_000,
) -> Tuple[str, str, Optional[int], List[str], List[tuple]]:
    """
    Guard → limit → EXPLAIN gate → execute.
    Returns (final_sql, plan_text, est_rows, columns, rows).
    """

    # 1) Core safety gates
    ok = tables_whitelisted(sql)
    if not ok:
        print("[DEBUG] ORACLE_OWNER_ALIASES:", sorted(OWNER_ALIASES))
        print("[DEBUG] ALLOWED_BARE:", sorted(ALLOWED_BARE))
        print("[DEBUG] SQL:", sql)

    if not is_readonly_select(sql):
        raise RuntimeError("Blocked: not a read-only SELECT/CTE.")

    if not ok:
        # keep wording identical to the one you saw before
        raise RuntimeError("Blocked: query references tables outside the allowed ATS scope.")

    # 2) Ensure row limit
    final_sql = ensure_row_limit(sql, row_limit_default)

    # 3) Explain gate (optional)
    plan_text, est = explain_plan(final_sql)
    if (
        est is not None
        and max_estimated_rows > 0
        and est > max_estimated_rows
    ):
        raise RuntimeError(
            f"Blocked: estimated rows {est:,} exceeds threshold {max_estimated_rows:,}.\n"
            f"Please narrow the date range or add filters."
        )

    # 4) Execute preview (bounded to row_limit_default at driver level)
    cols, rows = execute_preview(final_sql, preview_rows=row_limit_default)
    return final_sql, plan_text, est, cols, rows
