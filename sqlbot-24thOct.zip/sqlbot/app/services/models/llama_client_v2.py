# # app/clients/llama_client_v2.py
# import os, json, requests
# from typing import Optional, Dict, Tuple

# PROMPTS_DIR = os.path.join(os.path.dirname(__file__), "../../prompts")

# def _load_file(name: str) -> str:
#     path = os.path.join(PROMPTS_DIR, name)
#     if os.path.exists(path):
#         with open(path, "r", encoding="utf-8") as f:
#             return f.read().strip()
#     return ""

# # Keep caps (but trim to protect context if files get huge)
# FEWSHOTS_TEXT = _load_file("fewshots.sql.md")[:4000]
# GLOSSARY_TEXT = _load_file("glossary.md")[:2000]

# OLLAMA_GENERATE_URL = os.getenv("OLLAMA_GENERATE_URL", "http://localhost:11434/api/generate")
# OLLAMA_MODEL        = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
# LLAMA_TEMPERATURE   = float(os.getenv("LLAMA_TEMPERATURE", "0.0"))
# LLM_TIMEOUT         = int(os.getenv("LLM_TIMEOUT", "120"))

# # Row-limit & owner so rules can be concrete
# ROW_LIMIT = int(os.getenv("DEFAULT_ROW_LIMIT", "200"))
# OWNER     = os.getenv("ORACLE_OWNER", "ATS").upper()

# # Load structured JSON schema (hard fail if missing—this client is schema-driven)
# SCHEMA_PATH = os.path.join(PROMPTS_DIR, "schema_card_llama.json")
# with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
#     SCHEMA_JSON = json.load(f)

# def _structured_prompt(question: str, repair_hint: Optional[str] = None) -> Tuple[str, str]:
#     """
#     Build system + user prompts for a schema-aware Llama call that returns JSON {"sql": "..."}.
#     The system text now covers both market-data AND orders semantics.
#     """
#     system_text = f"""
# You are an expert Oracle SQL developer.
# Generate a single, valid, **read-only** Oracle SQL query for the {OWNER} schema.

# GLOBAL RULES
# 1) Use ONLY tables/columns present in the provided schema_json.
# 2) SELECT-only. Never use UPDATE/INSERT/DELETE/MERGE/DDL.
# 3) Use explicit ANSI JOINs with clear aliases (no implicit joins).
# 4) Use Oracle syntax: no LIMIT; use FETCH FIRST {ROW_LIMIT} ROWS ONLY.
# 5) Date grains via TRUNC(date_col, 'DD'|'MM'|'YYYY').
# 6) When using GROUP BY, every non-grouped numeric field MUST be aggregated (SUM/AVG/MIN/MAX/MEDIAN/PERCENTILE_CONT as appropriate).
# 7) Do not output raw *_ID fields unless explicitly asked. Prefer human labels via joins.

# MARKET-DATA HINTS (if SDI/SI/BM are used)
# - SYMBOL labels from {OWNER}.SYMBOLS (SYMBOL).
# - EXCHANGE labels from {OWNER}.EXCHANGES (EXCHANGE_NAME).
# - Typical date columns: STATS_DATE (SYMBOL_DAILY_INDICATORS), ENTRY_DATETIME (SYMBOL_INDICATORS/BEST_MKT).

# ORDERS HINTS (if ORDERS is used)
# - Default time column: ORDERS.ENTRY_DATETIME. Use this unless the user asks about lifecycle timing (then ORDERS.STATE_TIME).
# - Notional (default monetary measure): SUM(ORDERS.VOLUME * ORDERS.PRICE).
# - Stored value (explicit only): SUM(ORDERS.VALUE) (may include multipliers/accrued for bonds).
# - Side: ORDERS.SIDE ('B' buy, 'S' sell). Treat IS_SHORT as stringy boolean if needed.
# - Label joins (select labels instead of IDs):
#     JOIN {OWNER}.SYMBOLS s   ON s.SYMBOL_ID = o.SYMBOL_ID       -- s.SYMBOL
#     JOIN {OWNER}.EXCHANGES e ON e.EXCHANGE_ID = o.EXCHANGE_ID   -- e.EXCHANGE_NAME
#     JOIN {OWNER}.FLAGS f     ON f.FLAG_ID = o.FLAG_ID           -- f.FLAG_CODE
#     JOIN {OWNER}.ORDER_TYPES t ON t.ID = o.ORDER_TYPE           -- t.CODE
#     JOIN {OWNER}.ORDER_STATES st ON st.STATE_ID = o.STATE       -- st.STATE_CODE
#     JOIN {OWNER}.SUBSCRIBED_BROKERS b ON b.BROKER_ID = o.BROKER_ID   -- b.BROKER_NAME
#     JOIN {OWNER}.EDS_CLIENTS c ON c.CLIENT_ID = o.CLIENT_ID          -- c.NAME
#     JOIN {OWNER}.USERS u ON u.USER_ID = o.USER_ID                     -- u.USER_NAME (or COMPLETE_NAME)
#     -- Use SYMBOL_MARKETS (m) only if you truly need market-level attributes:
#     -- JOIN {OWNER}.SYMBOL_MARKETS m ON m.SYMBOL_ID=o.SYMBOL_ID AND m.EXCHANGE_ID=o.EXCHANGE_ID AND m.MARKET_ID=o.MARKET_ID

# OUTPUT
# - Return ONLY JSON of the form: {{"sql": "<the SQL query>"}}
# - The SQL must end with a semicolon.
# """.strip()

#     user_prompt = {
#         "task": "Convert the user question into valid Oracle SQL.",
#         "schema_json": SCHEMA_JSON,
#         "fewshots": FEWSHOTS_TEXT,
#         "glossary": GLOSSARY_TEXT,
#         "question": question,
#         "repair": repair_hint or "",
#         "output_format": "Return only JSON: {\"sql\": \"<the SQL query>\"}"
#     }

#     return system_text, json.dumps(user_prompt, indent=2)

# def _ollama_generate_json(system_text: str, user_prompt: str) -> Dict:
#     payload = {
#         "model": OLLAMA_MODEL,
#         "system": system_text,
#         "prompt": user_prompt,
#         "format": "json",
#         "stream": False,
#         "options": {"temperature": LLAMA_TEMPERATURE},
#     }
#     resp = requests.post(OLLAMA_GENERATE_URL, json=payload, timeout=LLM_TIMEOUT)
#     if resp.status_code >= 400:
#         raise RuntimeError(f"Ollama error {resp.status_code}: {resp.text}")
#     data = resp.json()
#     text = (data.get("response") or "").strip()
#     if not text:
#         raise RuntimeError("Ollama returned empty response")
#     return json.loads(text)

# def generate_sql_llama_v2(question: str, repair_hint: Optional[str] = None, **kwargs) -> Optional[str]:
#     """
#     Main entrypoint for schema-aware Llama SQL generation.
#     - 'repair_hint' aligns with your validator path (alias for prior 'repair_error').
#     """
#     system_text, user_prompt = _structured_prompt(question, repair_hint)
#     try:
#         obj = _ollama_generate_json(system_text, user_prompt)
#         return obj.get("sql", "").strip()
#     except Exception as e:
#         print(f"❌ Llama v2 failed: {e}")
#         return None


# app/clients/llama_client_v2.py
import os, json, requests
from typing import Optional, Dict, Tuple

PROMPTS_DIR = os.path.join(os.path.dirname(__file__), "../../prompts")

def _load_file(name: str) -> str:
    path = os.path.join(PROMPTS_DIR, name)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    return ""

# Keep caps (but trim to protect context if files get huge)
FEWSHOTS_TEXT = _load_file("fewshots.sql.md")[:4000]
GLOSSARY_TEXT = _load_file("glossary.md")[:2000]

OLLAMA_GENERATE_URL = os.getenv("OLLAMA_GENERATE_URL", "http://localhost:11434/api/generate")
OLLAMA_MODEL        = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
LLAMA_TEMPERATURE   = float(os.getenv("LLAMA_TEMPERATURE", "0.0"))
LLM_TIMEOUT         = int(os.getenv("LLM_TIMEOUT", "120"))

# Row-limit & owner so rules can be concrete
ROW_LIMIT = int(os.getenv("DEFAULT_ROW_LIMIT", "200"))
OWNER     = os.getenv("ORACLE_OWNER", "ATS").upper()

# ---- CHANGED: load the new JSON card that build_schema_card_json.py writes
SCHEMA_JSON_PATHS = [
    os.path.join(PROMPTS_DIR, "schema_card.json"),        # preferred (new)
    os.path.join(PROMPTS_DIR, "schema_card_llama.json"),  # legacy (fallback)
]
SCHEMA_JSON = None
for p in SCHEMA_JSON_PATHS:
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            SCHEMA_JSON = json.load(f)
        break
if not SCHEMA_JSON:
    raise FileNotFoundError(
        "Structured schema JSON not found. Expected one of: "
        + ", ".join(SCHEMA_JSON_PATHS)
        + ". Please run app/build_schema_card_json.py."
    )

def _structured_prompt(question: str, repair_hint: Optional[str] = None) -> Tuple[str, str]:
    """
    Build system + user prompts for a schema-aware Llama call that returns JSON {"sql": "..."}.
    Now includes TRADES / CANCELLED_TRADES / NEGOTIATED_TRADES hints.
    """
    system_text = f"""
You are an expert Oracle SQL developer.
Generate exactly one valid, **read-only** Oracle SQL query for the {OWNER} schema.

GLOBAL RULES
1) Use ONLY tables/columns present in the provided schema_json.
2) SELECT-only. Never use UPDATE/INSERT/DELETE/MERGE/DDL.
3) Use explicit ANSI JOINs with clear aliases (no implicit joins).
4) Oracle syntax: no LIMIT; always end with a semicolon; include FETCH FIRST {ROW_LIMIT} ROWS ONLY unless a stricter limit already exists.
5) Aggregate by day/month/year using TRUNC(date_col, 'DD'|'MM'|'YYYY').
6) In grouped queries, every non-grouped field MUST be aggregated (SUM/AVG/MIN/MAX/MEDIAN/PERCENTILE_CONT).
7) Do **not** project raw *_ID fields unless explicitly asked; join to labels instead.

MARKET-DATA HINTS (if SDI/SI/BM are used)
- SYMBOL labels:      JOIN {OWNER}.SYMBOLS s   ON s.SYMBOL_ID = d.SYMBOL_ID    → s.SYMBOL
- EXCHANGE labels:    JOIN {OWNER}.EXCHANGES e ON e.EXCHANGE_ID = d.EXCHANGE_ID → e.EXCHANGE_CODE or e.EXCHANGE_NAME
- Typical date columns: STATS_DATE (SYMBOL_DAILY_INDICATORS), ENTRY_DATETIME (SYMBOL_INDICATORS/BEST_MKT).

ORDERS HINTS (if ORDERS is used)
- Time column: ORDERS.ENTRY_DATETIME (use unless user asks for lifecycle timing, then ORDERS.STATE_TIME).
- Notional default: SUM(o.VOLUME * o.PRICE). Stored value: SUM(o.VALUE) (may include multipliers/accrued for bonds).
- Side semantics: o.SIDE ('B' buy, 'S' sell). IS_SHORT is a stringy boolean.
- Label joins (prefer labels over IDs):
    JOIN {OWNER}.SYMBOLS s    ON s.SYMBOL_ID = o.SYMBOL_ID       -- s.SYMBOL
    JOIN {OWNER}.EXCHANGES e  ON e.EXCHANGE_ID = o.EXCHANGE_ID   -- e.EXCHANGE_CODE/NAME
    JOIN {OWNER}.FLAGS f      ON f.FLAG_ID = o.FLAG_ID           -- f.FLAG_CODE
    JOIN {OWNER}.ORDER_TYPES t  ON t.ID = o.ORDER_TYPE           -- t.CODE
    JOIN {OWNER}.ORDER_STATES st ON st.STATE_ID = o.STATE        -- st.STATE_CODE
    JOIN {OWNER}.SUBSCRIBED_BROKERS b ON b.BROKER_ID = o.BROKER_ID  -- b.BROKER_NAME
    JOIN {OWNER}.EDS_CLIENTS c ON c.CLIENT_ID = o.CLIENT_ID         -- c.NAME
    JOIN {OWNER}.USERS u ON u.USER_ID = o.USER_ID                   -- u.COMPLETE_NAME
- Use SYMBOL_MARKETS only when you truly need market attributes:
    JOIN {OWNER}.SYMBOL_MARKETS m
      ON m.SYMBOL_ID=o.SYMBOL_ID AND m.EXCHANGE_ID=o.EXCHANGE_ID AND m.MARKET_ID=o.MARKET_ID

----New---- TRADES HINTS
- Time column: t.ENTRY_DATETIME
- Measures: SUM(t.PRICE * t.VOLUME) as notional; SUM(t.SETTLEMENT_AMOUNT) for cash consideration;
            AVG(t.DIRTY_PRICE) (bonds); AVG(t.YIELD) (bonds); SUM(t.ACCRUED_PROFIT).
- Label joins (project labels, not IDs):
    JOIN {OWNER}.SYMBOLS s   ON s.SYMBOL_ID = t.SYMBOL_ID             -- s.SYMBOL
    JOIN {OWNER}.EXCHANGES e ON e.EXCHANGE_ID = t.EXCHANGE_ID         -- e.EXCHANGE_CODE/NAME
    JOIN {OWNER}.SUBSCRIBED_BROKERS bb ON bb.BROKER_ID = t.BUYER_BROKER_ID   -- bb.BROKER_NAME AS buyer_broker
    JOIN {OWNER}.SUBSCRIBED_BROKERS sb ON sb.BROKER_ID = t.SELLER_BROKER_ID  -- sb.BROKER_NAME AS seller_broker
    JOIN {OWNER}.EDS_CLIENTS bc ON bc.CLIENT_ID = t.BUYER_CLIENT_ID          -- bc.NAME AS buyer_client
    JOIN {OWNER}.EDS_CLIENTS sc ON sc.CLIENT_ID = t.SELLER_CLIENT_ID         -- sc.NAME AS seller_client
    JOIN {OWNER}.USERS bu ON bu.USER_ID = t.BUYER_USER_ID                     -- bu.COMPLETE_NAME AS buyer_user
    JOIN {OWNER}.USERS su ON su.USER_ID = t.SELLER_USER_ID                    -- su.COMPLETE_NAME AS seller_user
    LEFT JOIN {OWNER}.SETTLEMENT_TYPES sty ON sty.SETTLEMENT_TYPE_ID = t.SETTLEMENT_TYPE_ID  -- sty.SETTLEMENT_TYPE AS settlement_type
    LEFT JOIN {OWNER}.TRADE_STATES ts ON ts.STATE_ID = t.STATE_ID                                 -- NVL(ts.STATE_NAME, ts.STATE_CODE) AS trade_state
- Venue triple (only if needed): (SYMBOL_ID, MARKET_ID, EXCHANGE_ID) ↔ {OWNER}.SYMBOL_MARKETS

----New---- CANCELLED_TRADES HINTS
- Use ct.CANCELLATION_DATETIME for date bucketing.
- Same label joins as TRADES (buyer/seller client/broker/user, symbol, exchange).
- Do **not** assume 1:1 with TRADES by ticket; if linkage is required, prefer (BUYER_ORDER_NO, SELLER_ORDER_NO, EXCHANGE_ID).

----New---- NEGOTIATED_TRADES HINTS
- Use nt.ENTRY_DATETIME for time.
- Counterparty labels:
    JOIN {OWNER}.SUBSCRIBED_BROKERS cb ON cb.BROKER_ID = nt.COUNTER_BROKER_ID    -- counter_broker
    JOIN {OWNER}.EDS_CLIENTS cc ON cc.CLIENT_ID = nt.COUNTER_CLIENT_ID           -- counter_client
- Linking to executed TRADES (when required by the question):
    Map (nt.ORDER_NO or nt.COUNTER_ORDER_NO) ↔ (t.BUYER_ORDER_NO or t.SELLER_ORDER_NO) with same EXCHANGE_ID.

OUTPUT
- Return ONLY JSON of the form: {{"sql": "<the SQL query>"}}
- The SQL must end with a semicolon and include a row limit unless a stricter one is already present.
""".strip()

    user_prompt = {
        "task": "Convert the user question into valid Oracle SQL.",
        "schema_json": SCHEMA_JSON,
        "fewshots": FEWSHOTS_TEXT,
        "glossary": GLOSSARY_TEXT,
        "question": question,
        "repair": repair_hint or "",
        "output_format": "Return only JSON: {\"sql\": \"<the SQL query>\"}"
    }
    return system_text, json.dumps(user_prompt, indent=2)

def _ollama_generate_json(system_text: str, user_prompt: str) -> Dict:
    payload = {
        "model": OLLAMA_MODEL,
        "system": system_text,
        "prompt": user_prompt,
        "format": "json",
        "stream": False,
        "options": {"temperature": LLAMA_TEMPERATURE},
    }
    resp = requests.post(OLLAMA_GENERATE_URL, json=payload, timeout=LLM_TIMEOUT)
    if resp.status_code >= 400:
        raise RuntimeError(f"Ollama error {resp.status_code}: {resp.text}")
    data = resp.json()
    text = (data.get("response") or "").strip()
    if not text:
        raise RuntimeError("Ollama returned empty response")
    return json.loads(text)

def generate_sql_llama_v2(question: str, repair_hint: Optional[str] = None, **kwargs) -> Optional[str]:
    """
    Main entrypoint for schema-aware Llama SQL generation.
    - 'repair_hint' matches your validator's hint string (formerly 'repair_error').
    """
    system_text, user_prompt = _structured_prompt(question, repair_hint)
    try:
        obj = _ollama_generate_json(system_text, user_prompt)
        return obj.get("sql", "").strip()
    except Exception as e:
        print(f"❌ Llama v2 failed: {e}")
        return None
