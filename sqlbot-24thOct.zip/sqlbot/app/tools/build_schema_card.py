# # app/build_schema_card.py
# """
# Build a compact, Oracle-specific Schema Card for NL→SQL prompts.

# Reads env vars (.env):
#   ORACLE_DSN, ORACLE_USER, ORACLE_PASSWORD, ORACLE_OWNER
# Writes:
#   app/prompts/schema_card.txt

# Scope (v2): ATS.SYMBOL_DAILY_INDICATORS, ATS.SYMBOL_INDICATORS, ATS.BEST_MKT,
#             ATS.SYMBOLS, ATS.EXCHANGES, ATS.ORDERS, ATS.SYMBOL_MARKETS,
#             ATS.FLAGS, ATS.ORDER_TYPES, ATS.ORDER_STATES,
#             ATS.SUBSCRIBED_BROKERS, ATS.EDS_CLIENTS, ATS.USERS
# """
# from __future__ import annotations
# import os
# import sys
# import textwrap
# from dataclasses import dataclass
# from typing import Dict, List, Optional, Tuple

# import oracledb
# from dotenv import load_dotenv

# # --------------------------
# # Config & enrichment (from your JSON spec)
# # --------------------------

# OWNER_TABLES = [
#     # existing stats scope
#     "SYMBOL_DAILY_INDICATORS",
#     "SYMBOL_INDICATORS",
#     "BEST_MKT",
#     "SYMBOLS",
#     "EXCHANGES",
#     # new orders scope
#     "ORDERS",
#     "SYMBOL_MARKETS",
#     "FLAGS",
#     "ORDER_TYPES",
#     "ORDER_STATES",
#     "SUBSCRIBED_BROKERS",
#     "EDS_CLIENTS",
#     "USERS",
# ]

# # Business semantics to enrich the raw dictionary metadata
# CATALOG = {
#     "version": "stats+orders-catalog-v2",
#     "facts": {
#         "SYMBOL_DAILY_INDICATORS": {
#             "id": "SDI",
#             "grain": "symbol_day",
#             "date_key": "STATS_DATE",
#             "measures": {
#                 "turnover": ("TURNOVER_VALUE", "SUM"),
#                 "avg_price": ("CLOSE_PRICE", "AVG"),
#                 "open": ("OPEN_PRICE", None),
#                 "high": ("HIGH_PRICE", None),
#                 "low": ("LOW_PRICE", None),
#                 "close": ("CLOSE_PRICE", None),
#                 "trades_count": ("TRADES_COUNT", "SUM"),
#             },
#             "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
#         },
#         "SYMBOL_INDICATORS": {
#             "id": "SI",
#             "grain": "symbol_timestamp",
#             "date_key": "ENTRY_DATETIME",
#             "measures": {
#                 "volume": ("VOLUME", "SUM"),
#                 "turnover": ("VALUE", "SUM"),
#                 "avg_price": ("CLOSE", "AVG"),
#                 "open": ("OPEN", None),
#                 "high": ("HIGH", None),
#                 "low": ("LOW", None),
#                 "close": ("CLOSE", None),
#             },
#             "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
#         },
#         "BEST_MKT": {
#             "id": "BM",
#             "grain": "symbol_timestamp",
#             "date_key": "ENTRY_DATETIME",
#             "measures": {
#                 "bid_price": ("BID_PRICE", "AVG"),
#                 "offer_price": ("OFFER_PRICE", "AVG"),
#                 "spread": ("OFFER_PRICE - BID_PRICE", "AVG"),
#                 "mid": ("(BID_PRICE + OFFER_PRICE)/2", "AVG"),
#                 "bid_volume": ("BID_VOLUME", "SUM"),
#                 "offer_volume": ("OFFER_VOLUME", "SUM"),
#             },
#             "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
#         },
#         # NEW: Orders fact
#         "ORDERS": {
#             "id": "O",
#             "grain": "order_event",
#             "date_key": "ENTRY_DATETIME",  # default time filter
#             "measures": {
#                 # prefer computed notional in general analytics
#                 "orders": ("*", "COUNT"),
#                 "volume": ("VOLUME", "SUM"),
#                 "notional_computed": ("VOLUME * PRICE", "SUM"),
#                 # stored value may include multipliers (bonds); use when explicitly requested
#                 "value_stored": ("VALUE", "SUM"),
#                 "avg_price": ("PRICE", "AVG"),
#                 "avg_yield": ("YIELD", "AVG"),
#                 "accrued_profit": ("ACCRUED_PROFIT", "SUM"),
#             },
#             "dimensions": [
#                 "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
#                 "SIDE", "FLAG_ID", "ORDER_TYPE", "STATE",
#                 "CLIENT_ID", "BROKER_ID", "USER_ID", "TRADER_ID"
#             ],
#             "notes": [
#                 "Use ENTRY_DATETIME for date filtering unless another timestamp is specified (STATE_TIME for state changes).",
#                 "For generic notional, prefer SUM(VOLUME * PRICE). SUM(VALUE) (value_stored) may include instrument multipliers (esp. bonds).",
#                 "SIDE is 'B'/'S'; IS_SHORT is a stringy boolean ('0'/'1').",
#             ],
#         },
#     },
#     "lookups": {
#         "SYMBOLS":            {"key": "SYMBOL_ID", "label": ("SYMBOL",)},
#         "EXCHANGES":          {"key": "EXCHANGE_ID", "label": ("EXCHANGE_NAME",)},
#         # NEW lookups for orders
#         "FLAGS":              {"key": "FLAG_ID", "label": ("FLAG_CODE", "DESC_")},
#         "ORDER_TYPES":        {"key": "ID", "label": ("CODE", "DESCRIPTION")},
#         "ORDER_STATES":       {"key": "STATE_ID", "label": ("STATE_CODE",)},
#         "SUBSCRIBED_BROKERS": {"key": "BROKER_ID", "label": ("BROKER_NAME", "BROKER_CODE")},
#         "EDS_CLIENTS":        {"key": "CLIENT_ID", "label": ("NAME", "CLIENT_CODE")},
#         "USERS":              {"key": "USER_ID", "label": ("USER_NAME", "COMPLETE_NAME")},
#         # SYMBOL_MARKETS is a structural/bridge table; no label
#     },
#     "notes": {
#         "allowed_grains": ["day", "month", "year"],
#         "safety": "No intraday bucketing in v1; aggregate to day/month/year only.",
#     },
# }

# # --------------------------
# # Data structures
# # --------------------------

# @dataclass
# class Column:
#     name: str
#     data_type: str
#     nullable: bool
#     comment: Optional[str] = None
#     is_pk: bool = False
#     is_fk: bool = False
#     fk_ref: Optional[Tuple[str, str, str]] = None  # (owner, table, column)

# @dataclass
# class TableMeta:
#     owner: str
#     name: str
#     comment: Optional[str]
#     columns: List[Column]

# # --------------------------
# # Helpers
# # --------------------------

# def env(name: str, required: bool = True, default: Optional[str] = None) -> str:
#     v = os.getenv(name, default)
#     if required and not v:
#         print(f"Missing env: {name}", file=sys.stderr)
#         sys.exit(1)
#     return v or ""

# def connect_oracle() -> oracledb.Connection:
#     dsn = env("ORACLE_DSN")
#     user = env("ORACLE_USER")
#     pwd = env("ORACLE_PASSWORD")
#     owner = env("ORACLE_OWNER")
#     conn = oracledb.connect(user=user, password=pwd, dsn=dsn)
#     with conn.cursor() as cur:
#         cur.execute(f"alter session set current_schema = {owner}")
#     return conn

# def fetch_columns(cur: oracledb.Cursor, owner: str) -> Dict[str, List[Column]]:
#     q = """
#     SELECT
#       c.table_name,
#       c.column_name,
#       c.data_type ||
#         CASE
#           WHEN c.data_type IN ('NUMBER') AND c.data_precision IS NOT NULL
#             THEN '('||c.data_precision||
#                  CASE WHEN c.data_scale IS NOT NULL THEN ','||c.data_scale END||')'
#           WHEN c.data_type IN ('VARCHAR2','CHAR','NVARCHAR2','NCHAR') AND c.char_length IS NOT NULL
#             THEN '('||c.char_length||')'
#         END AS dtype,
#       c.nullable,
#       cc.comments
#     FROM all_tab_columns c
#     LEFT JOIN all_col_comments cc
#       ON cc.owner = c.owner AND cc.table_name = c.table_name AND cc.column_name = c.column_name
#     WHERE c.owner = :owner
#       AND c.table_name IN ({placeholders})
#     ORDER BY c.table_name, c.column_id
#     """.format(placeholders=", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)]))
#     binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
#     cur.execute(q, binds)
#     out: Dict[str, List[Column]] = {t: [] for t in OWNER_TABLES}
#     for tname, col, dtype, nullable, comment in cur:
#         out[tname].append(Column(name=col, data_type=dtype or "UNKNOWN", nullable=(nullable == "Y"), comment=comment))
#     return out

# def fetch_table_comments(cur: oracledb.Cursor, owner: str) -> Dict[str, Optional[str]]:
#     q = """
#     SELECT table_name, comments
#     FROM all_tab_comments
#     WHERE owner = :owner
#       AND table_name IN ({placeholders})
#     """.format(placeholders=", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)]))
#     binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
#     cur.execute(q, binds)
#     comments = {t: None for t in OWNER_TABLES}
#     for t, c in cur:
#         comments[t] = c
#     return comments

# def fetch_constraints(cur: oracledb.Cursor, owner: str):
#     # Map PKs and FKs per table/column, with referenced targets
#     q = """
#     WITH cons AS (
#       SELECT owner, table_name, constraint_name, constraint_type, r_owner, r_constraint_name
#       FROM all_constraints
#       WHERE owner = :owner
#         AND table_name IN ({placeholders})
#     )
#     SELECT
#       c.constraint_type,
#       c.table_name,
#       cols.column_name,
#       c.constraint_name,
#       rc.owner AS r_owner,
#       rc.table_name AS r_table,
#       rcols.column_name AS r_col
#     FROM cons c
#     JOIN all_cons_columns cols
#       ON cols.owner = c.owner AND cols.constraint_name = c.constraint_name
#     LEFT JOIN all_constraints rc
#       ON c.r_owner = rc.owner AND c.r_constraint_name = rc.constraint_name
#     LEFT JOIN all_cons_columns rcols
#       ON rcols.owner = rc.owner AND rcols.constraint_name = rc.constraint_name
#          AND rcols.position = cols.position
#     ORDER BY c.table_name, c.constraint_type DESC, cols.position
#     """.format(placeholders=", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)]))
#     binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
#     cur.execute(q, binds)

#     pk_map: Dict[Tuple[str, str], bool] = {}
#     fk_map: Dict[Tuple[str, str], Tuple[str, str, str]] = {}
#     for ctype, table, col, _cname, r_owner, r_table, r_col in cur:
#         if ctype == "P":
#             pk_map[(table, col)] = True
#         elif ctype == "R":
#             if r_owner and r_table and r_col:
#                 fk_map[(table, col)] = (r_owner, r_table, r_col)
#     return pk_map, fk_map

# def build_table_meta(owner: str, columns: Dict[str, List[Column]],
#                      comments: Dict[str, Optional[str]],
#                      pk_map, fk_map) -> List[TableMeta]:
#     metas: List[TableMeta] = []
#     for t in OWNER_TABLES:
#         cols = []
#         for c in columns.get(t, []):
#             is_pk = pk_map.get((t, c.name), False)
#             fk_ref = fk_map.get((t, c.name))
#             cols.append(Column(
#                 name=c.name, data_type=c.data_type, nullable=c.nullable,
#                 comment=c.comment, is_pk=is_pk, is_fk=bool(fk_ref), fk_ref=fk_ref
#             ))
#         metas.append(TableMeta(owner=owner, name=t, comment=comments.get(t), columns=cols))
#     return metas

# def fmt_columns(cols: List[Column]) -> List[str]:
#     lines = []
#     for c in cols:
#         flags = []
#         if c.is_pk: flags.append("PK")
#         if c.is_fk and c.fk_ref:
#             ro, rt, rc = c.fk_ref
#             flags.append(f"FK→{ro}.{rt}({rc})")
#         if not c.nullable: flags.append("NOT NULL")
#         flag_str = f"  -- {', '.join(flags)}" if flags else ""
#         comment = f"  -- {c.comment}" if (c.comment and not flag_str) else (f" | {c.comment}" if c.comment else "")
#         lines.append(f"    - {c.name} {c.data_type}{flag_str}{comment}")
#     return lines

# def synthesize_joins() -> List[str]:
#     # From your join rules (facts -> lookups)
#     j = [
#         "SDI ↔ SYMBOLS on (SYMBOL_DAILY_INDICATORS.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
#         "SDI ↔ EXCHANGES on (SYMBOL_DAILY_INDICATORS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
#         "SI  ↔ SYMBOLS on (SYMBOL_INDICATORS.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
#         "SI  ↔ EXCHANGES on (SYMBOL_INDICATORS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
#         "BM  ↔ SYMBOLS on (BEST_MKT.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
#         "BM  ↔ EXCHANGES on (BEST_MKT.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
#     ]
#     # ORDERS joins
#     j += [
#         "ORDERS ↔ SYMBOLS on (ORDERS.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
#         "ORDERS ↔ EXCHANGES on (ORDERS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
#         "ORDERS ↔ SYMBOL_MARKETS on (ORDERS.SYMBOL_ID = SYMBOL_MARKETS.SYMBOL_ID AND "
#         "ORDERS.MARKET_ID = SYMBOL_MARKETS.MARKET_ID AND ORDERS.EXCHANGE_ID = SYMBOL_MARKETS.EXCHANGE_ID)",
#         "ORDERS ↔ FLAGS on (ORDERS.FLAG_ID = FLAGS.FLAG_ID)",
#         "ORDERS ↔ ORDER_TYPES on (ORDERS.ORDER_TYPE = ORDER_TYPES.ID)",
#         "ORDERS ↔ ORDER_STATES on (ORDERS.STATE = ORDER_STATES.STATE_ID)",
#         "ORDERS ↔ SUBSCRIBED_BROKERS on (ORDERS.BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID)",
#         "ORDERS ↔ EDS_CLIENTS on (ORDERS.CLIENT_ID = EDS_CLIENTS.CLIENT_ID)",
#         "ORDERS ↔ USERS (as USER_ID) on (ORDERS.USER_ID = USERS.USER_ID)",
#         "ORDERS ↔ USERS (as TRADER_ID) on (ORDERS.TRADER_ID = USERS.USER_ID)",
#     ]
#     return j

# def measures_block(table: str) -> Optional[str]:
#     fx = CATALOG["facts"].get(table)
#     if not fx:
#         return None
#     lines = []
#     for mname, (col_or_expr, agg) in fx["measures"].items():
#         if agg:
#             if mname == "orders" and col_or_expr == "*":
#                 lines.append(f"  - {mname}: COUNT(*)")
#             else:
#                 lines.append(f"  - {mname}: {agg}({col_or_expr})")
#         else:
#             lines.append(f"  - {mname}: {col_or_expr}")
#     # attach any notes for the fact
#     notes = fx.get("notes") or []
#     if notes:
#         lines.append("  Notes:")
#         for n in notes:
#             lines.append(f"    • {n}")
#     return "\n".join(lines)

# def dimensions_block(table: str) -> Optional[str]:
#     fx = CATALOG["facts"].get(table)
#     if not fx:
#         return None
#     dims = fx.get("dimensions") or []
#     if not dims:
#         return None
#     return "\n".join([f"  - {d}" for d in dims])

# def write_card(path: str, owner: str, metas: List[TableMeta]) -> str:
#     allowed_grains = ", ".join(CATALOG["notes"]["allowed_grains"])
#     header = textwrap.dedent(f"""\
#     # Schema Card — Oracle (owner: {owner})

#     Scope: {', '.join([f'{owner}.{t}' for t in OWNER_TABLES])}
#     Allowed grains: {allowed_grains}
#     Safety: {CATALOG["notes"]["safety"]}

#     Oracle helpers:
#       - Date buckets: TRUNC(<date_col>, 'DD'|'MM'|'YYYY')
#       - Range filter: col >= DATE 'YYYY-MM-DD' AND col < DATE 'YYYY-MM-DD'
#       - Row limit: FETCH FIRST <N> ROWS ONLY  (fallback: WHERE ROWNUM <= N)
#       - Percentiles: PERCENTILE_CONT(p) WITHIN GROUP (ORDER BY expr)
#       - Median: MEDIAN(expr)
#       - Window: LAG/LEAD, AVG(...) OVER (PARTITION BY ... ORDER BY ... ROWS BETWEEN ...)
#       - ANSI JOINs only; no legacy (+) joins.

#     Joins (preferred):
#     """)
#     joins = "\n".join([f"  - {j}" for j in synthesize_joins()])

#     body_parts = []
#     for tm in metas:
#         fq = f"{tm.owner}.{tm.name}"
#         fact = CATALOG["facts"].get(tm.name)
#         grain = fact.get("grain") if fact else None
#         date_key = fact.get("date_key") if fact else None

#         header_tbl = f"\n## {fq}" + (f"  (grain: {grain})" if grain else "")
#         if tm.comment:
#             header_tbl += f"\n-- {tm.comment}"

#         cols_str = "\n".join(fmt_columns(tm.columns))

#         measures = measures_block(tm.name)
#         dims = dimensions_block(tm.name)
#         measures_str = f"\n  Measures:\n{measures}" if measures else ""
#         dims_str = f"\n  Dimensions:\n{dims}" if dims else ""
#         date_str = f"\n  Date key: {date_key}" if date_key else ""

#         body_parts.append(
#             f"""{header_tbl}
#   Columns:
# {cols_str}{date_str}{dims_str}{measures_str}
# """
#         )

#     card = f"{header}\n{joins}\n" + "\n".join(body_parts)

#     os.makedirs(os.path.dirname(path), exist_ok=True)
#     with open(path, "w", encoding="utf-8") as f:
#         f.write(card)

#     return card

# def main() -> None:
#     load_dotenv()
#     owner = env("ORACLE_OWNER")
#     out_path = os.path.join("app", "prompts", "schema_card.txt")

#     print("→ Connecting to Oracle…")
#     conn = connect_oracle()
#     try:
#         with conn.cursor() as cur:
#             print(f"→ Introspecting columns, keys, and comments for {owner}…")
#             columns = fetch_columns(cur, owner)
#             comments = fetch_table_comments(cur, owner)
#             pk_map, fk_map = fetch_constraints(cur, owner)
#             metas = build_table_meta(owner, columns, comments, pk_map, fk_map)

#         print("→ Writing schema card…")
#         card = write_card(out_path, owner, metas)

#         # Show a short preview
#         preview = "\n".join(card.splitlines()[:80])
#         print("=== schema_card.txt (preview) ===")
#         print(preview)
#         print("… (truncated)")
#         print(f"\nDone. Full card at: {out_path}")
#     finally:
#         conn.close()

# if __name__ == "__main__":
#     main()

# app/build_schema_card.py
"""
Build a compact, Oracle-specific Schema Card for NL→SQL prompts.

Reads env vars (.env):
  ORACLE_DSN, ORACLE_USER, ORACLE_PASSWORD, ORACLE_OWNER
Writes:
  app/prompts/schema_card.txt

Scope (v3): ATS.SYMBOL_DAILY_INDICATORS, ATS.SYMBOL_INDICATORS, ATS.BEST_MKT,
            ATS.SYMBOLS, ATS.EXCHANGES,
            ATS.ORDERS, ATS.SYMBOL_MARKETS, ATS.FLAGS, ATS.ORDER_TYPES, ATS.ORDER_STATES,
            ATS.SUBSCRIBED_BROKERS, ATS.EDS_CLIENTS, ATS.USERS,
            ----New---- ATS.TRADES, ATS.CANCELLED_TRADES, ATS.NEGOTIATED_TRADES,
            ----New---- ATS.TRADE_STATES, ATS.SETTLEMENT_TYPES, ATS.SYMBOL_TYPES
"""
from __future__ import annotations

import os
import sys
import textwrap
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import oracledb
from dotenv import load_dotenv

# --------------------------
# Config & enrichment
# --------------------------

# Core + Orders scope (existing)
OWNER_TABLES = [
    # existing stats scope
    "SYMBOL_DAILY_INDICATORS",
    "SYMBOL_INDICATORS",
    "BEST_MKT",
    "SYMBOLS",
    "EXCHANGES",

    # existing orders scope
    "ORDERS",
    "SYMBOL_MARKETS",
    "FLAGS",
    "ORDER_TYPES",
    "ORDER_STATES",
    "SUBSCRIBED_BROKERS",
    "EDS_CLIENTS",
    "USERS",

    # ----New---- trades scope
    "TRADES",
    "CANCELLED_TRADES",
    "NEGOTIATED_TRADES",

    # ----New---- extra lookups
    "TRADE_STATES",
    "SETTLEMENT_TYPES",
    "SYMBOL_TYPES",
]

# Business semantics to enrich the raw dictionary metadata
CATALOG = {
    "version": "stats+orders+trades-catalog-v3",
    "facts": {
        "SYMBOL_DAILY_INDICATORS": {
            "id": "SDI",
            "grain": "symbol_day",
            "date_key": "STATS_DATE",
            "measures": {
                "turnover": ("TURNOVER_VALUE", "SUM"),
                "avg_price": ("CLOSE_PRICE", "AVG"),
                "open": ("OPEN_PRICE", None),
                "high": ("HIGH_PRICE", None),
                "low": ("LOW_PRICE", None),
                "close": ("CLOSE_PRICE", None),
                "trades_count": ("TRADES_COUNT", "SUM"),
            },
            "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
        },
        "SYMBOL_INDICATORS": {
            "id": "SI",
            "grain": "symbol_timestamp",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "volume": ("VOLUME", "SUM"),
                "turnover": ("VALUE", "SUM"),
                "avg_price": ("CLOSE", "AVG"),
                "open": ("OPEN", None),
                "high": ("HIGH", None),
                "low": ("LOW", None),
                "close": ("CLOSE", None),
            },
            "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
        },
        "BEST_MKT": {
            "id": "BM",
            "grain": "symbol_timestamp",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "bid_price": ("BID_PRICE", "AVG"),
                "offer_price": ("OFFER_PRICE", "AVG"),
                "spread": ("OFFER_PRICE - BID_PRICE", "AVG"),
                "mid": ("(BID_PRICE + OFFER_PRICE)/2", "AVG"),
                "bid_volume": ("BID_VOLUME", "SUM"),
                "offer_volume": ("OFFER_VOLUME", "SUM"),
            },
            "dimensions": ["SYMBOL_ID", "EXCHANGE_ID"],
        },
        # ORDERS fact (existing)
        "ORDERS": {
            "id": "O",
            "grain": "order_event",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "orders": ("*", "COUNT"),
                "volume": ("VOLUME", "SUM"),
                "notional_computed": ("VOLUME * PRICE", "SUM"),
                "value_stored": ("VALUE", "SUM"),
                "avg_price": ("PRICE", "AVG"),
                "avg_yield": ("YIELD", "AVG"),
                "accrued_profit": ("ACCRUED_PROFIT", "SUM"),
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "SIDE", "FLAG_ID", "ORDER_TYPE", "STATE",
                "CLIENT_ID", "BROKER_ID", "USER_ID", "TRADER_ID"
            ],
            "notes": [
                "Use ENTRY_DATETIME for date filtering unless another timestamp is specified (STATE_TIME for state changes).",
                "For generic notional, prefer SUM(VOLUME * PRICE). SUM(VALUE) (value_stored) may include instrument multipliers (esp. bonds).",
                "SIDE is 'B'/'S'; IS_SHORT is a stringy boolean ('0'/'1').",
            ],
        },
        # ----New---- TRADES fact
        "TRADES": {
            "id": "T",
            "grain": "trade_event",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "trades": ("*", "COUNT"),
                "volume": ("VOLUME", "SUM"),
                "notional_computed": ("PRICE * VOLUME", "SUM"),
                "settlement_amount": ("SETTLEMENT_AMOUNT", "SUM"),
                "avg_price": ("PRICE", "AVG"),
                "avg_dirty_price": ("DIRTY_PRICE", "AVG"),
                "avg_yield": ("YIELD", "AVG"),
                "accrued_profit": ("ACCRUED_PROFIT", "SUM"),
                "avg_repurchase_price": ("REPURCHASE_PRICE", "AVG"),
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "BUYER_CLIENT_ID", "SELLER_CLIENT_ID",
                "BUYER_BROKER_ID", "SELLER_BROKER_ID",
                "BUYER_USER_ID", "SELLER_USER_ID",
                "BUYER_TRADER_ID", "SELLER_TRADER_ID",
                "STATE_ID", "SETTLEMENT_TYPE_ID", "TRADE_TYPE", "IS_SHORT"
            ],
            "notes": [
                "TRADES has buyer_* and seller_* party columns; no explicit SIDE.",
                "DIRTY_PRICE is clean+accrued (primarily bonds). SETTLEMENT_AMOUNT is the cash consideration.",
                "Remaining volumes may be non-zero due to partial fills (do not assume zero).",
                "Use (SYMBOL_ID, MARKET_ID, EXCHANGE_ID) to join venue info via SYMBOL_MARKETS when needed."
            ],
        },
        # ----New---- CANCELLED_TRADES fact
        "CANCELLED_TRADES": {
            "id": "CT",
            "grain": "cancel_event",
            "date_key": "CANCELLATION_DATETIME",
            "measures": {
                "cancellations": ("*", "COUNT"),
                "volume": ("VOLUME", "SUM"),
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "BUYER_CLIENT_ID", "SELLER_CLIENT_ID",
                "BUYER_BROKER_ID", "SELLER_BROKER_ID",
                "BUYER_USER_ID", "SELLER_USER_ID",
                "STATE_ID", "SETTLEMENT_TYPE_ID", "TRADE_TYPE", "IS_SHORT"
            ],
            "notes": [
                "Treat as standalone cancellation events; do not assume 1:1 linkage to TRADES by TICKET_NO.",
                "For exploratory linkage, try (BUYER_ORDER_NO, SELLER_ORDER_NO, EXCHANGE_ID) → TRADES."
            ],
        },
        # ----New---- NEGOTIATED_TRADES fact
        "NEGOTIATED_TRADES": {
            "id": "NT",
            "grain": "negotiation_event",
            "date_key": "ENTRY_DATETIME",
            "measures": {
                "negotiations": ("*", "COUNT"),
                "volume": ("VOLUME", "SUM"),
                "notional_computed": ("PRICE * VOLUME", "SUM"),
                "avg_price": ("PRICE", "AVG"),
                "avg_yield": ("YIELD", "AVG"),
                "accrued_profit": ("ACCRUED_PROFIT", "SUM"),
                "value_stored": ("VALUE", "SUM"),
            },
            "dimensions": [
                "SYMBOL_ID", "EXCHANGE_ID", "MARKET_ID",
                "CLIENT_ID", "COUNTER_CLIENT_ID",
                "BROKER_ID", "COUNTER_BROKER_ID",
                "USER_ID", "TRADER_ID",
                "NEGOTIATED_STATE", "NEGOTIATED_STATUS",
                "ORDER_TYPE", "PRICE_TYPE", "IS_SHORT", "SIDE"
            ],
            "notes": [
                "Empirically maps to executed TRADES via order numbers:",
                "  (NEGOTIATED_TRADES.ORDER_NO or COUNTER_ORDER_NO) ↔ (TRADES.BUYER_ORDER_NO or SELLER_ORDER_NO) with same EXCHANGE_ID.",
                "Do not assume linkage to ORDERS.ORDER_NO in this dataset."
            ],
        },
    },
    "lookups": {
        "SYMBOLS":            {"key": "SYMBOL_ID", "label": ("SYMBOL",)},
        "EXCHANGES":          {"key": "EXCHANGE_ID", "label": ("EXCHANGE_CODE", "EXCHANGE_NAME")},
        "FLAGS":              {"key": "FLAG_ID", "label": ("FLAG_CODE", "DESC_")},
        "ORDER_TYPES":        {"key": "ID", "label": ("CODE", "DESCRIPTION")},
        "ORDER_STATES":       {"key": "STATE_ID", "label": ("STATE_CODE",)},
        "SUBSCRIBED_BROKERS": {"key": "BROKER_ID", "label": ("BROKER_NAME", "BROKER_CODE")},
        "EDS_CLIENTS":        {"key": "CLIENT_ID", "label": ("NAME", "CLIENT_CODE")},
        "USERS":              {"key": "USER_ID", "label": ("USER_NAME", "COMPLETE_NAME")},
        # ----New----
        "TRADE_STATES":       {"key": "STATE_ID", "label": ("STATE_NAME", "STATE_CODE", "DESCRIPTION")},
        "SETTLEMENT_TYPES":   {"key": "SETTLEMENT_TYPE_ID", "label": ("SETTLEMENT_TYPE", "NAME", "DESCRIPTION")},
        "SYMBOL_TYPES":       {"key": "SYMBOL_TYPE_ID", "label": ("SYMBOL_TYPE", "NAME", "DESCRIPTION")},
        # SYMBOL_MARKETS is a structural bridge; no label
    },
    "notes": {
        "allowed_grains": ["day", "month", "year"],
        "safety": "No intraday bucketing in v1; aggregate to day/month/year only.",
    },
}

# --------------------------
# Data structures
# --------------------------

@dataclass
class Column:
    name: str
    data_type: str
    nullable: bool
    comment: Optional[str] = None
    is_pk: bool = False
    is_fk: bool = False
    fk_ref: Optional[Tuple[str, str, str]] = None  # (owner, table, column)

@dataclass
class TableMeta:
    owner: str
    name: str
    comment: Optional[str]
    columns: List[Column]

# --------------------------
# Helpers
# --------------------------

def env(name: str, required: bool = True, default: Optional[str] = None) -> str:
    v = os.getenv(name, default)
    if required and not v:
        print(f"Missing env: {name}", file=sys.stderr)
        sys.exit(1)
    return v or ""

def connect_oracle() -> oracledb.Connection:
    dsn = env("ORACLE_DSN")
    user = env("ORACLE_USER")
    pwd = env("ORACLE_PASSWORD")
    owner = env("ORACLE_OWNER")
    conn = oracledb.connect(user=user, password=pwd, dsn=dsn)
    with conn.cursor() as cur:
        cur.execute(f"alter session set current_schema = {owner}")
        try:
            cur.execute("alter session set nls_date_format = 'YYYY-MM-DD HH24:MI:SS'")
        except Exception:
            pass
    return conn

def fetch_columns(cur: oracledb.Cursor, owner: str) -> Dict[str, List[Column]]:
    placeholders = ", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)])
    q = f"""
    SELECT
      c.table_name,
      c.column_name,
      c.data_type ||
        CASE
          WHEN c.data_type IN ('NUMBER') AND c.data_precision IS NOT NULL
            THEN '('||c.data_precision||
                 CASE WHEN c.data_scale IS NOT NULL THEN ','||c.data_scale END||')'
          WHEN c.data_type IN ('VARCHAR2','CHAR','NVARCHAR2','NCHAR') AND c.char_length IS NOT NULL
            THEN '('||c.char_length||')'
        END AS dtype,
      c.nullable,
      cc.comments
    FROM all_tab_columns c
    LEFT JOIN all_col_comments cc
      ON cc.owner = c.owner AND cc.table_name = c.table_name AND cc.column_name = c.column_name
    WHERE c.owner = :owner
      AND c.table_name IN ({placeholders})
    ORDER BY c.table_name, c.column_id
    """
    binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
    cur.execute(q, binds)
    out: Dict[str, List[Column]] = {t: [] for t in OWNER_TABLES}
    for tname, col, dtype, nullable, comment in cur:
        out[tname].append(Column(
            name=col,
            data_type=dtype or "UNKNOWN",
            nullable=(nullable == "Y"),
            comment=comment
        ))
    return out

def fetch_table_comments(cur: oracledb.Cursor, owner: str) -> Dict[str, Optional[str]]:
    placeholders = ", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)])
    q = f"""
    SELECT table_name, comments
    FROM all_tab_comments
    WHERE owner = :owner
      AND table_name IN ({placeholders})
    """
    binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
    cur.execute(q, binds)
    comments = {t: None for t in OWNER_TABLES}
    for t, c in cur:
        comments[t] = c
    return comments

def fetch_constraints(cur: oracledb.Cursor, owner: str):
    placeholders = ", ".join([f":t{i}" for i, _ in enumerate(OWNER_TABLES)])
    q = f"""
    WITH cons AS (
      SELECT owner, table_name, constraint_name, constraint_type, r_owner, r_constraint_name
      FROM all_constraints
      WHERE owner = :owner
        AND table_name IN ({placeholders})
    )
    SELECT
      c.constraint_type,
      c.table_name,
      cols.column_name,
      c.constraint_name,
      rc.owner AS r_owner,
      rc.table_name AS r_table,
      rcols.column_name AS r_col
    FROM cons c
    JOIN all_cons_columns cols
      ON cols.owner = c.owner AND cols.constraint_name = c.constraint_name
    LEFT JOIN all_constraints rc
      ON c.r_owner = rc.owner AND c.r_constraint_name = rc.constraint_name
    LEFT JOIN all_cons_columns rcols
      ON rcols.owner = rc.owner AND rcols.constraint_name = rc.constraint_name
         AND rcols.position = cols.position
    ORDER BY c.table_name, c.constraint_type DESC, cols.position
    """
    binds = {"owner": owner, **{f"t{i}": t for i, t in enumerate(OWNER_TABLES)}}
    cur.execute(q, binds)

    pk_map: Dict[Tuple[str, str], bool] = {}
    fk_map: Dict[Tuple[str, str], Tuple[str, str, str]] = {}
    for ctype, table, col, _cname, r_owner, r_table, r_col in cur:
        if ctype == "P":
            pk_map[(table, col)] = True
        elif ctype == "R":
            if r_owner and r_table and r_col:
                fk_map[(table, col)] = (r_owner, r_table, r_col)
    return pk_map, fk_map

def build_table_meta(owner: str, columns: Dict[str, List[Column]],
                     comments: Dict[str, Optional[str]],
                     pk_map, fk_map) -> List[TableMeta]:
    metas: List[TableMeta] = []
    for t in OWNER_TABLES:
        cols = []
        for c in columns.get(t, []):
            is_pk = pk_map.get((t, c.name), False)
            fk_ref = fk_map.get((t, c.name))
            cols.append(Column(
                name=c.name, data_type=c.data_type, nullable=c.nullable,
                comment=c.comment, is_pk=is_pk, is_fk=bool(fk_ref), fk_ref=fk_ref
            ))
        metas.append(TableMeta(owner=owner, name=t, comment=comments.get(t), columns=cols))
    return metas

def fmt_columns(cols: List[Column]) -> List[str]:
    lines = []
    for c in cols:
        flags = []
        if c.is_pk: flags.append("PK")
        if c.is_fk and c.fk_ref:
            ro, rt, rc = c.fk_ref
            flags.append(f"FK→{ro}.{rt}({rc})")
        if not c.nullable: flags.append("NOT NULL")
        flag_str = f"  -- {', '.join(flags)}" if flags else ""
        comment = f"  -- {c.comment}" if (c.comment and not flag_str) else (f" | {c.comment}" if c.comment else "")
        lines.append(f"    - {c.name} {c.data_type}{flag_str}{comment}")
    return lines

def synthesize_joins() -> List[str]:
    # From your join rules (facts -> lookups)
    j = [
        "SDI ↔ SYMBOLS on (SYMBOL_DAILY_INDICATORS.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
        "SDI ↔ EXCHANGES on (SYMBOL_DAILY_INDICATORS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
        "SI  ↔ SYMBOLS on (SYMBOL_INDICATORS.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
        "SI  ↔ EXCHANGES on (SYMBOL_INDICATORS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
        "BM  ↔ SYMBOLS on (BEST_MKT.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
        "BM  ↔ EXCHANGES on (BEST_MKT.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
        "ORDERS ↔ SYMBOLS on (ORDERS.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
        "ORDERS ↔ EXCHANGES on (ORDERS.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
        "ORDERS ↔ SYMBOL_MARKETS on (ORDERS.SYMBOL_ID = SYMBOL_MARKETS.SYMBOL_ID AND "
        "ORDERS.MARKET_ID = SYMBOL_MARKETS.MARKET_ID AND ORDERS.EXCHANGE_ID = SYMBOL_MARKETS.EXCHANGE_ID)",
        "ORDERS ↔ FLAGS on (ORDERS.FLAG_ID = FLAGS.FLAG_ID)",
        "ORDERS ↔ ORDER_TYPES on (ORDERS.ORDER_TYPE = ORDER_TYPES.ID)",
        "ORDERS ↔ ORDER_STATES on (ORDERS.STATE = ORDER_STATES.STATE_ID)",
        "ORDERS ↔ SUBSCRIBED_BROKERS on (ORDERS.BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID)",
        "ORDERS ↔ EDS_CLIENTS on (ORDERS.CLIENT_ID = EDS_CLIENTS.CLIENT_ID)",
        "ORDERS ↔ USERS (as USER_ID) on (ORDERS.USER_ID = USERS.USER_ID)",
        "ORDERS ↔ USERS (as TRADER_ID) on (ORDERS.TRADER_ID = USERS.USER_ID)",
    ]
    # ----New---- TRADES joins (hard constraints + recommended)
    j += [
        "----New---- TRADES ↔ SYMBOLS on (TRADES.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
        "----New---- TRADES ↔ EXCHANGES on (TRADES.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
        "----New---- TRADES ↔ SYMBOL_MARKETS on (TRADES.SYMBOL_ID = SYMBOL_MARKETS.SYMBOL_ID AND "
        "TRADES.MARKET_ID = SYMBOL_MARKETS.MARKET_ID AND TRADES.EXCHANGE_ID = SYMBOL_MARKETS.EXCHANGE_ID)",
        "----New---- TRADES ↔ SUBSCRIBED_BROKERS (buyer) on (TRADES.BUYER_BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID)",
        "----New---- TRADES ↔ SUBSCRIBED_BROKERS (seller) on (TRADES.SELLER_BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID)",
        "----New---- TRADES ↔ EDS_CLIENTS (buyer) on (TRADES.BUYER_CLIENT_ID = EDS_CLIENTS.CLIENT_ID)",
        "----New---- TRADES ↔ EDS_CLIENTS (seller) on (TRADES.SELLER_CLIENT_ID = EDS_CLIENTS.CLIENT_ID)",
        "----New---- TRADES ↔ USERS (buyer) on (TRADES.BUYER_USER_ID = USERS.USER_ID)",
        "----New---- TRADES ↔ USERS (seller) on (TRADES.SELLER_USER_ID = USERS.USER_ID)",
        "----New---- TRADES ↔ SETTLEMENT_TYPES on (TRADES.SETTLEMENT_TYPE_ID = SETTLEMENT_TYPES.SETTLEMENT_TYPE_ID)",
        "----New---- TRADES ↔ TRADE_STATES on (TRADES.STATE_ID = TRADE_STATES.STATE_ID)",
    ]
    # ----New---- CANCELLED_TRADES joins (hard + soft guidance)
    j += [
        "----New---- CANCELLED_TRADES ↔ EXCHANGES on (CANCELLED_TRADES.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
        "----New---- CANCELLED_TRADES ↔ SYMBOLS on (CANCELLED_TRADES.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
        "----New---- CANCELLED_TRADES ↔ SUBSCRIBED_BROKERS (buyer/seller) on (…BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID)",
        "----New---- CANCELLED_TRADES ↔ EDS_CLIENTS (buyer/seller) on (…CLIENT_ID = EDS_CLIENTS.CLIENT_ID)",
        "----New---- [soft] CANCELLED_TRADES ↔ TRADES on ((BUYER_ORDER_NO, SELLER_ORDER_NO, EXCHANGE_ID) matching)",
    ]
    # ----New---- NEGOTIATED_TRADES joins (hard + soft guidance)
    j += [
        "----New---- NEGOTIATED_TRADES ↔ SYMBOLS on (NEGOTIATED_TRADES.SYMBOL_ID = SYMBOLS.SYMBOL_ID)",
        "----New---- NEGOTIATED_TRADES ↔ EXCHANGES on (NEGOTIATED_TRADES.EXCHANGE_ID = EXCHANGES.EXCHANGE_ID)",
        "----New---- NEGOTIATED_TRADES ↔ SUBSCRIBED_BROKERS (sides) on (…BROKER_ID = SUBSCRIBED_BROKERS.BROKER_ID)",
        "----New---- NEGOTIATED_TRADES ↔ EDS_CLIENTS (sides) on (…CLIENT_ID = EDS_CLIENTS.CLIENT_ID)",
        "----New---- [soft] NEGOTIATED_TRADES ↔ TRADES on (ORDER_NO/COUNTER_ORDER_NO ↔ BUYER_ORDER_NO/SELLER_ORDER_NO, same EXCHANGE_ID)",
    ]
    return j

def measures_block(table: str) -> Optional[str]:
    fx = CATALOG["facts"].get(table)
    if not fx:
        return None
    lines = []
    for mname, (col_or_expr, agg) in fx["measures"].items():
        if agg:
            if mname in ("orders", "trades", "cancellations", "negotiations") and col_or_expr == "*":
                lines.append(f"  - {mname}: COUNT(*)")
            else:
                lines.append(f"  - {mname}: {agg}({col_or_expr})")
        else:
            lines.append(f"  - {mname}: {col_or_expr}")
    # attach any notes for the fact
    notes = fx.get("notes") or []
    if notes:
        lines.append("  Notes:")
        for n in notes:
            lines.append(f"    • {n}")
    return "\n".join(lines)

def dimensions_block(table: str) -> Optional[str]:
    fx = CATALOG["facts"].get(table)
    if not fx:
        return None
    dims = fx.get("dimensions") or []
    if not dims:
        return None
    return "\n".join([f"  - {d}" for d in dims])

def write_card(path: str, owner: str, metas: List[TableMeta]) -> str:
    allowed_grains = ", ".join(CATALOG["notes"]["allowed_grains"])
    header = textwrap.dedent(f"""\
    # Schema Card — Oracle (owner: {owner})

    Scope: {', '.join([f'{owner}.{t}' for t in OWNER_TABLES])}
    Allowed grains: {allowed_grains}
    Safety: {CATALOG["notes"]["safety"]}

    Oracle helpers:
      - Date buckets: TRUNC(<date_col>, 'DD'|'MM'|'YYYY')
      - Range filter: col >= DATE 'YYYY-MM-DD' AND col < DATE 'YYYY-MM-DD'
      - Row limit: FETCH FIRST <N> ROWS ONLY  (fallback: WHERE ROWNUM <= N)
      - Percentiles: PERCENTILE_CONT(p) WITHIN GROUP (ORDER BY expr)
      - Median: MEDIAN(expr)
      - Window: LAG/LEAD, AVG(...) OVER (PARTITION BY ... ORDER BY ... ROWS BETWEEN ...)
      - ANSI JOINs only; no legacy (+) joins.

    Joins (preferred):
    """)
    joins = "\n".join([f"  - {j}" for j in synthesize_joins()])

    body_parts = []
    for tm in metas:
        fq = f"{tm.owner}.{tm.name}"
        fact = CATALOG["facts"].get(tm.name)
        grain = fact.get("grain") if fact else None
        date_key = fact.get("date_key") if fact else None

        # Mark new tables visibly in the header
        new_marker = " ----New----" if tm.name in {"TRADES", "CANCELLED_TRADES", "NEGOTIATED_TRADES", "TRADE_STATES", "SETTLEMENT_TYPES", "SYMBOL_TYPES"} else ""
        header_tbl = f"\n## {fq}{new_marker}" + (f"  (grain: {grain})" if grain else "")
        if tm.comment:
            header_tbl += f"\n-- {tm.comment}"

        cols_str = "\n".join(fmt_columns(tm.columns))

        measures = measures_block(tm.name)
        dims = dimensions_block(tm.name)
        measures_str = f"\n  Measures:\n{measures}" if measures else ""
        dims_str = f"\n  Dimensions:\n{dims}" if dims else ""
        date_str = f"\n  Date key: {date_key}" if date_key else ""

        body_parts.append(
            f"""{header_tbl}
  Columns:
{cols_str}{date_str}{dims_str}{measures_str}
"""
        )

    card = f"{header}\n{joins}\n" + "\n".join(body_parts)

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(card)

    return card

def main() -> None:
    load_dotenv()
    owner = env("ORACLE_OWNER")
    out_path = os.path.join("app", "prompts", "schema_card.txt")

    print("→ Connecting to Oracle…")
    conn = connect_oracle()
    try:
        with conn.cursor() as cur:
            print(f"→ Introspecting columns, keys, and comments for {owner}…")
            columns = fetch_columns(cur, owner)
            comments = fetch_table_comments(cur, owner)
            pk_map, fk_map = fetch_constraints(cur, owner)
            metas = build_table_meta(owner, columns, comments, pk_map, fk_map)

        print("→ Writing schema card…")
        card = write_card(out_path, owner, metas)

        # Show a short preview
        preview = "\n".join(card.splitlines()[:100])
        print("=== schema_card.txt (preview) ===")
        print(preview)
        print("… (truncated)")
        print(f"\nDone. Full card at: {out_path}")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
